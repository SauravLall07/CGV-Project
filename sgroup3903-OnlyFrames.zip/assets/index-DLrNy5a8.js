const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./DRACOLoader-RyA7e7Ou.js","./three.core-BiuZ-PTv.js","./moving-heist-C5spllfr.js","./chrono-field-8iQeXy3x.js","./timewreck-DcpguXFS.js"])))=>i.map(i=>d[i]);
import{$ as e,$n as t,$t as n,A as r,Ar as i,At as a,B as o,Bn as s,Br as c,Bt as l,C as u,Cr as d,Ct as f,D as p,Dr as m,Dt as h,E as g,Er as _,Et as v,F as y,Fr as b,Ft as x,G as S,Gn as C,Gt as w,H as T,Hr as E,Ht as D,I as O,Ir as k,It as A,Jt as j,K as ee,Kn as M,Kt as N,L as P,Ln as te,Lr as F,Lt as ne,M as re,Mr as I,Mt as L,N as ie,Nr as ae,Nt as oe,O as se,Or as R,Ot as z,P as ce,Pr as le,Pt as ue,Qn as de,R as fe,Rn as pe,Rr as me,Rt as he,S as ge,St as _e,T as ve,Tr as ye,Tt as B,U as be,Un as xe,Ur as V,Ut as Se,V as Ce,Vn as we,Vr as Te,Vt as Ee,W as De,Wn as Oe,Wr as H,X as ke,Xt as Ae,Y as U,Yt as je,Z as W,Zn as Me,Zt as Ne,_ as G,_r as Pe,_t as Fe,a as Ie,ar as Le,at as Re,b as ze,bt as Be,c as Ve,cr as He,ct as Ue,d as We,dr as Ge,dt as Ke,en as qe,er as Je,et as Ye,fr as Xe,ft as Ze,g as Qe,gr as $e,gt as et,h as tt,hr as nt,ht as rt,i as it,it as at,j as ot,jr as st,jt as ct,k as lt,kr as ut,kt as dt,l as K,lr as ft,lt as pt,m as mt,mr as ht,mt as gt,n as _t,nn as vt,nr as yt,o as bt,on as xt,or as St,ot as Ct,p as wt,pr as Tt,pt as Et,q as Dt,qt as Ot,r as kt,rr as At,rt as jt,s as Mt,sn as Nt,sr as Pt,st as Ft,tr as It,tt as Lt,u as Rt,ur as zt,ut as Bt,v as Vt,vr as Ht,vt as Ut,w as Wt,wr as Gt,wt as Kt,x as qt,xr as Jt,xt as Yt,y as q,yr as Xt,yt as Zt,z as Qt,zn as $t,zr as en,zt as tn}from"./three.core-BiuZ-PTv.js";(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),t.credentials=e.crossOrigin===`use-credentials`?`include`:e.crossOrigin===`anonymous`?`omit`:`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();function nn(){let e=null,t=!1,n=null,r=null;function i(t,a){n(t,a),r=e.requestAnimationFrame(i)}return{start:function(){t!==!0&&n!==null&&e!==null&&(r=e.requestAnimationFrame(i),t=!0)},stop:function(){e!==null&&e.cancelAnimationFrame(r),t=!1},setAnimationLoop:function(e){n=e},setContext:function(t){e=t}}}function rn(e){let t=new WeakMap;function n(t,n){let r=t.array,i=t.usage,a=r.byteLength,o=e.createBuffer();e.bindBuffer(n,o),e.bufferData(n,r,i),t.onUploadCallback();let s;if(r instanceof Float32Array)s=e.FLOAT;else if(typeof Float16Array<`u`&&r instanceof Float16Array)s=e.HALF_FLOAT;else if(r instanceof Uint16Array)s=t.isFloat16BufferAttribute?e.HALF_FLOAT:e.UNSIGNED_SHORT;else if(r instanceof Int16Array)s=e.SHORT;else if(r instanceof Uint32Array)s=e.UNSIGNED_INT;else if(r instanceof Int32Array)s=e.INT;else if(r instanceof Int8Array)s=e.BYTE;else if(r instanceof Uint8Array)s=e.UNSIGNED_BYTE;else if(r instanceof Uint8ClampedArray)s=e.UNSIGNED_BYTE;else throw Error(`THREE.WebGLAttributes: Unsupported buffer data format: `+r);return{buffer:o,type:s,bytesPerElement:r.BYTES_PER_ELEMENT,version:t.version,size:a}}function r(t,n,r){let i=n.array,a=n.updateRanges;if(e.bindBuffer(r,t),a.length===0)e.bufferSubData(r,0,i);else{a.sort((e,t)=>e.start-t.start);let t=0;for(let e=1;e<a.length;e++){let n=a[t],r=a[e];r.start<=n.start+n.count+1?n.count=Math.max(n.count,r.start+r.count-n.start):(++t,a[t]=r)}a.length=t+1;for(let t=0,n=a.length;t<n;t++){let n=a[t];e.bufferSubData(r,n.start*i.BYTES_PER_ELEMENT,i,n.start,n.count)}n.clearUpdateRanges()}n.onUploadCallback()}function i(e){return e.isInterleavedBufferAttribute&&(e=e.data),t.get(e)}function a(n){n.isInterleavedBufferAttribute&&(n=n.data);let r=t.get(n);r&&(e.deleteBuffer(r.buffer),t.delete(n))}function o(e,i){if(e.isInterleavedBufferAttribute&&(e=e.data),e.isGLBufferAttribute){let n=t.get(e);(!n||n.version<e.version)&&t.set(e,{buffer:e.buffer,type:e.type,bytesPerElement:e.elementSize,version:e.version});return}let a=t.get(e);if(a===void 0)t.set(e,n(e,i));else if(a.version<e.version){if(a.size!==e.array.byteLength)throw Error(`THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.`);r(a.buffer,e,i),a.version=e.version}}return{get:i,remove:a,update:o}}var an={alphahash_fragment:`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,alphahash_pars_fragment:`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,alphamap_fragment:`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,alphamap_pars_fragment:`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,alphatest_fragment:`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,alphatest_pars_fragment:`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,aomap_fragment:`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,aomap_pars_fragment:`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,batching_pars_vertex:`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec4 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 );
	}
#endif`,batching_vertex:`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,begin_vertex:`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,beginnormal_vertex:`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,bsdfs:`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,iridescence_fragment:`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,bumpmap_pars_fragment:`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,clipping_planes_fragment:`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,clipping_planes_pars_fragment:`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,clipping_planes_pars_vertex:`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,clipping_planes_vertex:`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,color_fragment:`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#endif`,color_pars_fragment:`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#endif`,color_pars_vertex:`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec4 vColor;
#endif`,color_vertex:`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec4( 1.0 );
#endif
#ifdef USE_COLOR_ALPHA
	vColor *= color;
#elif defined( USE_COLOR )
	vColor.rgb *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.rgb *= instanceColor.rgb;
#endif
#ifdef USE_BATCHING_COLOR
	vColor *= getBatchingColor( getIndirectIndex( gl_DrawID ) );
#endif`,common:`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
#define inverseTransformDirection transformDirectionByInverseViewMatrix
vec3 transformNormalByInverseViewMatrix( in vec3 normal, in mat4 viewMatrix ) {
	return normalize( ( vec4( normal, 0.0 ) * viewMatrix ).xyz );
}
vec3 transformDirectionByInverseViewMatrix( in vec3 dir, in mat4 viewMatrix ) {
	return normalize( ( vec4( dir, 0.0 ) * viewMatrix ).xyz );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,cube_uv_reflection_fragment:`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,defaultnormal_vertex:`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
#endif`,displacementmap_pars_vertex:`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,displacementmap_vertex:`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,emissivemap_fragment:`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,emissivemap_pars_fragment:`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,colorspace_fragment:`gl_FragColor = linearToOutputTexel( gl_FragColor );`,colorspace_pars_fragment:`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,envmap_fragment:`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * reflectVec );
		#ifdef ENVMAP_BLENDING_MULTIPLY
			outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_MIX )
			outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_ADD )
			outgoingLight += envColor.xyz * specularStrength * reflectivity;
		#endif
	#endif
#endif`,envmap_common_pars_fragment:`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
#endif`,envmap_pars_fragment:`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,envmap_pars_vertex:`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,envmap_physical_pars_fragment:`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, pow4( roughness ) ) );
			reflectVec = transformDirectionByInverseViewMatrix( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,envmap_vertex:`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,fog_vertex:`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,fog_pars_vertex:`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,fog_fragment:`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,fog_pars_fragment:`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,gradientmap_pars_fragment:`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,lightmap_pars_fragment:`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,lights_lambert_fragment:`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,lights_lambert_pars_fragment:`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,lights_pars_begin:`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif
#include <lightprobes_pars_fragment>`,lights_toon_fragment:`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,lights_toon_pars_fragment:`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,lights_phong_fragment:`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,lights_phong_pars_fragment:`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,lights_physical_fragment:`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.diffuseContribution = diffuseColor.rgb * ( 1.0 - metalnessFactor );
material.metalness = metalnessFactor;
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor;
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = vec3( 0.04 );
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.0001, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,lights_physical_pars_fragment:`uniform sampler2D dfgLUT;
struct PhysicalMaterial {
	vec3 diffuseColor;
	vec3 diffuseContribution;
	vec3 specularColor;
	vec3 specularColorBlended;
	float roughness;
	float metalness;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
		vec3 iridescenceFresnelDielectric;
		vec3 iridescenceFresnelMetallic;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		return 0.5 / max( gv + gl, EPSILON );
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColorBlended;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transpose( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float rInv = 1.0 / ( roughness + 0.1 );
	float a = -1.9362 + 1.0678 * roughness + 0.4573 * r2 - 0.8469 * rInv;
	float b = -0.6014 + 0.5538 * roughness - 0.4670 * r2 - 0.1255 * rInv;
	float DG = exp( a * dotNV + b );
	return saturate( DG );
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
vec3 BRDF_GGX_Multiscatter( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 singleScatter = BRDF_GGX( lightDir, viewDir, normal, material );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 dfgV = texture2D( dfgLUT, vec2( material.roughness, dotNV ) ).rg;
	vec2 dfgL = texture2D( dfgLUT, vec2( material.roughness, dotNL ) ).rg;
	vec3 FssEss_V = material.specularColorBlended * dfgV.x + material.specularF90 * dfgV.y;
	vec3 FssEss_L = material.specularColorBlended * dfgL.x + material.specularF90 * dfgL.y;
	float Ess_V = dfgV.x + dfgV.y;
	float Ess_L = dfgL.x + dfgL.y;
	float Ems_V = 1.0 - Ess_V;
	float Ems_L = 1.0 - Ess_L;
	vec3 Favg = material.specularColorBlended + ( 1.0 - material.specularColorBlended ) * 0.047619;
	vec3 Fms = FssEss_V * FssEss_L * Favg / ( 1.0 - Ems_V * Ems_L * Favg + EPSILON );
	float compensationFactor = Ems_V * Ems_L;
	vec3 multiScatter = Fms * compensationFactor;
	return singleScatter + multiScatter;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColorBlended * t2.x + ( material.specularF90 - material.specularColorBlended ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseContribution * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
		#ifdef USE_CLEARCOAT
			vec3 Ncc = geometryClearcoatNormal;
			vec2 uvClearcoat = LTC_Uv( Ncc, viewDir, material.clearcoatRoughness );
			vec4 t1Clearcoat = texture2D( ltc_1, uvClearcoat );
			vec4 t2Clearcoat = texture2D( ltc_2, uvClearcoat );
			mat3 mInvClearcoat = mat3(
				vec3( t1Clearcoat.x, 0, t1Clearcoat.y ),
				vec3(             0, 1,             0 ),
				vec3( t1Clearcoat.z, 0, t1Clearcoat.w )
			);
			vec3 fresnelClearcoat = material.clearcoatF0 * t2Clearcoat.x + ( material.clearcoatF90 - material.clearcoatF0 ) * t2Clearcoat.y;
			clearcoatSpecularDirect += lightColor * fresnelClearcoat * LTC_Evaluate( Ncc, viewDir, position, mInvClearcoat, rectCoords );
		#endif
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
 
 		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
 
 		float sheenAlbedoV = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
 		float sheenAlbedoL = IBLSheenBRDF( geometryNormal, directLight.direction, material.sheenRoughness );
 
 		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * max( sheenAlbedoV, sheenAlbedoL );
 
 		irradiance *= sheenEnergyComp;
 
 	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX_Multiscatter( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseContribution );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 diffuse = irradiance * BRDF_Lambert( material.diffuseContribution );
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		diffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectDiffuse += diffuse;
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness ) * RECIPROCAL_PI;
 	#endif
	vec3 singleScatteringDielectric = vec3( 0.0 );
	vec3 multiScatteringDielectric = vec3( 0.0 );
	vec3 singleScatteringMetallic = vec3( 0.0 );
	vec3 multiScatteringMetallic = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnelDielectric, material.roughness, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.diffuseColor, material.specularF90, material.iridescence, material.iridescenceFresnelMetallic, material.roughness, singleScatteringMetallic, multiScatteringMetallic );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscattering( geometryNormal, geometryViewDir, material.diffuseColor, material.specularF90, material.roughness, singleScatteringMetallic, multiScatteringMetallic );
	#endif
	vec3 singleScattering = mix( singleScatteringDielectric, singleScatteringMetallic, material.metalness );
	vec3 multiScattering = mix( multiScatteringDielectric, multiScatteringMetallic, material.metalness );
	vec3 totalScatteringDielectric = singleScatteringDielectric + multiScatteringDielectric;
	vec3 diffuse = material.diffuseContribution * ( 1.0 - totalScatteringDielectric );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	vec3 indirectSpecular = radiance * singleScattering;
	indirectSpecular += multiScattering * cosineWeightedIrradiance;
	vec3 indirectDiffuse = diffuse * cosineWeightedIrradiance;
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		indirectSpecular *= sheenEnergyComp;
		indirectDiffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectSpecular += indirectSpecular;
	reflectedLight.indirectDiffuse += indirectDiffuse;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,lights_fragment_begin:`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnelDielectric = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceFresnelMetallic = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.diffuseColor );
		material.iridescenceFresnel = mix( material.iridescenceFresnelDielectric, material.iridescenceFresnelMetallic, material.metalness );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS ) && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
	#ifdef USE_LIGHT_PROBES_GRID
		vec3 probeWorldPos = ( ( vec4( geometryPosition, 1.0 ) - viewMatrix[ 3 ] ) * viewMatrix ).xyz;
		vec3 probeWorldNormal = transformNormalByInverseViewMatrix( geometryNormal, viewMatrix );
		irradiance += getLightProbeGridIrradiance( probeWorldPos, probeWorldNormal );
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,lights_fragment_maps:`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( ENVMAP_TYPE_CUBE_UV )
		#if defined( STANDARD ) || defined( LAMBERT ) || defined( PHONG )
			iblIrradiance += getIBLIrradiance( geometryNormal );
		#endif
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,lights_fragment_end:`#if defined( RE_IndirectDiffuse )
	#if defined( LAMBERT ) || defined( PHONG )
		irradiance += iblIrradiance;
	#endif
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,lightprobes_pars_fragment:`#ifdef USE_LIGHT_PROBES_GRID
uniform highp sampler3D probesSH;
uniform vec3 probesMin;
uniform vec3 probesMax;
uniform vec3 probesResolution;
vec3 getLightProbeGridIrradiance( vec3 worldPos, vec3 worldNormal ) {
	vec3 res = probesResolution;
	vec3 gridRange = probesMax - probesMin;
	vec3 resMinusOne = res - 1.0;
	vec3 probeSpacing = gridRange / resMinusOne;
	vec3 samplePos = worldPos + worldNormal * probeSpacing * 0.5;
	vec3 uvw = clamp( ( samplePos - probesMin ) / gridRange, 0.0, 1.0 );
	uvw = uvw * resMinusOne / res + 0.5 / res;
	float nz          = res.z;
	float paddedSlices = nz + 2.0;
	float atlasDepth  = 7.0 * paddedSlices;
	float uvZBase     = uvw.z * nz + 1.0;
	vec4 s0 = texture( probesSH, vec3( uvw.xy, ( uvZBase                       ) / atlasDepth ) );
	vec4 s1 = texture( probesSH, vec3( uvw.xy, ( uvZBase +       paddedSlices   ) / atlasDepth ) );
	vec4 s2 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 2.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s3 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 3.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s4 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 4.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s5 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 5.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s6 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 6.0 * paddedSlices   ) / atlasDepth ) );
	vec3 c0 = s0.xyz;
	vec3 c1 = vec3( s0.w, s1.xy );
	vec3 c2 = vec3( s1.zw, s2.x );
	vec3 c3 = s2.yzw;
	vec3 c4 = s3.xyz;
	vec3 c5 = vec3( s3.w, s4.xy );
	vec3 c6 = vec3( s4.zw, s5.x );
	vec3 c7 = s5.yzw;
	vec3 c8 = s6.xyz;
	float x = worldNormal.x, y = worldNormal.y, z = worldNormal.z;
	vec3 result = c0 * 0.886227;
	result += c1 * 2.0 * 0.511664 * y;
	result += c2 * 2.0 * 0.511664 * z;
	result += c3 * 2.0 * 0.511664 * x;
	result += c4 * 2.0 * 0.429043 * x * y;
	result += c5 * 2.0 * 0.429043 * y * z;
	result += c6 * ( 0.743125 * z * z - 0.247708 );
	result += c7 * 2.0 * 0.429043 * x * z;
	result += c8 * 0.429043 * ( x * x - y * y );
	return max( result, vec3( 0.0 ) );
}
#endif`,logdepthbuf_fragment:`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,logdepthbuf_pars_fragment:`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,logdepthbuf_pars_vertex:`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,logdepthbuf_vertex:`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,map_fragment:`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,map_pars_fragment:`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,map_particle_fragment:`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,map_particle_pars_fragment:`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,metalnessmap_fragment:`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,metalnessmap_pars_fragment:`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,morphinstance_vertex:`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,morphcolor_vertex:`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,morphnormal_vertex:`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,morphtarget_pars_vertex:`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,morphtarget_vertex:`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,normal_fragment_begin:`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#ifdef DOUBLE_SIDED
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#ifdef DOUBLE_SIDED
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,normal_fragment_maps:`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#if defined( USE_PACKED_NORMALMAP )
		mapN = vec3( mapN.xy, sqrt( saturate( 1.0 - dot( mapN.xy, mapN.xy ) ) ) );
	#endif
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,normal_pars_fragment:`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,normal_pars_vertex:`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,normal_vertex:`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
		#ifdef FLIP_SIDED
			vBitangent = - vBitangent;
		#endif
	#endif
#endif`,normalmap_pars_fragment:`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,clearcoat_normal_fragment_begin:`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,clearcoat_normal_fragment_maps:`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,clearcoat_pars_fragment:`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,iridescence_pars_fragment:`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,opaque_fragment:`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,packing:`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	#ifdef USE_REVERSED_DEPTH_BUFFER
	
		return depth * ( far - near ) - far;
	#else
		return depth * ( near - far ) - near;
	#endif
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	
	#ifdef USE_REVERSED_DEPTH_BUFFER
		return ( near * far ) / ( ( near - far ) * depth - near );
	#else
		return ( near * far ) / ( ( far - near ) * depth - far );
	#endif
}`,premultiplied_alpha_fragment:`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,project_vertex:`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,dithering_fragment:`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,dithering_pars_fragment:`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,roughnessmap_fragment:`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,roughnessmap_pars_fragment:`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,shadowmap_pars_fragment:`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#else
			uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#endif
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#else
			uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#endif
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform samplerCubeShadow pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#elif defined( SHADOWMAP_TYPE_BASIC )
			uniform samplerCube pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#endif
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float interleavedGradientNoise( vec2 position ) {
			return fract( 52.9829189 * fract( dot( position, vec2( 0.06711056, 0.00583715 ) ) ) );
		}
		vec2 vogelDiskSample( int sampleIndex, int samplesCount, float phi ) {
			const float goldenAngle = 2.399963229728653;
			float r = sqrt( ( float( sampleIndex ) + 0.5 ) / float( samplesCount ) );
			float theta = float( sampleIndex ) * goldenAngle + phi;
			return vec2( cos( theta ), sin( theta ) ) * r;
		}
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float getShadow( sampler2DShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			shadowCoord.z += shadowBias;
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
				float radius = shadowRadius * texelSize.x;
				float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
				shadow = (
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 0, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 1, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 2, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 3, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 4, 5, phi ) * radius, shadowCoord.z ) )
				) * 0.2;
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#elif defined( SHADOWMAP_TYPE_VSM )
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 distribution = texture2D( shadowMap, shadowCoord.xy ).rg;
				float mean = distribution.x;
				float variance = distribution.y * distribution.y;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					float hard_shadow = step( mean, shadowCoord.z );
				#else
					float hard_shadow = step( shadowCoord.z, mean );
				#endif
				
				if ( hard_shadow == 1.0 ) {
					shadow = 1.0;
				} else {
					variance = max( variance, 0.0000001 );
					float d = shadowCoord.z - mean;
					float p_max = variance / ( variance + d * d );
					p_max = clamp( ( p_max - 0.3 ) / 0.65, 0.0, 1.0 );
					shadow = max( hard_shadow, p_max );
				}
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#else
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				float depth = texture2D( shadowMap, shadowCoord.xy ).r;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					shadow = step( depth, shadowCoord.z );
				#else
					shadow = step( shadowCoord.z, depth );
				#endif
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	#if defined( SHADOWMAP_TYPE_PCF )
	float getPointShadow( samplerCubeShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 bd3D = normalize( lightToPosition );
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			#ifdef USE_REVERSED_DEPTH_BUFFER
				float dp = ( shadowCameraNear * ( shadowCameraFar - viewSpaceZ ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp -= shadowBias;
			#else
				float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp += shadowBias;
			#endif
			float texelSize = shadowRadius / shadowMapSize.x;
			vec3 absDir = abs( bd3D );
			vec3 tangent = absDir.x > absDir.z ? vec3( 0.0, 1.0, 0.0 ) : vec3( 1.0, 0.0, 0.0 );
			tangent = normalize( cross( bd3D, tangent ) );
			vec3 bitangent = cross( bd3D, tangent );
			float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
			vec2 sample0 = vogelDiskSample( 0, 5, phi );
			vec2 sample1 = vogelDiskSample( 1, 5, phi );
			vec2 sample2 = vogelDiskSample( 2, 5, phi );
			vec2 sample3 = vogelDiskSample( 3, 5, phi );
			vec2 sample4 = vogelDiskSample( 4, 5, phi );
			shadow = (
				texture( shadowMap, vec4( bd3D + ( tangent * sample0.x + bitangent * sample0.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample1.x + bitangent * sample1.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample2.x + bitangent * sample2.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample3.x + bitangent * sample3.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample4.x + bitangent * sample4.y ) * texelSize, dp ) )
			) * 0.2;
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#elif defined( SHADOWMAP_TYPE_BASIC )
	float getPointShadow( samplerCube shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			float depth = textureCube( shadowMap, bd3D ).r;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				depth = 1.0 - depth;
			#endif
			shadow = step( dp, depth );
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#endif
	#endif
#endif`,shadowmap_pars_vertex:`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,shadowmap_vertex:`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	#ifdef HAS_NORMAL
		vec3 shadowWorldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
	#else
		vec3 shadowWorldNormal = vec3( 0.0 );
	#endif
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,shadowmask_pars_fragment:`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0 && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,skinbase_vertex:`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,skinning_pars_vertex:`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,skinning_vertex:`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,skinnormal_vertex:`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,specularmap_fragment:`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,specularmap_pars_fragment:`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,tonemapping_fragment:`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,tonemapping_pars_fragment:`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,transmission_fragment:`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseContribution, material.specularColorBlended, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,transmission_pars_fragment:`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,uv_pars_fragment:`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,uv_pars_vertex:`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,uv_vertex:`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,worldpos_vertex:`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`,background_vert:`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,background_frag:`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,backgroundCube_vert:`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,backgroundCube_frag:`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vWorldDirection );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,cube_vert:`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,cube_frag:`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,depth_vert:`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,depth_frag:`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,distance_vert:`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,distance_frag:`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = vec4( dist, 0.0, 0.0, 1.0 );
}`,equirect_vert:`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,equirect_frag:`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,linedashed_vert:`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,linedashed_frag:`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,meshbasic_vert:`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,meshbasic_frag:`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshlambert_vert:`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,meshlambert_frag:`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshmatcap_vert:`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,meshmatcap_frag:`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshnormal_vert:`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,meshnormal_frag:`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( normalize( normal ) * 0.5 + 0.5, diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,meshphong_vert:`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,meshphong_frag:`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshphysical_vert:`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,meshphysical_frag:`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
 
		outgoingLight = outgoingLight + sheenSpecularDirect + sheenSpecularIndirect;
 
 	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshtoon_vert:`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,meshtoon_frag:`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,points_vert:`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,points_frag:`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,shadow_vert:`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,shadow_frag:`uniform vec3 color;
uniform float opacity;
#include <common>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,sprite_vert:`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,sprite_frag:`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`},J={common:{diffuse:{value:new q(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new v},alphaMap:{value:null},alphaMapTransform:{value:new v},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new v}},envmap:{envMap:{value:null},envMapRotation:{value:new v},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98},dfgLUT:{value:null}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new v}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new v}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new v},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new v},normalScale:{value:new m(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new v},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new v}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new v}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new v}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new q(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null},probesSH:{value:null},probesMin:{value:new R},probesMax:{value:new R},probesResolution:{value:new R}},points:{diffuse:{value:new q(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new v},alphaTest:{value:0},uvTransform:{value:new v}},sprite:{diffuse:{value:new q(16777215)},opacity:{value:1},center:{value:new m(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new v},alphaMap:{value:null},alphaMapTransform:{value:new v},alphaTest:{value:0}}},on={basic:{uniforms:Te([J.common,J.specularmap,J.envmap,J.aomap,J.lightmap,J.fog]),vertexShader:an.meshbasic_vert,fragmentShader:an.meshbasic_frag},lambert:{uniforms:Te([J.common,J.specularmap,J.envmap,J.aomap,J.lightmap,J.emissivemap,J.bumpmap,J.normalmap,J.displacementmap,J.fog,J.lights,{emissive:{value:new q(0)},envMapIntensity:{value:1}}]),vertexShader:an.meshlambert_vert,fragmentShader:an.meshlambert_frag},phong:{uniforms:Te([J.common,J.specularmap,J.envmap,J.aomap,J.lightmap,J.emissivemap,J.bumpmap,J.normalmap,J.displacementmap,J.fog,J.lights,{emissive:{value:new q(0)},specular:{value:new q(1118481)},shininess:{value:30},envMapIntensity:{value:1}}]),vertexShader:an.meshphong_vert,fragmentShader:an.meshphong_frag},standard:{uniforms:Te([J.common,J.envmap,J.aomap,J.lightmap,J.emissivemap,J.bumpmap,J.normalmap,J.displacementmap,J.roughnessmap,J.metalnessmap,J.fog,J.lights,{emissive:{value:new q(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:an.meshphysical_vert,fragmentShader:an.meshphysical_frag},toon:{uniforms:Te([J.common,J.aomap,J.lightmap,J.emissivemap,J.bumpmap,J.normalmap,J.displacementmap,J.gradientmap,J.fog,J.lights,{emissive:{value:new q(0)}}]),vertexShader:an.meshtoon_vert,fragmentShader:an.meshtoon_frag},matcap:{uniforms:Te([J.common,J.bumpmap,J.normalmap,J.displacementmap,J.fog,{matcap:{value:null}}]),vertexShader:an.meshmatcap_vert,fragmentShader:an.meshmatcap_frag},points:{uniforms:Te([J.points,J.fog]),vertexShader:an.points_vert,fragmentShader:an.points_frag},dashed:{uniforms:Te([J.common,J.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:an.linedashed_vert,fragmentShader:an.linedashed_frag},depth:{uniforms:Te([J.common,J.displacementmap]),vertexShader:an.depth_vert,fragmentShader:an.depth_frag},normal:{uniforms:Te([J.common,J.bumpmap,J.normalmap,J.displacementmap,{opacity:{value:1}}]),vertexShader:an.meshnormal_vert,fragmentShader:an.meshnormal_frag},sprite:{uniforms:Te([J.sprite,J.fog]),vertexShader:an.sprite_vert,fragmentShader:an.sprite_frag},background:{uniforms:{uvTransform:{value:new v},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:an.background_vert,fragmentShader:an.background_frag},backgroundCube:{uniforms:{envMap:{value:null},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new v}},vertexShader:an.backgroundCube_vert,fragmentShader:an.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:an.cube_vert,fragmentShader:an.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:an.equirect_vert,fragmentShader:an.equirect_frag},distance:{uniforms:Te([J.common,J.displacementmap,{referencePosition:{value:new R},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:an.distance_vert,fragmentShader:an.distance_frag},shadow:{uniforms:Te([J.lights,J.fog,{color:{value:new q(0)},opacity:{value:1}}]),vertexShader:an.shadow_vert,fragmentShader:an.shadow_frag}};on.physical={uniforms:Te([on.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new v},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new v},clearcoatNormalScale:{value:new m(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new v},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new v},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new v},sheen:{value:0},sheenColor:{value:new q(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new v},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new v},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new v},transmissionSamplerSize:{value:new m},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new v},attenuationDistance:{value:0},attenuationColor:{value:new q(0)},specularColor:{value:new q(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new v},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new v},anisotropyVector:{value:new m},anisotropyMap:{value:null},anisotropyMapTransform:{value:new v}}]),vertexShader:an.meshphysical_vert,fragmentShader:an.meshphysical_frag};var sn={r:0,b:0,g:0},cn=new h,ln=new v;ln.set(-1,0,0,0,1,0,0,0,1);function un(e,t,n,r,i,a){let o=new q(0),s=i===!0?0:1,c,l,u=null,d=0,f=null;function p(e){let n=e.isScene===!0?e.background:null;if(n&&n.isTexture){let r=e.backgroundBlurriness>0;n=t.get(n,r)}return n}function m(t){let r=!1,i=p(t);i===null?g(o,s):i&&i.isColor&&(g(i,1),r=!0);let c=e.xr.getEnvironmentBlendMode();c===`additive`?n.buffers.color.setClear(0,0,0,1,a):c===`alpha-blend`&&n.buffers.color.setClear(0,0,0,0,a),(e.autoClear||r)&&(n.buffers.depth.setTest(!0),n.buffers.depth.setMask(!0),n.buffers.color.setMask(!0),e.clear(e.autoClearColor,e.autoClearDepth,e.autoClearStencil))}function h(t,n){let i=p(n);i&&(i.isCubeTexture||i.mapping===306)?(l===void 0&&(l=new z(new K(1,1,1),new Je({name:`BackgroundCubeMaterial`,uniforms:le(on.backgroundCube.uniforms),vertexShader:on.backgroundCube.vertexShader,fragmentShader:on.backgroundCube.fragmentShader,side:1,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),l.geometry.deleteAttribute(`normal`),l.geometry.deleteAttribute(`uv`),l.onBeforeRender=function(e,t,n){this.matrixWorld.copyPosition(n.matrixWorld)},Object.defineProperty(l.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),r.update(l)),l.material.uniforms.envMap.value=i,l.material.uniforms.backgroundBlurriness.value=n.backgroundBlurriness,l.material.uniforms.backgroundIntensity.value=n.backgroundIntensity,l.material.uniforms.backgroundRotation.value.setFromMatrix4(cn.makeRotationFromEuler(n.backgroundRotation)).transpose(),i.isCubeTexture&&i.isRenderTargetTexture===!1&&l.material.uniforms.backgroundRotation.value.premultiply(ln),l.material.toneMapped=ze.getTransfer(i.colorSpace)!==de,(u!==i||d!==i.version||f!==e.toneMapping)&&(l.material.needsUpdate=!0,u=i,d=i.version,f=e.toneMapping),l.layers.enableAll(),t.unshift(l,l.geometry,l.material,0,0,null)):i&&i.isTexture&&(c===void 0&&(c=new z(new Ot(2,2),new Je({name:`BackgroundMaterial`,uniforms:le(on.background.uniforms),vertexShader:on.background.vertexShader,fragmentShader:on.background.fragmentShader,side:0,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),c.geometry.deleteAttribute(`normal`),Object.defineProperty(c.material,"map",{get:function(){return this.uniforms.t2D.value}}),r.update(c)),c.material.uniforms.t2D.value=i,c.material.uniforms.backgroundIntensity.value=n.backgroundIntensity,c.material.toneMapped=ze.getTransfer(i.colorSpace)!==de,i.matrixAutoUpdate===!0&&i.updateMatrix(),c.material.uniforms.uvTransform.value.copy(i.matrix),(u!==i||d!==i.version||f!==e.toneMapping)&&(c.material.needsUpdate=!0,u=i,d=i.version,f=e.toneMapping),c.layers.enableAll(),t.unshift(c,c.geometry,c.material,0,0,null))}function g(t,r){t.getRGB(sn,en(e)),n.buffers.color.setClear(sn.r,sn.g,sn.b,r,a)}function _(){l!==void 0&&(l.geometry.dispose(),l.material.dispose(),l=void 0),c!==void 0&&(c.geometry.dispose(),c.material.dispose(),c=void 0)}return{getClearColor:function(){return o},setClearColor:function(e,t=1){o.set(e),s=t,g(o,s)},getClearAlpha:function(){return s},setClearAlpha:function(e){s=e,g(o,s)},render:m,addToRenderList:h,dispose:_}}function dn(e,t){let n=e.getParameter(e.MAX_VERTEX_ATTRIBS),r={},i=f(null),a=i,o=!1;function s(n,r,i,s,c){let u=!1,f=d(n,s,i,r);a!==f&&(a=f,l(a.object)),u=p(n,s,i,c),u&&m(n,s,i,c),c!==null&&t.update(c,e.ELEMENT_ARRAY_BUFFER),(u||o)&&(o=!1,b(n,r,i,s),c!==null&&e.bindBuffer(e.ELEMENT_ARRAY_BUFFER,t.get(c).buffer))}function c(){return e.createVertexArray()}function l(t){return e.bindVertexArray(t)}function u(t){return e.deleteVertexArray(t)}function d(e,t,n,i){let a=i.wireframe===!0,o=r[t.id];o===void 0&&(o={},r[t.id]=o);let s=e.isInstancedMesh===!0?e.id:0,l=o[s];l===void 0&&(l={},o[s]=l);let u=l[n.id];u===void 0&&(u={},l[n.id]=u);let d=u[a];return d===void 0&&(d=f(c()),u[a]=d),d}function f(e){let t=[],r=[],i=[];for(let e=0;e<n;e++)t[e]=0,r[e]=0,i[e]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:t,enabledAttributes:r,attributeDivisors:i,object:e,attributes:{},index:null}}function p(e,t,n,r){let i=a.attributes,o=t.attributes,s=0,c=n.getAttributes();for(let t in c)if(c[t].location>=0){let n=i[t],r=o[t];if(r===void 0&&(t===`instanceMatrix`&&e.instanceMatrix&&(r=e.instanceMatrix),t===`instanceColor`&&e.instanceColor&&(r=e.instanceColor)),n===void 0||n.attribute!==r||r&&n.data!==r.data)return!0;s++}return a.attributesNum!==s||a.index!==r}function m(e,t,n,r){let i={},o=t.attributes,s=0,c=n.getAttributes();for(let t in c)if(c[t].location>=0){let n=o[t];n===void 0&&(t===`instanceMatrix`&&e.instanceMatrix&&(n=e.instanceMatrix),t===`instanceColor`&&e.instanceColor&&(n=e.instanceColor));let r={};r.attribute=n,n&&n.data&&(r.data=n.data),i[t]=r,s++}a.attributes=i,a.attributesNum=s,a.index=r}function h(){let e=a.newAttributes;for(let t=0,n=e.length;t<n;t++)e[t]=0}function g(e){_(e,0)}function _(t,n){let r=a.newAttributes,i=a.enabledAttributes,o=a.attributeDivisors;r[t]=1,i[t]===0&&(e.enableVertexAttribArray(t),i[t]=1),o[t]!==n&&(e.vertexAttribDivisor(t,n),o[t]=n)}function v(){let t=a.newAttributes,n=a.enabledAttributes;for(let r=0,i=n.length;r<i;r++)n[r]!==t[r]&&(e.disableVertexAttribArray(r),n[r]=0)}function y(t,n,r,i,a,o,s){s===!0?e.vertexAttribIPointer(t,n,r,a,o):e.vertexAttribPointer(t,n,r,i,a,o)}function b(n,r,i,a){h();let o=a.attributes,s=i.getAttributes(),c=r.defaultAttributeValues;for(let r in s){let i=s[r];if(i.location>=0){let s=o[r];if(s===void 0&&(r===`instanceMatrix`&&n.instanceMatrix&&(s=n.instanceMatrix),r===`instanceColor`&&n.instanceColor&&(s=n.instanceColor)),s!==void 0){let r=s.normalized,o=s.itemSize,c=t.get(s);if(c===void 0)continue;let l=c.buffer,u=c.type,d=c.bytesPerElement,f=u===e.INT||u===e.UNSIGNED_INT||s.gpuType===1013;if(s.isInterleavedBufferAttribute){let t=s.data,c=t.stride,p=s.offset;if(t.isInstancedInterleavedBuffer){for(let e=0;e<i.locationSize;e++)_(i.location+e,t.meshPerAttribute);n.isInstancedMesh!==!0&&a._maxInstanceCount===void 0&&(a._maxInstanceCount=t.meshPerAttribute*t.count)}else for(let e=0;e<i.locationSize;e++)g(i.location+e);e.bindBuffer(e.ARRAY_BUFFER,l);for(let e=0;e<i.locationSize;e++)y(i.location+e,o/i.locationSize,u,r,c*d,(p+o/i.locationSize*e)*d,f)}else{if(s.isInstancedBufferAttribute){for(let e=0;e<i.locationSize;e++)_(i.location+e,s.meshPerAttribute);n.isInstancedMesh!==!0&&a._maxInstanceCount===void 0&&(a._maxInstanceCount=s.meshPerAttribute*s.count)}else for(let e=0;e<i.locationSize;e++)g(i.location+e);e.bindBuffer(e.ARRAY_BUFFER,l);for(let e=0;e<i.locationSize;e++)y(i.location+e,o/i.locationSize,u,r,o*d,o/i.locationSize*e*d,f)}}else if(c!==void 0){let t=c[r];if(t!==void 0)switch(t.length){case 2:e.vertexAttrib2fv(i.location,t);break;case 3:e.vertexAttrib3fv(i.location,t);break;case 4:e.vertexAttrib4fv(i.location,t);break;default:e.vertexAttrib1fv(i.location,t)}}}}v()}function x(){T();for(let e in r){let t=r[e];for(let e in t){let n=t[e];for(let e in n){let t=n[e];for(let e in t)u(t[e].object),delete t[e];delete n[e]}}delete r[e]}}function S(e){if(r[e.id]===void 0)return;let t=r[e.id];for(let e in t){let n=t[e];for(let e in n){let t=n[e];for(let e in t)u(t[e].object),delete t[e];delete n[e]}}delete r[e.id]}function C(e){for(let t in r){let n=r[t];for(let t in n){let r=n[t];if(r[e.id]===void 0)continue;let i=r[e.id];for(let e in i)u(i[e].object),delete i[e];delete r[e.id]}}}function w(e){for(let t in r){let n=r[t],i=e.isInstancedMesh===!0?e.id:0,a=n[i];if(a!==void 0){for(let e in a){let t=a[e];for(let e in t)u(t[e].object),delete t[e];delete a[e]}delete n[i],Object.keys(n).length===0&&delete r[t]}}}function T(){E(),o=!0,a!==i&&(a=i,l(a.object))}function E(){i.geometry=null,i.program=null,i.wireframe=!1}return{setup:s,reset:T,resetDefaultState:E,dispose:x,releaseStatesOfGeometry:S,releaseStatesOfObject:w,releaseStatesOfProgram:C,initAttributes:h,enableAttribute:g,disableUnusedAttributes:v}}function fn(e,t,n){let r;function i(e){r=e}function a(t,i){e.drawArrays(r,t,i),n.update(i,r,1)}function o(t,i,a){a!==0&&(e.drawArraysInstanced(r,t,i,a),n.update(i,r,a))}function s(e,i,a){if(a===0)return;t.get(`WEBGL_multi_draw`).multiDrawArraysWEBGL(r,e,0,i,0,a);let o=0;for(let e=0;e<a;e++)o+=i[e];n.update(o,r,1)}this.setMode=i,this.render=a,this.renderInstances=o,this.renderMultiDraw=s}function pn(e,t,n,r){let i;function a(){if(i!==void 0)return i;if(t.has(`EXT_texture_filter_anisotropic`)===!0){let n=t.get(`EXT_texture_filter_anisotropic`);i=e.getParameter(n.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else i=0;return i}function o(t){return t===1023||r.convert(t)===e.getParameter(e.IMPLEMENTATION_COLOR_READ_FORMAT)}function s(n){let i=n===1016&&(t.has(`EXT_color_buffer_half_float`)||t.has(`EXT_color_buffer_float`));return!(n!==1009&&r.convert(n)!==e.getParameter(e.IMPLEMENTATION_COLOR_READ_TYPE)&&n!==1015&&!i)}function c(t){if(t===`highp`){if(e.getShaderPrecisionFormat(e.VERTEX_SHADER,e.HIGH_FLOAT).precision>0&&e.getShaderPrecisionFormat(e.FRAGMENT_SHADER,e.HIGH_FLOAT).precision>0)return`highp`;t=`mediump`}return t===`mediump`&&e.getShaderPrecisionFormat(e.VERTEX_SHADER,e.MEDIUM_FLOAT).precision>0&&e.getShaderPrecisionFormat(e.FRAGMENT_SHADER,e.MEDIUM_FLOAT).precision>0?`mediump`:`lowp`}let l=n.precision===void 0?`highp`:n.precision,u=c(l);u!==l&&(V(`WebGLRenderer:`,l,`not supported, using`,u,`instead.`),l=u);let d=n.logarithmicDepthBuffer===!0,f=n.reversedDepthBuffer===!0&&t.has(`EXT_clip_control`);n.reversedDepthBuffer===!0&&f===!1&&V(`WebGLRenderer: Unable to use reversed depth buffer due to missing EXT_clip_control extension. Fallback to default depth buffer.`);let p=e.getParameter(e.MAX_TEXTURE_IMAGE_UNITS),m=e.getParameter(e.MAX_VERTEX_TEXTURE_IMAGE_UNITS),h=e.getParameter(e.MAX_TEXTURE_SIZE),g=e.getParameter(e.MAX_CUBE_MAP_TEXTURE_SIZE),_=e.getParameter(e.MAX_VERTEX_ATTRIBS),v=e.getParameter(e.MAX_VERTEX_UNIFORM_VECTORS),y=e.getParameter(e.MAX_VARYING_VECTORS),b=e.getParameter(e.MAX_FRAGMENT_UNIFORM_VECTORS),x=e.getParameter(e.MAX_SAMPLES),S=e.getParameter(e.SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:a,getMaxPrecision:c,textureFormatReadable:o,textureTypeReadable:s,precision:l,logarithmicDepthBuffer:d,reversedDepthBuffer:f,maxTextures:p,maxVertexTextures:m,maxTextureSize:h,maxCubemapSize:g,maxAttributes:_,maxVertexUniforms:v,maxVaryings:y,maxFragmentUniforms:b,maxSamples:x,samples:S}}function mn(e){let t=this,n=null,r=0,i=!1,a=!1,o=new N,s=new v,c={value:null,needsUpdate:!1};this.uniform=c,this.numPlanes=0,this.numIntersection=0,this.init=function(e,t){let n=e.length!==0||t||r!==0||i;return i=t,r=e.length,n},this.beginShadows=function(){a=!0,u(null)},this.endShadows=function(){a=!1},this.setGlobalState=function(e,t){n=u(e,t,0)},this.setState=function(t,o,s){let d=t.clippingPlanes,f=t.clipIntersection,p=t.clipShadows,m=e.get(t);if(!i||d===null||d.length===0||a&&!p)a?u(null):l();else{let e=a?0:r,t=e*4,i=m.clippingState||null;c.value=i,i=u(d,o,t,s);for(let e=0;e!==t;++e)i[e]=n[e];m.clippingState=i,this.numIntersection=f?this.numPlanes:0,this.numPlanes+=e}};function l(){c.value!==n&&(c.value=n,c.needsUpdate=r>0),t.numPlanes=r,t.numIntersection=0}function u(e,n,r,i){let a=e===null?0:e.length,l=null;if(a!==0){if(l=c.value,i!==!0||l===null){let t=r+a*4,i=n.matrixWorldInverse;s.getNormalMatrix(i),(l===null||l.length<t)&&(l=new Float32Array(t));for(let t=0,n=r;t!==a;++t,n+=4)o.copy(e[t]).applyMatrix4(i,s),o.normal.toArray(l,n),l[n+3]=o.constant}c.value=l,c.needsUpdate=!0}return t.numPlanes=a,t.numIntersection=0,l}}var hn=4,gn=[.125,.215,.35,.446,.526,.582],_n=20,vn=256,yn=new Se,bn=new q,xn=null,Sn=0,Cn=0,wn=!1,Tn=new R,En=class{constructor(e){this._renderer=e,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._sizeLods=[],this._sigmas=[],this._lodMeshes=[],this._backgroundBox=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._blurMaterial=null,this._ggxMaterial=null}fromScene(e,t=0,n=.1,r=100,i={}){let{size:a=256,position:o=Tn}=i;xn=this._renderer.getRenderTarget(),Sn=this._renderer.getActiveCubeFace(),Cn=this._renderer.getActiveMipmapLevel(),wn=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(a);let s=this._allocateTargets();return s.depthBuffer=!0,this._sceneToCubeUV(e,n,r,s,o),t>0&&this._blur(s,0,0,t),this._applyPMREM(s),this._cleanup(s),s}fromEquirectangular(e,t=null){return this._fromTexture(e,t)}fromCubemap(e,t=null){return this._fromTexture(e,t)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=Nn(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=Mn(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose(),this._backgroundBox!==null&&(this._backgroundBox.geometry.dispose(),this._backgroundBox.material.dispose())}_setSize(e){this._lodMax=Math.floor(Math.log2(e)),this._cubeSize=2**this._lodMax}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._ggxMaterial!==null&&this._ggxMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let e=0;e<this._lodMeshes.length;e++)this._lodMeshes[e].geometry.dispose()}_cleanup(e){this._renderer.setRenderTarget(xn,Sn,Cn),this._renderer.xr.enabled=wn,e.scissorTest=!1,kn(e,0,0,e.width,e.height)}_fromTexture(e,t){e.mapping===301||e.mapping===302?this._setSize(e.image.length===0?16:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4),xn=this._renderer.getRenderTarget(),Sn=this._renderer.getActiveCubeFace(),Cn=this._renderer.getActiveMipmapLevel(),wn=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;let n=t||this._allocateTargets();return this._textureToCubeUV(e,n),this._applyPMREM(n),this._cleanup(n),n}_allocateTargets(){let e=3*Math.max(this._cubeSize,112),t=4*this._cubeSize,n={magFilter:gt,minFilter:gt,generateMipmaps:!1,type:ke,format:xt,colorSpace:Fe,depthBuffer:!1},r=On(e,t,n);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==e||this._pingPongRenderTarget.height!==t){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=On(e,t,n);let{_lodMax:r}=this;({lodMeshes:this._lodMeshes,sizeLods:this._sizeLods,sigmas:this._sigmas}=Dn(r)),this._blurMaterial=jn(r,e,t),this._ggxMaterial=An(r,e,t)}return r}_compileMaterial(e){let t=new z(new We,e);this._renderer.compile(t,yn)}_sceneToCubeUV(e,t,n,r,i){let a=new w(90,1,t,n),o=[1,-1,1,1,1,1],s=[1,1,1,-1,-1,-1],c=this._renderer,l=c.autoClear,u=c.toneMapping;c.getClearColor(bn),c.toneMapping=0,c.autoClear=!1,c.state.buffers.depth.getReversed()&&(c.setRenderTarget(r),c.clearDepth(),c.setRenderTarget(null)),this._backgroundBox===null&&(this._backgroundBox=new z(new K,new dt({name:`PMREM.Background`,side:1,depthWrite:!1,depthTest:!1})));let d=this._backgroundBox,f=d.material,p=!1,m=e.background;m?m.isColor&&(f.color.copy(m),e.background=null,p=!0):(f.color.copy(bn),p=!0);for(let t=0;t<6;t++){let n=t%3;n===0?(a.up.set(0,o[t],0),a.position.set(i.x,i.y,i.z),a.lookAt(i.x+s[t],i.y,i.z)):n===1?(a.up.set(0,0,o[t]),a.position.set(i.x,i.y,i.z),a.lookAt(i.x,i.y+s[t],i.z)):(a.up.set(0,o[t],0),a.position.set(i.x,i.y,i.z),a.lookAt(i.x,i.y,i.z+s[t]));let l=this._cubeSize;kn(r,n*l,t>2?l:0,l,l),c.setRenderTarget(r),p&&c.render(d,a),c.render(e,a)}c.toneMapping=u,c.autoClear=l,e.background=m}_textureToCubeUV(e,t){let n=this._renderer,r=e.mapping===301||e.mapping===302;r?(this._cubemapMaterial===null&&(this._cubemapMaterial=Nn()),this._cubemapMaterial.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=Mn());let i=r?this._cubemapMaterial:this._equirectMaterial,a=this._lodMeshes[0];a.material=i;let o=i.uniforms;o.envMap.value=e;let s=this._cubeSize;kn(t,0,0,3*s,2*s),n.setRenderTarget(t),n.render(a,yn)}_applyPMREM(e){let t=this._renderer,n=t.autoClear;t.autoClear=!1;let r=this._lodMeshes.length;for(let t=1;t<r;t++)this._applyGGXFilter(e,t-1,t);t.autoClear=n}_applyGGXFilter(e,t,n){let r=this._renderer,i=this._pingPongRenderTarget,a=this._ggxMaterial,o=this._lodMeshes[n];o.material=a;let s=a.uniforms,c=n/(this._lodMeshes.length-1),l=t/(this._lodMeshes.length-1),u=Math.sqrt(c*c-l*l)*(0+c*1.25),{_lodMax:d}=this,f=this._sizeLods[n],p=3*f*(n>d-hn?n-d+hn:0),m=4*(this._cubeSize-f);s.envMap.value=e.texture,s.roughness.value=u,s.mipInt.value=d-t,kn(i,p,m,3*f,2*f),r.setRenderTarget(i),r.render(o,yn),s.envMap.value=i.texture,s.roughness.value=0,s.mipInt.value=d-n,kn(e,p,m,3*f,2*f),r.setRenderTarget(e),r.render(o,yn)}_blur(e,t,n,r,i){let a=this._pingPongRenderTarget;this._halfBlur(e,a,t,n,r,`latitudinal`,i),this._halfBlur(a,e,n,n,r,`longitudinal`,i)}_halfBlur(e,t,n,r,i,a,o){let s=this._renderer,c=this._blurMaterial;a!==`latitudinal`&&a!==`longitudinal`&&F(`blur direction must be either latitudinal or longitudinal!`);let l=this._lodMeshes[r];l.material=c;let u=c.uniforms,d=this._sizeLods[n]-1,f=isFinite(i)?Math.PI/(2*d):2*Math.PI/39,p=i/f,m=isFinite(i)?1+Math.floor(3*p):_n;m>_n&&V(`sigmaRadians, ${i}, is too large and will clip, as it requested ${m} samples when the maximum is set to ${_n}`);let h=[],g=0;for(let e=0;e<_n;++e){let t=e/p,n=Math.exp(-t*t/2);h.push(n),e===0?g+=n:e<m&&(g+=2*n)}for(let e=0;e<h.length;e++)h[e]=h[e]/g;u.envMap.value=e.texture,u.samples.value=m,u.weights.value=h,u.latitudinal.value=a===`latitudinal`,o&&(u.poleAxis.value=o);let{_lodMax:_}=this;u.dTheta.value=f,u.mipInt.value=_-n;let v=this._sizeLods[r];kn(t,3*v*(r>_-hn?r-_+hn:0),4*(this._cubeSize-v),3*v,2*v),s.setRenderTarget(t),s.render(l,yn)}};function Dn(e){let t=[],n=[],r=[],i=e,a=e-hn+1+gn.length;for(let o=0;o<a;o++){let a=2**i;t.push(a);let s=1/a;o>e-hn?s=gn[o-e+hn-1]:o===0&&(s=0),n.push(s);let c=1/(a-2),l=-c,u=1+c,d=[l,l,u,l,u,u,l,l,u,u,l,u],f=new Float32Array(108),p=new Float32Array(72),m=new Float32Array(36);for(let e=0;e<6;e++){let t=e%3*2/3-1,n=e>2?0:-1,r=[t,n,0,t+2/3,n,0,t+2/3,n+1,0,t,n,0,t+2/3,n+1,0,t,n+1,0];f.set(r,18*e),p.set(d,12*e);let i=[e,e,e,e,e,e];m.set(i,6*e)}let h=new We;h.setAttribute(`position`,new Rt(f,3)),h.setAttribute(`uv`,new Rt(p,2)),h.setAttribute(`faceIndex`,new Rt(m,1)),r.push(new z(h,null)),i>hn&&i--}return{lodMeshes:r,sizeLods:t,sigmas:n}}function On(e,t,n){let r=new I(e,t,n);return r.texture.mapping=306,r.texture.name=`PMREM.cubeUv`,r.scissorTest=!0,r}function kn(e,t,n,r,i){e.viewport.set(t,n,r,i),e.scissor.set(t,n,r,i)}function An(e,t,n){return new Je({name:`PMREMGGXConvolution`,defines:{GGX_SAMPLES:vn,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/n,CUBEUV_MAX_MIP:`${e}.0`},uniforms:{envMap:{value:null},roughness:{value:0},mipInt:{value:0}},vertexShader:Pn(),fragmentShader:`

			precision highp float;
			precision highp int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform float roughness;
			uniform float mipInt;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			#define PI 3.14159265359

			// Van der Corput radical inverse
			float radicalInverse_VdC(uint bits) {
				bits = (bits << 16u) | (bits >> 16u);
				bits = ((bits & 0x55555555u) << 1u) | ((bits & 0xAAAAAAAAu) >> 1u);
				bits = ((bits & 0x33333333u) << 2u) | ((bits & 0xCCCCCCCCu) >> 2u);
				bits = ((bits & 0x0F0F0F0Fu) << 4u) | ((bits & 0xF0F0F0F0u) >> 4u);
				bits = ((bits & 0x00FF00FFu) << 8u) | ((bits & 0xFF00FF00u) >> 8u);
				return float(bits) * 2.3283064365386963e-10; // / 0x100000000
			}

			// Hammersley sequence
			vec2 hammersley(uint i, uint N) {
				return vec2(float(i) / float(N), radicalInverse_VdC(i));
			}

			// GGX VNDF importance sampling (Eric Heitz 2018)
			// "Sampling the GGX Distribution of Visible Normals"
			// https://jcgt.org/published/0007/04/01/
			vec3 importanceSampleGGX_VNDF(vec2 Xi, vec3 V, float roughness) {
				float alpha = roughness * roughness;

				// Section 4.1: Orthonormal basis
				vec3 T1 = vec3(1.0, 0.0, 0.0);
				vec3 T2 = cross(V, T1);

				// Section 4.2: Parameterization of projected area
				float r = sqrt(Xi.x);
				float phi = 2.0 * PI * Xi.y;
				float t1 = r * cos(phi);
				float t2 = r * sin(phi);
				float s = 0.5 * (1.0 + V.z);
				t2 = (1.0 - s) * sqrt(1.0 - t1 * t1) + s * t2;

				// Section 4.3: Reprojection onto hemisphere
				vec3 Nh = t1 * T1 + t2 * T2 + sqrt(max(0.0, 1.0 - t1 * t1 - t2 * t2)) * V;

				// Section 3.4: Transform back to ellipsoid configuration
				return normalize(vec3(alpha * Nh.x, alpha * Nh.y, max(0.0, Nh.z)));
			}

			void main() {
				vec3 N = normalize(vOutputDirection);
				vec3 V = N; // Assume view direction equals normal for pre-filtering

				vec3 prefilteredColor = vec3(0.0);
				float totalWeight = 0.0;

				// For very low roughness, just sample the environment directly
				if (roughness < 0.001) {
					gl_FragColor = vec4(bilinearCubeUV(envMap, N, mipInt), 1.0);
					return;
				}

				// Tangent space basis for VNDF sampling
				vec3 up = abs(N.z) < 0.999 ? vec3(0.0, 0.0, 1.0) : vec3(1.0, 0.0, 0.0);
				vec3 tangent = normalize(cross(up, N));
				vec3 bitangent = cross(N, tangent);

				for(uint i = 0u; i < uint(GGX_SAMPLES); i++) {
					vec2 Xi = hammersley(i, uint(GGX_SAMPLES));

					// For PMREM, V = N, so in tangent space V is always (0, 0, 1)
					vec3 H_tangent = importanceSampleGGX_VNDF(Xi, vec3(0.0, 0.0, 1.0), roughness);

					// Transform H back to world space
					vec3 H = normalize(tangent * H_tangent.x + bitangent * H_tangent.y + N * H_tangent.z);
					vec3 L = normalize(2.0 * dot(V, H) * H - V);

					float NdotL = max(dot(N, L), 0.0);

					if(NdotL > 0.0) {
						// Sample environment at fixed mip level
						// VNDF importance sampling handles the distribution filtering
						vec3 sampleColor = bilinearCubeUV(envMap, L, mipInt);

						// Weight by NdotL for the split-sum approximation
						// VNDF PDF naturally accounts for the visible microfacet distribution
						prefilteredColor += sampleColor * NdotL;
						totalWeight += NdotL;
					}
				}

				if (totalWeight > 0.0) {
					prefilteredColor = prefilteredColor / totalWeight;
				}

				gl_FragColor = vec4(prefilteredColor, 1.0);
			}
		`,blending:0,depthTest:!1,depthWrite:!1})}function jn(e,t,n){let r=new Float32Array(_n),i=new R(0,1,0);return new Je({name:`SphericalGaussianBlur`,defines:{n:_n,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/n,CUBEUV_MAX_MIP:`${e}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:r},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:i}},vertexShader:Pn(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:0,depthTest:!1,depthWrite:!1})}function Mn(){return new Je({name:`EquirectangularToCubeUV`,uniforms:{envMap:{value:null}},vertexShader:Pn(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:0,depthTest:!1,depthWrite:!1})}function Nn(){return new Je({name:`CubemapToCubeUV`,uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:Pn(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:0,depthTest:!1,depthWrite:!1})}function Pn(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}var Fn=class extends I{constructor(e=1,t={}){super(e,e,t),this.isWebGLCubeRenderTarget=!0;let n={width:e,height:e,depth:1},r=[n,n,n,n,n,n];this.texture=new Wt(r),this._setTextureOptions(t),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(e,t){this.texture.type=t.type,this.texture.colorSpace=t.colorSpace,this.texture.generateMipmaps=t.generateMipmaps,this.texture.minFilter=t.minFilter,this.texture.magFilter=t.magFilter;let n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},r=new K(5,5,5),i=new Je({name:`CubemapFromEquirect`,uniforms:le(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:1,blending:0});i.uniforms.tEquirect.value=t;let a=new z(r,i),o=t.minFilter;return t.minFilter===1008&&(t.minFilter=gt),new ge(1,10,this).update(e,a),t.minFilter=o,a.geometry.dispose(),a.material.dispose(),this}clear(e,t=!0,n=!0,r=!0){let i=e.getRenderTarget();for(let i=0;i<6;i++)e.setRenderTarget(this,i),e.clear(t,n,r);e.setRenderTarget(i)}};function In(e){let t=new WeakMap,n=new WeakMap,r=null;function i(e,t=!1){return e==null?null:t?o(e):a(e)}function a(n){if(n&&n.isTexture){let r=n.mapping;if(r===303||r===304){if(t.has(n)){let e=t.get(n).texture;return s(e,n.mapping)}{let r=n.image;if(r&&r.height>0){let i=new Fn(r.height);return i.fromEquirectangularTexture(e,n),t.set(n,i),n.addEventListener(`dispose`,l),s(i.texture,n.mapping)}return null}}}return n}function o(t){if(t&&t.isTexture){let i=t.mapping,a=i===303||i===304,o=i===301||i===302;if(a||o){let i=n.get(t),s=i===void 0?0:i.texture.pmremVersion;if(t.isRenderTargetTexture&&t.pmremVersion!==s)return r===null&&(r=new En(e)),i=a?r.fromEquirectangular(t,i):r.fromCubemap(t,i),i.texture.pmremVersion=t.pmremVersion,n.set(t,i),i.texture;if(i!==void 0)return i.texture;{let s=t.image;return a&&s&&s.height>0||o&&s&&c(s)?(r===null&&(r=new En(e)),i=a?r.fromEquirectangular(t):r.fromCubemap(t),i.texture.pmremVersion=t.pmremVersion,n.set(t,i),t.addEventListener(`dispose`,u),i.texture):null}}}return t}function s(e,t){return t===303?e.mapping=301:t===304&&(e.mapping=302),e}function c(e){let t=0;for(let n=0;n<6;n++)e[n]!==void 0&&t++;return t===6}function l(e){let n=e.target;n.removeEventListener(`dispose`,l);let r=t.get(n);r!==void 0&&(t.delete(n),r.dispose())}function u(e){let t=e.target;t.removeEventListener(`dispose`,u);let r=n.get(t);r!==void 0&&(n.delete(t),r.dispose())}function d(){t=new WeakMap,n=new WeakMap,r!==null&&(r.dispose(),r=null)}return{get:i,dispose:d}}function Ln(e){let t={};function n(n){if(t[n]!==void 0)return t[n];let r=e.getExtension(n);return t[n]=r,r}return{has:function(e){return n(e)!==null},init:function(){n(`EXT_color_buffer_float`),n(`WEBGL_clip_cull_distance`),n(`OES_texture_float_linear`),n(`EXT_color_buffer_half_float`),n(`WEBGL_multisampled_render_to_texture`),n(`WEBGL_render_shared_exponent`)},get:function(e){let t=n(e);return t===null&&H(`WebGLRenderer: `+e+` extension not supported.`),t}}}function Rn(e,t,n,r){let i={},a=new WeakMap;function o(e){let s=e.target;s.index!==null&&t.remove(s.index);for(let e in s.attributes)t.remove(s.attributes[e]);s.removeEventListener(`dispose`,o),delete i[s.id];let c=a.get(s);c&&(t.remove(c),a.delete(s)),r.releaseStatesOfGeometry(s),s.isInstancedBufferGeometry===!0&&delete s._maxInstanceCount,n.memory.geometries--}function s(e,t){return i[t.id]===!0?t:(t.addEventListener(`dispose`,o),i[t.id]=!0,n.memory.geometries++,t)}function c(n){let r=n.attributes;for(let n in r)t.update(r[n],e.ARRAY_BUFFER)}function l(e){let n=[],r=e.index,i=e.attributes.position,o=0;if(i===void 0)return;if(r!==null){let e=r.array;o=r.version;for(let t=0,r=e.length;t<r;t+=3){let r=e[t+0],i=e[t+1],a=e[t+2];n.push(r,i,i,a,a,r)}}else{let e=i.array;o=i.version;for(let t=0,r=e.length/3-1;t<r;t+=3){let e=t+0,r=t+1,i=t+2;n.push(e,r,r,i,i,e)}}let s=new(i.count>=65535?Pe:$e)(n,1);s.version=o;let c=a.get(e);c&&t.remove(c),a.set(e,s)}function u(e){let t=a.get(e);if(t){let n=e.index;n!==null&&t.version<n.version&&l(e)}else l(e);return a.get(e)}return{get:s,update:c,getWireframeAttribute:u}}function zn(e,t,n){let r;function i(e){r=e}let a,o;function s(e){a=e.type,o=e.bytesPerElement}function c(t,i){e.drawElements(r,i,a,t*o),n.update(i,r,1)}function l(t,i,s){s!==0&&(e.drawElementsInstanced(r,i,a,t*o,s),n.update(i,r,s))}function u(e,i,o){if(o===0)return;t.get(`WEBGL_multi_draw`).multiDrawElementsWEBGL(r,i,0,a,e,0,o);let s=0;for(let e=0;e<o;e++)s+=i[e];n.update(s,r,1)}this.setMode=i,this.setIndex=s,this.render=c,this.renderInstances=l,this.renderMultiDraw=u}function Bn(e){let t={geometries:0,textures:0},n={frame:0,calls:0,triangles:0,points:0,lines:0};function r(t,r,i){switch(n.calls++,r){case e.TRIANGLES:n.triangles+=t/3*i;break;case e.LINES:n.lines+=t/2*i;break;case e.LINE_STRIP:n.lines+=i*(t-1);break;case e.LINE_LOOP:n.lines+=i*t;break;case e.POINTS:n.points+=i*t;break;default:F(`WebGLInfo: Unknown draw mode:`,r)}}function i(){n.calls=0,n.triangles=0,n.points=0,n.lines=0}return{memory:t,render:n,programs:null,autoReset:!0,reset:i,update:r}}function Vn(e,t,n){let r=new WeakMap,i=new ut;function a(a,o,s){let c=a.morphTargetInfluences,l=o.morphAttributes.position||o.morphAttributes.normal||o.morphAttributes.color,u=l===void 0?0:l.length,d=r.get(o);if(d===void 0||d.count!==u){d!==void 0&&d.texture.dispose();let e=o.morphAttributes.position!==void 0,n=o.morphAttributes.normal!==void 0,a=o.morphAttributes.color!==void 0,s=o.morphAttributes.position||[],c=o.morphAttributes.normal||[],l=o.morphAttributes.color||[],f=0;e===!0&&(f=1),n===!0&&(f=2),a===!0&&(f=3);let p=o.attributes.position.count*f,h=1;p>t.maxTextureSize&&(h=Math.ceil(p/t.maxTextureSize),p=t.maxTextureSize);let g=new Float32Array(p*h*4*u),_=new lt(g,p,h,u);_.type=De,_.needsUpdate=!0;let v=f*4;for(let t=0;t<u;t++){let r=s[t],o=c[t],u=l[t],d=p*h*4*t;for(let t=0;t<r.count;t++){let s=t*v;e===!0&&(i.fromBufferAttribute(r,t),g[d+s+0]=i.x,g[d+s+1]=i.y,g[d+s+2]=i.z,g[d+s+3]=0),n===!0&&(i.fromBufferAttribute(o,t),g[d+s+4]=i.x,g[d+s+5]=i.y,g[d+s+6]=i.z,g[d+s+7]=0),a===!0&&(i.fromBufferAttribute(u,t),g[d+s+8]=i.x,g[d+s+9]=i.y,g[d+s+10]=i.z,g[d+s+11]=u.itemSize===4?i.w:1)}}d={count:u,texture:_,size:new m(p,h)},r.set(o,d);function y(){_.dispose(),r.delete(o),o.removeEventListener(`dispose`,y)}o.addEventListener(`dispose`,y)}if(a.isInstancedMesh===!0&&a.morphTexture!==null)s.getUniforms().setValue(e,`morphTexture`,a.morphTexture,n);else{let t=0;for(let e=0;e<c.length;e++)t+=c[e];let n=o.morphTargetsRelative?1:1-t;s.getUniforms().setValue(e,`morphTargetBaseInfluence`,n),s.getUniforms().setValue(e,`morphTargetInfluences`,c)}s.getUniforms().setValue(e,`morphTargetsTexture`,d.texture,n),s.getUniforms().setValue(e,`morphTargetsTextureSize`,d.size)}return{update:a}}function Hn(e,t,n,r,i){let a=new WeakMap;function o(r){let o=i.render.frame,s=r.geometry,l=t.get(r,s);if(a.get(l)!==o&&(t.update(l),a.set(l,o)),r.isInstancedMesh&&(r.hasEventListener(`dispose`,c)===!1&&r.addEventListener(`dispose`,c),a.get(r)!==o&&(n.update(r.instanceMatrix,e.ARRAY_BUFFER),r.instanceColor!==null&&n.update(r.instanceColor,e.ARRAY_BUFFER),a.set(r,o))),r.isSkinnedMesh){let e=r.skeleton;a.get(e)!==o&&(e.update(),a.set(e,o))}return l}function s(){a=new WeakMap}function c(e){let t=e.target;t.removeEventListener(`dispose`,c),r.releaseStatesOfObject(t),n.remove(t.instanceMatrix),t.instanceColor!==null&&n.remove(t.instanceColor)}return{update:o,dispose:s}}var Un={1:`LINEAR_TONE_MAPPING`,2:`REINHARD_TONE_MAPPING`,3:`CINEON_TONE_MAPPING`,4:`ACES_FILMIC_TONE_MAPPING`,6:`AGX_TONE_MAPPING`,7:`NEUTRAL_TONE_MAPPING`,5:`CUSTOM_TONE_MAPPING`};function Wn(e,t,n,r,i,a){let o=new I(t,n,{type:e,depthBuffer:i,stencilBuffer:a,samples:r?4:0,depthTexture:i?new ie(t,n):void 0}),s=new I(t,n,{type:ke,depthBuffer:!1,stencilBuffer:!1}),c=new We;c.setAttribute(`position`,new be([-1,3,0,-1,-1,0,3,-1,0],3)),c.setAttribute(`uv`,new be([0,2,0,0,2,0],2));let l=new $t({uniforms:{tDiffuse:{value:null}},vertexShader:`
			precision highp float;

			uniform mat4 modelViewMatrix;
			uniform mat4 projectionMatrix;

			attribute vec3 position;
			attribute vec2 uv;

			varying vec2 vUv;

			void main() {
				vUv = uv;
				gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
			}`,fragmentShader:`
			precision highp float;

			uniform sampler2D tDiffuse;

			varying vec2 vUv;

			#include <tonemapping_pars_fragment>
			#include <colorspace_pars_fragment>

			void main() {
				gl_FragColor = texture2D( tDiffuse, vUv );

				#ifdef LINEAR_TONE_MAPPING
					gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );
				#elif defined( REINHARD_TONE_MAPPING )
					gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );
				#elif defined( CINEON_TONE_MAPPING )
					gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );
				#elif defined( ACES_FILMIC_TONE_MAPPING )
					gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );
				#elif defined( AGX_TONE_MAPPING )
					gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );
				#elif defined( NEUTRAL_TONE_MAPPING )
					gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );
				#elif defined( CUSTOM_TONE_MAPPING )
					gl_FragColor.rgb = CustomToneMapping( gl_FragColor.rgb );
				#endif

				#ifdef SRGB_TRANSFER
					gl_FragColor = sRGBTransferOETF( gl_FragColor );
				#endif
			}`,depthTest:!1,depthWrite:!1}),u=new z(c,l),d=new Se(-1,1,1,-1,0,1),f=null,p=null,m=!1,h,g=null,_=[],v=!1;this.setSize=function(e,t){o.setSize(e,t),s.setSize(e,t);for(let n=0;n<_.length;n++){let r=_[n];r.setSize&&r.setSize(e,t)}},this.setEffects=function(e){_=e,v=_.length>0&&_[0].isRenderPass===!0;let t=o.width,n=o.height;for(let e=0;e<_.length;e++){let r=_[e];r.setSize&&r.setSize(t,n)}},this.begin=function(e,t){if(m||e.toneMapping===0&&_.length===0)return!1;if(g=t,t!==null){let e=t.width,n=t.height;(o.width!==e||o.height!==n)&&this.setSize(e,n)}return v===!1&&e.setRenderTarget(o),h=e.toneMapping,e.toneMapping=0,!0},this.hasRenderPass=function(){return v},this.end=function(e,t){e.toneMapping=h,m=!0;let n=o,r=s;for(let i=0;i<_.length;i++){let a=_[i];if(a.enabled!==!1&&(a.render(e,r,n,t),a.needsSwap!==!1)){let e=n;n=r,r=e}}if(f!==e.outputColorSpace||p!==e.toneMapping){f=e.outputColorSpace,p=e.toneMapping,l.defines={},ze.getTransfer(f)===`srgb`&&(l.defines.SRGB_TRANSFER=``);let t=Un[p];t&&(l.defines[t]=``),l.needsUpdate=!0}l.uniforms.tDiffuse.value=n.texture,e.setRenderTarget(g),e.render(u,d),g=null,m=!1},this.isCompositing=function(){return m},this.dispose=function(){o.depthTexture&&o.depthTexture.dispose(),o.dispose(),s.dispose(),c.dispose(),l.dispose()}}var Gn=new zt,Kn=new ie(1,1),qn=new lt,Jn=new se,Yn=new Wt,Xn=[],Zn=[],Qn=new Float32Array(16),$n=new Float32Array(9),er=new Float32Array(4);function tr(e,t,n){let r=e[0];if(r<=0||r>0)return e;let i=t*n,a=Xn[i];if(a===void 0&&(a=new Float32Array(i),Xn[i]=a),t!==0){r.toArray(a,0);for(let r=1,i=0;r!==t;++r)i+=n,e[r].toArray(a,i)}return a}function nr(e,t){if(e.length!==t.length)return!1;for(let n=0,r=e.length;n<r;n++)if(e[n]!==t[n])return!1;return!0}function rr(e,t){for(let n=0,r=t.length;n<r;n++)e[n]=t[n]}function ir(e,t){let n=Zn[t];n===void 0&&(n=new Int32Array(t),Zn[t]=n);for(let r=0;r!==t;++r)n[r]=e.allocateTextureUnit();return n}function ar(e,t){let n=this.cache;n[0]!==t&&(e.uniform1f(this.addr,t),n[0]=t)}function or(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y)&&(e.uniform2f(this.addr,t.x,t.y),n[0]=t.x,n[1]=t.y);else{if(nr(n,t))return;e.uniform2fv(this.addr,t),rr(n,t)}}function sr(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z)&&(e.uniform3f(this.addr,t.x,t.y,t.z),n[0]=t.x,n[1]=t.y,n[2]=t.z);else if(t.r!==void 0)(n[0]!==t.r||n[1]!==t.g||n[2]!==t.b)&&(e.uniform3f(this.addr,t.r,t.g,t.b),n[0]=t.r,n[1]=t.g,n[2]=t.b);else{if(nr(n,t))return;e.uniform3fv(this.addr,t),rr(n,t)}}function cr(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z||n[3]!==t.w)&&(e.uniform4f(this.addr,t.x,t.y,t.z,t.w),n[0]=t.x,n[1]=t.y,n[2]=t.z,n[3]=t.w);else{if(nr(n,t))return;e.uniform4fv(this.addr,t),rr(n,t)}}function lr(e,t){let n=this.cache,r=t.elements;if(r===void 0){if(nr(n,t))return;e.uniformMatrix2fv(this.addr,!1,t),rr(n,t)}else{if(nr(n,r))return;er.set(r),e.uniformMatrix2fv(this.addr,!1,er),rr(n,r)}}function ur(e,t){let n=this.cache,r=t.elements;if(r===void 0){if(nr(n,t))return;e.uniformMatrix3fv(this.addr,!1,t),rr(n,t)}else{if(nr(n,r))return;$n.set(r),e.uniformMatrix3fv(this.addr,!1,$n),rr(n,r)}}function dr(e,t){let n=this.cache,r=t.elements;if(r===void 0){if(nr(n,t))return;e.uniformMatrix4fv(this.addr,!1,t),rr(n,t)}else{if(nr(n,r))return;Qn.set(r),e.uniformMatrix4fv(this.addr,!1,Qn),rr(n,r)}}function fr(e,t){let n=this.cache;n[0]!==t&&(e.uniform1i(this.addr,t),n[0]=t)}function pr(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y)&&(e.uniform2i(this.addr,t.x,t.y),n[0]=t.x,n[1]=t.y);else{if(nr(n,t))return;e.uniform2iv(this.addr,t),rr(n,t)}}function mr(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z)&&(e.uniform3i(this.addr,t.x,t.y,t.z),n[0]=t.x,n[1]=t.y,n[2]=t.z);else{if(nr(n,t))return;e.uniform3iv(this.addr,t),rr(n,t)}}function hr(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z||n[3]!==t.w)&&(e.uniform4i(this.addr,t.x,t.y,t.z,t.w),n[0]=t.x,n[1]=t.y,n[2]=t.z,n[3]=t.w);else{if(nr(n,t))return;e.uniform4iv(this.addr,t),rr(n,t)}}function gr(e,t){let n=this.cache;n[0]!==t&&(e.uniform1ui(this.addr,t),n[0]=t)}function _r(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y)&&(e.uniform2ui(this.addr,t.x,t.y),n[0]=t.x,n[1]=t.y);else{if(nr(n,t))return;e.uniform2uiv(this.addr,t),rr(n,t)}}function vr(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z)&&(e.uniform3ui(this.addr,t.x,t.y,t.z),n[0]=t.x,n[1]=t.y,n[2]=t.z);else{if(nr(n,t))return;e.uniform3uiv(this.addr,t),rr(n,t)}}function yr(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z||n[3]!==t.w)&&(e.uniform4ui(this.addr,t.x,t.y,t.z,t.w),n[0]=t.x,n[1]=t.y,n[2]=t.z,n[3]=t.w);else{if(nr(n,t))return;e.uniform4uiv(this.addr,t),rr(n,t)}}function br(e,t,n){let r=this.cache,i=n.allocateTextureUnit();r[0]!==i&&(e.uniform1i(this.addr,i),r[0]=i);let a;this.type===e.SAMPLER_2D_SHADOW?(Kn.compareFunction=n.isReversedDepthBuffer()?518:515,a=Kn):a=Gn,n.setTexture2D(t||a,i)}function xr(e,t,n){let r=this.cache,i=n.allocateTextureUnit();r[0]!==i&&(e.uniform1i(this.addr,i),r[0]=i),n.setTexture3D(t||Jn,i)}function Sr(e,t,n){let r=this.cache,i=n.allocateTextureUnit();r[0]!==i&&(e.uniform1i(this.addr,i),r[0]=i),n.setTextureCube(t||Yn,i)}function Cr(e,t,n){let r=this.cache,i=n.allocateTextureUnit();r[0]!==i&&(e.uniform1i(this.addr,i),r[0]=i),n.setTexture2DArray(t||qn,i)}function wr(e){switch(e){case 5126:return ar;case 35664:return or;case 35665:return sr;case 35666:return cr;case 35674:return lr;case 35675:return ur;case 35676:return dr;case 5124:case 35670:return fr;case 35667:case 35671:return pr;case 35668:case 35672:return mr;case 35669:case 35673:return hr;case 5125:return gr;case 36294:return _r;case 36295:return vr;case 36296:return yr;case 35678:case 36198:case 36298:case 36306:case 35682:return br;case 35679:case 36299:case 36307:return xr;case 35680:case 36300:case 36308:case 36293:return Sr;case 36289:case 36303:case 36311:case 36292:return Cr}}function Tr(e,t){e.uniform1fv(this.addr,t)}function Er(e,t){let n=tr(t,this.size,2);e.uniform2fv(this.addr,n)}function Dr(e,t){let n=tr(t,this.size,3);e.uniform3fv(this.addr,n)}function Or(e,t){let n=tr(t,this.size,4);e.uniform4fv(this.addr,n)}function kr(e,t){let n=tr(t,this.size,4);e.uniformMatrix2fv(this.addr,!1,n)}function Ar(e,t){let n=tr(t,this.size,9);e.uniformMatrix3fv(this.addr,!1,n)}function jr(e,t){let n=tr(t,this.size,16);e.uniformMatrix4fv(this.addr,!1,n)}function Mr(e,t){e.uniform1iv(this.addr,t)}function Nr(e,t){e.uniform2iv(this.addr,t)}function Pr(e,t){e.uniform3iv(this.addr,t)}function Fr(e,t){e.uniform4iv(this.addr,t)}function Ir(e,t){e.uniform1uiv(this.addr,t)}function Lr(e,t){e.uniform2uiv(this.addr,t)}function Rr(e,t){e.uniform3uiv(this.addr,t)}function zr(e,t){e.uniform4uiv(this.addr,t)}function Br(e,t,n){let r=this.cache,i=t.length,a=ir(n,i);nr(r,a)||(e.uniform1iv(this.addr,a),rr(r,a));let o;o=this.type===e.SAMPLER_2D_SHADOW?Kn:Gn;for(let e=0;e!==i;++e)n.setTexture2D(t[e]||o,a[e])}function Vr(e,t,n){let r=this.cache,i=t.length,a=ir(n,i);nr(r,a)||(e.uniform1iv(this.addr,a),rr(r,a));for(let e=0;e!==i;++e)n.setTexture3D(t[e]||Jn,a[e])}function Hr(e,t,n){let r=this.cache,i=t.length,a=ir(n,i);nr(r,a)||(e.uniform1iv(this.addr,a),rr(r,a));for(let e=0;e!==i;++e)n.setTextureCube(t[e]||Yn,a[e])}function Ur(e,t,n){let r=this.cache,i=t.length,a=ir(n,i);nr(r,a)||(e.uniform1iv(this.addr,a),rr(r,a));for(let e=0;e!==i;++e)n.setTexture2DArray(t[e]||qn,a[e])}function Wr(e){switch(e){case 5126:return Tr;case 35664:return Er;case 35665:return Dr;case 35666:return Or;case 35674:return kr;case 35675:return Ar;case 35676:return jr;case 5124:case 35670:return Mr;case 35667:case 35671:return Nr;case 35668:case 35672:return Pr;case 35669:case 35673:return Fr;case 5125:return Ir;case 36294:return Lr;case 36295:return Rr;case 36296:return zr;case 35678:case 36198:case 36298:case 36306:case 35682:return Br;case 35679:case 36299:case 36307:return Vr;case 35680:case 36300:case 36308:case 36293:return Hr;case 36289:case 36303:case 36311:case 36292:return Ur}}var Gr=class{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.setValue=wr(t.type)}},Kr=class{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.size=t.size,this.setValue=Wr(t.type)}},qr=class{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,t,n){let r=this.seq;for(let i=0,a=r.length;i!==a;++i){let a=r[i];a.setValue(e,t[a.id],n)}}},Jr=/(\w+)(\])?(\[|\.)?/g;function Yr(e,t){e.seq.push(t),e.map[t.id]=t}function Xr(e,t,n){let r=e.name,i=r.length;for(Jr.lastIndex=0;;){let a=Jr.exec(r),o=Jr.lastIndex,s=a[1],c=a[2]===`]`,l=a[3];if(c&&(s|=0),l===void 0||l===`[`&&o+2===i){Yr(n,l===void 0?new Gr(s,e,t):new Kr(s,e,t));break}{let e=n.map[s];e===void 0&&(e=new qr(s),Yr(n,e)),n=e}}}var Zr=class{constructor(e,t){this.seq=[],this.map={};let n=e.getProgramParameter(t,e.ACTIVE_UNIFORMS);for(let r=0;r<n;++r){let n=e.getActiveUniform(t,r);Xr(n,e.getUniformLocation(t,n.name),this)}let r=[],i=[];for(let t of this.seq)t.type===e.SAMPLER_2D_SHADOW||t.type===e.SAMPLER_CUBE_SHADOW||t.type===e.SAMPLER_2D_ARRAY_SHADOW?r.push(t):i.push(t);r.length>0&&(this.seq=r.concat(i))}setValue(e,t,n,r){let i=this.map[t];i!==void 0&&i.setValue(e,n,r)}setOptional(e,t,n){let r=t[n];r!==void 0&&this.setValue(e,n,r)}static upload(e,t,n,r){for(let i=0,a=t.length;i!==a;++i){let a=t[i],o=n[a.id];o.needsUpdate!==!1&&a.setValue(e,o.value,r)}}static seqWithValue(e,t){let n=[];for(let r=0,i=e.length;r!==i;++r){let i=e[r];i.id in t&&n.push(i)}return n}};function Qr(e,t,n){let r=e.createShader(t);return e.shaderSource(r,n),e.compileShader(r),r}var $r=37297,ei=0;function ti(e,t){let n=e.split(`
`),r=[],i=Math.max(t-6,0),a=Math.min(t+6,n.length);for(let e=i;e<a;e++){let i=e+1;r.push(`${i===t?`>`:` `} ${i}: ${n[e]}`)}return r.join(`
`)}var ni=new v;function ri(e){ze._getMatrix(ni,ze.workingColorSpace,e);let t=`mat3( ${ni.elements.map(e=>e.toFixed(4))} )`;switch(ze.getTransfer(e)){case Ut:return[t,`LinearTransferOETF`];case de:return[t,`sRGBTransferOETF`];default:return V(`WebGLProgram: Unsupported color space: `,e),[t,`LinearTransferOETF`]}}function ii(e,t,n){let r=e.getShaderParameter(t,e.COMPILE_STATUS),i=(e.getShaderInfoLog(t)||``).trim();if(r&&i===``)return``;let a=/ERROR: 0:(\d+)/.exec(i);if(a){let r=parseInt(a[1]);return n.toUpperCase()+`

`+i+`

`+ti(e.getShaderSource(t),r)}return i}function ai(e,t){let n=ri(t);return[`vec4 ${e}( vec4 value ) {`,`	return ${n[1]}( vec4( value.rgb * ${n[0]}, value.a ) );`,`}`].join(`
`)}var oi={1:`Linear`,2:`Reinhard`,3:`Cineon`,4:`ACESFilmic`,6:`AgX`,7:`Neutral`,5:`Custom`};function si(e,t){let n=oi[t];return n===void 0?(V(`WebGLProgram: Unsupported toneMapping:`,t),`vec3 `+e+`( vec3 color ) { return LinearToneMapping( color ); }`):`vec3 `+e+`( vec3 color ) { return `+n+`ToneMapping( color ); }`}var ci=new R;function li(){return ze.getLuminanceCoefficients(ci),[`float luminance( const in vec3 rgb ) {`,`	const vec3 weights = vec3( ${ci.x.toFixed(4)}, ${ci.y.toFixed(4)}, ${ci.z.toFixed(4)} );`,`	return dot( weights, rgb );`,`}`].join(`
`)}function ui(e){return[e.extensionClipCullDistance?`#extension GL_ANGLE_clip_cull_distance : require`:``,e.extensionMultiDraw?`#extension GL_ANGLE_multi_draw : require`:``].filter(pi).join(`
`)}function di(e){let t=[];for(let n in e){let r=e[n];r!==!1&&t.push(`#define `+n+` `+r)}return t.join(`
`)}function fi(e,t){let n={},r=e.getProgramParameter(t,e.ACTIVE_ATTRIBUTES);for(let i=0;i<r;i++){let r=e.getActiveAttrib(t,i),a=r.name,o=1;r.type===e.FLOAT_MAT2&&(o=2),r.type===e.FLOAT_MAT3&&(o=3),r.type===e.FLOAT_MAT4&&(o=4),n[a]={type:r.type,location:e.getAttribLocation(t,a),locationSize:o}}return n}function pi(e){return e!==``}function mi(e,t){let n=t.numSpotLightShadows+t.numSpotLightMaps-t.numSpotLightShadowsWithMaps;return e.replace(/NUM_DIR_LIGHTS/g,t.numDirLights).replace(/NUM_SPOT_LIGHTS/g,t.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,t.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,n).replace(/NUM_RECT_AREA_LIGHTS/g,t.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,t.numPointLights).replace(/NUM_HEMI_LIGHTS/g,t.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,t.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,t.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,t.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,t.numPointLightShadows)}function hi(e,t){return e.replace(/NUM_CLIPPING_PLANES/g,t.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,t.numClippingPlanes-t.numClipIntersection)}var gi=/^[ \t]*#include +<([\w\d./]+)>/gm;function _i(e){return e.replace(gi,yi)}var vi=new Map;function yi(e,t){let n=an[t];if(n===void 0){let e=vi.get(t);if(e!==void 0)n=an[e],V(`WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.`,t,e);else throw Error(`THREE.WebGLProgram: Can not resolve #include <`+t+`>`)}return _i(n)}var bi=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function xi(e){return e.replace(bi,Si)}function Si(e,t,n,r){let i=``;for(let e=parseInt(t);e<parseInt(n);e++)i+=r.replace(/\[\s*i\s*\]/g,`[ `+e+` ]`).replace(/UNROLLED_LOOP_INDEX/g,e);return i}function Ci(e){let t=`precision ${e.precision} float;
	precision ${e.precision} int;
	precision ${e.precision} sampler2D;
	precision ${e.precision} samplerCube;
	precision ${e.precision} sampler3D;
	precision ${e.precision} sampler2DArray;
	precision ${e.precision} sampler2DShadow;
	precision ${e.precision} samplerCubeShadow;
	precision ${e.precision} sampler2DArrayShadow;
	precision ${e.precision} isampler2D;
	precision ${e.precision} isampler3D;
	precision ${e.precision} isamplerCube;
	precision ${e.precision} isampler2DArray;
	precision ${e.precision} usampler2D;
	precision ${e.precision} usampler3D;
	precision ${e.precision} usamplerCube;
	precision ${e.precision} usampler2DArray;
	`;return e.precision===`highp`?t+=`
#define HIGH_PRECISION`:e.precision===`mediump`?t+=`
#define MEDIUM_PRECISION`:e.precision===`lowp`&&(t+=`
#define LOW_PRECISION`),t}var wi={1:`SHADOWMAP_TYPE_PCF`,3:`SHADOWMAP_TYPE_VSM`};function Ti(e){return wi[e.shadowMapType]||`SHADOWMAP_TYPE_BASIC`}var Ei={301:`ENVMAP_TYPE_CUBE`,302:`ENVMAP_TYPE_CUBE`,306:`ENVMAP_TYPE_CUBE_UV`};function Di(e){return e.envMap===!1?`ENVMAP_TYPE_CUBE`:Ei[e.envMapMode]||`ENVMAP_TYPE_CUBE`}var Oi={302:`ENVMAP_MODE_REFRACTION`};function ki(e){return e.envMap===!1?`ENVMAP_MODE_REFLECTION`:Oi[e.envMapMode]||`ENVMAP_MODE_REFLECTION`}var Ai={0:`ENVMAP_BLENDING_MULTIPLY`,1:`ENVMAP_BLENDING_MIX`,2:`ENVMAP_BLENDING_ADD`};function ji(e){return e.envMap===!1?`ENVMAP_BLENDING_NONE`:Ai[e.combine]||`ENVMAP_BLENDING_NONE`}function Mi(e){let t=e.envMapCubeUVHeight;if(t===null)return null;let n=Math.log2(t)-2,r=1/t;return{texelWidth:1/(3*Math.max(2**n,112)),texelHeight:r,maxMip:n}}function Ni(e,t,n,r){let i=e.getContext(),a=n.defines,o=n.vertexShader,s=n.fragmentShader,c=Ti(n),l=Di(n),u=ki(n),d=ji(n),f=Mi(n),p=ui(n),m=di(a),h=i.createProgram(),g,_,v=n.glslVersion?`#version `+n.glslVersion+`
`:``;n.isRawShaderMaterial?(g=[`#define SHADER_TYPE `+n.shaderType,`#define SHADER_NAME `+n.shaderName,m].filter(pi).join(`
`),g.length>0&&(g+=`
`),_=[`#define SHADER_TYPE `+n.shaderType,`#define SHADER_NAME `+n.shaderName,m].filter(pi).join(`
`),_.length>0&&(_+=`
`)):(g=[Ci(n),`#define SHADER_TYPE `+n.shaderType,`#define SHADER_NAME `+n.shaderName,m,n.extensionClipCullDistance?`#define USE_CLIP_DISTANCE`:``,n.batching?`#define USE_BATCHING`:``,n.batchingColor?`#define USE_BATCHING_COLOR`:``,n.instancing?`#define USE_INSTANCING`:``,n.instancingColor?`#define USE_INSTANCING_COLOR`:``,n.instancingMorph?`#define USE_INSTANCING_MORPH`:``,n.useFog&&n.fog?`#define USE_FOG`:``,n.useFog&&n.fogExp2?`#define FOG_EXP2`:``,n.map?`#define USE_MAP`:``,n.envMap?`#define USE_ENVMAP`:``,n.envMap?`#define `+u:``,n.lightMap?`#define USE_LIGHTMAP`:``,n.aoMap?`#define USE_AOMAP`:``,n.bumpMap?`#define USE_BUMPMAP`:``,n.normalMap?`#define USE_NORMALMAP`:``,n.normalMapObjectSpace?`#define USE_NORMALMAP_OBJECTSPACE`:``,n.normalMapTangentSpace?`#define USE_NORMALMAP_TANGENTSPACE`:``,n.displacementMap?`#define USE_DISPLACEMENTMAP`:``,n.emissiveMap?`#define USE_EMISSIVEMAP`:``,n.anisotropy?`#define USE_ANISOTROPY`:``,n.anisotropyMap?`#define USE_ANISOTROPYMAP`:``,n.clearcoatMap?`#define USE_CLEARCOATMAP`:``,n.clearcoatRoughnessMap?`#define USE_CLEARCOAT_ROUGHNESSMAP`:``,n.clearcoatNormalMap?`#define USE_CLEARCOAT_NORMALMAP`:``,n.iridescenceMap?`#define USE_IRIDESCENCEMAP`:``,n.iridescenceThicknessMap?`#define USE_IRIDESCENCE_THICKNESSMAP`:``,n.specularMap?`#define USE_SPECULARMAP`:``,n.specularColorMap?`#define USE_SPECULAR_COLORMAP`:``,n.specularIntensityMap?`#define USE_SPECULAR_INTENSITYMAP`:``,n.roughnessMap?`#define USE_ROUGHNESSMAP`:``,n.metalnessMap?`#define USE_METALNESSMAP`:``,n.alphaMap?`#define USE_ALPHAMAP`:``,n.alphaHash?`#define USE_ALPHAHASH`:``,n.transmission?`#define USE_TRANSMISSION`:``,n.transmissionMap?`#define USE_TRANSMISSIONMAP`:``,n.thicknessMap?`#define USE_THICKNESSMAP`:``,n.sheenColorMap?`#define USE_SHEEN_COLORMAP`:``,n.sheenRoughnessMap?`#define USE_SHEEN_ROUGHNESSMAP`:``,n.mapUv?`#define MAP_UV `+n.mapUv:``,n.alphaMapUv?`#define ALPHAMAP_UV `+n.alphaMapUv:``,n.lightMapUv?`#define LIGHTMAP_UV `+n.lightMapUv:``,n.aoMapUv?`#define AOMAP_UV `+n.aoMapUv:``,n.emissiveMapUv?`#define EMISSIVEMAP_UV `+n.emissiveMapUv:``,n.bumpMapUv?`#define BUMPMAP_UV `+n.bumpMapUv:``,n.normalMapUv?`#define NORMALMAP_UV `+n.normalMapUv:``,n.displacementMapUv?`#define DISPLACEMENTMAP_UV `+n.displacementMapUv:``,n.metalnessMapUv?`#define METALNESSMAP_UV `+n.metalnessMapUv:``,n.roughnessMapUv?`#define ROUGHNESSMAP_UV `+n.roughnessMapUv:``,n.anisotropyMapUv?`#define ANISOTROPYMAP_UV `+n.anisotropyMapUv:``,n.clearcoatMapUv?`#define CLEARCOATMAP_UV `+n.clearcoatMapUv:``,n.clearcoatNormalMapUv?`#define CLEARCOAT_NORMALMAP_UV `+n.clearcoatNormalMapUv:``,n.clearcoatRoughnessMapUv?`#define CLEARCOAT_ROUGHNESSMAP_UV `+n.clearcoatRoughnessMapUv:``,n.iridescenceMapUv?`#define IRIDESCENCEMAP_UV `+n.iridescenceMapUv:``,n.iridescenceThicknessMapUv?`#define IRIDESCENCE_THICKNESSMAP_UV `+n.iridescenceThicknessMapUv:``,n.sheenColorMapUv?`#define SHEEN_COLORMAP_UV `+n.sheenColorMapUv:``,n.sheenRoughnessMapUv?`#define SHEEN_ROUGHNESSMAP_UV `+n.sheenRoughnessMapUv:``,n.specularMapUv?`#define SPECULARMAP_UV `+n.specularMapUv:``,n.specularColorMapUv?`#define SPECULAR_COLORMAP_UV `+n.specularColorMapUv:``,n.specularIntensityMapUv?`#define SPECULAR_INTENSITYMAP_UV `+n.specularIntensityMapUv:``,n.transmissionMapUv?`#define TRANSMISSIONMAP_UV `+n.transmissionMapUv:``,n.thicknessMapUv?`#define THICKNESSMAP_UV `+n.thicknessMapUv:``,n.vertexTangents&&n.flatShading===!1?`#define USE_TANGENT`:``,n.vertexNormals?`#define HAS_NORMAL`:``,n.vertexColors?`#define USE_COLOR`:``,n.vertexAlphas?`#define USE_COLOR_ALPHA`:``,n.vertexUv1s?`#define USE_UV1`:``,n.vertexUv2s?`#define USE_UV2`:``,n.vertexUv3s?`#define USE_UV3`:``,n.pointsUvs?`#define USE_POINTS_UV`:``,n.flatShading?`#define FLAT_SHADED`:``,n.skinning?`#define USE_SKINNING`:``,n.morphTargets?`#define USE_MORPHTARGETS`:``,n.morphNormals&&n.flatShading===!1?`#define USE_MORPHNORMALS`:``,n.morphColors?`#define USE_MORPHCOLORS`:``,n.morphTargetsCount>0?`#define MORPHTARGETS_TEXTURE_STRIDE `+n.morphTextureStride:``,n.morphTargetsCount>0?`#define MORPHTARGETS_COUNT `+n.morphTargetsCount:``,n.doubleSided?`#define DOUBLE_SIDED`:``,n.flipSided?`#define FLIP_SIDED`:``,n.shadowMapEnabled?`#define USE_SHADOWMAP`:``,n.shadowMapEnabled?`#define `+c:``,n.sizeAttenuation?`#define USE_SIZEATTENUATION`:``,n.numLightProbes>0?`#define USE_LIGHT_PROBES`:``,n.logarithmicDepthBuffer?`#define USE_LOGARITHMIC_DEPTH_BUFFER`:``,n.reversedDepthBuffer?`#define USE_REVERSED_DEPTH_BUFFER`:``,`uniform mat4 modelMatrix;`,`uniform mat4 modelViewMatrix;`,`uniform mat4 projectionMatrix;`,`uniform mat4 viewMatrix;`,`uniform mat3 normalMatrix;`,`uniform vec3 cameraPosition;`,`uniform bool isOrthographic;`,`#ifdef USE_INSTANCING`,`	attribute mat4 instanceMatrix;`,`#endif`,`#ifdef USE_INSTANCING_COLOR`,`	attribute vec3 instanceColor;`,`#endif`,`#ifdef USE_INSTANCING_MORPH`,`	uniform sampler2D morphTexture;`,`#endif`,`attribute vec3 position;`,`attribute vec3 normal;`,`attribute vec2 uv;`,`#ifdef USE_UV1`,`	attribute vec2 uv1;`,`#endif`,`#ifdef USE_UV2`,`	attribute vec2 uv2;`,`#endif`,`#ifdef USE_UV3`,`	attribute vec2 uv3;`,`#endif`,`#ifdef USE_TANGENT`,`	attribute vec4 tangent;`,`#endif`,`#if defined( USE_COLOR_ALPHA )`,`	attribute vec4 color;`,`#elif defined( USE_COLOR )`,`	attribute vec3 color;`,`#endif`,`#ifdef USE_SKINNING`,`	attribute vec4 skinIndex;`,`	attribute vec4 skinWeight;`,`#endif`,`
`].filter(pi).join(`
`),_=[Ci(n),`#define SHADER_TYPE `+n.shaderType,`#define SHADER_NAME `+n.shaderName,m,n.useFog&&n.fog?`#define USE_FOG`:``,n.useFog&&n.fogExp2?`#define FOG_EXP2`:``,n.alphaToCoverage?`#define ALPHA_TO_COVERAGE`:``,n.map?`#define USE_MAP`:``,n.matcap?`#define USE_MATCAP`:``,n.envMap?`#define USE_ENVMAP`:``,n.envMap?`#define `+l:``,n.envMap?`#define `+u:``,n.envMap?`#define `+d:``,f?`#define CUBEUV_TEXEL_WIDTH `+f.texelWidth:``,f?`#define CUBEUV_TEXEL_HEIGHT `+f.texelHeight:``,f?`#define CUBEUV_MAX_MIP `+f.maxMip+`.0`:``,n.lightMap?`#define USE_LIGHTMAP`:``,n.aoMap?`#define USE_AOMAP`:``,n.bumpMap?`#define USE_BUMPMAP`:``,n.normalMap?`#define USE_NORMALMAP`:``,n.normalMapObjectSpace?`#define USE_NORMALMAP_OBJECTSPACE`:``,n.normalMapTangentSpace?`#define USE_NORMALMAP_TANGENTSPACE`:``,n.packedNormalMap?`#define USE_PACKED_NORMALMAP`:``,n.emissiveMap?`#define USE_EMISSIVEMAP`:``,n.anisotropy?`#define USE_ANISOTROPY`:``,n.anisotropyMap?`#define USE_ANISOTROPYMAP`:``,n.clearcoat?`#define USE_CLEARCOAT`:``,n.clearcoatMap?`#define USE_CLEARCOATMAP`:``,n.clearcoatRoughnessMap?`#define USE_CLEARCOAT_ROUGHNESSMAP`:``,n.clearcoatNormalMap?`#define USE_CLEARCOAT_NORMALMAP`:``,n.dispersion?`#define USE_DISPERSION`:``,n.iridescence?`#define USE_IRIDESCENCE`:``,n.iridescenceMap?`#define USE_IRIDESCENCEMAP`:``,n.iridescenceThicknessMap?`#define USE_IRIDESCENCE_THICKNESSMAP`:``,n.specularMap?`#define USE_SPECULARMAP`:``,n.specularColorMap?`#define USE_SPECULAR_COLORMAP`:``,n.specularIntensityMap?`#define USE_SPECULAR_INTENSITYMAP`:``,n.roughnessMap?`#define USE_ROUGHNESSMAP`:``,n.metalnessMap?`#define USE_METALNESSMAP`:``,n.alphaMap?`#define USE_ALPHAMAP`:``,n.alphaTest?`#define USE_ALPHATEST`:``,n.alphaHash?`#define USE_ALPHAHASH`:``,n.sheen?`#define USE_SHEEN`:``,n.sheenColorMap?`#define USE_SHEEN_COLORMAP`:``,n.sheenRoughnessMap?`#define USE_SHEEN_ROUGHNESSMAP`:``,n.transmission?`#define USE_TRANSMISSION`:``,n.transmissionMap?`#define USE_TRANSMISSIONMAP`:``,n.thicknessMap?`#define USE_THICKNESSMAP`:``,n.vertexTangents&&n.flatShading===!1?`#define USE_TANGENT`:``,n.vertexColors||n.instancingColor?`#define USE_COLOR`:``,n.vertexAlphas||n.batchingColor?`#define USE_COLOR_ALPHA`:``,n.vertexUv1s?`#define USE_UV1`:``,n.vertexUv2s?`#define USE_UV2`:``,n.vertexUv3s?`#define USE_UV3`:``,n.pointsUvs?`#define USE_POINTS_UV`:``,n.gradientMap?`#define USE_GRADIENTMAP`:``,n.flatShading?`#define FLAT_SHADED`:``,n.doubleSided?`#define DOUBLE_SIDED`:``,n.flipSided?`#define FLIP_SIDED`:``,n.shadowMapEnabled?`#define USE_SHADOWMAP`:``,n.shadowMapEnabled?`#define `+c:``,n.premultipliedAlpha?`#define PREMULTIPLIED_ALPHA`:``,n.numLightProbes>0?`#define USE_LIGHT_PROBES`:``,n.numLightProbeGrids>0?`#define USE_LIGHT_PROBES_GRID`:``,n.decodeVideoTexture?`#define DECODE_VIDEO_TEXTURE`:``,n.decodeVideoTextureEmissive?`#define DECODE_VIDEO_TEXTURE_EMISSIVE`:``,n.logarithmicDepthBuffer?`#define USE_LOGARITHMIC_DEPTH_BUFFER`:``,n.reversedDepthBuffer?`#define USE_REVERSED_DEPTH_BUFFER`:``,`uniform mat4 viewMatrix;`,`uniform vec3 cameraPosition;`,`uniform bool isOrthographic;`,n.toneMapping===0?``:`#define TONE_MAPPING`,n.toneMapping===0?``:an.tonemapping_pars_fragment,n.toneMapping===0?``:si(`toneMapping`,n.toneMapping),n.dithering?`#define DITHERING`:``,n.opaque?`#define OPAQUE`:``,an.colorspace_pars_fragment,ai(`linearToOutputTexel`,n.outputColorSpace),li(),n.useDepthPacking?`#define DEPTH_PACKING `+n.depthPacking:``,`
`].filter(pi).join(`
`)),o=_i(o),o=mi(o,n),o=hi(o,n),s=_i(s),s=mi(s,n),s=hi(s,n),o=xi(o),s=xi(s),n.isRawShaderMaterial!==!0&&(v=`#version 300 es
`,g=[p,`#define attribute in`,`#define varying out`,`#define texture2D texture`].join(`
`)+`
`+g,_=[`#define varying in`,n.glslVersion===`300 es`?``:`layout(location = 0) out highp vec4 pc_fragColor;`,n.glslVersion===`300 es`?``:`#define gl_FragColor pc_fragColor`,`#define gl_FragDepthEXT gl_FragDepth`,`#define texture2D texture`,`#define textureCube texture`,`#define texture2DProj textureProj`,`#define texture2DLodEXT textureLod`,`#define texture2DProjLodEXT textureProjLod`,`#define textureCubeLodEXT textureLod`,`#define texture2DGradEXT textureGrad`,`#define texture2DProjGradEXT textureProjGrad`,`#define textureCubeGradEXT textureGrad`].join(`
`)+`
`+_);let y=v+g+o,b=v+_+s,x=Qr(i,i.VERTEX_SHADER,y),S=Qr(i,i.FRAGMENT_SHADER,b);i.attachShader(h,x),i.attachShader(h,S),n.index0AttributeName===void 0?n.hasPositionAttribute===!0&&i.bindAttribLocation(h,0,`position`):i.bindAttribLocation(h,0,n.index0AttributeName),i.linkProgram(h);function C(t){if(e.debug.checkShaderErrors){let n=i.getProgramInfoLog(h)||``,r=i.getShaderInfoLog(x)||``,a=i.getShaderInfoLog(S)||``,o=n.trim(),s=r.trim(),c=a.trim(),l=!0,u=!0;if(i.getProgramParameter(h,i.LINK_STATUS)===!1){if(l=!1,typeof e.debug.onShaderError==`function`)e.debug.onShaderError(i,h,x,S);else{let e=ii(i,x,`vertex`),n=ii(i,S,`fragment`);F(`WebGLProgram: Shader Error `+i.getError()+` - VALIDATE_STATUS `+i.getProgramParameter(h,i.VALIDATE_STATUS)+`

Material Name: `+t.name+`
Material Type: `+t.type+`

Program Info Log: `+o+`
`+e+`
`+n)}}else o===``?(s===``||c===``)&&(u=!1):V(`WebGLProgram: Program Info Log:`,o);u&&(t.diagnostics={runnable:l,programLog:o,vertexShader:{log:s,prefix:g},fragmentShader:{log:c,prefix:_}})}i.deleteShader(x),i.deleteShader(S),w=new Zr(i,h),T=fi(i,h)}let w;this.getUniforms=function(){return w===void 0&&C(this),w};let T;this.getAttributes=function(){return T===void 0&&C(this),T};let E=n.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return E===!1&&(E=i.getProgramParameter(h,$r)),E},this.destroy=function(){r.releaseStatesOfProgram(this),i.deleteProgram(h),this.program=void 0},this.type=n.shaderType,this.name=n.shaderName,this.id=ei++,this.cacheKey=t,this.usedTimes=1,this.program=h,this.vertexShader=x,this.fragmentShader=S,this}var Pi=0,Fi=class{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e,t,n){let r=this._getShaderCacheForMaterial(e);return r.has(t)===!1&&(r.add(t),t.usedTimes++),r.has(n)===!1&&(r.add(n),n.usedTimes++),this}remove(e){let t=this.materialCache.get(e);for(let e of t)e.usedTimes--,e.usedTimes===0&&this.shaderCache.delete(e.code);return this.materialCache.delete(e),this}getVertexShaderStage(e){return this._getShaderStage(e.vertexShader)}getFragmentShaderStage(e){return this._getShaderStage(e.fragmentShader)}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){let t=this.materialCache,n=t.get(e);return n===void 0&&(n=new Set,t.set(e,n)),n}_getShaderStage(e){let t=this.shaderCache,n=t.get(e);return n===void 0&&(n=new Ii(e),t.set(e,n)),n}},Ii=class{constructor(e){this.id=Pi++,this.code=e,this.usedTimes=0}};function Li(e){return e===1030||e===37490||e===36285}function Ri(e,t,n,r,i,a){let o=new pt,s=new Fi,c=new Set,l=[],u=new Map,d=r.logarithmicDepthBuffer,f=r.precision,p={MeshDepthMaterial:`depth`,MeshDistanceMaterial:`distance`,MeshNormalMaterial:`normal`,MeshBasicMaterial:`basic`,MeshLambertMaterial:`lambert`,MeshPhongMaterial:`phong`,MeshToonMaterial:`toon`,MeshStandardMaterial:`physical`,MeshPhysicalMaterial:`physical`,MeshMatcapMaterial:`matcap`,LineBasicMaterial:`basic`,LineDashedMaterial:`dashed`,PointsMaterial:`points`,ShadowMaterial:`shadow`,SpriteMaterial:`sprite`};function m(e){return c.add(e),e===0?`uv`:`uv${e}`}function h(i,o,l,u,h,g){let _=u.fog,v=h.geometry,y=i.isMeshStandardMaterial||i.isMeshLambertMaterial||i.isMeshPhongMaterial?u.environment:null,b=i.isMeshStandardMaterial||i.isMeshLambertMaterial&&!i.envMap||i.isMeshPhongMaterial&&!i.envMap,x=t.get(i.envMap||y,b),S=x&&x.mapping===306?x.image.height:null,C=p[i.type];i.precision!==null&&(f=r.getMaxPrecision(i.precision),f!==i.precision&&V(`WebGLProgram.getParameters:`,i.precision,`not supported, using`,f,`instead.`));let w=v.morphAttributes.position||v.morphAttributes.normal||v.morphAttributes.color,T=w===void 0?0:w.length,E=0;v.morphAttributes.position!==void 0&&(E=1),v.morphAttributes.normal!==void 0&&(E=2),v.morphAttributes.color!==void 0&&(E=3);let D,O,k,A;if(C){let e=on[C];D=e.vertexShader,O=e.fragmentShader}else{D=i.vertexShader,O=i.fragmentShader;let e=s.getVertexShaderStage(i),t=s.getFragmentShaderStage(i);s.update(i,e,t),k=e.id,A=t.id}let j=e.getRenderTarget(),ee=e.state.buffers.depth.getReversed(),M=h.isInstancedMesh===!0,N=h.isBatchedMesh===!0,P=!!i.map,te=!!i.matcap,F=!!x,ne=!!i.aoMap,re=!!i.lightMap,I=!!i.bumpMap&&i.wireframe===!1,L=!!i.normalMap,ie=!!i.displacementMap,ae=!!i.emissiveMap,oe=!!i.metalnessMap,se=!!i.roughnessMap,R=i.anisotropy>0,z=i.clearcoat>0,ce=i.dispersion>0,le=i.iridescence>0,ue=i.sheen>0,de=i.transmission>0,fe=R&&!!i.anisotropyMap,pe=z&&!!i.clearcoatMap,me=z&&!!i.clearcoatNormalMap,he=z&&!!i.clearcoatRoughnessMap,ge=le&&!!i.iridescenceMap,_e=le&&!!i.iridescenceThicknessMap,ve=ue&&!!i.sheenColorMap,ye=ue&&!!i.sheenRoughnessMap,B=!!i.specularMap,be=!!i.specularColorMap,xe=!!i.specularIntensityMap,Se=de&&!!i.transmissionMap,Ce=de&&!!i.thicknessMap,we=!!i.gradientMap,Te=!!i.alphaMap,Ee=i.alphaTest>0,De=!!i.alphaHash,Oe=!!i.extensions,H=0;i.toneMapped&&(j===null||j.isXRRenderTarget===!0)&&(H=e.toneMapping);let ke={shaderID:C,shaderType:i.type,shaderName:i.name,vertexShader:D,fragmentShader:O,defines:i.defines,customVertexShaderID:k,customFragmentShaderID:A,isRawShaderMaterial:i.isRawShaderMaterial===!0,glslVersion:i.glslVersion,precision:f,batching:N,batchingColor:N&&h._colorsTexture!==null,instancing:M,instancingColor:M&&h.instanceColor!==null,instancingMorph:M&&h.morphTexture!==null,outputColorSpace:j===null?e.outputColorSpace:j.isXRRenderTarget===!0?j.texture.colorSpace:ze.workingColorSpace,alphaToCoverage:!!i.alphaToCoverage,map:P,matcap:te,envMap:F,envMapMode:F&&x.mapping,envMapCubeUVHeight:S,aoMap:ne,lightMap:re,bumpMap:I,normalMap:L,displacementMap:ie,emissiveMap:ae,normalMapObjectSpace:L&&i.normalMapType===1,normalMapTangentSpace:L&&i.normalMapType===0,packedNormalMap:L&&i.normalMapType===0&&Li(i.normalMap.format),metalnessMap:oe,roughnessMap:se,anisotropy:R,anisotropyMap:fe,clearcoat:z,clearcoatMap:pe,clearcoatNormalMap:me,clearcoatRoughnessMap:he,dispersion:ce,iridescence:le,iridescenceMap:ge,iridescenceThicknessMap:_e,sheen:ue,sheenColorMap:ve,sheenRoughnessMap:ye,specularMap:B,specularColorMap:be,specularIntensityMap:xe,transmission:de,transmissionMap:Se,thicknessMap:Ce,gradientMap:we,opaque:i.transparent===!1&&i.blending===1&&i.alphaToCoverage===!1,alphaMap:Te,alphaTest:Ee,alphaHash:De,combine:i.combine,mapUv:P&&m(i.map.channel),aoMapUv:ne&&m(i.aoMap.channel),lightMapUv:re&&m(i.lightMap.channel),bumpMapUv:I&&m(i.bumpMap.channel),normalMapUv:L&&m(i.normalMap.channel),displacementMapUv:ie&&m(i.displacementMap.channel),emissiveMapUv:ae&&m(i.emissiveMap.channel),metalnessMapUv:oe&&m(i.metalnessMap.channel),roughnessMapUv:se&&m(i.roughnessMap.channel),anisotropyMapUv:fe&&m(i.anisotropyMap.channel),clearcoatMapUv:pe&&m(i.clearcoatMap.channel),clearcoatNormalMapUv:me&&m(i.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:he&&m(i.clearcoatRoughnessMap.channel),iridescenceMapUv:ge&&m(i.iridescenceMap.channel),iridescenceThicknessMapUv:_e&&m(i.iridescenceThicknessMap.channel),sheenColorMapUv:ve&&m(i.sheenColorMap.channel),sheenRoughnessMapUv:ye&&m(i.sheenRoughnessMap.channel),specularMapUv:B&&m(i.specularMap.channel),specularColorMapUv:be&&m(i.specularColorMap.channel),specularIntensityMapUv:xe&&m(i.specularIntensityMap.channel),transmissionMapUv:Se&&m(i.transmissionMap.channel),thicknessMapUv:Ce&&m(i.thicknessMap.channel),alphaMapUv:Te&&m(i.alphaMap.channel),vertexTangents:!!v.attributes.tangent&&(L||R),vertexNormals:!!v.attributes.normal,vertexColors:i.vertexColors,vertexAlphas:i.vertexColors===!0&&!!v.attributes.color&&v.attributes.color.itemSize===4,pointsUvs:h.isPoints===!0&&!!v.attributes.uv&&(P||Te),fog:!!_,useFog:i.fog===!0,fogExp2:!!_&&_.isFogExp2,flatShading:i.wireframe===!1&&(i.flatShading===!0||v.attributes.normal===void 0&&L===!1&&(i.isMeshLambertMaterial||i.isMeshPhongMaterial||i.isMeshStandardMaterial||i.isMeshPhysicalMaterial)),sizeAttenuation:i.sizeAttenuation===!0,logarithmicDepthBuffer:d,reversedDepthBuffer:ee,skinning:h.isSkinnedMesh===!0,hasPositionAttribute:v.attributes.position!==void 0,morphTargets:v.morphAttributes.position!==void 0,morphNormals:v.morphAttributes.normal!==void 0,morphColors:v.morphAttributes.color!==void 0,morphTargetsCount:T,morphTextureStride:E,numDirLights:o.directional.length,numPointLights:o.point.length,numSpotLights:o.spot.length,numSpotLightMaps:o.spotLightMap.length,numRectAreaLights:o.rectArea.length,numHemiLights:o.hemi.length,numDirLightShadows:o.directionalShadowMap.length,numPointLightShadows:o.pointShadowMap.length,numSpotLightShadows:o.spotShadowMap.length,numSpotLightShadowsWithMaps:o.numSpotLightShadowsWithMaps,numLightProbes:o.numLightProbes,numLightProbeGrids:g.length,numClippingPlanes:a.numPlanes,numClipIntersection:a.numIntersection,dithering:i.dithering,shadowMapEnabled:e.shadowMap.enabled&&l.length>0,shadowMapType:e.shadowMap.type,toneMapping:H,decodeVideoTexture:P&&i.map.isVideoTexture===!0&&ze.getTransfer(i.map.colorSpace)===`srgb`,decodeVideoTextureEmissive:ae&&i.emissiveMap.isVideoTexture===!0&&ze.getTransfer(i.emissiveMap.colorSpace)===`srgb`,premultipliedAlpha:i.premultipliedAlpha,doubleSided:i.side===2,flipSided:i.side===1,useDepthPacking:i.depthPacking>=0,depthPacking:i.depthPacking||0,index0AttributeName:i.index0AttributeName,extensionClipCullDistance:Oe&&i.extensions.clipCullDistance===!0&&n.has(`WEBGL_clip_cull_distance`),extensionMultiDraw:(Oe&&i.extensions.multiDraw===!0||N)&&n.has(`WEBGL_multi_draw`),rendererExtensionParallelShaderCompile:n.has(`KHR_parallel_shader_compile`),customProgramCacheKey:i.customProgramCacheKey()};return ke.vertexUv1s=c.has(1),ke.vertexUv2s=c.has(2),ke.vertexUv3s=c.has(3),c.clear(),ke}function g(t){let n=[];if(t.shaderID?n.push(t.shaderID):(n.push(t.customVertexShaderID),n.push(t.customFragmentShaderID)),t.defines!==void 0)for(let e in t.defines)n.push(e),n.push(t.defines[e]);return t.isRawShaderMaterial===!1&&(_(n,t),v(n,t),n.push(e.outputColorSpace)),n.push(t.customProgramCacheKey),n.join()}function _(e,t){e.push(t.precision),e.push(t.outputColorSpace),e.push(t.envMapMode),e.push(t.envMapCubeUVHeight),e.push(t.mapUv),e.push(t.alphaMapUv),e.push(t.lightMapUv),e.push(t.aoMapUv),e.push(t.bumpMapUv),e.push(t.normalMapUv),e.push(t.displacementMapUv),e.push(t.emissiveMapUv),e.push(t.metalnessMapUv),e.push(t.roughnessMapUv),e.push(t.anisotropyMapUv),e.push(t.clearcoatMapUv),e.push(t.clearcoatNormalMapUv),e.push(t.clearcoatRoughnessMapUv),e.push(t.iridescenceMapUv),e.push(t.iridescenceThicknessMapUv),e.push(t.sheenColorMapUv),e.push(t.sheenRoughnessMapUv),e.push(t.specularMapUv),e.push(t.specularColorMapUv),e.push(t.specularIntensityMapUv),e.push(t.transmissionMapUv),e.push(t.thicknessMapUv),e.push(t.combine),e.push(t.fogExp2),e.push(t.sizeAttenuation),e.push(t.morphTargetsCount),e.push(t.morphAttributeCount),e.push(t.numDirLights),e.push(t.numPointLights),e.push(t.numSpotLights),e.push(t.numSpotLightMaps),e.push(t.numHemiLights),e.push(t.numRectAreaLights),e.push(t.numDirLightShadows),e.push(t.numPointLightShadows),e.push(t.numSpotLightShadows),e.push(t.numSpotLightShadowsWithMaps),e.push(t.numLightProbes),e.push(t.shadowMapType),e.push(t.toneMapping),e.push(t.numClippingPlanes),e.push(t.numClipIntersection),e.push(t.depthPacking)}function v(e,t){o.disableAll(),t.instancing&&o.enable(0),t.instancingColor&&o.enable(1),t.instancingMorph&&o.enable(2),t.matcap&&o.enable(3),t.envMap&&o.enable(4),t.normalMapObjectSpace&&o.enable(5),t.normalMapTangentSpace&&o.enable(6),t.clearcoat&&o.enable(7),t.iridescence&&o.enable(8),t.alphaTest&&o.enable(9),t.vertexColors&&o.enable(10),t.vertexAlphas&&o.enable(11),t.vertexUv1s&&o.enable(12),t.vertexUv2s&&o.enable(13),t.vertexUv3s&&o.enable(14),t.vertexTangents&&o.enable(15),t.anisotropy&&o.enable(16),t.alphaHash&&o.enable(17),t.batching&&o.enable(18),t.dispersion&&o.enable(19),t.batchingColor&&o.enable(20),t.gradientMap&&o.enable(21),t.packedNormalMap&&o.enable(22),t.vertexNormals&&o.enable(23),e.push(o.mask),o.disableAll(),t.fog&&o.enable(0),t.useFog&&o.enable(1),t.flatShading&&o.enable(2),t.logarithmicDepthBuffer&&o.enable(3),t.reversedDepthBuffer&&o.enable(4),t.skinning&&o.enable(5),t.morphTargets&&o.enable(6),t.morphNormals&&o.enable(7),t.morphColors&&o.enable(8),t.premultipliedAlpha&&o.enable(9),t.shadowMapEnabled&&o.enable(10),t.doubleSided&&o.enable(11),t.flipSided&&o.enable(12),t.useDepthPacking&&o.enable(13),t.dithering&&o.enable(14),t.transmission&&o.enable(15),t.sheen&&o.enable(16),t.opaque&&o.enable(17),t.pointsUvs&&o.enable(18),t.decodeVideoTexture&&o.enable(19),t.decodeVideoTextureEmissive&&o.enable(20),t.alphaToCoverage&&o.enable(21),t.numLightProbeGrids>0&&o.enable(22),t.hasPositionAttribute&&o.enable(23),e.push(o.mask)}function y(e){let t=p[e.type],n;if(t){let e=on[t];n=Ht.clone(e.uniforms)}else n=e.uniforms;return n}function b(t,n){let r=u.get(n);return r===void 0?(r=new Ni(e,n,t,i),l.push(r),u.set(n,r)):++r.usedTimes,r}function x(e){if(--e.usedTimes===0){let t=l.indexOf(e);l[t]=l[l.length-1],l.pop(),u.delete(e.cacheKey),e.destroy()}}function S(e){s.remove(e)}function C(){s.dispose()}return{getParameters:h,getProgramCacheKey:g,getUniforms:y,acquireProgram:b,releaseProgram:x,releaseShaderCache:S,programs:l,dispose:C}}function zi(){let e=new WeakMap;function t(t){return e.has(t)}function n(t){let n=e.get(t);return n===void 0&&(n={},e.set(t,n)),n}function r(t){e.delete(t)}function i(t,n,r){e.get(t)[n]=r}function a(){e=new WeakMap}return{has:t,get:n,remove:r,update:i,dispose:a}}function Bi(e,t){return e.groupOrder===t.groupOrder?e.renderOrder===t.renderOrder?e.material.id===t.material.id?e.materialVariant===t.materialVariant?e.z===t.z?e.id-t.id:e.z-t.z:e.materialVariant-t.materialVariant:e.material.id-t.material.id:e.renderOrder-t.renderOrder:e.groupOrder-t.groupOrder}function Vi(e,t){return e.groupOrder===t.groupOrder?e.renderOrder===t.renderOrder?e.z===t.z?e.id-t.id:t.z-e.z:e.renderOrder-t.renderOrder:e.groupOrder-t.groupOrder}function Hi(){let e=[],t=0,n=[],r=[],i=[];function a(){t=0,n.length=0,r.length=0,i.length=0}function o(e){let t=0;return e.isInstancedMesh&&(t+=2),e.isSkinnedMesh&&(t+=1),t}function s(n,r,i,a,s,c){let l=e[t];return l===void 0?(l={id:n.id,object:n,geometry:r,material:i,materialVariant:o(n),groupOrder:a,renderOrder:n.renderOrder,z:s,group:c},e[t]=l):(l.id=n.id,l.object=n,l.geometry=r,l.material=i,l.materialVariant=o(n),l.groupOrder=a,l.renderOrder=n.renderOrder,l.z=s,l.group=c),t++,l}function c(e,t,a,o,c,l){let u=s(e,t,a,o,c,l);a.transmission>0?r.push(u):a.transparent===!0?i.push(u):n.push(u)}function l(e,t,a,o,c,l){let u=s(e,t,a,o,c,l);a.transmission>0?r.unshift(u):a.transparent===!0?i.unshift(u):n.unshift(u)}function u(e,t,a){n.length>1&&n.sort(e||Bi),r.length>1&&r.sort(t||Vi),i.length>1&&i.sort(t||Vi),a&&(n.reverse(),r.reverse(),i.reverse())}function d(){for(let n=t,r=e.length;n<r;n++){let t=e[n];if(t.id===null)break;t.id=null,t.object=null,t.geometry=null,t.material=null,t.group=null}}return{opaque:n,transmissive:r,transparent:i,init:a,push:c,unshift:l,finish:d,sort:u}}function Ui(){let e=new WeakMap;function t(t,n){let r=e.get(t),i;return r===void 0?(i=new Hi,e.set(t,[i])):n>=r.length?(i=new Hi,r.push(i)):i=r[n],i}function n(){e=new WeakMap}return{get:t,dispose:n}}function Wi(){let e={};return{get:function(t){if(e[t.id]!==void 0)return e[t.id];let n;switch(t.type){case`DirectionalLight`:n={direction:new R,color:new q};break;case`SpotLight`:n={position:new R,direction:new R,color:new q,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case`PointLight`:n={position:new R,color:new q,distance:0,decay:0};break;case`HemisphereLight`:n={direction:new R,skyColor:new q,groundColor:new q};break;case`RectAreaLight`:n={color:new q,position:new R,halfWidth:new R,halfHeight:new R}}return e[t.id]=n,n}}}function Gi(){let e={};return{get:function(t){if(e[t.id]!==void 0)return e[t.id];let n;switch(t.type){case`DirectionalLight`:n={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new m};break;case`SpotLight`:n={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new m};break;case`PointLight`:n={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new m,shadowCameraNear:1,shadowCameraFar:1e3}}return e[t.id]=n,n}}}var Ki=0;function qi(e,t){return(t.castShadow?2:0)-(e.castShadow?2:0)+ +!!t.map-!!e.map}function Ji(e){let t=new Wi,n=Gi(),r={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let e=0;e<9;e++)r.probe.push(new R);let i=new R,a=new h,o=new h;function s(i){let a=0,o=0,s=0;for(let e=0;e<9;e++)r.probe[e].set(0,0,0);let c=0,l=0,u=0,d=0,f=0,p=0,m=0,h=0,g=0,_=0,v=0;i.sort(qi);for(let e=0,y=i.length;e<y;e++){let y=i[e],b=y.color,x=y.intensity,S=y.distance,C=null;if(y.shadow&&y.shadow.map&&(C=y.shadow.map.texture.format===1030?y.shadow.map.texture:y.shadow.map.depthTexture||y.shadow.map.texture),y.isAmbientLight)a+=b.r*x,o+=b.g*x,s+=b.b*x;else if(y.isLightProbe){for(let e=0;e<9;e++)r.probe[e].addScaledVector(y.sh.coefficients[e],x);v++}else if(y.isDirectionalLight){let e=t.get(y);if(e.color.copy(y.color).multiplyScalar(y.intensity),y.castShadow){let e=y.shadow,t=n.get(y);t.shadowIntensity=e.intensity,t.shadowBias=e.bias,t.shadowNormalBias=e.normalBias,t.shadowRadius=e.radius,t.shadowMapSize=e.mapSize,r.directionalShadow[c]=t,r.directionalShadowMap[c]=C,r.directionalShadowMatrix[c]=y.shadow.matrix,p++}r.directional[c]=e,c++}else if(y.isSpotLight){let e=t.get(y);e.position.setFromMatrixPosition(y.matrixWorld),e.color.copy(b).multiplyScalar(x),e.distance=S,e.coneCos=Math.cos(y.angle),e.penumbraCos=Math.cos(y.angle*(1-y.penumbra)),e.decay=y.decay,r.spot[u]=e;let i=y.shadow;if(y.map&&(r.spotLightMap[g]=y.map,g++,i.updateMatrices(y),y.castShadow&&_++),r.spotLightMatrix[u]=i.matrix,y.castShadow){let e=n.get(y);e.shadowIntensity=i.intensity,e.shadowBias=i.bias,e.shadowNormalBias=i.normalBias,e.shadowRadius=i.radius,e.shadowMapSize=i.mapSize,r.spotShadow[u]=e,r.spotShadowMap[u]=C,h++}u++}else if(y.isRectAreaLight){let e=t.get(y);e.color.copy(b).multiplyScalar(x),e.halfWidth.set(y.width*.5,0,0),e.halfHeight.set(0,y.height*.5,0),r.rectArea[d]=e,d++}else if(y.isPointLight){let e=t.get(y);if(e.color.copy(y.color).multiplyScalar(y.intensity),e.distance=y.distance,e.decay=y.decay,y.castShadow){let e=y.shadow,t=n.get(y);t.shadowIntensity=e.intensity,t.shadowBias=e.bias,t.shadowNormalBias=e.normalBias,t.shadowRadius=e.radius,t.shadowMapSize=e.mapSize,t.shadowCameraNear=e.camera.near,t.shadowCameraFar=e.camera.far,r.pointShadow[l]=t,r.pointShadowMap[l]=C,r.pointShadowMatrix[l]=y.shadow.matrix,m++}r.point[l]=e,l++}else if(y.isHemisphereLight){let e=t.get(y);e.skyColor.copy(y.color).multiplyScalar(x),e.groundColor.copy(y.groundColor).multiplyScalar(x),r.hemi[f]=e,f++}}d>0&&(e.has(`OES_texture_float_linear`)===!0?(r.rectAreaLTC1=J.LTC_FLOAT_1,r.rectAreaLTC2=J.LTC_FLOAT_2):(r.rectAreaLTC1=J.LTC_HALF_1,r.rectAreaLTC2=J.LTC_HALF_2)),r.ambient[0]=a,r.ambient[1]=o,r.ambient[2]=s;let y=r.hash;(y.directionalLength!==c||y.pointLength!==l||y.spotLength!==u||y.rectAreaLength!==d||y.hemiLength!==f||y.numDirectionalShadows!==p||y.numPointShadows!==m||y.numSpotShadows!==h||y.numSpotMaps!==g||y.numLightProbes!==v)&&(r.directional.length=c,r.spot.length=u,r.rectArea.length=d,r.point.length=l,r.hemi.length=f,r.directionalShadow.length=p,r.directionalShadowMap.length=p,r.pointShadow.length=m,r.pointShadowMap.length=m,r.spotShadow.length=h,r.spotShadowMap.length=h,r.directionalShadowMatrix.length=p,r.pointShadowMatrix.length=m,r.spotLightMatrix.length=h+g-_,r.spotLightMap.length=g,r.numSpotLightShadowsWithMaps=_,r.numLightProbes=v,y.directionalLength=c,y.pointLength=l,y.spotLength=u,y.rectAreaLength=d,y.hemiLength=f,y.numDirectionalShadows=p,y.numPointShadows=m,y.numSpotShadows=h,y.numSpotMaps=g,y.numLightProbes=v,r.version=Ki++)}function c(e,t){let n=0,s=0,c=0,l=0,u=0,d=t.matrixWorldInverse;for(let t=0,f=e.length;t<f;t++){let f=e[t];if(f.isDirectionalLight){let e=r.directional[n];e.direction.setFromMatrixPosition(f.matrixWorld),i.setFromMatrixPosition(f.target.matrixWorld),e.direction.sub(i),e.direction.transformDirection(d),n++}else if(f.isSpotLight){let e=r.spot[c];e.position.setFromMatrixPosition(f.matrixWorld),e.position.applyMatrix4(d),e.direction.setFromMatrixPosition(f.matrixWorld),i.setFromMatrixPosition(f.target.matrixWorld),e.direction.sub(i),e.direction.transformDirection(d),c++}else if(f.isRectAreaLight){let e=r.rectArea[l];e.position.setFromMatrixPosition(f.matrixWorld),e.position.applyMatrix4(d),o.identity(),a.copy(f.matrixWorld),a.premultiply(d),o.extractRotation(a),e.halfWidth.set(f.width*.5,0,0),e.halfHeight.set(0,f.height*.5,0),e.halfWidth.applyMatrix4(o),e.halfHeight.applyMatrix4(o),l++}else if(f.isPointLight){let e=r.point[s];e.position.setFromMatrixPosition(f.matrixWorld),e.position.applyMatrix4(d),s++}else if(f.isHemisphereLight){let e=r.hemi[u];e.direction.setFromMatrixPosition(f.matrixWorld),e.direction.transformDirection(d),u++}}}return{setup:s,setupView:c,state:r}}function Yi(e){let t=new Ji(e),n=[],r=[],i=[];function a(e){d.camera=e,n.length=0,r.length=0,i.length=0}function o(e){n.push(e)}function s(e){r.push(e)}function c(e){i.push(e)}function l(){t.setup(n)}function u(e){t.setupView(n,e)}let d={lightsArray:n,shadowsArray:r,lightProbeGridArray:i,camera:null,lights:t,transmissionRenderTarget:{},textureUnits:0};return{init:a,state:d,setupLights:l,setupLightsView:u,pushLight:o,pushShadow:s,pushLightProbeGrid:c}}function Xi(e){let t=new WeakMap;function n(n,r=0){let i=t.get(n),a;return i===void 0?(a=new Yi(e),t.set(n,[a])):r>=i.length?(a=new Yi(e),i.push(a)):a=i[r],a}function r(){t=new WeakMap}return{get:n,dispose:r}}var Zi=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,Qi=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ).rg;
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ).r;
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( max( 0.0, squared_mean - mean * mean ) );
	gl_FragColor = vec4( mean, std_dev, 0.0, 1.0 );
}`,$i=[new R(1,0,0),new R(-1,0,0),new R(0,1,0),new R(0,-1,0),new R(0,0,1),new R(0,0,-1)],ea=[new R(0,-1,0),new R(0,-1,0),new R(0,0,1),new R(0,0,-1),new R(0,-1,0),new R(0,-1,0)],ta=new h,na=new R,ra=new R;function ia(e,t,n){let r=new Dt,i=new m,o=new m,s=new ut,c=new a,l=new ct,f={},p=n.maxTextureSize,h={0:1,1:0,2:2},g=new Je({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new m},radius:{value:4}},vertexShader:Zi,fragmentShader:Qi}),_=g.clone();_.defines.HORIZONTAL_PASS=1;let v=new We;v.setAttribute(`position`,new Rt(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));let y=new z(v,g),b=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=1;let x=this.type;this.render=function(t,n,a){if(b.enabled===!1||b.autoUpdate===!1&&b.needsUpdate===!1||t.length===0)return;this.type===2&&(V(`WebGLShadowMap: PCFSoftShadowMap has been deprecated. Using PCFShadowMap instead.`),this.type=1);let c=e.getRenderTarget(),l=e.getActiveCubeFace(),f=e.getActiveMipmapLevel(),m=e.state;m.setBlending(0),m.buffers.depth.getReversed()===!0?m.buffers.color.setClear(0,0,0,0):m.buffers.color.setClear(1,1,1,1),m.buffers.depth.setTest(!0),m.setScissorTest(!1);let h=x!==this.type;h&&n.traverse(function(e){e.material&&(Array.isArray(e.material)?e.material.forEach(e=>e.needsUpdate=!0):e.material.needsUpdate=!0)});for(let c=0,l=t.length;c<l;c++){let l=t[c],f=l.shadow;if(f===void 0){V(`WebGLShadowMap:`,l,`has no shadow.`);continue}if(f.autoUpdate===!1&&f.needsUpdate===!1)continue;i.copy(f.mapSize);let g=f.getFrameExtents();i.multiply(g),o.copy(f.mapSize),(i.x>p||i.y>p)&&(i.x>p&&(o.x=Math.floor(p/g.x),i.x=o.x*g.x,f.mapSize.x=o.x),i.y>p&&(o.y=Math.floor(p/g.y),i.y=o.y*g.y,f.mapSize.y=o.y));let _=e.state.buffers.depth.getReversed();if(f.camera._reversedDepth=_,f.map===null||h===!0){if(f.map!==null&&(f.map.depthTexture!==null&&(f.map.depthTexture.dispose(),f.map.depthTexture=null),f.map.dispose()),this.type===3){if(l.isPointLight){V(`WebGLShadowMap: VSM shadow maps are not supported for PointLights. Use PCF or BasicShadowMap instead.`);continue}f.map=new I(i.x,i.y,{format:te,type:ke,minFilter:gt,magFilter:gt,generateMipmaps:!1}),f.map.texture.name=l.name+`.shadowMap`,f.map.depthTexture=new ie(i.x,i.y,De),f.map.depthTexture.name=l.name+`.shadowMapDepth`,f.map.depthTexture.format=ot,f.map.depthTexture.compareFunction=null,f.map.depthTexture.minFilter=ne,f.map.depthTexture.magFilter=ne}else l.isPointLight?(f.map=new Fn(i.x),f.map.depthTexture=new u(i.x,d)):(f.map=new I(i.x,i.y),f.map.depthTexture=new ie(i.x,i.y,d)),f.map.depthTexture.name=l.name+`.shadowMap`,f.map.depthTexture.format=ot,this.type===1?(f.map.depthTexture.compareFunction=_?518:515,f.map.depthTexture.minFilter=gt,f.map.depthTexture.magFilter=gt):(f.map.depthTexture.compareFunction=null,f.map.depthTexture.minFilter=ne,f.map.depthTexture.magFilter=ne);f.camera.updateProjectionMatrix()}let v=f.map.isWebGLCubeRenderTarget?6:1;for(let t=0;t<v;t++){if(f.map.isWebGLCubeRenderTarget)e.setRenderTarget(f.map,t),e.clear();else{t===0&&(e.setRenderTarget(f.map),e.clear());let n=f.getViewport(t);s.set(o.x*n.x,o.y*n.y,o.x*n.z,o.y*n.w),m.viewport(s)}if(l.isPointLight){let e=f.camera,n=f.matrix,r=l.distance||e.far;r!==e.far&&(e.far=r,e.updateProjectionMatrix()),na.setFromMatrixPosition(l.matrixWorld),e.position.copy(na),ra.copy(e.position),ra.add($i[t]),e.up.copy(ea[t]),e.lookAt(ra),e.updateMatrixWorld(),n.makeTranslation(-na.x,-na.y,-na.z),ta.multiplyMatrices(e.projectionMatrix,e.matrixWorldInverse),f._frustum.setFromProjectionMatrix(ta,e.coordinateSystem,e.reversedDepth)}else f.updateMatrices(l);r=f.getFrustum(),w(n,a,f.camera,l,this.type)}f.isPointLightShadow!==!0&&this.type===3&&S(f,a),f.needsUpdate=!1}x=this.type,b.needsUpdate=!1,e.setRenderTarget(c,l,f)};function S(n,r){let a=t.update(y);g.defines.VSM_SAMPLES!==n.blurSamples&&(g.defines.VSM_SAMPLES=n.blurSamples,_.defines.VSM_SAMPLES=n.blurSamples,g.needsUpdate=!0,_.needsUpdate=!0),n.mapPass===null&&(n.mapPass=new I(i.x,i.y,{format:te,type:ke})),g.uniforms.shadow_pass.value=n.map.depthTexture,g.uniforms.resolution.value=n.mapSize,g.uniforms.radius.value=n.radius,e.setRenderTarget(n.mapPass),e.clear(),e.renderBufferDirect(r,null,a,g,y,null),_.uniforms.shadow_pass.value=n.mapPass.texture,_.uniforms.resolution.value=n.mapSize,_.uniforms.radius.value=n.radius,e.setRenderTarget(n.map),e.clear(),e.renderBufferDirect(r,null,a,_,y,null)}function C(t,n,r,i){let a=null,o=r.isPointLight===!0?t.customDistanceMaterial:t.customDepthMaterial;if(o!==void 0)a=o;else if(a=r.isPointLight===!0?l:c,e.localClippingEnabled&&n.clipShadows===!0&&Array.isArray(n.clippingPlanes)&&n.clippingPlanes.length!==0||n.displacementMap&&n.displacementScale!==0||n.alphaMap&&n.alphaTest>0||n.map&&n.alphaTest>0||n.alphaToCoverage===!0){let e=a.uuid,t=n.uuid,r=f[e];r===void 0&&(r={},f[e]=r);let i=r[t];i===void 0&&(i=a.clone(),r[t]=i,n.addEventListener(`dispose`,T)),a=i}if(a.visible=n.visible,a.wireframe=n.wireframe,i===3?a.side=n.shadowSide===null?n.side:n.shadowSide:a.side=n.shadowSide===null?h[n.side]:n.shadowSide,a.alphaMap=n.alphaMap,a.alphaTest=n.alphaToCoverage===!0?.5:n.alphaTest,a.map=n.map,a.clipShadows=n.clipShadows,a.clippingPlanes=n.clippingPlanes,a.clipIntersection=n.clipIntersection,a.displacementMap=n.displacementMap,a.displacementScale=n.displacementScale,a.displacementBias=n.displacementBias,a.wireframeLinewidth=n.wireframeLinewidth,a.linewidth=n.linewidth,r.isPointLight===!0&&a.isMeshDistanceMaterial===!0){let t=e.properties.get(a);t.light=r}return a}function w(n,i,a,o,s){if(n.visible===!1)return;if(n.layers.test(i.layers)&&(n.isMesh||n.isLine||n.isPoints)&&(n.castShadow||n.receiveShadow&&s===3)&&(!n.frustumCulled||r.intersectsObject(n))){n.modelViewMatrix.multiplyMatrices(a.matrixWorldInverse,n.matrixWorld);let r=t.update(n),c=n.material;if(Array.isArray(c)){let t=r.groups;for(let l=0,u=t.length;l<u;l++){let u=t[l],d=c[u.materialIndex];if(d&&d.visible){let t=C(n,d,o,s);n.onBeforeShadow(e,n,i,a,r,t,u),e.renderBufferDirect(a,null,r,t,n,u),n.onAfterShadow(e,n,i,a,r,t,u)}}}else if(c.visible){let t=C(n,c,o,s);n.onBeforeShadow(e,n,i,a,r,t,null),e.renderBufferDirect(a,null,r,t,n,null),n.onAfterShadow(e,n,i,a,r,t,null)}}let c=n.children;for(let e=0,t=c.length;e<t;e++)w(c[e],i,a,o,s)}function T(e){e.target.removeEventListener(`dispose`,T);for(let t in f){let n=f[t],r=e.target.uuid;r in n&&(n[r].dispose(),delete n[r])}}}function aa(e,t){function n(){let t=!1,n=new ut,r=null,i=new ut(0,0,0,0);return{setMask:function(n){r!==n&&!t&&(e.colorMask(n,n,n,n),r=n)},setLocked:function(e){t=e},setClear:function(t,r,a,o,s){s===!0&&(t*=o,r*=o,a*=o),n.set(t,r,a,o),i.equals(n)===!1&&(e.clearColor(t,r,a,o),i.copy(n))},reset:function(){t=!1,r=null,i.set(-1,0,0,0)}}}function r(){let n=!1,r=!1,i=null,a=null,o=null;return{setReversed:function(e){if(r!==e){let n=t.get(`EXT_clip_control`);e?n.clipControlEXT(n.LOWER_LEFT_EXT,n.ZERO_TO_ONE_EXT):n.clipControlEXT(n.LOWER_LEFT_EXT,n.NEGATIVE_ONE_TO_ONE_EXT),r=e;let i=o;o=null,this.setClear(i)}},getReversed:function(){return r},setTest:function(t){t?R(e.DEPTH_TEST):z(e.DEPTH_TEST)},setMask:function(t){i!==t&&!n&&(e.depthMask(t),i=t)},setFunc:function(t){if(r&&(t=C[t]),a!==t){switch(t){case 0:e.depthFunc(e.NEVER);break;case 1:e.depthFunc(e.ALWAYS);break;case 2:e.depthFunc(e.LESS);break;case 3:e.depthFunc(e.LEQUAL);break;case 4:e.depthFunc(e.EQUAL);break;case 5:e.depthFunc(e.GEQUAL);break;case 6:e.depthFunc(e.GREATER);break;case 7:e.depthFunc(e.NOTEQUAL);break;default:e.depthFunc(e.LEQUAL)}a=t}},setLocked:function(e){n=e},setClear:function(t){o!==t&&(o=t,r&&(t=1-t),e.clearDepth(t))},reset:function(){n=!1,i=null,a=null,o=null,r=!1}}}function i(){let t=!1,n=null,r=null,i=null,a=null,o=null,s=null,c=null,l=null;return{setTest:function(n){t||(n?R(e.STENCIL_TEST):z(e.STENCIL_TEST))},setMask:function(r){n!==r&&!t&&(e.stencilMask(r),n=r)},setFunc:function(t,n,o){(r!==t||i!==n||a!==o)&&(e.stencilFunc(t,n,o),r=t,i=n,a=o)},setOp:function(t,n,r){(o!==t||s!==n||c!==r)&&(e.stencilOp(t,n,r),o=t,s=n,c=r)},setLocked:function(e){t=e},setClear:function(t){l!==t&&(e.clearStencil(t),l=t)},reset:function(){t=!1,n=null,r=null,i=null,a=null,o=null,s=null,c=null,l=null}}}let a=new n,o=new r,s=new i,c=new WeakMap,l=new WeakMap,u={},d={},f={},p=new WeakMap,m=[],h=null,g=!1,_=null,v=null,y=null,b=null,x=null,S=null,w=null,T=new q(0,0,0),E=0,D=!1,O=null,k=null,A=null,j=null,ee=null,M=e.getParameter(e.MAX_COMBINED_TEXTURE_IMAGE_UNITS),N=!1,P=0,te=e.getParameter(e.VERSION);te.indexOf(`WebGL`)===-1?te.indexOf(`OpenGL ES`)!==-1&&(P=parseFloat(/^OpenGL ES (\d)/.exec(te)[1]),N=P>=2):(P=parseFloat(/^WebGL (\d)/.exec(te)[1]),N=P>=1);let ne=null,re={},I=e.getParameter(e.SCISSOR_BOX),L=e.getParameter(e.VIEWPORT),ie=new ut().fromArray(I),ae=new ut().fromArray(L);function oe(t,n,r,i){let a=new Uint8Array(4),o=e.createTexture();e.bindTexture(t,o),e.texParameteri(t,e.TEXTURE_MIN_FILTER,e.NEAREST),e.texParameteri(t,e.TEXTURE_MAG_FILTER,e.NEAREST);for(let o=0;o<r;o++)t===e.TEXTURE_3D||t===e.TEXTURE_2D_ARRAY?e.texImage3D(n,0,e.RGBA,1,1,i,0,e.RGBA,e.UNSIGNED_BYTE,a):e.texImage2D(n+o,0,e.RGBA,1,1,0,e.RGBA,e.UNSIGNED_BYTE,a);return o}let se={};se[e.TEXTURE_2D]=oe(e.TEXTURE_2D,e.TEXTURE_2D,1),se[e.TEXTURE_CUBE_MAP]=oe(e.TEXTURE_CUBE_MAP,e.TEXTURE_CUBE_MAP_POSITIVE_X,6),se[e.TEXTURE_2D_ARRAY]=oe(e.TEXTURE_2D_ARRAY,e.TEXTURE_2D_ARRAY,1,1),se[e.TEXTURE_3D]=oe(e.TEXTURE_3D,e.TEXTURE_3D,1,1),a.setClear(0,0,0,1),o.setClear(1),s.setClear(0),R(e.DEPTH_TEST),o.setFunc(3),he(!1),ge(1),R(e.CULL_FACE),pe(0);function R(t){u[t]!==!0&&(e.enable(t),u[t]=!0)}function z(t){u[t]!==!1&&(e.disable(t),u[t]=!1)}function ce(t,n){return f[t]!==n&&(e.bindFramebuffer(t,n),f[t]=n,t===e.DRAW_FRAMEBUFFER&&(f[e.FRAMEBUFFER]=n),t===e.FRAMEBUFFER&&(f[e.DRAW_FRAMEBUFFER]=n),!0)}function le(t,n){let r=m,i=!1;if(t){r=p.get(n),r===void 0&&(r=[],p.set(n,r));let a=t.textures;if(r.length!==a.length||r[0]!==e.COLOR_ATTACHMENT0){for(let t=0,n=a.length;t<n;t++)r[t]=e.COLOR_ATTACHMENT0+t;r.length=a.length,i=!0}}else r[0]!==e.BACK&&(r[0]=e.BACK,i=!0);i&&e.drawBuffers(r)}function ue(t){return h!==t&&(e.useProgram(t),h=t,!0)}let de={100:e.FUNC_ADD,101:e.FUNC_SUBTRACT,102:e.FUNC_REVERSE_SUBTRACT};de[103]=e.MIN,de[104]=e.MAX;let fe={200:e.ZERO,201:e.ONE,202:e.SRC_COLOR,204:e.SRC_ALPHA,210:e.SRC_ALPHA_SATURATE,208:e.DST_COLOR,206:e.DST_ALPHA,203:e.ONE_MINUS_SRC_COLOR,205:e.ONE_MINUS_SRC_ALPHA,209:e.ONE_MINUS_DST_COLOR,207:e.ONE_MINUS_DST_ALPHA,211:e.CONSTANT_COLOR,212:e.ONE_MINUS_CONSTANT_COLOR,213:e.CONSTANT_ALPHA,214:e.ONE_MINUS_CONSTANT_ALPHA};function pe(t,n,r,i,a,o,s,c,l,u){if(t===0){g===!0&&(z(e.BLEND),g=!1);return}if(g===!1&&(R(e.BLEND),g=!0),t!==5){if(t!==_||u!==D){if((v!==100||x!==100)&&(e.blendEquation(e.FUNC_ADD),v=100,x=100),u)switch(t){case 1:e.blendFuncSeparate(e.ONE,e.ONE_MINUS_SRC_ALPHA,e.ONE,e.ONE_MINUS_SRC_ALPHA);break;case 2:e.blendFunc(e.ONE,e.ONE);break;case 3:e.blendFuncSeparate(e.ZERO,e.ONE_MINUS_SRC_COLOR,e.ZERO,e.ONE);break;case 4:e.blendFuncSeparate(e.DST_COLOR,e.ONE_MINUS_SRC_ALPHA,e.ZERO,e.ONE);break;default:F(`WebGLState: Invalid blending: `,t)}else switch(t){case 1:e.blendFuncSeparate(e.SRC_ALPHA,e.ONE_MINUS_SRC_ALPHA,e.ONE,e.ONE_MINUS_SRC_ALPHA);break;case 2:e.blendFuncSeparate(e.SRC_ALPHA,e.ONE,e.ONE,e.ONE);break;case 3:F(`WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true`);break;case 4:F(`WebGLState: MultiplyBlending requires material.premultipliedAlpha = true`);break;default:F(`WebGLState: Invalid blending: `,t)}y=null,b=null,S=null,w=null,T.set(0,0,0),E=0,_=t,D=u}return}a||=n,o||=r,s||=i,(n!==v||a!==x)&&(e.blendEquationSeparate(de[n],de[a]),v=n,x=a),(r!==y||i!==b||o!==S||s!==w)&&(e.blendFuncSeparate(fe[r],fe[i],fe[o],fe[s]),y=r,b=i,S=o,w=s),(c.equals(T)===!1||l!==E)&&(e.blendColor(c.r,c.g,c.b,l),T.copy(c),E=l),_=t,D=!1}function me(t,n){t.side===2?z(e.CULL_FACE):R(e.CULL_FACE);let r=t.side===1;n&&(r=!r),he(r),t.blending===1&&t.transparent===!1?pe(0):pe(t.blending,t.blendEquation,t.blendSrc,t.blendDst,t.blendEquationAlpha,t.blendSrcAlpha,t.blendDstAlpha,t.blendColor,t.blendAlpha,t.premultipliedAlpha),o.setFunc(t.depthFunc),o.setTest(t.depthTest),o.setMask(t.depthWrite),a.setMask(t.colorWrite);let i=t.stencilWrite;s.setTest(i),i&&(s.setMask(t.stencilWriteMask),s.setFunc(t.stencilFunc,t.stencilRef,t.stencilFuncMask),s.setOp(t.stencilFail,t.stencilZFail,t.stencilZPass)),ve(t.polygonOffset,t.polygonOffsetFactor,t.polygonOffsetUnits),t.alphaToCoverage===!0?R(e.SAMPLE_ALPHA_TO_COVERAGE):z(e.SAMPLE_ALPHA_TO_COVERAGE)}function he(t){O!==t&&(t?e.frontFace(e.CW):e.frontFace(e.CCW),O=t)}function ge(t){t===0?z(e.CULL_FACE):(R(e.CULL_FACE),t!==k&&(t===1?e.cullFace(e.BACK):t===2?e.cullFace(e.FRONT):e.cullFace(e.FRONT_AND_BACK))),k=t}function _e(t){t!==A&&(N&&e.lineWidth(t),A=t)}function ve(t,n,r){t?(R(e.POLYGON_OFFSET_FILL),(j!==n||ee!==r)&&(j=n,ee=r,o.getReversed()&&(n=-n),e.polygonOffset(n,r))):z(e.POLYGON_OFFSET_FILL)}function ye(t){t?R(e.SCISSOR_TEST):z(e.SCISSOR_TEST)}function B(t){t===void 0&&(t=e.TEXTURE0+M-1),ne!==t&&(e.activeTexture(t),ne=t)}function be(t,n,r){r===void 0&&(r=ne===null?e.TEXTURE0+M-1:ne);let i=re[r];i===void 0&&(i={type:void 0,texture:void 0},re[r]=i),(i.type!==t||i.texture!==n)&&(ne!==r&&(e.activeTexture(r),ne=r),e.bindTexture(t,n||se[t]),i.type=t,i.texture=n)}function xe(){let t=re[ne];t!==void 0&&t.type!==void 0&&(e.bindTexture(t.type,null),t.type=void 0,t.texture=void 0)}function V(){try{e.compressedTexImage2D(...arguments)}catch(e){F(`WebGLState:`,e)}}function Se(){try{e.compressedTexImage3D(...arguments)}catch(e){F(`WebGLState:`,e)}}function Ce(){try{e.texSubImage2D(...arguments)}catch(e){F(`WebGLState:`,e)}}function we(){try{e.texSubImage3D(...arguments)}catch(e){F(`WebGLState:`,e)}}function Te(){try{e.compressedTexSubImage2D(...arguments)}catch(e){F(`WebGLState:`,e)}}function Ee(){try{e.compressedTexSubImage3D(...arguments)}catch(e){F(`WebGLState:`,e)}}function De(){try{e.texStorage2D(...arguments)}catch(e){F(`WebGLState:`,e)}}function Oe(){try{e.texStorage3D(...arguments)}catch(e){F(`WebGLState:`,e)}}function H(){try{e.texImage2D(...arguments)}catch(e){F(`WebGLState:`,e)}}function ke(){try{e.texImage3D(...arguments)}catch(e){F(`WebGLState:`,e)}}function Ae(t){return d[t]===void 0?e.getParameter(t):d[t]}function U(t,n){d[t]!==n&&(e.pixelStorei(t,n),d[t]=n)}function je(t){ie.equals(t)===!1&&(e.scissor(t.x,t.y,t.z,t.w),ie.copy(t))}function W(t){ae.equals(t)===!1&&(e.viewport(t.x,t.y,t.z,t.w),ae.copy(t))}function Me(t,n){let r=l.get(n);r===void 0&&(r=new WeakMap,l.set(n,r));let i=r.get(t);i===void 0&&(i=e.getUniformBlockIndex(n,t.name),r.set(t,i))}function Ne(t,n){let r=l.get(n).get(t);c.get(n)!==r&&(e.uniformBlockBinding(n,r,t.__bindingPointIndex),c.set(n,r))}function G(){e.disable(e.BLEND),e.disable(e.CULL_FACE),e.disable(e.DEPTH_TEST),e.disable(e.POLYGON_OFFSET_FILL),e.disable(e.SCISSOR_TEST),e.disable(e.STENCIL_TEST),e.disable(e.SAMPLE_ALPHA_TO_COVERAGE),e.blendEquation(e.FUNC_ADD),e.blendFunc(e.ONE,e.ZERO),e.blendFuncSeparate(e.ONE,e.ZERO,e.ONE,e.ZERO),e.blendColor(0,0,0,0),e.colorMask(!0,!0,!0,!0),e.clearColor(0,0,0,0),e.depthMask(!0),e.depthFunc(e.LESS),o.setReversed(!1),e.clearDepth(1),e.stencilMask(4294967295),e.stencilFunc(e.ALWAYS,0,4294967295),e.stencilOp(e.KEEP,e.KEEP,e.KEEP),e.clearStencil(0),e.cullFace(e.BACK),e.frontFace(e.CCW),e.polygonOffset(0,0),e.activeTexture(e.TEXTURE0),e.bindFramebuffer(e.FRAMEBUFFER,null),e.bindFramebuffer(e.DRAW_FRAMEBUFFER,null),e.bindFramebuffer(e.READ_FRAMEBUFFER,null),e.useProgram(null),e.lineWidth(1),e.scissor(0,0,e.canvas.width,e.canvas.height),e.viewport(0,0,e.canvas.width,e.canvas.height),e.pixelStorei(e.PACK_ALIGNMENT,4),e.pixelStorei(e.UNPACK_ALIGNMENT,4),e.pixelStorei(e.UNPACK_FLIP_Y_WEBGL,!1),e.pixelStorei(e.UNPACK_PREMULTIPLY_ALPHA_WEBGL,!1),e.pixelStorei(e.UNPACK_COLORSPACE_CONVERSION_WEBGL,e.BROWSER_DEFAULT_WEBGL),e.pixelStorei(e.PACK_ROW_LENGTH,0),e.pixelStorei(e.PACK_SKIP_PIXELS,0),e.pixelStorei(e.PACK_SKIP_ROWS,0),e.pixelStorei(e.UNPACK_ROW_LENGTH,0),e.pixelStorei(e.UNPACK_IMAGE_HEIGHT,0),e.pixelStorei(e.UNPACK_SKIP_PIXELS,0),e.pixelStorei(e.UNPACK_SKIP_ROWS,0),e.pixelStorei(e.UNPACK_SKIP_IMAGES,0),u={},d={},ne=null,re={},f={},p=new WeakMap,m=[],h=null,g=!1,_=null,v=null,y=null,b=null,x=null,S=null,w=null,T=new q(0,0,0),E=0,D=!1,O=null,k=null,A=null,j=null,ee=null,ie.set(0,0,e.canvas.width,e.canvas.height),ae.set(0,0,e.canvas.width,e.canvas.height),a.reset(),o.reset(),s.reset()}return{buffers:{color:a,depth:o,stencil:s},enable:R,disable:z,bindFramebuffer:ce,drawBuffers:le,useProgram:ue,setBlending:pe,setMaterial:me,setFlipSided:he,setCullFace:ge,setLineWidth:_e,setPolygonOffset:ve,setScissorTest:ye,activeTexture:B,bindTexture:be,unbindTexture:xe,compressedTexImage2D:V,compressedTexImage3D:Se,texImage2D:H,texImage3D:ke,pixelStorei:U,getParameter:Ae,updateUBOMapping:Me,uniformBlockBinding:Ne,texStorage2D:De,texStorage3D:Oe,texSubImage2D:Ce,texSubImage3D:we,compressedTexSubImage2D:Te,compressedTexSubImage3D:Ee,scissor:je,viewport:W,reset:G}}function oa(e,t,n,r,i,a,o){let s=t.has(`WEBGL_multisampled_render_to_texture`)?t.get(`WEBGL_multisampled_render_to_texture`):null,c=typeof navigator>`u`?!1:/OculusBrowser/g.test(navigator.userAgent),l=new m,u=new WeakMap,d=new Set,f,p=new WeakMap,h=!1;try{h=typeof OffscreenCanvas<`u`&&new OffscreenCanvas(1,1).getContext(`2d`)!==null}catch{}function g(e,t){return h?new OffscreenCanvas(e,t):k(`canvas`)}function _(e,t,n){let r=1,i=H(e);if((i.width>n||i.height>n)&&(r=n/Math.max(i.width,i.height)),r<1){if(typeof HTMLImageElement<`u`&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<`u`&&e instanceof HTMLCanvasElement||typeof ImageBitmap<`u`&&e instanceof ImageBitmap||typeof VideoFrame<`u`&&e instanceof VideoFrame){let n=Math.floor(r*i.width),a=Math.floor(r*i.height);f===void 0&&(f=g(n,a));let o=t?g(n,a):f;return o.width=n,o.height=a,o.getContext(`2d`).drawImage(e,0,0,n,a),V(`WebGLRenderer: Texture has been resized from (`+i.width+`x`+i.height+`) to (`+n+`x`+a+`).`),o}return`data`in e&&V(`WebGLRenderer: Image in DataTexture is too big (`+i.width+`x`+i.height+`).`),e}return e}function v(e){return e.generateMipmaps}function y(t){e.generateMipmap(t)}function b(t){return t.isWebGLCubeRenderTarget?e.TEXTURE_CUBE_MAP:t.isWebGL3DRenderTarget?e.TEXTURE_3D:t.isWebGLArrayRenderTarget||t.isCompressedArrayTexture?e.TEXTURE_2D_ARRAY:e.TEXTURE_2D}function x(n,r,i,a,o,s=!1){if(n!==null){if(e[n]!==void 0)return e[n];V(`WebGLRenderer: Attempt to use non-existing WebGL internal format '`+n+`'`)}let c;a&&(c=t.get(`EXT_texture_norm16`),c||V(`WebGLRenderer: Unable to use normalized textures without EXT_texture_norm16 extension`));let l=r;if(r===e.RED&&(i===e.FLOAT&&(l=e.R32F),i===e.HALF_FLOAT&&(l=e.R16F),i===e.UNSIGNED_BYTE&&(l=e.R8),i===e.UNSIGNED_SHORT&&c&&(l=c.R16_EXT),i===e.SHORT&&c&&(l=c.R16_SNORM_EXT)),r===e.RED_INTEGER&&(i===e.UNSIGNED_BYTE&&(l=e.R8UI),i===e.UNSIGNED_SHORT&&(l=e.R16UI),i===e.UNSIGNED_INT&&(l=e.R32UI),i===e.BYTE&&(l=e.R8I),i===e.SHORT&&(l=e.R16I),i===e.INT&&(l=e.R32I)),r===e.RG&&(i===e.FLOAT&&(l=e.RG32F),i===e.HALF_FLOAT&&(l=e.RG16F),i===e.UNSIGNED_BYTE&&(l=e.RG8),i===e.UNSIGNED_SHORT&&c&&(l=c.RG16_EXT),i===e.SHORT&&c&&(l=c.RG16_SNORM_EXT)),r===e.RG_INTEGER&&(i===e.UNSIGNED_BYTE&&(l=e.RG8UI),i===e.UNSIGNED_SHORT&&(l=e.RG16UI),i===e.UNSIGNED_INT&&(l=e.RG32UI),i===e.BYTE&&(l=e.RG8I),i===e.SHORT&&(l=e.RG16I),i===e.INT&&(l=e.RG32I)),r===e.RGB_INTEGER&&(i===e.UNSIGNED_BYTE&&(l=e.RGB8UI),i===e.UNSIGNED_SHORT&&(l=e.RGB16UI),i===e.UNSIGNED_INT&&(l=e.RGB32UI),i===e.BYTE&&(l=e.RGB8I),i===e.SHORT&&(l=e.RGB16I),i===e.INT&&(l=e.RGB32I)),r===e.RGBA_INTEGER&&(i===e.UNSIGNED_BYTE&&(l=e.RGBA8UI),i===e.UNSIGNED_SHORT&&(l=e.RGBA16UI),i===e.UNSIGNED_INT&&(l=e.RGBA32UI),i===e.BYTE&&(l=e.RGBA8I),i===e.SHORT&&(l=e.RGBA16I),i===e.INT&&(l=e.RGBA32I)),r===e.RGB&&(i===e.UNSIGNED_SHORT&&c&&(l=c.RGB16_EXT),i===e.SHORT&&c&&(l=c.RGB16_SNORM_EXT),i===e.UNSIGNED_INT_5_9_9_9_REV&&(l=e.RGB9_E5),i===e.UNSIGNED_INT_10F_11F_11F_REV&&(l=e.R11F_G11F_B10F)),r===e.RGBA){let t=s?Ut:ze.getTransfer(o);i===e.FLOAT&&(l=e.RGBA32F),i===e.HALF_FLOAT&&(l=e.RGBA16F),i===e.UNSIGNED_BYTE&&(l=t===`srgb`?e.SRGB8_ALPHA8:e.RGBA8),i===e.UNSIGNED_SHORT&&c&&(l=c.RGBA16_EXT),i===e.SHORT&&c&&(l=c.RGBA16_SNORM_EXT),i===e.UNSIGNED_SHORT_4_4_4_4&&(l=e.RGBA4),i===e.UNSIGNED_SHORT_5_5_5_1&&(l=e.RGB5_A1)}return(l===e.R16F||l===e.R32F||l===e.RG16F||l===e.RG32F||l===e.RGBA16F||l===e.RGBA32F)&&t.get(`EXT_color_buffer_float`),l}function S(t,n){let r;return t?n===null||n===1014||n===1020?r=e.DEPTH24_STENCIL8:n===1015?r=e.DEPTH32F_STENCIL8:n===1012&&(r=e.DEPTH24_STENCIL8,V(`DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.`)):n===null||n===1014||n===1020?r=e.DEPTH_COMPONENT24:n===1015?r=e.DEPTH_COMPONENT32F:n===1012&&(r=e.DEPTH_COMPONENT16),r}function C(e,t){return v(e)===!0||e.isFramebufferTexture&&e.minFilter!==1003&&e.minFilter!==1006?Math.log2(Math.max(t.width,t.height))+1:e.mipmaps!==void 0&&e.mipmaps.length>0?e.mipmaps.length:e.isCompressedTexture&&Array.isArray(e.image)?t.mipmaps.length:1}function w(e){let t=e.target;t.removeEventListener(`dispose`,w),E(t),t.isVideoTexture&&u.delete(t),t.isHTMLTexture&&d.delete(t)}function T(e){let t=e.target;t.removeEventListener(`dispose`,T),O(t)}function E(e){let t=r.get(e);if(t.__webglInit===void 0)return;let n=e.source,i=p.get(n);if(i){let r=i[t.__cacheKey];r.usedTimes--,r.usedTimes===0&&D(e),Object.keys(i).length===0&&p.delete(n)}r.remove(e)}function D(t){let n=r.get(t);e.deleteTexture(n.__webglTexture);let i=t.source,a=p.get(i);delete a[n.__cacheKey],o.memory.textures--}function O(t){let n=r.get(t);if(t.depthTexture&&(t.depthTexture.dispose(),r.remove(t.depthTexture)),t.isWebGLCubeRenderTarget)for(let t=0;t<6;t++){if(Array.isArray(n.__webglFramebuffer[t]))for(let r=0;r<n.__webglFramebuffer[t].length;r++)e.deleteFramebuffer(n.__webglFramebuffer[t][r]);else e.deleteFramebuffer(n.__webglFramebuffer[t]);n.__webglDepthbuffer&&e.deleteRenderbuffer(n.__webglDepthbuffer[t])}else{if(Array.isArray(n.__webglFramebuffer))for(let t=0;t<n.__webglFramebuffer.length;t++)e.deleteFramebuffer(n.__webglFramebuffer[t]);else e.deleteFramebuffer(n.__webglFramebuffer);if(n.__webglDepthbuffer&&e.deleteRenderbuffer(n.__webglDepthbuffer),n.__webglMultisampledFramebuffer&&e.deleteFramebuffer(n.__webglMultisampledFramebuffer),n.__webglColorRenderbuffer)for(let t=0;t<n.__webglColorRenderbuffer.length;t++)n.__webglColorRenderbuffer[t]&&e.deleteRenderbuffer(n.__webglColorRenderbuffer[t]);n.__webglDepthRenderbuffer&&e.deleteRenderbuffer(n.__webglDepthRenderbuffer)}let i=t.textures;for(let t=0,n=i.length;t<n;t++){let n=r.get(i[t]);n.__webglTexture&&(e.deleteTexture(n.__webglTexture),o.memory.textures--),r.remove(i[t])}r.remove(t)}let j=0;function ee(){j=0}function M(){return j}function N(e){j=e}function P(){let e=j;return e>=i.maxTextures&&V(`WebGLTextures: Trying to use `+e+` texture units while this GPU supports only `+i.maxTextures),j+=1,e}function te(e){let t=[];return t.push(e.wrapS),t.push(e.wrapT),t.push(e.wrapR||0),t.push(e.magFilter),t.push(e.minFilter),t.push(e.anisotropy),t.push(e.internalFormat),t.push(e.format),t.push(e.type),t.push(e.generateMipmaps),t.push(e.premultiplyAlpha),t.push(e.flipY),t.push(e.unpackAlignment),t.push(e.colorSpace),t.join()}function I(t,i){let a=r.get(t);if(t.isVideoTexture&&Ee(t),t.isRenderTargetTexture===!1&&t.isExternalTexture!==!0&&t.version>0&&a.__version!==t.version){let e=t.image;if(e===null)V(`WebGLRenderer: Texture marked for update but no image data found.`);else if(e.complete===!1)V(`WebGLRenderer: Texture marked for update but image is incomplete`);else{de(a,t,i);return}}else t.isExternalTexture&&(a.__webglTexture=t.sourceTexture?t.sourceTexture:null);n.bindTexture(e.TEXTURE_2D,a.__webglTexture,e.TEXTURE0+i)}function L(t,i){let a=r.get(t);if(t.isRenderTargetTexture===!1&&t.version>0&&a.__version!==t.version){de(a,t,i);return}t.isExternalTexture&&(a.__webglTexture=t.sourceTexture?t.sourceTexture:null),n.bindTexture(e.TEXTURE_2D_ARRAY,a.__webglTexture,e.TEXTURE0+i)}function ie(t,i){let a=r.get(t);if(t.isRenderTargetTexture===!1&&t.version>0&&a.__version!==t.version){de(a,t,i);return}n.bindTexture(e.TEXTURE_3D,a.__webglTexture,e.TEXTURE0+i)}function ae(t,i){let a=r.get(t);if(t.isCubeDepthTexture!==!0&&t.version>0&&a.__version!==t.version){fe(a,t,i);return}n.bindTexture(e.TEXTURE_CUBE_MAP,a.__webglTexture,e.TEXTURE0+i)}let oe={[Oe]:e.REPEAT,[Vt]:e.CLAMP_TO_EDGE,[A]:e.MIRRORED_REPEAT},se={[ne]:e.NEAREST,[tn]:e.NEAREST_MIPMAP_NEAREST,[he]:e.NEAREST_MIPMAP_LINEAR,[gt]:e.LINEAR,[et]:e.LINEAR_MIPMAP_NEAREST,[rt]:e.LINEAR_MIPMAP_LINEAR},R={512:e.NEVER,519:e.ALWAYS,513:e.LESS,515:e.LEQUAL,514:e.EQUAL,518:e.GEQUAL,516:e.GREATER,517:e.NOTEQUAL};function z(n,a){if(a.type===1015&&t.has(`OES_texture_float_linear`)===!1&&(a.magFilter===1006||a.magFilter===1007||a.magFilter===1005||a.magFilter===1008||a.minFilter===1006||a.minFilter===1007||a.minFilter===1005||a.minFilter===1008)&&V(`WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device.`),e.texParameteri(n,e.TEXTURE_WRAP_S,oe[a.wrapS]),e.texParameteri(n,e.TEXTURE_WRAP_T,oe[a.wrapT]),(n===e.TEXTURE_3D||n===e.TEXTURE_2D_ARRAY)&&e.texParameteri(n,e.TEXTURE_WRAP_R,oe[a.wrapR]),e.texParameteri(n,e.TEXTURE_MAG_FILTER,se[a.magFilter]),e.texParameteri(n,e.TEXTURE_MIN_FILTER,se[a.minFilter]),a.compareFunction&&(e.texParameteri(n,e.TEXTURE_COMPARE_MODE,e.COMPARE_REF_TO_TEXTURE),e.texParameteri(n,e.TEXTURE_COMPARE_FUNC,R[a.compareFunction])),t.has(`EXT_texture_filter_anisotropic`)===!0){if(a.magFilter===1003||a.minFilter!==1005&&a.minFilter!==1008||a.type===1015&&t.has(`OES_texture_float_linear`)===!1)return;if(a.anisotropy>1||r.get(a).__currentAnisotropy){let o=t.get(`EXT_texture_filter_anisotropic`);e.texParameterf(n,o.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(a.anisotropy,i.getMaxAnisotropy())),r.get(a).__currentAnisotropy=a.anisotropy}}}function ce(t,n){let r=!1;t.__webglInit===void 0&&(t.__webglInit=!0,n.addEventListener(`dispose`,w));let i=n.source,a=p.get(i);a===void 0&&(a={},p.set(i,a));let s=te(n);if(s!==t.__cacheKey){a[s]===void 0&&(a[s]={texture:e.createTexture(),usedTimes:0},o.memory.textures++,r=!0),a[s].usedTimes++;let i=a[t.__cacheKey];i!==void 0&&(a[t.__cacheKey].usedTimes--,i.usedTimes===0&&D(n)),t.__cacheKey=s,t.__webglTexture=a[s].texture}return r}function le(e,t,n){return Math.floor(Math.floor(e/n)/t)}function ue(t,r,i,a){let o=t.updateRanges;if(o.length===0)n.texSubImage2D(e.TEXTURE_2D,0,0,0,r.width,r.height,i,a,r.data);else{o.sort((e,t)=>e.start-t.start);let s=0;for(let e=1;e<o.length;e++){let t=o[s],n=o[e],i=t.start+t.count,a=le(n.start,r.width,4),c=le(t.start,r.width,4);n.start<=i+1&&a===c&&le(n.start+n.count-1,r.width,4)===a?t.count=Math.max(t.count,n.start+n.count-t.start):(++s,o[s]=n)}o.length=s+1;let c=n.getParameter(e.UNPACK_ROW_LENGTH),l=n.getParameter(e.UNPACK_SKIP_PIXELS),u=n.getParameter(e.UNPACK_SKIP_ROWS);n.pixelStorei(e.UNPACK_ROW_LENGTH,r.width);for(let t=0,s=o.length;t<s;t++){let s=o[t],c=Math.floor(s.start/4),l=Math.ceil(s.count/4),u=c%r.width,d=Math.floor(c/r.width),f=l;n.pixelStorei(e.UNPACK_SKIP_PIXELS,u),n.pixelStorei(e.UNPACK_SKIP_ROWS,d),n.texSubImage2D(e.TEXTURE_2D,0,u,d,f,1,i,a,r.data)}t.clearUpdateRanges(),n.pixelStorei(e.UNPACK_ROW_LENGTH,c),n.pixelStorei(e.UNPACK_SKIP_PIXELS,l),n.pixelStorei(e.UNPACK_SKIP_ROWS,u)}}function de(t,o,s){let c=e.TEXTURE_2D;(o.isDataArrayTexture||o.isCompressedArrayTexture)&&(c=e.TEXTURE_2D_ARRAY),o.isData3DTexture&&(c=e.TEXTURE_3D);let l=ce(t,o),u=o.source;n.bindTexture(c,t.__webglTexture,e.TEXTURE0+s);let f=r.get(u);if(u.version!==f.__version||l===!0){if(n.activeTexture(e.TEXTURE0+s),!(typeof ImageBitmap<`u`&&o.image instanceof ImageBitmap)){let t=ze.getPrimaries(ze.workingColorSpace),r=o.colorSpace===``?null:ze.getPrimaries(o.colorSpace),i=o.colorSpace===``||t===r?e.NONE:e.BROWSER_DEFAULT_WEBGL;n.pixelStorei(e.UNPACK_FLIP_Y_WEBGL,o.flipY),n.pixelStorei(e.UNPACK_PREMULTIPLY_ALPHA_WEBGL,o.premultiplyAlpha),n.pixelStorei(e.UNPACK_COLORSPACE_CONVERSION_WEBGL,i)}n.pixelStorei(e.UNPACK_ALIGNMENT,o.unpackAlignment);let t=_(o.image,!1,i.maxTextureSize);t=De(o,t);let r=a.convert(o.format,o.colorSpace),p=a.convert(o.type),m=x(o.internalFormat,r,p,o.normalized,o.colorSpace,o.isVideoTexture);z(c,o);let h,g=o.mipmaps,b=o.isVideoTexture!==!0,w=f.__version===void 0||l===!0,T=u.dataReady,E=C(o,t);if(o.isDepthTexture)m=S(o.format===re,o.type),w&&(b?n.texStorage2D(e.TEXTURE_2D,1,m,t.width,t.height):n.texImage2D(e.TEXTURE_2D,0,m,t.width,t.height,0,r,p,null));else if(o.isDataTexture){if(g.length>0){b&&w&&n.texStorage2D(e.TEXTURE_2D,E,m,g[0].width,g[0].height);for(let t=0,i=g.length;t<i;t++)h=g[t],b?T&&n.texSubImage2D(e.TEXTURE_2D,t,0,0,h.width,h.height,r,p,h.data):n.texImage2D(e.TEXTURE_2D,t,m,h.width,h.height,0,r,p,h.data);o.generateMipmaps=!1}else b?(w&&n.texStorage2D(e.TEXTURE_2D,E,m,t.width,t.height),T&&ue(o,t,r,p)):n.texImage2D(e.TEXTURE_2D,0,m,t.width,t.height,0,r,p,t.data)}else if(o.isCompressedTexture){if(o.isCompressedArrayTexture){b&&w&&n.texStorage3D(e.TEXTURE_2D_ARRAY,E,m,g[0].width,g[0].height,t.depth);for(let i=0,a=g.length;i<a;i++)if(h=g[i],o.format!==1023){if(r!==null){if(b){if(T){if(o.layerUpdates.size>0){let t=me(h.width,h.height,o.format,o.type);for(let a of o.layerUpdates){let o=h.data.subarray(a*t/h.data.BYTES_PER_ELEMENT,(a+1)*t/h.data.BYTES_PER_ELEMENT);n.compressedTexSubImage3D(e.TEXTURE_2D_ARRAY,i,0,0,a,h.width,h.height,1,r,o)}o.clearLayerUpdates()}else n.compressedTexSubImage3D(e.TEXTURE_2D_ARRAY,i,0,0,0,h.width,h.height,t.depth,r,h.data)}}else n.compressedTexImage3D(e.TEXTURE_2D_ARRAY,i,m,h.width,h.height,t.depth,0,h.data,0,0)}else V(`WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()`)}else b?T&&n.texSubImage3D(e.TEXTURE_2D_ARRAY,i,0,0,0,h.width,h.height,t.depth,r,p,h.data):n.texImage3D(e.TEXTURE_2D_ARRAY,i,m,h.width,h.height,t.depth,0,r,p,h.data)}else{b&&w&&n.texStorage2D(e.TEXTURE_2D,E,m,g[0].width,g[0].height);for(let t=0,i=g.length;t<i;t++)h=g[t],o.format===1023?b?T&&n.texSubImage2D(e.TEXTURE_2D,t,0,0,h.width,h.height,r,p,h.data):n.texImage2D(e.TEXTURE_2D,t,m,h.width,h.height,0,r,p,h.data):r===null?V(`WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()`):b?T&&n.compressedTexSubImage2D(e.TEXTURE_2D,t,0,0,h.width,h.height,r,h.data):n.compressedTexImage2D(e.TEXTURE_2D,t,m,h.width,h.height,0,h.data)}}else if(o.isDataArrayTexture){if(b){if(w&&n.texStorage3D(e.TEXTURE_2D_ARRAY,E,m,t.width,t.height,t.depth),T){if(o.layerUpdates.size>0){let i=me(t.width,t.height,o.format,o.type);for(let a of o.layerUpdates){let o=t.data.subarray(a*i/t.data.BYTES_PER_ELEMENT,(a+1)*i/t.data.BYTES_PER_ELEMENT);n.texSubImage3D(e.TEXTURE_2D_ARRAY,0,0,0,a,t.width,t.height,1,r,p,o)}o.clearLayerUpdates()}else n.texSubImage3D(e.TEXTURE_2D_ARRAY,0,0,0,0,t.width,t.height,t.depth,r,p,t.data)}}else n.texImage3D(e.TEXTURE_2D_ARRAY,0,m,t.width,t.height,t.depth,0,r,p,t.data)}else if(o.isData3DTexture)b?(w&&n.texStorage3D(e.TEXTURE_3D,E,m,t.width,t.height,t.depth),T&&n.texSubImage3D(e.TEXTURE_3D,0,0,0,0,t.width,t.height,t.depth,r,p,t.data)):n.texImage3D(e.TEXTURE_3D,0,m,t.width,t.height,t.depth,0,r,p,t.data);else if(o.isFramebufferTexture){if(w){if(b)n.texStorage2D(e.TEXTURE_2D,E,m,t.width,t.height);else{let i=t.width,a=t.height;for(let t=0;t<E;t++)n.texImage2D(e.TEXTURE_2D,t,m,i,a,0,r,p,null),i>>=1,a>>=1}}}else if(o.isHTMLTexture){if(`texElementImage2D`in e){let n=e.canvas;if(n.hasAttribute(`layoutsubtree`)||n.setAttribute(`layoutsubtree`,`true`),t.parentNode!==n){n.appendChild(t),d.add(o),n.onpaint=e=>{let t=e.changedElements;for(let e of d)t.includes(e.image)&&(e.needsUpdate=!0)},n.requestPaint();return}if(e.texElementImage2D.length===3)e.texElementImage2D(e.TEXTURE_2D,e.RGBA8,t);else{let n=e.RGBA,r=e.RGBA,i=e.UNSIGNED_BYTE;e.texElementImage2D(e.TEXTURE_2D,0,n,r,i,t)}e.texParameteri(e.TEXTURE_2D,e.TEXTURE_MIN_FILTER,e.LINEAR),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_WRAP_S,e.CLAMP_TO_EDGE),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_WRAP_T,e.CLAMP_TO_EDGE)}}else if(g.length>0){if(b&&w){let t=H(g[0]);n.texStorage2D(e.TEXTURE_2D,E,m,t.width,t.height)}for(let t=0,i=g.length;t<i;t++)h=g[t],b?T&&n.texSubImage2D(e.TEXTURE_2D,t,0,0,r,p,h):n.texImage2D(e.TEXTURE_2D,t,m,r,p,h);o.generateMipmaps=!1}else if(b){if(w){let r=H(t);n.texStorage2D(e.TEXTURE_2D,E,m,r.width,r.height)}T&&n.texSubImage2D(e.TEXTURE_2D,0,0,0,r,p,t)}else n.texImage2D(e.TEXTURE_2D,0,m,r,p,t);v(o)&&y(c),f.__version=u.version,o.onUpdate&&o.onUpdate(o)}t.__version=o.version}function fe(t,o,s){if(o.image.length!==6)return;let c=ce(t,o),l=o.source;n.bindTexture(e.TEXTURE_CUBE_MAP,t.__webglTexture,e.TEXTURE0+s);let u=r.get(l);if(l.version!==u.__version||c===!0){n.activeTexture(e.TEXTURE0+s);let t=ze.getPrimaries(ze.workingColorSpace),r=o.colorSpace===``?null:ze.getPrimaries(o.colorSpace),d=o.colorSpace===``||t===r?e.NONE:e.BROWSER_DEFAULT_WEBGL;n.pixelStorei(e.UNPACK_FLIP_Y_WEBGL,o.flipY),n.pixelStorei(e.UNPACK_PREMULTIPLY_ALPHA_WEBGL,o.premultiplyAlpha),n.pixelStorei(e.UNPACK_ALIGNMENT,o.unpackAlignment),n.pixelStorei(e.UNPACK_COLORSPACE_CONVERSION_WEBGL,d);let f=o.isCompressedTexture||o.image[0].isCompressedTexture,p=o.image[0]&&o.image[0].isDataTexture,m=[];for(let e=0;e<6;e++)!f&&!p?m[e]=_(o.image[e],!0,i.maxCubemapSize):m[e]=p?o.image[e].image:o.image[e],m[e]=De(o,m[e]);let h=m[0],g=a.convert(o.format,o.colorSpace),b=a.convert(o.type),S=x(o.internalFormat,g,b,o.normalized,o.colorSpace),w=o.isVideoTexture!==!0,T=u.__version===void 0||c===!0,E=l.dataReady,D=C(o,h);z(e.TEXTURE_CUBE_MAP,o);let O;if(f){w&&T&&n.texStorage2D(e.TEXTURE_CUBE_MAP,D,S,h.width,h.height);for(let t=0;t<6;t++){O=m[t].mipmaps;for(let r=0;r<O.length;r++){let i=O[r];o.format===1023?w?E&&n.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,r,0,0,i.width,i.height,g,b,i.data):n.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,r,S,i.width,i.height,0,g,b,i.data):g===null?V(`WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()`):w?E&&n.compressedTexSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,r,0,0,i.width,i.height,g,i.data):n.compressedTexImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,r,S,i.width,i.height,0,i.data)}}}else{if(O=o.mipmaps,w&&T){O.length>0&&D++;let t=H(m[0]);n.texStorage2D(e.TEXTURE_CUBE_MAP,D,S,t.width,t.height)}for(let t=0;t<6;t++)if(p){w?E&&n.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,0,0,0,m[t].width,m[t].height,g,b,m[t].data):n.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,0,S,m[t].width,m[t].height,0,g,b,m[t].data);for(let r=0;r<O.length;r++){let i=O[r].image[t].image;w?E&&n.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,r+1,0,0,i.width,i.height,g,b,i.data):n.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,r+1,S,i.width,i.height,0,g,b,i.data)}}else{w?E&&n.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,0,0,0,g,b,m[t]):n.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,0,S,g,b,m[t]);for(let r=0;r<O.length;r++){let i=O[r];w?E&&n.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,r+1,0,0,g,b,i.image[t]):n.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,r+1,S,g,b,i.image[t])}}}v(o)&&y(e.TEXTURE_CUBE_MAP),u.__version=l.version,o.onUpdate&&o.onUpdate(o)}t.__version=o.version}function pe(t,i,o,c,l,u){let d=a.convert(o.format,o.colorSpace),f=a.convert(o.type),p=x(o.internalFormat,d,f,o.normalized,o.colorSpace),m=r.get(i),h=r.get(o);if(h.__renderTarget=i,!m.__hasExternalTextures){let t=Math.max(1,i.width>>u),r=Math.max(1,i.height>>u);l===e.TEXTURE_3D||l===e.TEXTURE_2D_ARRAY?n.texImage3D(l,u,p,t,r,i.depth,0,d,f,null):n.texImage2D(l,u,p,t,r,0,d,f,null)}n.bindFramebuffer(e.FRAMEBUFFER,t),Te(i)?s.framebufferTexture2DMultisampleEXT(e.FRAMEBUFFER,c,l,h.__webglTexture,0,we(i)):(l===e.TEXTURE_2D||l>=e.TEXTURE_CUBE_MAP_POSITIVE_X&&l<=e.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&e.framebufferTexture2D(e.FRAMEBUFFER,c,l,h.__webglTexture,u),n.bindFramebuffer(e.FRAMEBUFFER,null)}function ge(t,n,r){if(e.bindRenderbuffer(e.RENDERBUFFER,t),n.depthBuffer){let i=n.depthTexture,a=i&&i.isDepthTexture?i.type:null,o=S(n.stencilBuffer,a),c=n.stencilBuffer?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT;Te(n)?s.renderbufferStorageMultisampleEXT(e.RENDERBUFFER,we(n),o,n.width,n.height):r?e.renderbufferStorageMultisample(e.RENDERBUFFER,we(n),o,n.width,n.height):e.renderbufferStorage(e.RENDERBUFFER,o,n.width,n.height),e.framebufferRenderbuffer(e.FRAMEBUFFER,c,e.RENDERBUFFER,t)}else{let t=n.textures;for(let i=0;i<t.length;i++){let o=t[i],c=a.convert(o.format,o.colorSpace),l=a.convert(o.type),u=x(o.internalFormat,c,l,o.normalized,o.colorSpace);Te(n)?s.renderbufferStorageMultisampleEXT(e.RENDERBUFFER,we(n),u,n.width,n.height):r?e.renderbufferStorageMultisample(e.RENDERBUFFER,we(n),u,n.width,n.height):e.renderbufferStorage(e.RENDERBUFFER,u,n.width,n.height)}}e.bindRenderbuffer(e.RENDERBUFFER,null)}function _e(t,i,o){let c=i.isWebGLCubeRenderTarget===!0;if(n.bindFramebuffer(e.FRAMEBUFFER,t),!(i.depthTexture&&i.depthTexture.isDepthTexture))throw Error(`THREE.WebGLTextures: renderTarget.depthTexture must be an instance of THREE.DepthTexture.`);let l=r.get(i.depthTexture);if(l.__renderTarget=i,(!l.__webglTexture||i.depthTexture.image.width!==i.width||i.depthTexture.image.height!==i.height)&&(i.depthTexture.image.width=i.width,i.depthTexture.image.height=i.height,i.depthTexture.needsUpdate=!0),c){if(l.__webglInit===void 0&&(l.__webglInit=!0,i.depthTexture.addEventListener(`dispose`,w)),l.__webglTexture===void 0){l.__webglTexture=e.createTexture(),n.bindTexture(e.TEXTURE_CUBE_MAP,l.__webglTexture),z(e.TEXTURE_CUBE_MAP,i.depthTexture);let t=a.convert(i.depthTexture.format),r=a.convert(i.depthTexture.type),o;i.depthTexture.format===1026?o=e.DEPTH_COMPONENT24:i.depthTexture.format===1027&&(o=e.DEPTH24_STENCIL8);for(let n=0;n<6;n++)e.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+n,0,o,i.width,i.height,0,t,r,null)}}else I(i.depthTexture,0);let u=l.__webglTexture,d=we(i),f=c?e.TEXTURE_CUBE_MAP_POSITIVE_X+o:e.TEXTURE_2D,p=i.depthTexture.format===1027?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT;if(i.depthTexture.format===1026)Te(i)?s.framebufferTexture2DMultisampleEXT(e.FRAMEBUFFER,p,f,u,0,d):e.framebufferTexture2D(e.FRAMEBUFFER,p,f,u,0);else if(i.depthTexture.format===1027)Te(i)?s.framebufferTexture2DMultisampleEXT(e.FRAMEBUFFER,p,f,u,0,d):e.framebufferTexture2D(e.FRAMEBUFFER,p,f,u,0);else throw Error(`THREE.WebGLTextures: Unknown depthTexture format.`)}function ve(t){let i=r.get(t),a=t.isWebGLCubeRenderTarget===!0;if(i.__boundDepthTexture!==t.depthTexture){let e=t.depthTexture;if(i.__depthDisposeCallback&&i.__depthDisposeCallback(),e){let t=()=>{delete i.__boundDepthTexture,delete i.__depthDisposeCallback,e.removeEventListener(`dispose`,t)};e.addEventListener(`dispose`,t),i.__depthDisposeCallback=t}i.__boundDepthTexture=e}if(t.depthTexture&&!i.__autoAllocateDepthBuffer){if(a)for(let e=0;e<6;e++)_e(i.__webglFramebuffer[e],t,e);else{let e=t.texture.mipmaps;e&&e.length>0?_e(i.__webglFramebuffer[0],t,0):_e(i.__webglFramebuffer,t,0)}}else if(a){i.__webglDepthbuffer=[];for(let r=0;r<6;r++)if(n.bindFramebuffer(e.FRAMEBUFFER,i.__webglFramebuffer[r]),i.__webglDepthbuffer[r]===void 0)i.__webglDepthbuffer[r]=e.createRenderbuffer(),ge(i.__webglDepthbuffer[r],t,!1);else{let n=t.stencilBuffer?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT,a=i.__webglDepthbuffer[r];e.bindRenderbuffer(e.RENDERBUFFER,a),e.framebufferRenderbuffer(e.FRAMEBUFFER,n,e.RENDERBUFFER,a)}}else{let r=t.texture.mipmaps;if(r&&r.length>0?n.bindFramebuffer(e.FRAMEBUFFER,i.__webglFramebuffer[0]):n.bindFramebuffer(e.FRAMEBUFFER,i.__webglFramebuffer),i.__webglDepthbuffer===void 0)i.__webglDepthbuffer=e.createRenderbuffer(),ge(i.__webglDepthbuffer,t,!1);else{let n=t.stencilBuffer?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT,r=i.__webglDepthbuffer;e.bindRenderbuffer(e.RENDERBUFFER,r),e.framebufferRenderbuffer(e.FRAMEBUFFER,n,e.RENDERBUFFER,r)}}n.bindFramebuffer(e.FRAMEBUFFER,null)}function ye(t,n,i){let a=r.get(t);n!==void 0&&pe(a.__webglFramebuffer,t,t.texture,e.COLOR_ATTACHMENT0,e.TEXTURE_2D,0),i!==void 0&&ve(t)}function B(t){let i=t.texture,s=r.get(t),c=r.get(i);t.addEventListener(`dispose`,T);let l=t.textures,u=t.isWebGLCubeRenderTarget===!0,d=l.length>1;if(d||(c.__webglTexture===void 0&&(c.__webglTexture=e.createTexture()),c.__version=i.version,o.memory.textures++),u){s.__webglFramebuffer=[];for(let t=0;t<6;t++)if(i.mipmaps&&i.mipmaps.length>0){s.__webglFramebuffer[t]=[];for(let n=0;n<i.mipmaps.length;n++)s.__webglFramebuffer[t][n]=e.createFramebuffer()}else s.__webglFramebuffer[t]=e.createFramebuffer()}else{if(i.mipmaps&&i.mipmaps.length>0){s.__webglFramebuffer=[];for(let t=0;t<i.mipmaps.length;t++)s.__webglFramebuffer[t]=e.createFramebuffer()}else s.__webglFramebuffer=e.createFramebuffer();if(d)for(let t=0,n=l.length;t<n;t++){let n=r.get(l[t]);n.__webglTexture===void 0&&(n.__webglTexture=e.createTexture(),o.memory.textures++)}if(t.samples>0&&Te(t)===!1){s.__webglMultisampledFramebuffer=e.createFramebuffer(),s.__webglColorRenderbuffer=[],n.bindFramebuffer(e.FRAMEBUFFER,s.__webglMultisampledFramebuffer);for(let n=0;n<l.length;n++){let r=l[n];s.__webglColorRenderbuffer[n]=e.createRenderbuffer(),e.bindRenderbuffer(e.RENDERBUFFER,s.__webglColorRenderbuffer[n]);let i=a.convert(r.format,r.colorSpace),o=a.convert(r.type),c=x(r.internalFormat,i,o,r.normalized,r.colorSpace,t.isXRRenderTarget===!0),u=we(t);e.renderbufferStorageMultisample(e.RENDERBUFFER,u,c,t.width,t.height),e.framebufferRenderbuffer(e.FRAMEBUFFER,e.COLOR_ATTACHMENT0+n,e.RENDERBUFFER,s.__webglColorRenderbuffer[n])}e.bindRenderbuffer(e.RENDERBUFFER,null),t.depthBuffer&&(s.__webglDepthRenderbuffer=e.createRenderbuffer(),ge(s.__webglDepthRenderbuffer,t,!0)),n.bindFramebuffer(e.FRAMEBUFFER,null)}}if(u){n.bindTexture(e.TEXTURE_CUBE_MAP,c.__webglTexture),z(e.TEXTURE_CUBE_MAP,i);for(let n=0;n<6;n++)if(i.mipmaps&&i.mipmaps.length>0)for(let r=0;r<i.mipmaps.length;r++)pe(s.__webglFramebuffer[n][r],t,i,e.COLOR_ATTACHMENT0,e.TEXTURE_CUBE_MAP_POSITIVE_X+n,r);else pe(s.__webglFramebuffer[n],t,i,e.COLOR_ATTACHMENT0,e.TEXTURE_CUBE_MAP_POSITIVE_X+n,0);v(i)&&y(e.TEXTURE_CUBE_MAP),n.unbindTexture()}else if(d){for(let i=0,a=l.length;i<a;i++){let a=l[i],o=r.get(a),c=e.TEXTURE_2D;(t.isWebGL3DRenderTarget||t.isWebGLArrayRenderTarget)&&(c=t.isWebGL3DRenderTarget?e.TEXTURE_3D:e.TEXTURE_2D_ARRAY),n.bindTexture(c,o.__webglTexture),z(c,a),pe(s.__webglFramebuffer,t,a,e.COLOR_ATTACHMENT0+i,c,0),v(a)&&y(c)}n.unbindTexture()}else{let r=e.TEXTURE_2D;if((t.isWebGL3DRenderTarget||t.isWebGLArrayRenderTarget)&&(r=t.isWebGL3DRenderTarget?e.TEXTURE_3D:e.TEXTURE_2D_ARRAY),n.bindTexture(r,c.__webglTexture),z(r,i),i.mipmaps&&i.mipmaps.length>0)for(let n=0;n<i.mipmaps.length;n++)pe(s.__webglFramebuffer[n],t,i,e.COLOR_ATTACHMENT0,r,n);else pe(s.__webglFramebuffer,t,i,e.COLOR_ATTACHMENT0,r,0);v(i)&&y(r),n.unbindTexture()}t.depthBuffer&&ve(t)}function be(e){let t=e.textures;for(let i=0,a=t.length;i<a;i++){let a=t[i];if(v(a)){let t=b(e),i=r.get(a).__webglTexture;n.bindTexture(t,i),y(t),n.unbindTexture()}}}let xe=[],Se=[];function Ce(t){if(t.samples>0){if(Te(t)===!1){let i=t.textures,a=t.width,o=t.height,s=e.COLOR_BUFFER_BIT,l=t.stencilBuffer?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT,u=r.get(t),d=i.length>1;if(d)for(let t=0;t<i.length;t++)n.bindFramebuffer(e.FRAMEBUFFER,u.__webglMultisampledFramebuffer),e.framebufferRenderbuffer(e.FRAMEBUFFER,e.COLOR_ATTACHMENT0+t,e.RENDERBUFFER,null),n.bindFramebuffer(e.FRAMEBUFFER,u.__webglFramebuffer),e.framebufferTexture2D(e.DRAW_FRAMEBUFFER,e.COLOR_ATTACHMENT0+t,e.TEXTURE_2D,null,0);n.bindFramebuffer(e.READ_FRAMEBUFFER,u.__webglMultisampledFramebuffer);let f=t.texture.mipmaps;f&&f.length>0?n.bindFramebuffer(e.DRAW_FRAMEBUFFER,u.__webglFramebuffer[0]):n.bindFramebuffer(e.DRAW_FRAMEBUFFER,u.__webglFramebuffer);for(let n=0;n<i.length;n++){if(t.resolveDepthBuffer&&(t.depthBuffer&&(s|=e.DEPTH_BUFFER_BIT),t.stencilBuffer&&t.resolveStencilBuffer&&(s|=e.STENCIL_BUFFER_BIT)),d){e.framebufferRenderbuffer(e.READ_FRAMEBUFFER,e.COLOR_ATTACHMENT0,e.RENDERBUFFER,u.__webglColorRenderbuffer[n]);let t=r.get(i[n]).__webglTexture;e.framebufferTexture2D(e.DRAW_FRAMEBUFFER,e.COLOR_ATTACHMENT0,e.TEXTURE_2D,t,0)}e.blitFramebuffer(0,0,a,o,0,0,a,o,s,e.NEAREST),c===!0&&(xe.length=0,Se.length=0,xe.push(e.COLOR_ATTACHMENT0+n),t.depthBuffer&&t.resolveDepthBuffer===!1&&(xe.push(l),Se.push(l),e.invalidateFramebuffer(e.DRAW_FRAMEBUFFER,Se)),e.invalidateFramebuffer(e.READ_FRAMEBUFFER,xe))}if(n.bindFramebuffer(e.READ_FRAMEBUFFER,null),n.bindFramebuffer(e.DRAW_FRAMEBUFFER,null),d)for(let t=0;t<i.length;t++){n.bindFramebuffer(e.FRAMEBUFFER,u.__webglMultisampledFramebuffer),e.framebufferRenderbuffer(e.FRAMEBUFFER,e.COLOR_ATTACHMENT0+t,e.RENDERBUFFER,u.__webglColorRenderbuffer[t]);let a=r.get(i[t]).__webglTexture;n.bindFramebuffer(e.FRAMEBUFFER,u.__webglFramebuffer),e.framebufferTexture2D(e.DRAW_FRAMEBUFFER,e.COLOR_ATTACHMENT0+t,e.TEXTURE_2D,a,0)}n.bindFramebuffer(e.DRAW_FRAMEBUFFER,u.__webglMultisampledFramebuffer)}else if(t.depthBuffer&&t.resolveDepthBuffer===!1&&c){let n=t.stencilBuffer?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT;e.invalidateFramebuffer(e.DRAW_FRAMEBUFFER,[n])}}}function we(e){return Math.min(i.maxSamples,e.samples)}function Te(e){let n=r.get(e);return e.samples>0&&t.has(`WEBGL_multisampled_render_to_texture`)===!0&&n.__useRenderToTexture!==!1}function Ee(e){let t=o.render.frame;u.get(e)!==t&&(u.set(e,t),e.update())}function De(e,t){let n=e.colorSpace,r=e.format,i=e.type;return e.isCompressedTexture===!0||e.isVideoTexture===!0||n!==`srgb-linear`&&n!==``&&(ze.getTransfer(n)===`srgb`?(r!==1023||i!==1009)&&V(`WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType.`):F(`WebGLTextures: Unsupported texture color space:`,n)),t}function H(e){return typeof HTMLImageElement<`u`&&e instanceof HTMLImageElement?(l.width=e.naturalWidth||e.width,l.height=e.naturalHeight||e.height):typeof VideoFrame<`u`&&e instanceof VideoFrame?(l.width=e.displayWidth,l.height=e.displayHeight):(l.width=e.width,l.height=e.height),l}this.allocateTextureUnit=P,this.resetTextureUnits=ee,this.getTextureUnits=M,this.setTextureUnits=N,this.setTexture2D=I,this.setTexture2DArray=L,this.setTexture3D=ie,this.setTextureCube=ae,this.rebindTextures=ye,this.setupRenderTarget=B,this.updateRenderTargetMipmap=be,this.updateMultisampleRenderTarget=Ce,this.setupDepthRenderbuffer=ve,this.setupFrameBufferTexture=pe,this.useMultisampledRTT=Te,this.isReversedDepthBuffer=function(){return n.buffers.depth.getReversed()}}function sa(e,t){function n(n,r=``){let i,a=ze.getTransfer(r);if(n===1009)return e.UNSIGNED_BYTE;if(n===1017)return e.UNSIGNED_SHORT_4_4_4_4;if(n===1018)return e.UNSIGNED_SHORT_5_5_5_1;if(n===35902)return e.UNSIGNED_INT_5_9_9_9_REV;if(n===35899)return e.UNSIGNED_INT_10F_11F_11F_REV;if(n===1010)return e.BYTE;if(n===1011)return e.SHORT;if(n===1012)return e.UNSIGNED_SHORT;if(n===1013)return e.INT;if(n===1014)return e.UNSIGNED_INT;if(n===1015)return e.FLOAT;if(n===1016)return e.HALF_FLOAT;if(n===1021)return e.ALPHA;if(n===1022)return e.RGB;if(n===1023)return e.RGBA;if(n===1026)return e.DEPTH_COMPONENT;if(n===1027)return e.DEPTH_STENCIL;if(n===1028)return e.RED;if(n===1029)return e.RED_INTEGER;if(n===1030)return e.RG;if(n===1031)return e.RG_INTEGER;if(n===1033)return e.RGBA_INTEGER;if(n===33776||n===33777||n===33778||n===33779){if(a===`srgb`){if(i=t.get(`WEBGL_compressed_texture_s3tc_srgb`),i!==null){if(n===33776)return i.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(n===33777)return i.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(n===33778)return i.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(n===33779)return i.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null}else if(i=t.get(`WEBGL_compressed_texture_s3tc`),i!==null){if(n===33776)return i.COMPRESSED_RGB_S3TC_DXT1_EXT;if(n===33777)return i.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(n===33778)return i.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(n===33779)return i.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null}if(n===35840||n===35841||n===35842||n===35843){if(i=t.get(`WEBGL_compressed_texture_pvrtc`),i!==null){if(n===35840)return i.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(n===35841)return i.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(n===35842)return i.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(n===35843)return i.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null}if(n===36196||n===37492||n===37496||n===37488||n===37489||n===37490||n===37491){if(i=t.get(`WEBGL_compressed_texture_etc`),i!==null){if(n===36196||n===37492)return a===`srgb`?i.COMPRESSED_SRGB8_ETC2:i.COMPRESSED_RGB8_ETC2;if(n===37496)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:i.COMPRESSED_RGBA8_ETC2_EAC;if(n===37488)return i.COMPRESSED_R11_EAC;if(n===37489)return i.COMPRESSED_SIGNED_R11_EAC;if(n===37490)return i.COMPRESSED_RG11_EAC;if(n===37491)return i.COMPRESSED_SIGNED_RG11_EAC}else return null}if(n===37808||n===37809||n===37810||n===37811||n===37812||n===37813||n===37814||n===37815||n===37816||n===37817||n===37818||n===37819||n===37820||n===37821){if(i=t.get(`WEBGL_compressed_texture_astc`),i!==null){if(n===37808)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:i.COMPRESSED_RGBA_ASTC_4x4_KHR;if(n===37809)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:i.COMPRESSED_RGBA_ASTC_5x4_KHR;if(n===37810)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:i.COMPRESSED_RGBA_ASTC_5x5_KHR;if(n===37811)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:i.COMPRESSED_RGBA_ASTC_6x5_KHR;if(n===37812)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:i.COMPRESSED_RGBA_ASTC_6x6_KHR;if(n===37813)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:i.COMPRESSED_RGBA_ASTC_8x5_KHR;if(n===37814)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:i.COMPRESSED_RGBA_ASTC_8x6_KHR;if(n===37815)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:i.COMPRESSED_RGBA_ASTC_8x8_KHR;if(n===37816)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:i.COMPRESSED_RGBA_ASTC_10x5_KHR;if(n===37817)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:i.COMPRESSED_RGBA_ASTC_10x6_KHR;if(n===37818)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:i.COMPRESSED_RGBA_ASTC_10x8_KHR;if(n===37819)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:i.COMPRESSED_RGBA_ASTC_10x10_KHR;if(n===37820)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:i.COMPRESSED_RGBA_ASTC_12x10_KHR;if(n===37821)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:i.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null}if(n===36492||n===36494||n===36495){if(i=t.get(`EXT_texture_compression_bptc`),i!==null){if(n===36492)return a===`srgb`?i.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:i.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(n===36494)return i.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(n===36495)return i.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null}if(n===36283||n===36284||n===36285||n===36286){if(i=t.get(`EXT_texture_compression_rgtc`),i!==null){if(n===36283)return i.COMPRESSED_RED_RGTC1_EXT;if(n===36284)return i.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(n===36285)return i.COMPRESSED_RED_GREEN_RGTC2_EXT;if(n===36286)return i.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null}return n===1020?e.UNSIGNED_INT_24_8:e[n]===void 0?null:e[n]}return{convert:n}}var ca=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,la=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`,ua=class{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(e,t){if(this.texture===null){let n=new o(e.texture);(e.depthNear!==t.depthNear||e.depthFar!==t.depthFar)&&(this.depthNear=e.depthNear,this.depthFar=e.depthFar),this.texture=n}}getMesh(e){if(this.texture!==null&&this.mesh===null){let t=e.cameras[0].viewport,n=new Je({vertexShader:ca,fragmentShader:la,uniforms:{depthColor:{value:this.texture},depthWidth:{value:t.z},depthHeight:{value:t.w}}});this.mesh=new z(new Ot(20,20),n)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}},da=class extends Qt{constructor(e,t){super();let n=this,r=null,i=1,a=null,s=`local-floor`,c=1,l=null,u=null,f=null,p=null,h=null,g=null,_=typeof XRWebGLBinding<`u`,v=new ua,y={},b=t.getContextAttributes(),x=null,S=null,C=[],T=[],E=new m,D=null,O=new w;O.viewport=new ut;let k=new w;k.viewport=new ut;let A=[O,k],j=new bt,ee=null,M=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(e){let t=C[e];return t===void 0&&(t=new ae,C[e]=t),t.getTargetRaySpace()},this.getControllerGrip=function(e){let t=C[e];return t===void 0&&(t=new ae,C[e]=t),t.getGripSpace()},this.getHand=function(e){let t=C[e];return t===void 0&&(t=new ae,C[e]=t),t.getHandSpace()};function N(e){let t=T.indexOf(e.inputSource);if(t===-1)return;let n=C[t];n!==void 0&&(n.update(e.inputSource,e.frame,l||a),n.dispatchEvent({type:e.type,data:e.inputSource}))}function P(){r.removeEventListener(`select`,N),r.removeEventListener(`selectstart`,N),r.removeEventListener(`selectend`,N),r.removeEventListener(`squeeze`,N),r.removeEventListener(`squeezestart`,N),r.removeEventListener(`squeezeend`,N),r.removeEventListener(`end`,P),r.removeEventListener(`inputsourceschange`,te);for(let e=0;e<C.length;e++){let t=T[e];t!==null&&(T[e]=null,C[e].disconnect(t))}ee=null,M=null,v.reset();for(let e in y)delete y[e];e.setRenderTarget(x),h=null,p=null,f=null,r=null,S=null,le.stop(),n.isPresenting=!1,e.setPixelRatio(D),e.setSize(E.width,E.height,!1),n.dispatchEvent({type:`sessionend`})}this.setFramebufferScaleFactor=function(e){i=e,n.isPresenting===!0&&V(`WebXRManager: Cannot change framebuffer scale while presenting.`)},this.setReferenceSpaceType=function(e){s=e,n.isPresenting===!0&&V(`WebXRManager: Cannot change reference space type while presenting.`)},this.getReferenceSpace=function(){return l||a},this.setReferenceSpace=function(e){l=e},this.getBaseLayer=function(){return p===null?h:p},this.getBinding=function(){return f===null&&_&&(f=new XRWebGLBinding(r,t)),f},this.getFrame=function(){return g},this.getSession=function(){return r},this.setSession=async function(o){if(r=o,r!==null){if(x=e.getRenderTarget(),r.addEventListener(`select`,N),r.addEventListener(`selectstart`,N),r.addEventListener(`selectend`,N),r.addEventListener(`squeeze`,N),r.addEventListener(`squeezestart`,N),r.addEventListener(`squeezeend`,N),r.addEventListener(`end`,P),r.addEventListener(`inputsourceschange`,te),b.xrCompatible!==!0&&await t.makeXRCompatible(),D=e.getPixelRatio(),e.getSize(E),_&&`createProjectionLayer`in XRWebGLBinding.prototype){let n=null,a=null,o=null;b.depth&&(o=b.stencil?t.DEPTH24_STENCIL8:t.DEPTH_COMPONENT24,n=b.stencil?re:ot,a=b.stencil?Jt:d);let s={colorFormat:t.RGBA8,depthFormat:o,scaleFactor:i};f=this.getBinding(),p=f.createProjectionLayer(s),r.updateRenderState({layers:[p]}),e.setPixelRatio(1),e.setSize(p.textureWidth,p.textureHeight,!1),S=new I(p.textureWidth,p.textureHeight,{format:xt,type:Xt,depthTexture:new ie(p.textureWidth,p.textureHeight,a,void 0,void 0,void 0,void 0,void 0,void 0,n),stencilBuffer:b.stencil,colorSpace:e.outputColorSpace,samples:b.antialias?4:0,resolveDepthBuffer:p.ignoreDepthValues===!1,resolveStencilBuffer:p.ignoreDepthValues===!1})}else{let n={antialias:b.antialias,alpha:!0,depth:b.depth,stencil:b.stencil,framebufferScaleFactor:i};h=new XRWebGLLayer(r,t,n),r.updateRenderState({baseLayer:h}),e.setPixelRatio(1),e.setSize(h.framebufferWidth,h.framebufferHeight,!1),S=new I(h.framebufferWidth,h.framebufferHeight,{format:xt,type:Xt,colorSpace:e.outputColorSpace,stencilBuffer:b.stencil,resolveDepthBuffer:h.ignoreDepthValues===!1,resolveStencilBuffer:h.ignoreDepthValues===!1})}S.isXRRenderTarget=!0,this.setFoveation(c),l=null,a=await r.requestReferenceSpace(s),le.setContext(r),le.start(),n.isPresenting=!0,n.dispatchEvent({type:`sessionstart`})}},this.getEnvironmentBlendMode=function(){if(r!==null)return r.environmentBlendMode},this.getDepthTexture=function(){return v.getDepthTexture()};function te(e){for(let t=0;t<e.removed.length;t++){let n=e.removed[t],r=T.indexOf(n);r>=0&&(T[r]=null,C[r].disconnect(n))}for(let t=0;t<e.added.length;t++){let n=e.added[t],r=T.indexOf(n);if(r===-1){for(let e=0;e<C.length;e++)if(e>=T.length){T.push(n),r=e;break}else if(T[e]===null){T[e]=n,r=e;break}if(r===-1)break}let i=C[r];i&&i.connect(n)}}let F=new R,ne=new R;function L(e,t,n){F.setFromMatrixPosition(t.matrixWorld),ne.setFromMatrixPosition(n.matrixWorld);let r=F.distanceTo(ne),i=t.projectionMatrix.elements,a=n.projectionMatrix.elements,o=i[14]/(i[10]-1),s=i[14]/(i[10]+1),c=(i[9]+1)/i[5],l=(i[9]-1)/i[5],u=(i[8]-1)/i[0],d=(a[8]+1)/a[0],f=o*u,p=o*d,m=r/(-u+d),h=m*-u;if(t.matrixWorld.decompose(e.position,e.quaternion,e.scale),e.translateX(h),e.translateZ(m),e.matrixWorld.compose(e.position,e.quaternion,e.scale),e.matrixWorldInverse.copy(e.matrixWorld).invert(),i[10]===-1)e.projectionMatrix.copy(t.projectionMatrix),e.projectionMatrixInverse.copy(t.projectionMatrixInverse);else{let t=o+m,n=s+m,i=f-h,a=p+(r-h),u=c*s/n*t,d=l*s/n*t;e.projectionMatrix.makePerspective(i,a,u,d,t,n),e.projectionMatrixInverse.copy(e.projectionMatrix).invert()}}function oe(e,t){t===null?e.matrixWorld.copy(e.matrix):e.matrixWorld.multiplyMatrices(t.matrixWorld,e.matrix),e.matrixWorldInverse.copy(e.matrixWorld).invert()}this.updateCamera=function(e){if(r===null)return;let t=e.near,n=e.far;v.texture!==null&&(v.depthNear>0&&(t=v.depthNear),v.depthFar>0&&(n=v.depthFar)),j.near=k.near=O.near=t,j.far=k.far=O.far=n,(ee!==j.near||M!==j.far)&&(r.updateRenderState({depthNear:j.near,depthFar:j.far}),ee=j.near,M=j.far),j.layers.mask=e.layers.mask|6,O.layers.mask=j.layers.mask&-5,k.layers.mask=j.layers.mask&-3;let i=e.parent,a=j.cameras;oe(j,i);for(let e=0;e<a.length;e++)oe(a[e],i);a.length===2?L(j,O,k):j.projectionMatrix.copy(O.projectionMatrix),se(e,j,i)};function se(e,t,n){n===null?e.matrix.copy(t.matrixWorld):(e.matrix.copy(n.matrixWorld),e.matrix.invert(),e.matrix.multiply(t.matrixWorld)),e.matrix.decompose(e.position,e.quaternion,e.scale),e.updateMatrixWorld(!0),e.projectionMatrix.copy(t.projectionMatrix),e.projectionMatrixInverse.copy(t.projectionMatrixInverse),e.isPerspectiveCamera&&(e.fov=vt*2*Math.atan(1/e.projectionMatrix.elements[5]),e.zoom=1)}this.getCamera=function(){return j},this.getFoveation=function(){if(p!==null||h!==null)return c},this.setFoveation=function(e){c=e,p!==null&&(p.fixedFoveation=e),h!==null&&h.fixedFoveation!==void 0&&(h.fixedFoveation=e)},this.hasDepthSensing=function(){return v.texture!==null},this.getDepthSensingMesh=function(){return v.getMesh(j)},this.getCameraTexture=function(e){return y[e]};let z=null;function ce(t,i){if(u=i.getViewerPose(l||a),g=i,u!==null){let t=u.views;h!==null&&(e.setRenderTargetFramebuffer(S,h.framebuffer),e.setRenderTarget(S));let i=!1;t.length!==j.cameras.length&&(j.cameras.length=0,i=!0);for(let n=0;n<t.length;n++){let r=t[n],a=null;if(h!==null)a=h.getViewport(r);else{let t=f.getViewSubImage(p,r);a=t.viewport,n===0&&(e.setRenderTargetTextures(S,t.colorTexture,t.depthStencilTexture),e.setRenderTarget(S))}let o=A[n];o===void 0&&(o=new w,o.layers.enable(n),o.viewport=new ut,A[n]=o),o.matrix.fromArray(r.transform.matrix),o.matrix.decompose(o.position,o.quaternion,o.scale),o.projectionMatrix.fromArray(r.projectionMatrix),o.projectionMatrixInverse.copy(o.projectionMatrix).invert(),o.viewport.set(a.x,a.y,a.width,a.height),n===0&&(j.matrix.copy(o.matrix),j.matrix.decompose(j.position,j.quaternion,j.scale)),i===!0&&j.cameras.push(o)}let a=r.enabledFeatures;if(a&&a.includes(`depth-sensing`)&&r.depthUsage==`gpu-optimized`&&_){f=n.getBinding();let e=f.getDepthInformation(t[0]);e&&e.isValid&&e.texture&&v.init(e,r.renderState)}if(a&&a.includes(`camera-access`)&&_){e.state.unbindTexture(),f=n.getBinding();for(let e=0;e<t.length;e++){let n=t[e].camera;if(n){let e=y[n];e||(e=new o,y[n]=e);let t=f.getCameraImage(n);e.sourceTexture=t}}}}for(let e=0;e<C.length;e++){let t=T[e],n=C[e];t!==null&&n!==void 0&&n.update(t,i,l||a)}z&&z(t,i),i.detectedPlanes&&n.dispatchEvent({type:`planesdetected`,data:i}),g=null}let le=new nn;le.setAnimationLoop(ce),this.setAnimationLoop=function(e){z=e},this.dispose=function(){}}},fa=new h,pa=new v;pa.set(-1,0,0,0,1,0,0,0,1);function ma(e,t){function n(e,t){e.matrixAutoUpdate===!0&&e.updateMatrix(),t.value.copy(e.matrix)}function r(t,n){n.color.getRGB(t.fogColor.value,en(e)),n.isFog?(t.fogNear.value=n.near,t.fogFar.value=n.far):n.isFogExp2&&(t.fogDensity.value=n.density)}function i(e,t,n,r,i){t.isNodeMaterial?t.uniformsNeedUpdate=!1:t.isMeshBasicMaterial?a(e,t):t.isMeshLambertMaterial?(a(e,t),t.envMap&&(e.envMapIntensity.value=t.envMapIntensity)):t.isMeshToonMaterial?(a(e,t),d(e,t)):t.isMeshPhongMaterial?(a(e,t),u(e,t),t.envMap&&(e.envMapIntensity.value=t.envMapIntensity)):t.isMeshStandardMaterial?(a(e,t),f(e,t),t.isMeshPhysicalMaterial&&p(e,t,i)):t.isMeshMatcapMaterial?(a(e,t),m(e,t)):t.isMeshDepthMaterial?a(e,t):t.isMeshDistanceMaterial?(a(e,t),h(e,t)):t.isMeshNormalMaterial?a(e,t):t.isLineBasicMaterial?(o(e,t),t.isLineDashedMaterial&&s(e,t)):t.isPointsMaterial?c(e,t,n,r):t.isSpriteMaterial?l(e,t):t.isShadowMaterial?(e.color.value.copy(t.color),e.opacity.value=t.opacity):t.isShaderMaterial&&(t.uniformsNeedUpdate=!1)}function a(e,r){e.opacity.value=r.opacity,r.color&&e.diffuse.value.copy(r.color),r.emissive&&e.emissive.value.copy(r.emissive).multiplyScalar(r.emissiveIntensity),r.map&&(e.map.value=r.map,n(r.map,e.mapTransform)),r.alphaMap&&(e.alphaMap.value=r.alphaMap,n(r.alphaMap,e.alphaMapTransform)),r.bumpMap&&(e.bumpMap.value=r.bumpMap,n(r.bumpMap,e.bumpMapTransform),e.bumpScale.value=r.bumpScale,r.side===1&&(e.bumpScale.value*=-1)),r.normalMap&&(e.normalMap.value=r.normalMap,n(r.normalMap,e.normalMapTransform),e.normalScale.value.copy(r.normalScale),r.side===1&&e.normalScale.value.negate()),r.displacementMap&&(e.displacementMap.value=r.displacementMap,n(r.displacementMap,e.displacementMapTransform),e.displacementScale.value=r.displacementScale,e.displacementBias.value=r.displacementBias),r.emissiveMap&&(e.emissiveMap.value=r.emissiveMap,n(r.emissiveMap,e.emissiveMapTransform)),r.specularMap&&(e.specularMap.value=r.specularMap,n(r.specularMap,e.specularMapTransform)),r.alphaTest>0&&(e.alphaTest.value=r.alphaTest);let i=t.get(r),a=i.envMap,o=i.envMapRotation;a&&(e.envMap.value=a,e.envMapRotation.value.setFromMatrix4(fa.makeRotationFromEuler(o)).transpose(),a.isCubeTexture&&a.isRenderTargetTexture===!1&&e.envMapRotation.value.premultiply(pa),e.reflectivity.value=r.reflectivity,e.ior.value=r.ior,e.refractionRatio.value=r.refractionRatio),r.lightMap&&(e.lightMap.value=r.lightMap,e.lightMapIntensity.value=r.lightMapIntensity,n(r.lightMap,e.lightMapTransform)),r.aoMap&&(e.aoMap.value=r.aoMap,e.aoMapIntensity.value=r.aoMapIntensity,n(r.aoMap,e.aoMapTransform))}function o(e,t){e.diffuse.value.copy(t.color),e.opacity.value=t.opacity,t.map&&(e.map.value=t.map,n(t.map,e.mapTransform))}function s(e,t){e.dashSize.value=t.dashSize,e.totalSize.value=t.dashSize+t.gapSize,e.scale.value=t.scale}function c(e,t,r,i){e.diffuse.value.copy(t.color),e.opacity.value=t.opacity,e.size.value=t.size*r,e.scale.value=i*.5,t.map&&(e.map.value=t.map,n(t.map,e.uvTransform)),t.alphaMap&&(e.alphaMap.value=t.alphaMap,n(t.alphaMap,e.alphaMapTransform)),t.alphaTest>0&&(e.alphaTest.value=t.alphaTest)}function l(e,t){e.diffuse.value.copy(t.color),e.opacity.value=t.opacity,e.rotation.value=t.rotation,t.map&&(e.map.value=t.map,n(t.map,e.mapTransform)),t.alphaMap&&(e.alphaMap.value=t.alphaMap,n(t.alphaMap,e.alphaMapTransform)),t.alphaTest>0&&(e.alphaTest.value=t.alphaTest)}function u(e,t){e.specular.value.copy(t.specular),e.shininess.value=Math.max(t.shininess,1e-4)}function d(e,t){t.gradientMap&&(e.gradientMap.value=t.gradientMap)}function f(e,t){e.metalness.value=t.metalness,t.metalnessMap&&(e.metalnessMap.value=t.metalnessMap,n(t.metalnessMap,e.metalnessMapTransform)),e.roughness.value=t.roughness,t.roughnessMap&&(e.roughnessMap.value=t.roughnessMap,n(t.roughnessMap,e.roughnessMapTransform)),t.envMap&&(e.envMapIntensity.value=t.envMapIntensity)}function p(e,t,r){e.ior.value=t.ior,t.sheen>0&&(e.sheenColor.value.copy(t.sheenColor).multiplyScalar(t.sheen),e.sheenRoughness.value=t.sheenRoughness,t.sheenColorMap&&(e.sheenColorMap.value=t.sheenColorMap,n(t.sheenColorMap,e.sheenColorMapTransform)),t.sheenRoughnessMap&&(e.sheenRoughnessMap.value=t.sheenRoughnessMap,n(t.sheenRoughnessMap,e.sheenRoughnessMapTransform))),t.clearcoat>0&&(e.clearcoat.value=t.clearcoat,e.clearcoatRoughness.value=t.clearcoatRoughness,t.clearcoatMap&&(e.clearcoatMap.value=t.clearcoatMap,n(t.clearcoatMap,e.clearcoatMapTransform)),t.clearcoatRoughnessMap&&(e.clearcoatRoughnessMap.value=t.clearcoatRoughnessMap,n(t.clearcoatRoughnessMap,e.clearcoatRoughnessMapTransform)),t.clearcoatNormalMap&&(e.clearcoatNormalMap.value=t.clearcoatNormalMap,n(t.clearcoatNormalMap,e.clearcoatNormalMapTransform),e.clearcoatNormalScale.value.copy(t.clearcoatNormalScale),t.side===1&&e.clearcoatNormalScale.value.negate())),t.dispersion>0&&(e.dispersion.value=t.dispersion),t.iridescence>0&&(e.iridescence.value=t.iridescence,e.iridescenceIOR.value=t.iridescenceIOR,e.iridescenceThicknessMinimum.value=t.iridescenceThicknessRange[0],e.iridescenceThicknessMaximum.value=t.iridescenceThicknessRange[1],t.iridescenceMap&&(e.iridescenceMap.value=t.iridescenceMap,n(t.iridescenceMap,e.iridescenceMapTransform)),t.iridescenceThicknessMap&&(e.iridescenceThicknessMap.value=t.iridescenceThicknessMap,n(t.iridescenceThicknessMap,e.iridescenceThicknessMapTransform))),t.transmission>0&&(e.transmission.value=t.transmission,e.transmissionSamplerMap.value=r.texture,e.transmissionSamplerSize.value.set(r.width,r.height),t.transmissionMap&&(e.transmissionMap.value=t.transmissionMap,n(t.transmissionMap,e.transmissionMapTransform)),e.thickness.value=t.thickness,t.thicknessMap&&(e.thicknessMap.value=t.thicknessMap,n(t.thicknessMap,e.thicknessMapTransform)),e.attenuationDistance.value=t.attenuationDistance,e.attenuationColor.value.copy(t.attenuationColor)),t.anisotropy>0&&(e.anisotropyVector.value.set(t.anisotropy*Math.cos(t.anisotropyRotation),t.anisotropy*Math.sin(t.anisotropyRotation)),t.anisotropyMap&&(e.anisotropyMap.value=t.anisotropyMap,n(t.anisotropyMap,e.anisotropyMapTransform))),e.specularIntensity.value=t.specularIntensity,e.specularColor.value.copy(t.specularColor),t.specularColorMap&&(e.specularColorMap.value=t.specularColorMap,n(t.specularColorMap,e.specularColorMapTransform)),t.specularIntensityMap&&(e.specularIntensityMap.value=t.specularIntensityMap,n(t.specularIntensityMap,e.specularIntensityMapTransform))}function m(e,t){t.matcap&&(e.matcap.value=t.matcap)}function h(e,n){let r=t.get(n).light;e.referencePosition.value.setFromMatrixPosition(r.matrixWorld),e.nearDistance.value=r.shadow.camera.near,e.farDistance.value=r.shadow.camera.far}return{refreshFogUniforms:r,refreshMaterialUniforms:i}}function ha(e,t,n,r){let i={},a={},o=[],s=e.getParameter(e.MAX_UNIFORM_BUFFER_BINDINGS);function c(e,t){let n=t.program;r.uniformBlockBinding(e,n)}function l(e,n){let o=i[e.id];o===void 0&&(g(e),o=u(e),i[e.id]=o,e.addEventListener(`dispose`,v));let s=n.program;r.updateUBOMapping(e,s);let c=t.render.frame;a[e.id]!==c&&(f(e),a[e.id]=c)}function u(t){let n=d();t.__bindingPointIndex=n;let r=e.createBuffer(),i=t.__size,a=t.usage;return e.bindBuffer(e.UNIFORM_BUFFER,r),e.bufferData(e.UNIFORM_BUFFER,i,a),e.bindBuffer(e.UNIFORM_BUFFER,null),e.bindBufferBase(e.UNIFORM_BUFFER,n,r),r}function d(){for(let e=0;e<s;e++)if(o.indexOf(e)===-1)return o.push(e),e;return F(`WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached.`),0}function f(t){let n=i[t.id],r=t.uniforms,a=t.__cache;e.bindBuffer(e.UNIFORM_BUFFER,n);for(let e=0,t=r.length;e<t;e++){let t=r[e];if(Array.isArray(t))for(let n=0,r=t.length;n<r;n++)p(t[n],e,n,a);else p(t,e,0,a)}e.bindBuffer(e.UNIFORM_BUFFER,null)}function p(t,n,r,i){if(h(t,n,r,i)===!0){let n=t.__offset,r=t.value;if(Array.isArray(r)){let e=0;for(let n=0;n<r.length;n++){let i=r[n],a=_(i);m(i,t.__data,e),typeof i!=`number`&&typeof i!=`boolean`&&!i.isMatrix3&&!ArrayBuffer.isView(i)&&(e+=a.storage/Float32Array.BYTES_PER_ELEMENT)}}else m(r,t.__data,0);e.bufferSubData(e.UNIFORM_BUFFER,n,t.__data)}}function m(e,t,n){typeof e==`number`||typeof e==`boolean`?t[0]=e:e.isMatrix3?(t[0]=e.elements[0],t[1]=e.elements[1],t[2]=e.elements[2],t[3]=0,t[4]=e.elements[3],t[5]=e.elements[4],t[6]=e.elements[5],t[7]=0,t[8]=e.elements[6],t[9]=e.elements[7],t[10]=e.elements[8],t[11]=0):ArrayBuffer.isView(e)?t.set(new e.constructor(e.buffer,e.byteOffset,t.length)):e.toArray(t,n)}function h(e,t,n,r){let i=e.value,a=t+`_`+n;if(r[a]===void 0)return r[a]=typeof i==`number`||typeof i==`boolean`?i:ArrayBuffer.isView(i)?i.slice():i.clone(),!0;{let e=r[a];if(typeof i==`number`||typeof i==`boolean`){if(e!==i)return r[a]=i,!0}else if(ArrayBuffer.isView(i))return!0;else if(e.equals(i)===!1)return e.copy(i),!0}return!1}function g(e){let t=e.uniforms,n=0;for(let e=0,r=t.length;e<r;e++){let r=Array.isArray(t[e])?t[e]:[t[e]];for(let e=0,t=r.length;e<t;e++){let t=r[e],i=Array.isArray(t.value)?t.value:[t.value];for(let e=0,r=i.length;e<r;e++){let r=i[e],a=_(r),o=n%16,s=o%a.boundary,c=o+s;n+=s,c!==0&&16-c<a.storage&&(n+=16-c),t.__data=new Float32Array(a.storage/Float32Array.BYTES_PER_ELEMENT),t.__offset=n,n+=a.storage}}}let r=n%16;return r>0&&(n+=16-r),e.__size=n,e.__cache={},this}function _(e){let t={boundary:0,storage:0};return typeof e==`number`||typeof e==`boolean`?(t.boundary=4,t.storage=4):e.isVector2?(t.boundary=8,t.storage=8):e.isVector3||e.isColor?(t.boundary=16,t.storage=12):e.isVector4?(t.boundary=16,t.storage=16):e.isMatrix3?(t.boundary=48,t.storage=48):e.isMatrix4?(t.boundary=64,t.storage=64):e.isTexture?V(`WebGLRenderer: Texture samplers can not be part of an uniforms group.`):ArrayBuffer.isView(e)?(t.boundary=16,t.storage=e.byteLength):V(`WebGLRenderer: Unsupported uniform value type.`,e),t}function v(t){let n=t.target;n.removeEventListener(`dispose`,v);let r=o.indexOf(n.__bindingPointIndex);o.splice(r,1),e.deleteBuffer(i[n.id]),delete i[n.id],delete a[n.id]}function y(){for(let t in i)e.deleteBuffer(i[t]);o=[],i={},a={}}return{bind:c,update:l,dispose:y}}var ga=new Uint16Array([12469,15057,12620,14925,13266,14620,13807,14376,14323,13990,14545,13625,14713,13328,14840,12882,14931,12528,14996,12233,15039,11829,15066,11525,15080,11295,15085,10976,15082,10705,15073,10495,13880,14564,13898,14542,13977,14430,14158,14124,14393,13732,14556,13410,14702,12996,14814,12596,14891,12291,14937,11834,14957,11489,14958,11194,14943,10803,14921,10506,14893,10278,14858,9960,14484,14039,14487,14025,14499,13941,14524,13740,14574,13468,14654,13106,14743,12678,14818,12344,14867,11893,14889,11509,14893,11180,14881,10751,14852,10428,14812,10128,14765,9754,14712,9466,14764,13480,14764,13475,14766,13440,14766,13347,14769,13070,14786,12713,14816,12387,14844,11957,14860,11549,14868,11215,14855,10751,14825,10403,14782,10044,14729,9651,14666,9352,14599,9029,14967,12835,14966,12831,14963,12804,14954,12723,14936,12564,14917,12347,14900,11958,14886,11569,14878,11247,14859,10765,14828,10401,14784,10011,14727,9600,14660,9289,14586,8893,14508,8533,15111,12234,15110,12234,15104,12216,15092,12156,15067,12010,15028,11776,14981,11500,14942,11205,14902,10752,14861,10393,14812,9991,14752,9570,14682,9252,14603,8808,14519,8445,14431,8145,15209,11449,15208,11451,15202,11451,15190,11438,15163,11384,15117,11274,15055,10979,14994,10648,14932,10343,14871,9936,14803,9532,14729,9218,14645,8742,14556,8381,14461,8020,14365,7603,15273,10603,15272,10607,15267,10619,15256,10631,15231,10614,15182,10535,15118,10389,15042,10167,14963,9787,14883,9447,14800,9115,14710,8665,14615,8318,14514,7911,14411,7507,14279,7198,15314,9675,15313,9683,15309,9712,15298,9759,15277,9797,15229,9773,15166,9668,15084,9487,14995,9274,14898,8910,14800,8539,14697,8234,14590,7790,14479,7409,14367,7067,14178,6621,15337,8619,15337,8631,15333,8677,15325,8769,15305,8871,15264,8940,15202,8909,15119,8775,15022,8565,14916,8328,14804,8009,14688,7614,14569,7287,14448,6888,14321,6483,14088,6171,15350,7402,15350,7419,15347,7480,15340,7613,15322,7804,15287,7973,15229,8057,15148,8012,15046,7846,14933,7611,14810,7357,14682,7069,14552,6656,14421,6316,14251,5948,14007,5528,15356,5942,15356,5977,15353,6119,15348,6294,15332,6551,15302,6824,15249,7044,15171,7122,15070,7050,14949,6861,14818,6611,14679,6349,14538,6067,14398,5651,14189,5311,13935,4958,15359,4123,15359,4153,15356,4296,15353,4646,15338,5160,15311,5508,15263,5829,15188,6042,15088,6094,14966,6001,14826,5796,14678,5543,14527,5287,14377,4985,14133,4586,13869,4257,15360,1563,15360,1642,15358,2076,15354,2636,15341,3350,15317,4019,15273,4429,15203,4732,15105,4911,14981,4932,14836,4818,14679,4621,14517,4386,14359,4156,14083,3795,13808,3437,15360,122,15360,137,15358,285,15355,636,15344,1274,15322,2177,15281,2765,15215,3223,15120,3451,14995,3569,14846,3567,14681,3466,14511,3305,14344,3121,14037,2800,13753,2467,15360,0,15360,1,15359,21,15355,89,15346,253,15325,479,15287,796,15225,1148,15133,1492,15008,1749,14856,1882,14685,1886,14506,1783,14324,1608,13996,1398,13702,1183]),_a=null;function va(){return _a===null&&(_a=new r(ga,16,16,te,ke),_a.name=`DFG_LUT`,_a.minFilter=gt,_a.magFilter=gt,_a.wrapS=Vt,_a.wrapT=Vt,_a.generateMipmaps=!1,_a.needsUpdate=!0),_a}var ya=class{constructor(e={}){let{canvas:t=b(),context:n=null,depth:r=!0,stencil:i=!1,alpha:a=!1,antialias:o=!1,premultipliedAlpha:s=!0,preserveDrawingBuffer:l=!1,powerPreference:u=`default`,failIfMajorPerformanceCaveat:f=!1,reversedDepthBuffer:p=!1,outputBufferType:m=Xt}=e;this.isWebGLRenderer=!0;let g;if(n!==null){if(typeof WebGLRenderingContext<`u`&&n instanceof WebGLRenderingContext)throw Error(`THREE.WebGLRenderer: WebGL 1 is not supported since r163.`);g=n.getContextAttributes().alpha}else g=a;let v=m,y=new Set([Nt,pe,xe]),x=new Set([Xt,d,_,Jt,Gt,ye]),S=new Uint32Array(4),C=new Int32Array(4),w=new R,T=null,D=null,O=[],k=[],A=null;this.domElement=t,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=0,this.toneMappingExposure=1,this.transmissionResolutionScale=1;let j=this,ee=!1,M=null,N=null,P=null,te=null;this._outputColorSpace=Me;let ne=0,re=0,L=null,ie=-1,ae=null,oe=new ut,se=new ut,z=null,ce=new q(0),le=0,ue=t.width,de=t.height,fe=1,me=null,he=null,ge=new ut(0,0,ue,de),_e=new ut(0,0,ue,de),ve=!1,B=new Dt,be=!1,Se=!1,Ce=new h,we=new R,Te=new ut,Ee={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0},De=!1;function Oe(){return L===null?fe:1}let H=n;function Ae(e,n){return t.getContext(e,n)}try{let e={alpha:!0,depth:r,stencil:i,antialias:o,premultipliedAlpha:s,preserveDrawingBuffer:l,powerPreference:u,failIfMajorPerformanceCaveat:f};if(`setAttribute`in t&&t.setAttribute(`data-engine`,`three.js r185`),t.addEventListener(`webglcontextlost`,tt,!1),t.addEventListener(`webglcontextrestored`,nt,!1),t.addEventListener(`webglcontextcreationerror`,it,!1),H===null){let t=`webgl2`;if(H=Ae(t,e),H===null)throw Ae(t)?Error(`THREE.WebGLRenderer: Error creating WebGL context with your selected attributes.`):Error(`THREE.WebGLRenderer: Error creating WebGL context.`)}}catch(e){throw F(`WebGLRenderer: `+e.message),e}let U,je,W,Ne,G,Pe,Fe,Ie,Le,Re,Be,Ve,He,Ue,We,Ge,Ke,qe,Je,Ye,Xe,Ze,Qe;function $e(){U=new Ln(H),U.init(),Xe=new sa(H,U),je=new pn(H,U,e,Xe),W=new aa(H,U),je.reversedDepthBuffer&&p&&W.buffers.depth.setReversed(!0),N=H.createFramebuffer(),P=H.createFramebuffer(),te=H.createFramebuffer(),Ne=new Bn(H),G=new zi,Pe=new oa(H,U,W,G,je,Xe,Ne),Fe=new In(j),Ie=new rn(H),Ze=new dn(H,Ie),Le=new Rn(H,Ie,Ne,Ze),Re=new Hn(H,Le,Ie,Ze,Ne),qe=new Vn(H,je,Pe),We=new mn(G),Be=new Ri(j,Fe,U,je,Ze,We),Ve=new ma(j,G),He=new Ui,Ue=new Xi(U),Ke=new un(j,Fe,W,Re,g,s),Ge=new ia(j,Re,je),Qe=new ha(H,Ne,je,W),Je=new fn(H,U,Ne),Ye=new zn(H,U,Ne),Ne.programs=Be.programs,j.capabilities=je,j.extensions=U,j.properties=G,j.renderLists=He,j.shadowMap=Ge,j.state=W,j.info=Ne}$e(),v!==1009&&(A=new Wn(v,t.width,t.height,o,r,i));let et=new da(j,H);this.xr=et,this.getContext=function(){return H},this.getContextAttributes=function(){return H.getContextAttributes()},this.forceContextLoss=function(){let e=U.get(`WEBGL_lose_context`);e&&e.loseContext()},this.forceContextRestore=function(){let e=U.get(`WEBGL_lose_context`);e&&e.restoreContext()},this.getPixelRatio=function(){return fe},this.setPixelRatio=function(e){e!==void 0&&(fe=e,this.setSize(ue,de,!1))},this.getSize=function(e){return e.set(ue,de)},this.setSize=function(e,n,r=!0){if(et.isPresenting){V(`WebGLRenderer: Can't change size while VR device is presenting.`);return}ue=e,de=n,t.width=Math.floor(e*fe),t.height=Math.floor(n*fe),r===!0&&(t.style.width=e+`px`,t.style.height=n+`px`),A!==null&&A.setSize(t.width,t.height),this.setViewport(0,0,e,n)},this.getDrawingBufferSize=function(e){return e.set(ue*fe,de*fe).floor()},this.setDrawingBufferSize=function(e,n,r){ue=e,de=n,fe=r,t.width=Math.floor(e*r),t.height=Math.floor(n*r),this.setViewport(0,0,e,n)},this.setEffects=function(e){if(v===1009){F(`WebGLRenderer: setEffects() requires outputBufferType set to HalfFloatType or FloatType.`);return}if(e){for(let t=0;t<e.length;t++)if(e[t].isOutputPass===!0){V(`WebGLRenderer: OutputPass is not needed in setEffects(). Tone mapping and color space conversion are applied automatically.`);break}}A.setEffects(e||[])},this.getCurrentViewport=function(e){return e.copy(oe)},this.getViewport=function(e){return e.copy(ge)},this.setViewport=function(e,t,n,r){e.isVector4?ge.set(e.x,e.y,e.z,e.w):ge.set(e,t,n,r),W.viewport(oe.copy(ge).multiplyScalar(fe).round())},this.getScissor=function(e){return e.copy(_e)},this.setScissor=function(e,t,n,r){e.isVector4?_e.set(e.x,e.y,e.z,e.w):_e.set(e,t,n,r),W.scissor(se.copy(_e).multiplyScalar(fe).round())},this.getScissorTest=function(){return ve},this.setScissorTest=function(e){W.setScissorTest(ve=e)},this.setOpaqueSort=function(e){me=e},this.setTransparentSort=function(e){he=e},this.getClearColor=function(e){return e.copy(Ke.getClearColor())},this.setClearColor=function(){Ke.setClearColor(...arguments)},this.getClearAlpha=function(){return Ke.getClearAlpha()},this.setClearAlpha=function(){Ke.setClearAlpha(...arguments)},this.clear=function(e=!0,t=!0,n=!0){let r=0;if(e){let e=!1;if(L!==null){let t=L.texture.format;e=y.has(t)}if(e){let e=L.texture.type,t=x.has(e),n=Ke.getClearColor(),r=Ke.getClearAlpha(),i=n.r,a=n.g,o=n.b;t?(S[0]=i,S[1]=a,S[2]=o,S[3]=r,H.clearBufferuiv(H.COLOR,0,S)):(C[0]=i,C[1]=a,C[2]=o,C[3]=r,H.clearBufferiv(H.COLOR,0,C))}else r|=H.COLOR_BUFFER_BIT}t&&(r|=H.DEPTH_BUFFER_BIT,this.state.buffers.depth.setMask(!0)),n&&(r|=H.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),r!==0&&H.clear(r)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.setNodesHandler=function(e){e.setRenderer(this),M=e},this.dispose=function(){t.removeEventListener(`webglcontextlost`,tt,!1),t.removeEventListener(`webglcontextrestored`,nt,!1),t.removeEventListener(`webglcontextcreationerror`,it,!1),Ke.dispose(),He.dispose(),Ue.dispose(),G.dispose(),Fe.dispose(),Re.dispose(),Ze.dispose(),Qe.dispose(),Be.dispose(),et.dispose(),et.removeEventListener(`sessionstart`,ft),et.removeEventListener(`sessionend`,pt),mt.stop()};function tt(e){e.preventDefault(),c(`WebGLRenderer: Context Lost.`),ee=!0}function nt(){c(`WebGLRenderer: Context Restored.`),ee=!1;let e=Ne.autoReset,t=Ge.enabled,n=Ge.autoUpdate,r=Ge.needsUpdate,i=Ge.type;$e(),Ne.autoReset=e,Ge.enabled=t,Ge.autoUpdate=n,Ge.needsUpdate=r,Ge.type=i}function it(e){F(`WebGLRenderer: A WebGL context could not be created. Reason: `,e.statusMessage)}function at(e){let t=e.target;t.removeEventListener(`dispose`,at),ot(t)}function ot(e){ct(e),G.remove(e)}function ct(e){let t=G.get(e).programs;t!==void 0&&(t.forEach(function(e){Be.releaseProgram(e)}),e.isShaderMaterial&&Be.releaseShaderCache(e))}this.renderBufferDirect=function(e,t,n,r,i,a){t===null&&(t=Ee);let o=i.isMesh&&i.matrixWorld.determinantAffine()<0,s=wt(e,t,n,r,i);W.setMaterial(r,o);let c=n.index,l=1;if(r.wireframe===!0){if(c=Le.getWireframeAttribute(n),c===void 0)return;l=2}let u=n.drawRange,d=n.attributes.position,f=u.start*l,p=(u.start+u.count)*l;a!==null&&(f=Math.max(f,a.start*l),p=Math.min(p,(a.start+a.count)*l)),c===null?d!=null&&(f=Math.max(f,0),p=Math.min(p,d.count)):(f=Math.max(f,0),p=Math.min(p,c.count));let m=p-f;if(m<0||m===1/0)return;Ze.setup(i,r,s,n,c);let h,g=Je;if(c!==null&&(h=Ie.get(c),g=Ye,g.setIndex(h)),i.isMesh)r.wireframe===!0?(W.setLineWidth(r.wireframeLinewidth*Oe()),g.setMode(H.LINES)):g.setMode(H.TRIANGLES);else if(i.isLine){let e=r.linewidth;e===void 0&&(e=1),W.setLineWidth(e*Oe()),i.isLineSegments?g.setMode(H.LINES):i.isLineLoop?g.setMode(H.LINE_LOOP):g.setMode(H.LINE_STRIP)}else i.isPoints?g.setMode(H.POINTS):i.isSprite&&g.setMode(H.TRIANGLES);if(i.isBatchedMesh){if(U.get(`WEBGL_multi_draw`))g.renderMultiDraw(i._multiDrawStarts,i._multiDrawCounts,i._multiDrawCount);else{let e=i._multiDrawStarts,t=i._multiDrawCounts,n=i._multiDrawCount,a=c?Ie.get(c).bytesPerElement:1,o=G.get(r).currentProgram.getUniforms();for(let r=0;r<n;r++)o.setValue(H,`_gl_DrawID`,r),g.render(e[r]/a,t[r])}}else if(i.isInstancedMesh)g.renderInstances(f,m,i.count);else if(n.isInstancedBufferGeometry){let e=n._maxInstanceCount===void 0?1/0:n._maxInstanceCount,t=Math.min(n.instanceCount,e);g.renderInstances(f,m,t)}else g.render(f,m)};function lt(e,t,n){e.transparent===!0&&e.side===2&&e.forceSinglePass===!1?(e.side=1,e.needsUpdate=!0,bt(e,t,n),e.side=0,e.needsUpdate=!0,bt(e,t,n),e.side=2):bt(e,t,n)}this.compile=function(e,t,n=null){n===null&&(n=e),D=Ue.get(n),D.init(t),k.push(D),n.traverseVisible(function(e){e.isLight&&e.layers.test(t.layers)&&(D.pushLight(e),e.castShadow&&D.pushShadow(e))}),e!==n&&e.traverseVisible(function(e){e.isLight&&e.layers.test(t.layers)&&(D.pushLight(e),e.castShadow&&D.pushShadow(e))}),D.setupLights();let r=new Set;return e.traverse(function(e){if(!(e.isMesh||e.isPoints||e.isLine||e.isSprite))return;let t=e.material;if(t){if(Array.isArray(t))for(let i=0;i<t.length;i++){let a=t[i];lt(a,n,e),r.add(a)}else lt(t,n,e),r.add(t)}}),D=k.pop(),r},this.compileAsync=function(e,t,n=null){let r=this.compile(e,t,n);return new Promise(t=>{function n(){if(r.forEach(function(e){G.get(e).currentProgram.isReady()&&r.delete(e)}),r.size===0){t(e);return}setTimeout(n,10)}U.get(`KHR_parallel_shader_compile`)===null?setTimeout(n,10):n()})};let dt=null;function K(e){dt&&dt(e)}function ft(){mt.stop()}function pt(){mt.start()}let mt=new nn;mt.setAnimationLoop(K),typeof self<`u`&&mt.setContext(self),this.setAnimationLoop=function(e){dt=e,et.setAnimationLoop(e),e===null?mt.stop():mt.start()},et.addEventListener(`sessionstart`,ft),et.addEventListener(`sessionend`,pt),this.render=function(e,t){if(t!==void 0&&t.isCamera!==!0){F(`WebGLRenderer.render: camera is not an instance of THREE.Camera.`);return}if(ee===!0)return;M!==null&&M.renderStart(e,t);let n=et.enabled===!0&&et.isPresenting===!0,r=A!==null&&(L===null||n)&&A.begin(j,L);if(e.matrixWorldAutoUpdate===!0&&e.updateMatrixWorld(),t.parent===null&&t.matrixWorldAutoUpdate===!0&&t.updateMatrixWorld(),et.enabled===!0&&et.isPresenting===!0&&(A===null||A.isCompositing()===!1)&&(et.cameraAutoUpdate===!0&&et.updateCamera(t),t=et.getCamera()),e.isScene===!0&&e.onBeforeRender(j,e,t,L),D=Ue.get(e,k.length),D.init(t),D.state.textureUnits=Pe.getTextureUnits(),k.push(D),Ce.multiplyMatrices(t.projectionMatrix,t.matrixWorldInverse),B.setFromProjectionMatrix(Ce,st,t.reversedDepth),Se=this.localClippingEnabled,be=We.init(this.clippingPlanes,Se),T=He.get(e,O.length),T.init(),O.push(T),et.enabled===!0&&et.isPresenting===!0){let e=j.xr.getDepthSensingMesh();e!==null&&ht(e,t,-1/0,j.sortObjects)}ht(e,t,0,j.sortObjects),T.finish(),j.sortObjects===!0&&T.sort(me,he,t.reversedDepth),De=et.enabled===!1||et.isPresenting===!1||et.hasDepthSensing()===!1,De&&Ke.addToRenderList(T,e),this.info.render.frame++,this.info.autoReset===!0&&this.info.reset(),be===!0&&We.beginShadows();let i=D.state.shadowsArray;if(Ge.render(i,e,t),be===!0&&We.endShadows(),(r&&A.hasRenderPass())===!1){let n=T.opaque,r=T.transmissive;if(D.setupLights(),t.isArrayCamera){let i=t.cameras;if(r.length>0)for(let t=0,a=i.length;t<a;t++){let a=i[t];_t(n,r,e,a)}De&&Ke.render(e);for(let t=0,n=i.length;t<n;t++){let n=i[t];gt(T,e,n,n.viewport)}}else r.length>0&&_t(n,r,e,t),De&&Ke.render(e),gt(T,e,t)}L!==null&&re===0&&(Pe.updateMultisampleRenderTarget(L),Pe.updateRenderTargetMipmap(L)),r&&A.end(j),e.isScene===!0&&e.onAfterRender(j,e,t),Ze.resetDefaultState(),ie=-1,ae=null,k.pop(),k.length>0?(D=k[k.length-1],Pe.setTextureUnits(D.state.textureUnits),be===!0&&We.setGlobalState(j.clippingPlanes,D.state.camera)):D=null,O.pop(),T=O.length>0?O[O.length-1]:null,M!==null&&M.renderEnd()};function ht(e,t,n,r){if(e.visible===!1)return;if(e.layers.test(t.layers)){if(e.isGroup)n=e.renderOrder;else if(e.isLOD)e.autoUpdate===!0&&e.update(t);else if(e.isLightProbeGrid)D.pushLightProbeGrid(e);else if(e.isLight)D.pushLight(e),e.castShadow&&D.pushShadow(e);else if(e.isSprite){if(!e.frustumCulled||B.intersectsSprite(e)){r&&Te.setFromMatrixPosition(e.matrixWorld).applyMatrix4(Ce);let t=Re.update(e),i=e.material;i.visible&&T.push(e,t,i,n,Te.z,null)}}else if((e.isMesh||e.isLine||e.isPoints)&&(!e.frustumCulled||B.intersectsObject(e))){let t=Re.update(e),i=e.material;if(r&&(e.boundingSphere===void 0?(t.boundingSphere===null&&t.computeBoundingSphere(),Te.copy(t.boundingSphere.center)):(e.boundingSphere===null&&e.computeBoundingSphere(),Te.copy(e.boundingSphere.center)),Te.applyMatrix4(e.matrixWorld).applyMatrix4(Ce)),Array.isArray(i)){let r=t.groups;for(let a=0,o=r.length;a<o;a++){let o=r[a],s=i[o.materialIndex];s&&s.visible&&T.push(e,t,s,n,Te.z,o)}}else i.visible&&T.push(e,t,i,n,Te.z,null)}}let i=e.children;for(let e=0,a=i.length;e<a;e++)ht(i[e],t,n,r)}function gt(e,t,n,r){let{opaque:i,transmissive:a,transparent:o}=e;D.setupLightsView(n),be===!0&&We.setGlobalState(j.clippingPlanes,n),r&&W.viewport(oe.copy(r)),i.length>0&&vt(i,t,n),a.length>0&&vt(a,t,n),o.length>0&&vt(o,t,n),W.buffers.depth.setTest(!0),W.buffers.depth.setMask(!0),W.buffers.color.setMask(!0),W.setPolygonOffset(!1)}function _t(e,t,n,r){if((n.isScene===!0?n.overrideMaterial:null)!==null)return;if(D.state.transmissionRenderTarget[r.id]===void 0){let e=U.has(`EXT_color_buffer_half_float`)||U.has(`EXT_color_buffer_float`);D.state.transmissionRenderTarget[r.id]=new I(1,1,{generateMipmaps:!0,type:e?ke:Xt,minFilter:rt,samples:Math.max(4,je.samples),stencilBuffer:i,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:ze.workingColorSpace})}let a=D.state.transmissionRenderTarget[r.id],o=r.viewport||oe;a.setSize(o.z*j.transmissionResolutionScale,o.w*j.transmissionResolutionScale);let s=j.getRenderTarget(),c=j.getActiveCubeFace(),l=j.getActiveMipmapLevel();j.setRenderTarget(a),j.getClearColor(ce),le=j.getClearAlpha(),le<1&&j.setClearColor(16777215,.5),j.clear(),De&&Ke.render(n);let u=j.toneMapping;j.toneMapping=0;let d=r.viewport;if(r.viewport!==void 0&&(r.viewport=void 0),D.setupLightsView(r),be===!0&&We.setGlobalState(j.clippingPlanes,r),vt(e,n,r),Pe.updateMultisampleRenderTarget(a),Pe.updateRenderTargetMipmap(a),U.has(`WEBGL_multisampled_render_to_texture`)===!1){let e=!1;for(let i=0,a=t.length;i<a;i++){let{object:a,geometry:o,material:s,group:c}=t[i];if(s.side===2&&a.layers.test(r.layers)){let t=s.side;s.side=1,s.needsUpdate=!0,yt(a,n,r,o,s,c),s.side=t,s.needsUpdate=!0,e=!0}}e===!0&&(Pe.updateMultisampleRenderTarget(a),Pe.updateRenderTargetMipmap(a))}j.setRenderTarget(s,c,l),j.setClearColor(ce,le),d!==void 0&&(r.viewport=d),j.toneMapping=u}function vt(e,t,n){let r=t.isScene===!0?t.overrideMaterial:null;for(let i=0,a=e.length;i<a;i++){let a=e[i],{object:o,geometry:s,group:c}=a,l=a.material;l.allowOverride===!0&&r!==null&&(l=r),o.layers.test(n.layers)&&yt(o,t,n,s,l,c)}}function yt(e,t,n,r,i,a){e.onBeforeRender(j,t,n,r,i,a),e.modelViewMatrix.multiplyMatrices(n.matrixWorldInverse,e.matrixWorld),e.normalMatrix.getNormalMatrix(e.modelViewMatrix),i.onBeforeRender(j,t,n,r,e,a),i.transparent===!0&&i.side===2&&i.forceSinglePass===!1?(i.side=1,i.needsUpdate=!0,j.renderBufferDirect(n,t,r,i,e,a),i.side=0,i.needsUpdate=!0,j.renderBufferDirect(n,t,r,i,e,a),i.side=2):j.renderBufferDirect(n,t,r,i,e,a),e.onAfterRender(j,t,n,r,i,a)}function bt(e,t,n){t.isScene!==!0&&(t=Ee);let r=G.get(e),i=D.state.lights,a=D.state.shadowsArray,o=i.state.version,s=Be.getParameters(e,i.state,a,t,n,D.state.lightProbeGridArray),c=Be.getProgramCacheKey(s),l=r.programs;r.environment=e.isMeshStandardMaterial||e.isMeshLambertMaterial||e.isMeshPhongMaterial?t.environment:null,r.fog=t.fog;let u=e.isMeshStandardMaterial||e.isMeshLambertMaterial&&!e.envMap||e.isMeshPhongMaterial&&!e.envMap;r.envMap=Fe.get(e.envMap||r.environment,u),r.envMapRotation=r.environment!==null&&e.envMap===null?t.environmentRotation:e.envMapRotation,l===void 0&&(e.addEventListener(`dispose`,at),l=new Map,r.programs=l);let d=l.get(c);if(d!==void 0){if(r.currentProgram===d&&r.lightsStateVersion===o)return St(e,s),d}else s.uniforms=Be.getUniforms(e),M!==null&&e.isNodeMaterial&&M.build(e,n,s),e.onBeforeCompile(s,j),d=Be.acquireProgram(s,c),l.set(c,d),r.uniforms=s.uniforms;let f=r.uniforms;return(!e.isShaderMaterial&&!e.isRawShaderMaterial||e.clipping===!0)&&(f.clippingPlanes=We.uniform),St(e,s),r.needsLights=Et(e),r.lightsStateVersion=o,r.needsLights&&(f.ambientLightColor.value=i.state.ambient,f.lightProbe.value=i.state.probe,f.directionalLights.value=i.state.directional,f.directionalLightShadows.value=i.state.directionalShadow,f.spotLights.value=i.state.spot,f.spotLightShadows.value=i.state.spotShadow,f.rectAreaLights.value=i.state.rectArea,f.ltc_1.value=i.state.rectAreaLTC1,f.ltc_2.value=i.state.rectAreaLTC2,f.pointLights.value=i.state.point,f.pointLightShadows.value=i.state.pointShadow,f.hemisphereLights.value=i.state.hemi,f.directionalShadowMatrix.value=i.state.directionalShadowMatrix,f.spotLightMatrix.value=i.state.spotLightMatrix,f.spotLightMap.value=i.state.spotLightMap,f.pointShadowMatrix.value=i.state.pointShadowMatrix),r.lightProbeGrid=D.state.lightProbeGridArray.length>0,r.currentProgram=d,r.uniformsList=null,d}function xt(e){if(e.uniformsList===null){let t=e.currentProgram.getUniforms();e.uniformsList=Zr.seqWithValue(t.seq,e.uniforms)}return e.uniformsList}function St(e,t){let n=G.get(e);n.outputColorSpace=t.outputColorSpace,n.batching=t.batching,n.batchingColor=t.batchingColor,n.instancing=t.instancing,n.instancingColor=t.instancingColor,n.instancingMorph=t.instancingMorph,n.skinning=t.skinning,n.morphTargets=t.morphTargets,n.morphNormals=t.morphNormals,n.morphColors=t.morphColors,n.morphTargetsCount=t.morphTargetsCount,n.numClippingPlanes=t.numClippingPlanes,n.numIntersection=t.numClipIntersection,n.vertexAlphas=t.vertexAlphas,n.vertexTangents=t.vertexTangents,n.toneMapping=t.toneMapping}function Ct(e,t){if(e.length===0)return null;if(e.length===1)return e[0].texture===null?null:e[0];w.setFromMatrixPosition(t.matrixWorld);for(let t=0,n=e.length;t<n;t++){let n=e[t];if(n.texture!==null&&n.boundingBox.containsPoint(w))return n}return null}function wt(e,t,n,r,i){t.isScene!==!0&&(t=Ee),Pe.resetTextureUnits();let a=t.fog,o=r.isMeshStandardMaterial||r.isMeshLambertMaterial||r.isMeshPhongMaterial?t.environment:null,s=L===null?j.outputColorSpace:L.isXRRenderTarget===!0?L.texture.colorSpace:ze.workingColorSpace,c=r.isMeshStandardMaterial||r.isMeshLambertMaterial&&!r.envMap||r.isMeshPhongMaterial&&!r.envMap,l=Fe.get(r.envMap||o,c),u=r.vertexColors===!0&&!!n.attributes.color&&n.attributes.color.itemSize===4,d=!!n.attributes.tangent&&(!!r.normalMap||r.anisotropy>0),f=!!n.morphAttributes.position,p=!!n.morphAttributes.normal,m=!!n.morphAttributes.color,h=0;r.toneMapped&&(L===null||L.isXRRenderTarget===!0)&&(h=j.toneMapping);let g=n.morphAttributes.position||n.morphAttributes.normal||n.morphAttributes.color,_=g===void 0?0:g.length,v=G.get(r),y=D.state.lights;if(be===!0&&(Se===!0||e!==ae)){let t=e===ae&&r.id===ie;We.setState(r,e,t)}let b=!1;r.version===v.__version?v.needsLights&&v.lightsStateVersion!==y.state.version?b=!0:v.outputColorSpace===s?i.isBatchedMesh&&v.batching===!1||!i.isBatchedMesh&&v.batching===!0||i.isBatchedMesh&&v.batchingColor===!0&&i.colorTexture===null||i.isBatchedMesh&&v.batchingColor===!1&&i.colorTexture!==null||i.isInstancedMesh&&v.instancing===!1||!i.isInstancedMesh&&v.instancing===!0||i.isSkinnedMesh&&v.skinning===!1||!i.isSkinnedMesh&&v.skinning===!0||i.isInstancedMesh&&v.instancingColor===!0&&i.instanceColor===null||i.isInstancedMesh&&v.instancingColor===!1&&i.instanceColor!==null||i.isInstancedMesh&&v.instancingMorph===!0&&i.morphTexture===null||i.isInstancedMesh&&v.instancingMorph===!1&&i.morphTexture!==null?b=!0:v.envMap===l?r.fog===!0&&v.fog!==a||v.numClippingPlanes!==void 0&&(v.numClippingPlanes!==We.numPlanes||v.numIntersection!==We.numIntersection)?b=!0:v.vertexAlphas===u&&v.vertexTangents===d&&v.morphTargets===f&&v.morphNormals===p&&v.morphColors===m&&v.toneMapping===h&&v.morphTargetsCount===_?!!v.lightProbeGrid!=D.state.lightProbeGridArray.length>0&&(b=!0):b=!0:b=!0:b=!0:(b=!0,v.__version=r.version);let x=v.currentProgram;b===!0&&(x=bt(r,t,i),M&&r.isNodeMaterial&&M.onUpdateProgram(r,x,v));let S=!1,C=!1,w=!1,T=x.getUniforms(),E=v.uniforms;if(W.useProgram(x.program)&&(S=!0,C=!0,w=!0),r.id!==ie&&(ie=r.id,C=!0),v.needsLights){let e=Ct(D.state.lightProbeGridArray,i);v.lightProbeGrid!==e&&(v.lightProbeGrid=e,C=!0)}if(S||ae!==e){W.buffers.depth.getReversed()&&e.reversedDepth!==!0&&(e._reversedDepth=!0,e.updateProjectionMatrix()),T.setValue(H,`projectionMatrix`,e.projectionMatrix),T.setValue(H,`viewMatrix`,e.matrixWorldInverse);let t=T.map.cameraPosition;t!==void 0&&t.setValue(H,we.setFromMatrixPosition(e.matrixWorld)),je.logarithmicDepthBuffer&&T.setValue(H,`logDepthBufFC`,2/(Math.log(e.far+1)/Math.LN2)),(r.isMeshPhongMaterial||r.isMeshToonMaterial||r.isMeshLambertMaterial||r.isMeshBasicMaterial||r.isMeshStandardMaterial||r.isShaderMaterial)&&T.setValue(H,`isOrthographic`,e.isOrthographicCamera===!0),ae!==e&&(ae=e,C=!0,w=!0)}if(v.needsLights&&(y.state.directionalShadowMap.length>0&&T.setValue(H,`directionalShadowMap`,y.state.directionalShadowMap,Pe),y.state.spotShadowMap.length>0&&T.setValue(H,`spotShadowMap`,y.state.spotShadowMap,Pe),y.state.pointShadowMap.length>0&&T.setValue(H,`pointShadowMap`,y.state.pointShadowMap,Pe)),i.isSkinnedMesh){T.setOptional(H,i,`bindMatrix`),T.setOptional(H,i,`bindMatrixInverse`);let e=i.skeleton;e&&(e.boneTexture===null&&e.computeBoneTexture(),T.setValue(H,`boneTexture`,e.boneTexture,Pe))}i.isBatchedMesh&&(T.setOptional(H,i,`batchingTexture`),T.setValue(H,`batchingTexture`,i._matricesTexture,Pe),T.setOptional(H,i,`batchingIdTexture`),T.setValue(H,`batchingIdTexture`,i._indirectTexture,Pe),T.setOptional(H,i,`batchingColorTexture`),i._colorsTexture!==null&&T.setValue(H,`batchingColorTexture`,i._colorsTexture,Pe));let O=n.morphAttributes;if((O.position!==void 0||O.normal!==void 0||O.color!==void 0)&&qe.update(i,n,x),(C||v.receiveShadow!==i.receiveShadow)&&(v.receiveShadow=i.receiveShadow,T.setValue(H,`receiveShadow`,i.receiveShadow)),(r.isMeshStandardMaterial||r.isMeshLambertMaterial||r.isMeshPhongMaterial)&&r.envMap===null&&t.environment!==null&&(E.envMapIntensity.value=t.environmentIntensity),E.dfgLUT!==void 0&&(E.dfgLUT.value=va()),C){if(T.setValue(H,`toneMappingExposure`,j.toneMappingExposure),v.needsLights&&Tt(E,w),a&&r.fog===!0&&Ve.refreshFogUniforms(E,a),Ve.refreshMaterialUniforms(E,r,fe,de,D.state.transmissionRenderTarget[e.id]),v.needsLights&&v.lightProbeGrid){let e=v.lightProbeGrid;E.probesSH.value=e.texture,E.probesMin.value.copy(e.boundingBox.min),E.probesMax.value.copy(e.boundingBox.max),E.probesResolution.value.copy(e.resolution)}Zr.upload(H,xt(v),E,Pe)}if(r.isShaderMaterial&&r.uniformsNeedUpdate===!0&&(Zr.upload(H,xt(v),E,Pe),r.uniformsNeedUpdate=!1),r.isSpriteMaterial&&T.setValue(H,`center`,i.center),T.setValue(H,`modelViewMatrix`,i.modelViewMatrix),T.setValue(H,`normalMatrix`,i.normalMatrix),T.setValue(H,`modelMatrix`,i.matrixWorld),r.uniformsGroups!==void 0){let e=r.uniformsGroups;for(let t=0,n=e.length;t<n;t++){let n=e[t];Qe.update(n,x),Qe.bind(n,x)}}return x}function Tt(e,t){e.ambientLightColor.needsUpdate=t,e.lightProbe.needsUpdate=t,e.directionalLights.needsUpdate=t,e.directionalLightShadows.needsUpdate=t,e.pointLights.needsUpdate=t,e.pointLightShadows.needsUpdate=t,e.spotLights.needsUpdate=t,e.spotLightShadows.needsUpdate=t,e.rectAreaLights.needsUpdate=t,e.hemisphereLights.needsUpdate=t}function Et(e){return e.isMeshLambertMaterial||e.isMeshToonMaterial||e.isMeshPhongMaterial||e.isMeshStandardMaterial||e.isShadowMaterial||e.isShaderMaterial&&e.lights===!0}this.getActiveCubeFace=function(){return ne},this.getActiveMipmapLevel=function(){return re},this.getRenderTarget=function(){return L},this.setRenderTargetTextures=function(e,t,n){let r=G.get(e);r.__autoAllocateDepthBuffer=e.resolveDepthBuffer===!1,r.__autoAllocateDepthBuffer===!1&&(r.__useRenderToTexture=!1),G.get(e.texture).__webglTexture=t,G.get(e.depthTexture).__webglTexture=r.__autoAllocateDepthBuffer?void 0:n,r.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(e,t){let n=G.get(e);n.__webglFramebuffer=t,n.__useDefaultFramebuffer=t===void 0},this.setRenderTarget=function(e,t=0,n=0){L=e,ne=t,re=n;let r=null,i=!1,a=!1;if(e){let o=G.get(e);if(o.__useDefaultFramebuffer!==void 0){W.bindFramebuffer(H.FRAMEBUFFER,o.__webglFramebuffer),oe.copy(e.viewport),se.copy(e.scissor),z=e.scissorTest,W.viewport(oe),W.scissor(se),W.setScissorTest(z),ie=-1;return}if(o.__webglFramebuffer===void 0)Pe.setupRenderTarget(e);else if(o.__hasExternalTextures)Pe.rebindTextures(e,G.get(e.texture).__webglTexture,G.get(e.depthTexture).__webglTexture);else if(e.depthBuffer){let t=e.depthTexture;if(o.__boundDepthTexture!==t){if(t!==null&&G.has(t)&&(e.width!==t.image.width||e.height!==t.image.height))throw Error(`THREE.WebGLRenderer: Attached DepthTexture is initialized to the incorrect size.`);Pe.setupDepthRenderbuffer(e)}}let s=e.texture;(s.isData3DTexture||s.isDataArrayTexture||s.isCompressedArrayTexture)&&(a=!0);let c=G.get(e).__webglFramebuffer;e.isWebGLCubeRenderTarget?(r=Array.isArray(c[t])?c[t][n]:c[t],i=!0):r=e.samples>0&&Pe.useMultisampledRTT(e)===!1?G.get(e).__webglMultisampledFramebuffer:Array.isArray(c)?c[n]:c,oe.copy(e.viewport),se.copy(e.scissor),z=e.scissorTest}else oe.copy(ge).multiplyScalar(fe).floor(),se.copy(_e).multiplyScalar(fe).floor(),z=ve;if(n!==0&&(r=N),W.bindFramebuffer(H.FRAMEBUFFER,r)&&W.drawBuffers(e,r),W.viewport(oe),W.scissor(se),W.setScissorTest(z),i){let r=G.get(e.texture);H.framebufferTexture2D(H.FRAMEBUFFER,H.COLOR_ATTACHMENT0,H.TEXTURE_CUBE_MAP_POSITIVE_X+t,r.__webglTexture,n)}else if(a){let r=t;for(let t=0;t<e.textures.length;t++){let i=G.get(e.textures[t]);H.framebufferTextureLayer(H.FRAMEBUFFER,H.COLOR_ATTACHMENT0+t,i.__webglTexture,n,r)}}else if(e!==null&&n!==0){let t=G.get(e.texture);H.framebufferTexture2D(H.FRAMEBUFFER,H.COLOR_ATTACHMENT0,H.TEXTURE_2D,t.__webglTexture,n)}ie=-1},this.readRenderTargetPixels=function(e,t,n,r,i,a,o,s=0){if(!(e&&e.isWebGLRenderTarget)){F(`WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.`);return}let c=G.get(e).__webglFramebuffer;if(e.isWebGLCubeRenderTarget&&o!==void 0&&(c=c[o]),c){W.bindFramebuffer(H.FRAMEBUFFER,c);try{let o=e.textures[s],c=o.format,l=o.type;if(e.textures.length>1&&H.readBuffer(H.COLOR_ATTACHMENT0+s),!je.textureFormatReadable(c)){F(`WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.`);return}if(!je.textureTypeReadable(l)){F(`WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.`);return}t>=0&&t<=e.width-r&&n>=0&&n<=e.height-i&&H.readPixels(t,n,r,i,Xe.convert(c),Xe.convert(l),a)}finally{let e=L===null?null:G.get(L).__webglFramebuffer;W.bindFramebuffer(H.FRAMEBUFFER,e)}}},this.readRenderTargetPixelsAsync=async function(e,t,n,r,i,a,o,s=0){if(!(e&&e.isWebGLRenderTarget))throw Error(`THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.`);let c=G.get(e).__webglFramebuffer;if(e.isWebGLCubeRenderTarget&&o!==void 0&&(c=c[o]),c){if(t>=0&&t<=e.width-r&&n>=0&&n<=e.height-i){W.bindFramebuffer(H.FRAMEBUFFER,c);let o=e.textures[s],l=o.format,u=o.type;if(e.textures.length>1&&H.readBuffer(H.COLOR_ATTACHMENT0+s),!je.textureFormatReadable(l))throw Error(`THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.`);if(!je.textureTypeReadable(u))throw Error(`THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.`);let d=H.createBuffer();H.bindBuffer(H.PIXEL_PACK_BUFFER,d),H.bufferData(H.PIXEL_PACK_BUFFER,a.byteLength,H.STREAM_READ),H.readPixels(t,n,r,i,Xe.convert(l),Xe.convert(u),0);let f=L===null?null:G.get(L).__webglFramebuffer;W.bindFramebuffer(H.FRAMEBUFFER,f);let p=H.fenceSync(H.SYNC_GPU_COMMANDS_COMPLETE,0);return H.flush(),await E(H,p,4),H.bindBuffer(H.PIXEL_PACK_BUFFER,d),H.getBufferSubData(H.PIXEL_PACK_BUFFER,0,a),H.deleteBuffer(d),H.deleteSync(p),a}throw Error(`THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.`)}},this.copyFramebufferToTexture=function(e,t=null,n=0){let r=2**-n,i=Math.floor(e.image.width*r),a=Math.floor(e.image.height*r),o=t===null?0:t.x,s=t===null?0:t.y;Pe.setTexture2D(e,0),H.copyTexSubImage2D(H.TEXTURE_2D,n,0,0,o,s,i,a),W.unbindTexture()},this.copyTextureToTexture=function(e,t,n=null,r=null,i=0,a=0){let o,s,c,l,u,d,f,p,m,h=e.isCompressedTexture?e.mipmaps[a]:e.image;if(n!==null)o=n.max.x-n.min.x,s=n.max.y-n.min.y,c=n.isBox3?n.max.z-n.min.z:1,l=n.min.x,u=n.min.y,d=n.isBox3?n.min.z:0;else{let t=2**-i;o=Math.floor(h.width*t),s=Math.floor(h.height*t),c=e.isDataArrayTexture?h.depth:e.isData3DTexture?Math.floor(h.depth*t):1,l=0,u=0,d=0}r===null?(f=0,p=0,m=0):(f=r.x,p=r.y,m=r.z);let g=Xe.convert(t.format),_=Xe.convert(t.type),v;t.isData3DTexture?(Pe.setTexture3D(t,0),v=H.TEXTURE_3D):t.isDataArrayTexture||t.isCompressedArrayTexture?(Pe.setTexture2DArray(t,0),v=H.TEXTURE_2D_ARRAY):(Pe.setTexture2D(t,0),v=H.TEXTURE_2D),W.activeTexture(H.TEXTURE0),W.pixelStorei(H.UNPACK_FLIP_Y_WEBGL,t.flipY),W.pixelStorei(H.UNPACK_PREMULTIPLY_ALPHA_WEBGL,t.premultiplyAlpha),W.pixelStorei(H.UNPACK_ALIGNMENT,t.unpackAlignment);let y=W.getParameter(H.UNPACK_ROW_LENGTH),b=W.getParameter(H.UNPACK_IMAGE_HEIGHT),x=W.getParameter(H.UNPACK_SKIP_PIXELS),S=W.getParameter(H.UNPACK_SKIP_ROWS),C=W.getParameter(H.UNPACK_SKIP_IMAGES);W.pixelStorei(H.UNPACK_ROW_LENGTH,h.width),W.pixelStorei(H.UNPACK_IMAGE_HEIGHT,h.height),W.pixelStorei(H.UNPACK_SKIP_PIXELS,l),W.pixelStorei(H.UNPACK_SKIP_ROWS,u),W.pixelStorei(H.UNPACK_SKIP_IMAGES,d);let w=e.isDataArrayTexture||e.isData3DTexture,T=t.isDataArrayTexture||t.isData3DTexture;if(e.isDepthTexture){let n=G.get(e),r=G.get(t),h=G.get(n.__renderTarget),g=G.get(r.__renderTarget);W.bindFramebuffer(H.READ_FRAMEBUFFER,h.__webglFramebuffer),W.bindFramebuffer(H.DRAW_FRAMEBUFFER,g.__webglFramebuffer);for(let n=0;n<c;n++)w&&(H.framebufferTextureLayer(H.READ_FRAMEBUFFER,H.COLOR_ATTACHMENT0,G.get(e).__webglTexture,i,d+n),H.framebufferTextureLayer(H.DRAW_FRAMEBUFFER,H.COLOR_ATTACHMENT0,G.get(t).__webglTexture,a,m+n)),H.blitFramebuffer(l,u,o,s,f,p,o,s,H.DEPTH_BUFFER_BIT,H.NEAREST);W.bindFramebuffer(H.READ_FRAMEBUFFER,null),W.bindFramebuffer(H.DRAW_FRAMEBUFFER,null)}else if(i!==0||e.isRenderTargetTexture||G.has(e)){let n=G.get(e),r=G.get(t);W.bindFramebuffer(H.READ_FRAMEBUFFER,P),W.bindFramebuffer(H.DRAW_FRAMEBUFFER,te);for(let e=0;e<c;e++)w?H.framebufferTextureLayer(H.READ_FRAMEBUFFER,H.COLOR_ATTACHMENT0,n.__webglTexture,i,d+e):H.framebufferTexture2D(H.READ_FRAMEBUFFER,H.COLOR_ATTACHMENT0,H.TEXTURE_2D,n.__webglTexture,i),T?H.framebufferTextureLayer(H.DRAW_FRAMEBUFFER,H.COLOR_ATTACHMENT0,r.__webglTexture,a,m+e):H.framebufferTexture2D(H.DRAW_FRAMEBUFFER,H.COLOR_ATTACHMENT0,H.TEXTURE_2D,r.__webglTexture,a),i===0?T?H.copyTexSubImage3D(v,a,f,p,m+e,l,u,o,s):H.copyTexSubImage2D(v,a,f,p,l,u,o,s):H.blitFramebuffer(l,u,o,s,f,p,o,s,H.COLOR_BUFFER_BIT,H.NEAREST);W.bindFramebuffer(H.READ_FRAMEBUFFER,null),W.bindFramebuffer(H.DRAW_FRAMEBUFFER,null)}else T?e.isDataTexture||e.isData3DTexture?H.texSubImage3D(v,a,f,p,m,o,s,c,g,_,h.data):t.isCompressedArrayTexture?H.compressedTexSubImage3D(v,a,f,p,m,o,s,c,g,h.data):H.texSubImage3D(v,a,f,p,m,o,s,c,g,_,h):e.isDataTexture?H.texSubImage2D(H.TEXTURE_2D,a,f,p,o,s,g,_,h.data):e.isCompressedTexture?H.compressedTexSubImage2D(H.TEXTURE_2D,a,f,p,h.width,h.height,g,h.data):H.texSubImage2D(H.TEXTURE_2D,a,f,p,o,s,g,_,h);W.pixelStorei(H.UNPACK_ROW_LENGTH,y),W.pixelStorei(H.UNPACK_IMAGE_HEIGHT,b),W.pixelStorei(H.UNPACK_SKIP_PIXELS,x),W.pixelStorei(H.UNPACK_SKIP_ROWS,S),W.pixelStorei(H.UNPACK_SKIP_IMAGES,C),a===0&&t.generateMipmaps&&H.generateMipmap(v),W.unbindTexture()},this.initRenderTarget=function(e){G.get(e).__webglFramebuffer===void 0&&Pe.setupRenderTarget(e)},this.initTexture=function(e){e.isCubeTexture?Pe.setTextureCube(e,0):e.isData3DTexture?Pe.setTexture3D(e,0):e.isDataArrayTexture||e.isCompressedArrayTexture?Pe.setTexture2DArray(e,0):Pe.setTexture2D(e,0),W.unbindTexture()},this.resetState=function(){ne=0,re=0,L=null,W.reset(),Ze.reset()},typeof __THREE_DEVTOOLS__<`u`&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent(`observe`,{detail:this}))}get coordinateSystem(){return st}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;let t=this.getContext();t.drawingBufferColorSpace=ze._getDrawingBufferColorSpace(e),t.unpackColorSpace=ze._getUnpackColorSpace()}},ba=`chrono-express:settings:v1`,xa=2,Sa=[{id:`brightness`,label:`Brightness`,hint:`Tone-mapping exposure. Raise it if the carriages read too dark.`,group:`Display`,type:`slider`,min:.4,max:2.2,step:.05,format:e=>`${Math.round(e/1.15*100)}%`},{id:`fov`,label:`Field of View`,hint:`Vertical FOV of the third-person camera.`,group:`Display`,type:`slider`,min:55,max:95,step:1,format:e=>`${Math.round(e)}°`},{id:`bloom`,label:`Bloom`,hint:`Soft glow on lamps, lit windows and the moon. The blur is half resolution.`,group:`Display`,type:`toggle`},{id:`shadowQuality`,label:`Shadow Quality`,hint:`PCF shadows on the evening sun. Off, or a 1024, 2048, or 4096 map. Applies immediately.`,group:`Display`,type:`choice`,choices:[{value:`off`,label:`Off`},{value:`low`,label:`Low`},{value:`medium`,label:`Medium`},{value:`high`,label:`High`}]},{id:`renderQuality`,label:`Render quality`,hint:`Auto adjusts resolution gradually for weak laptops. HTML menus and HUD stay sharp.`,group:`Display`,type:`choice`,choices:[{value:`auto`,label:`Auto`},{value:`high`,label:`High (100%)`},{value:`balanced`,label:`Balanced (85%)`},{value:`performance`,label:`Performance (70%)`}]},{id:`grassDensity`,label:`Grass Density`,hint:`How many blades are drawn around the Boarding spawn. Applies immediately.`,group:`Display`,type:`choice`,choices:[{value:`low`,label:`Low`},{value:`medium`,label:`Medium`},{value:`high`,label:`High`}]},{id:`showStats`,label:`Performance Counter`,hint:`Shows frames per second in the corner of the HUD.`,group:`Display`,type:`toggle`},{id:`captureShortcuts`,label:`Capture Browser Shortcuts`,hint:`Plays fullscreen so Ctrl+W, Ctrl+T and Ctrl+Tab reach the game instead of the browser. Esc still pauses.`,group:`Display`,type:`toggle`},{id:`mouseSensitivity`,label:`Mouse Sensitivity`,hint:`Multiplier on how far the camera swings per mouse movement.`,group:`Gameplay`,type:`slider`,min:.2,max:3,step:.05,format:e=>`${e.toFixed(2)}×`},{id:`invertY`,label:`Invert Vertical Look`,hint:`Push the mouse forward to look up.`,group:`Gameplay`,type:`toggle`},{id:`crouchMode`,label:`Crouch`,hint:`Toggle: press once to crouch, again to stand. Hold: crouch only while the key is down.`,group:`Gameplay`,type:`choice`,choices:[{value:`toggle`,label:`Toggle`},{value:`hold`,label:`Hold`}]},{id:`cameraDistance`,label:`Camera Distance`,hint:`How far the camera sits behind the player in open space.`,group:`Gameplay`,type:`slider`,min:3,max:7,step:.1,format:e=>`${e.toFixed(1)} m`},{id:`masterVolume`,label:`Master Volume`,hint:`Overall mix: music, ability cues and the time-distortion bed.`,group:`Audio`,type:`slider`,min:0,max:1,step:.01,format:e=>`${Math.round(e*100)}%`},{id:`mute`,label:`Mute`,hint:`Silence everything without changing the volume slider.`,group:`Audio`,type:`toggle`}],Ca={low:1024,medium:2048,high:4096};function wa(e){return Ca[e]??0}var Ta={brightness:1.15,fov:60,renderScale:1,renderQuality:`auto`,bloom:!0,shadowQuality:`medium`,grassDensity:`medium`,showStats:!1,captureShortcuts:!0,mouseSensitivity:1,invertY:!1,crouchMode:`toggle`,cameraDistance:4.8,masterVolume:.5,mute:!1},Ea=[{id:`forward`,label:`Move Forward`,group:`Movement`,held:!0},{id:`back`,label:`Move Back`,group:`Movement`,held:!0},{id:`left`,label:`Move Left`,group:`Movement`,held:!0},{id:`right`,label:`Move Right`,group:`Movement`,held:!0},{id:`run`,label:`Run`,group:`Movement`,held:!0},{id:`jump`,label:`Jump`,group:`Movement`,held:!0},{id:`duck`,label:`Crouch`,group:`Movement`,held:!0},{id:`interact`,label:`Interact`,group:`Actions`},{id:`distract`,label:`Throw Distractor`,group:`Actions`},{id:`toggleView`,label:`First / Third Person`,group:`Actions`},{id:`slow`,label:`Slow Time`,group:`Time Abilities`},{id:`freeze`,label:`Freeze Time`,group:`Time Abilities`},{id:`rewind`,label:`Rewind`,group:`Time Abilities`},{id:`ghost`,label:`Time Ghost`,group:`Time Abilities`},{id:`restart`,label:`Restart Level`,group:`System`}],Da={forward:[`KeyW`,`ArrowUp`],back:[`KeyS`,`ArrowDown`],left:[`KeyA`,`ArrowLeft`],right:[`KeyD`,`ArrowRight`],run:[`ShiftLeft`,`ShiftRight`],jump:[`Space`,null],duck:[`KeyX`,`KeyZ`],interact:[`KeyE`,null],distract:[`KeyT`,null],toggleView:[`KeyV`,null],slow:[`Digit1`,`KeyQ`],freeze:[`Digit2`,`KeyF`],rewind:[`Digit3`,`KeyC`],ghost:[`Digit4`,`KeyG`],restart:[`KeyR`,null]},Oa=[`Escape`],ka={Space:`Space`,Escape:`Esc`,Enter:`Enter`,NumpadEnter:`Num Enter`,Tab:`Tab`,Backspace:`Backspace`,Backquote:"`",Minus:`-`,Equal:`=`,BracketLeft:`[`,BracketRight:`]`,Backslash:`\\`,Semicolon:`;`,Quote:`'`,Comma:`,`,Period:`.`,Slash:`/`,CapsLock:`Caps`,ShiftLeft:`L Shift`,ShiftRight:`R Shift`,ControlLeft:`L Ctrl`,ControlRight:`R Ctrl`,AltLeft:`L Alt`,AltRight:`R Alt`,ArrowUp:`↑`,ArrowDown:`↓`,ArrowLeft:`←`,ArrowRight:`→`,Insert:`Ins`,Delete:`Del`,Home:`Home`,End:`End`,PageUp:`Pg Up`,PageDown:`Pg Dn`};function Aa(e){return e?ka[e]?ka[e]:e.startsWith(`Key`)?e.slice(3):e.startsWith(`Digit`)?e.slice(5):e.startsWith(`Numpad`)?`Num ${e.slice(6)}`:e:`—`}function ja(e){let t=(e??[]).filter(Boolean).map(Aa);return t.length?t.join(`/`):`Unbound`}function Ma(){let e=ja(Y.getBinding(`duck`));return Y.get(`crouchMode`)===`hold`?`hold ${e}`:`press ${e}`}function Na(e){let t={};for(let n of Ea){let r=e[n.id]??Da[n.id]??[null,null];t[n.id]=[r[0]??null,r[1]??null]}return t}function Pa(){try{let e=window.localStorage.getItem(ba);return e?JSON.parse(e):null}catch{return null}}function Fa(){let e=Pa()??{},t={...Ta};for(let n of Sa){let r=e.options?.[n.id];r!==void 0&&(n.type===`toggle`&&typeof r==`boolean`?t[n.id]=r:n.type===`slider`&&typeof r==`number`&&Number.isFinite(r)?t[n.id]=Math.min(n.max,Math.max(n.min,r)):n.type===`choice`&&n.choices.some(e=>e.value===r)&&(t[n.id]=r))}e.options&&e.options.shadowQuality===void 0&&e.options.shadows===!1&&(t.shadowQuality=`off`);let n={...e.bindings??{}},r=(e.bindingsVersion??1)<xa,i=Object.entries(n).some(([e,t])=>e!==`duck`&&t?.some(e=>e===`KeyX`||e===`KeyZ`));r&&n.duck?.[0]===`ControlLeft`&&n.duck?.[1]===`ControlRight`&&!i&&(n.duck=[...Da.duck]);let a=Na(n),o=new Set,s=1;r&&e.bindings&&c();function c(){try{window.localStorage.setItem(ba,JSON.stringify({options:t,bindings:a,bindingsVersion:xa}))}catch{}}function l(e){for(let n of o)n(t,e)}function u(e){return e===`renderScale`?s:e===void 0?t:t[e]}function d(e){let t=Math.min(1,Math.max(.7,e));s!==t&&(s=t,l(`renderScale`))}function f(e,n){t[e]!==n&&(t[e]=n,c(),l(e))}function p(e){return o.add(e),()=>o.delete(e)}function m(){return a}function h(e){return a[e]??[null,null]}function g(e,t){for(let n of Ea)if(n.id!==t&&a[n.id].includes(e))return n.id;return null}function _(e,t,n){if(!(!a[e]||t!==0&&t!==1)&&!(n&&Oa.includes(n))){if(n)for(let r of Ea){let i=a[r.id];for(let a=0;a<2;a+=1)i[a]===n&&(r.id!==e||a!==t)&&(i[a]=null)}a[e][t]=n??null,c(),l(`bindings`)}}function v(e,t){_(e,t,null)}function y(){Object.assign(t,Ta),c(),l(`options`)}function b(){Object.assign(a,Na(Da)),c(),l(`bindings`)}function x(){Object.assign(t,Ta),Object.assign(a,Na(Da)),c(),l(`all`)}return{get:u,set:f,setRuntimeRenderScale:d,subscribe:p,getBindings:m,getBinding:h,findConflict:g,setBinding:_,clearBinding:v,resetOptions:y,resetBindings:b,resetAll:x}}var Y=Fa(),Ia=1.25;function La(e){let t=new ya({canvas:e,antialias:!1});t.toneMapping=4;let n=null;function r(){t.setPixelRatio(Math.min(window.devicePixelRatio,Ia)*Y.get(`renderScale`)),t.setSize(window.innerWidth,window.innerHeight)}function i(){n&&n.traverse(e=>{let t=e.material;if(t)for(let e of Array.isArray(t)?t:[t])e.needsUpdate=!0})}function a(e){!n||!e||n.traverse(t=>{if(!t.isDirectionalLight||!t.castShadow)return;let n=t.shadow;(n.mapSize.x!==e||n.mapSize.y!==e)&&(n.mapSize.set(e,e),n.map&&=(n.map.depthTexture?.dispose(),n.map.dispose(),null),n.needsUpdate=!0)})}function o(){t.toneMappingExposure=Y.get(`brightness`);let e=Y.get(`shadowQuality`),n=e!==`off`,o=t.shadowMap.enabled!==n,s=t.shadowMap.type!==1;t.shadowMap.enabled=n,t.shadowMap.type=1,a(wa(e)||2048),(o||s)&&(t.shadowMap.needsUpdate=!0,i());let c=Math.min(window.devicePixelRatio,Ia)*Y.get(`renderScale`);Math.abs(t.getPixelRatio()-c)>1e-4&&r()}o(),r();let s=Y.subscribe(o);window.addEventListener(`resize`,r);function c(){s(),window.removeEventListener(`resize`,r)}return{renderer:t,resize:r,dispose:c,setScene(e){n=e}}}var Ra={name:`CopyShader`,uniforms:{tDiffuse:{value:null},opacity:{value:1}},vertexShader:`

		varying vec2 vUv;

		void main() {

			vUv = uv;
			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		uniform float opacity;

		uniform sampler2D tDiffuse;

		varying vec2 vUv;

		void main() {

			vec4 texel = texture2D( tDiffuse, vUv );
			gl_FragColor = opacity * texel;


		}`},za=class{constructor(){this.isPass=!0,this.enabled=!0,this.needsSwap=!0,this.clear=!1,this.renderToScreen=!1}setSize(){}render(){console.error(`THREE.Pass: .render() must be implemented in derived pass.`)}dispose(){}},Ba=new Se(-1,1,1,-1,0,1),Va=new class extends We{constructor(){super(),this.setAttribute(`position`,new be([-1,3,0,-1,-1,0,3,-1,0],3)),this.setAttribute(`uv`,new be([0,2,0,0,2,0],2))}},Ha=class{constructor(e){this._mesh=new z(Va,e)}dispose(){this._mesh.geometry.dispose()}render(e){e.render(this._mesh,Ba)}get material(){return this._mesh.material}set material(e){this._mesh.material=e}},Ua=class extends za{constructor(e,t=`tDiffuse`){super(),this.textureID=t,this.uniforms=null,this.material=null,e instanceof Je?(this.uniforms=e.uniforms,this.material=e):e&&(this.uniforms=Ht.clone(e.uniforms),this.material=new Je({name:e.name===void 0?`unspecified`:e.name,defines:Object.assign({},e.defines),uniforms:this.uniforms,vertexShader:e.vertexShader,fragmentShader:e.fragmentShader})),this._fsQuad=new Ha(this.material)}render(e,t,n){this.uniforms[this.textureID]&&(this.uniforms[this.textureID].value=n.texture),this._fsQuad.material=this.material,this.renderToScreen?(e.setRenderTarget(null),this._fsQuad.render(e)):(e.setRenderTarget(t),this.clear&&e.clear(e.autoClearColor,e.autoClearDepth,e.autoClearStencil),this._fsQuad.render(e))}dispose(){this.material.dispose(),this._fsQuad.dispose()}},Wa=class extends za{constructor(e,t){super(),this.scene=e,this.camera=t,this.clear=!0,this.needsSwap=!1,this.inverse=!1}render(e,t,n){let r=e.getContext(),i=e.state;i.buffers.color.setMask(!1),i.buffers.depth.setMask(!1),i.buffers.color.setLocked(!0),i.buffers.depth.setLocked(!0);let a,o;this.inverse?(a=0,o=1):(a=1,o=0),i.buffers.stencil.setTest(!0),i.buffers.stencil.setOp(r.REPLACE,r.REPLACE,r.REPLACE),i.buffers.stencil.setFunc(r.ALWAYS,a,4294967295),i.buffers.stencil.setClear(o),i.buffers.stencil.setLocked(!0),e.setRenderTarget(n),this.clear&&e.clear(),e.render(this.scene,this.camera),e.setRenderTarget(t),this.clear&&e.clear(),e.render(this.scene,this.camera),i.buffers.color.setLocked(!1),i.buffers.depth.setLocked(!1),i.buffers.color.setMask(!0),i.buffers.depth.setMask(!0),i.buffers.stencil.setLocked(!1),i.buffers.stencil.setFunc(r.EQUAL,1,4294967295),i.buffers.stencil.setOp(r.KEEP,r.KEEP,r.KEEP),i.buffers.stencil.setLocked(!0)}},Ga=class extends za{constructor(){super(),this.needsSwap=!1}render(e){e.state.buffers.stencil.setLocked(!1),e.state.buffers.stencil.setTest(!1)}},Ka=class{constructor(e,t){if(this.renderer=e,this._pixelRatio=e.getPixelRatio(),t===void 0){let n=e.getSize(new m);this._width=n.width,this._height=n.height,t=new I(this._width*this._pixelRatio,this._height*this._pixelRatio,{type:ke}),t.texture.name=`EffectComposer.rt1`}else this._width=t.width,this._height=t.height;this.renderTarget1=t,this.renderTarget2=t.clone(),this.renderTarget2.texture.name=`EffectComposer.rt2`,this.writeBuffer=this.renderTarget1,this.readBuffer=this.renderTarget2,this.renderToScreen=!0,this.passes=[],this.copyPass=new Ua(Ra),this.copyPass.material.blending=0,this.timer=new Xe}swapBuffers(){let e=this.readBuffer;this.readBuffer=this.writeBuffer,this.writeBuffer=e}addPass(e){this.passes.push(e),e.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}insertPass(e,t){this.passes.splice(t,0,e),e.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}removePass(e){let t=this.passes.indexOf(e);t!==-1&&this.passes.splice(t,1)}isLastEnabledPass(e){for(let t=e+1;t<this.passes.length;t++)if(this.passes[t].enabled)return!1;return!0}render(e){this.timer.update(),e===void 0&&(e=this.timer.getDelta());let t=this.renderer.getRenderTarget(),n=!1;for(let t=0,r=this.passes.length;t<r;t++){let r=this.passes[t];if(r.enabled!==!1){if(r.renderToScreen=this.renderToScreen&&this.isLastEnabledPass(t),r.render(this.renderer,this.writeBuffer,this.readBuffer,e,n),r.needsSwap){if(n){let t=this.renderer.getContext(),n=this.renderer.state.buffers.stencil;n.setFunc(t.NOTEQUAL,1,4294967295),this.copyPass.render(this.renderer,this.writeBuffer,this.readBuffer,e),n.setFunc(t.EQUAL,1,4294967295)}this.swapBuffers()}Wa!==void 0&&(r instanceof Wa?n=!0:r instanceof Ga&&(n=!1))}}this.renderer.setRenderTarget(t)}reset(e){if(e===void 0){let t=this.renderer.getSize(new m);this._pixelRatio=this.renderer.getPixelRatio(),this._width=t.width,this._height=t.height,e=this.renderTarget1.clone(),e.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}this.renderTarget1.dispose(),this.renderTarget2.dispose(),this.renderTarget1=e,this.renderTarget2=e.clone(),this.writeBuffer=this.renderTarget1,this.readBuffer=this.renderTarget2}setSize(e,t){this._width=e,this._height=t;let n=this._width*this._pixelRatio,r=this._height*this._pixelRatio;this.renderTarget1.setSize(n,r),this.renderTarget2.setSize(n,r);for(let e=0;e<this.passes.length;e++)this.passes[e].setSize(n,r)}setPixelRatio(e){this._pixelRatio=e,this.setSize(this._width,this._height)}dispose(){this.renderTarget1.dispose(),this.renderTarget2.dispose(),this.copyPass.dispose()}},qa=class extends za{constructor(e,t,n=null,r=null,i=null){super(),this.scene=e,this.camera=t,this.overrideMaterial=n,this.clearColor=r,this.clearAlpha=i,this.clear=!0,this.clearDepth=!1,this.needsSwap=!1,this.isRenderPass=!0,this._oldClearColor=new q}render(e,t,n){let r=e.autoClear;e.autoClear=!1;let i,a;this.overrideMaterial!==null&&(a=this.scene.overrideMaterial,this.scene.overrideMaterial=this.overrideMaterial),this.clearColor!==null&&(e.getClearColor(this._oldClearColor),e.setClearColor(this.clearColor,e.getClearAlpha())),this.clearAlpha!==null&&(i=e.getClearAlpha(),e.setClearAlpha(this.clearAlpha)),this.clearDepth==1&&e.clearDepth(),e.setRenderTarget(this.renderToScreen?null:n),this.clear===!0&&e.clear(e.autoClearColor,e.autoClearDepth,e.autoClearStencil),e.render(this.scene,this.camera),this.clearColor!==null&&e.setClearColor(this._oldClearColor),this.clearAlpha!==null&&e.setClearAlpha(i),this.overrideMaterial!==null&&(this.scene.overrideMaterial=a),e.autoClear=r}},Ja={name:`LuminosityHighPassShader`,uniforms:{tDiffuse:{value:null},luminosityThreshold:{value:1},smoothWidth:{value:1},defaultColor:{value:new q(0)},defaultOpacity:{value:0}},vertexShader:`

		varying vec2 vUv;

		void main() {

			vUv = uv;

			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		uniform sampler2D tDiffuse;
		uniform vec3 defaultColor;
		uniform float defaultOpacity;
		uniform float luminosityThreshold;
		uniform float smoothWidth;

		varying vec2 vUv;

		void main() {

			vec4 texel = texture2D( tDiffuse, vUv );

			float v = luminance( texel.xyz );

			vec4 outputColor = vec4( defaultColor.rgb, defaultOpacity );

			float alpha = smoothstep( luminosityThreshold, luminosityThreshold + smoothWidth, v );

			gl_FragColor = mix( outputColor, texel, alpha );

		}`},Ya=class e extends za{constructor(e,t=1,n,r){super(),this.strength=t,this.radius=n,this.threshold=r,this.resolution=e===void 0?new m(256,256):new m(e.x,e.y),this.clearColor=new q(0,0,0),this.needsSwap=!1,this.renderTargetsHorizontal=[],this.renderTargetsVertical=[],this.nMips=5;let i=Math.round(this.resolution.x/2),a=Math.round(this.resolution.y/2);this.renderTargetBright=new I(i,a,{type:ke}),this.renderTargetBright.texture.name=`UnrealBloomPass.bright`,this.renderTargetBright.texture.generateMipmaps=!1;for(let e=0;e<this.nMips;e++){let t=new I(i,a,{type:ke});t.texture.name=`UnrealBloomPass.h`+e,t.texture.generateMipmaps=!1,this.renderTargetsHorizontal.push(t);let n=new I(i,a,{type:ke});n.texture.name=`UnrealBloomPass.v`+e,n.texture.generateMipmaps=!1,this.renderTargetsVertical.push(n),i=Math.round(i/2),a=Math.round(a/2)}let o=Ja;this.highPassUniforms=Ht.clone(o.uniforms),this.highPassUniforms.luminosityThreshold.value=r,this.highPassUniforms.smoothWidth.value=.01,this.materialHighPassFilter=new Je({uniforms:this.highPassUniforms,vertexShader:o.vertexShader,fragmentShader:o.fragmentShader}),this.separableBlurMaterials=[];let s=[6,10,14,18,22];i=Math.round(this.resolution.x/2),a=Math.round(this.resolution.y/2);for(let e=0;e<this.nMips;e++)this.separableBlurMaterials.push(this._getSeparableBlurMaterial(s[e])),this.separableBlurMaterials[e].uniforms.invSize.value=new m(1/i,1/a),i=Math.round(i/2),a=Math.round(a/2);this.compositeMaterial=this._getCompositeMaterial(this.nMips),this.compositeMaterial.uniforms.blurTexture1.value=this.renderTargetsVertical[0].texture,this.compositeMaterial.uniforms.blurTexture2.value=this.renderTargetsVertical[1].texture,this.compositeMaterial.uniforms.blurTexture3.value=this.renderTargetsVertical[2].texture,this.compositeMaterial.uniforms.blurTexture4.value=this.renderTargetsVertical[3].texture,this.compositeMaterial.uniforms.blurTexture5.value=this.renderTargetsVertical[4].texture,this.compositeMaterial.uniforms.bloomStrength.value=t,this.compositeMaterial.uniforms.bloomRadius.value=.1;let c=[1,.8,.6,.4,.2];this.compositeMaterial.uniforms.bloomFactors.value=c,this.bloomTintColors=[new R(1,1,1),new R(1,1,1),new R(1,1,1),new R(1,1,1),new R(1,1,1)],this.compositeMaterial.uniforms.bloomTintColors.value=this.bloomTintColors,this.copyUniforms=Ht.clone(Ra.uniforms),this.blendMaterial=new Je({uniforms:this.copyUniforms,vertexShader:Ra.vertexShader,fragmentShader:Ra.fragmentShader,premultipliedAlpha:!0,blending:2,depthTest:!1,depthWrite:!1,transparent:!0}),this._oldClearColor=new q,this._oldClearAlpha=1,this._basic=new dt,this._fsQuad=new Ha(null)}dispose(){for(let e=0;e<this.renderTargetsHorizontal.length;e++)this.renderTargetsHorizontal[e].dispose();for(let e=0;e<this.renderTargetsVertical.length;e++)this.renderTargetsVertical[e].dispose();this.renderTargetBright.dispose();for(let e=0;e<this.separableBlurMaterials.length;e++)this.separableBlurMaterials[e].dispose();this.compositeMaterial.dispose(),this.blendMaterial.dispose(),this._basic.dispose(),this._fsQuad.dispose()}setSize(e,t){let n=Math.round(e/2),r=Math.round(t/2);this.renderTargetBright.setSize(n,r);for(let e=0;e<this.nMips;e++)this.renderTargetsHorizontal[e].setSize(n,r),this.renderTargetsVertical[e].setSize(n,r),this.separableBlurMaterials[e].uniforms.invSize.value=new m(1/n,1/r),n=Math.round(n/2),r=Math.round(r/2)}render(t,n,r,i,a){t.getClearColor(this._oldClearColor),this._oldClearAlpha=t.getClearAlpha();let o=t.autoClear;t.autoClear=!1,t.setClearColor(this.clearColor,0),a&&t.state.buffers.stencil.setTest(!1),this.renderToScreen&&(this._fsQuad.material=this._basic,this._basic.map=r.texture,t.setRenderTarget(null),t.clear(),this._fsQuad.render(t)),this.highPassUniforms.tDiffuse.value=r.texture,this.highPassUniforms.luminosityThreshold.value=this.threshold,this._fsQuad.material=this.materialHighPassFilter,t.setRenderTarget(this.renderTargetBright),t.clear(),this._fsQuad.render(t);let s=this.renderTargetBright;for(let n=0;n<this.nMips;n++)this._fsQuad.material=this.separableBlurMaterials[n],this.separableBlurMaterials[n].uniforms.colorTexture.value=s.texture,this.separableBlurMaterials[n].uniforms.direction.value=e.BlurDirectionX,t.setRenderTarget(this.renderTargetsHorizontal[n]),t.clear(),this._fsQuad.render(t),this.separableBlurMaterials[n].uniforms.colorTexture.value=this.renderTargetsHorizontal[n].texture,this.separableBlurMaterials[n].uniforms.direction.value=e.BlurDirectionY,t.setRenderTarget(this.renderTargetsVertical[n]),t.clear(),this._fsQuad.render(t),s=this.renderTargetsVertical[n];this._fsQuad.material=this.compositeMaterial,this.compositeMaterial.uniforms.bloomStrength.value=this.strength,this.compositeMaterial.uniforms.bloomRadius.value=this.radius,this.compositeMaterial.uniforms.bloomTintColors.value=this.bloomTintColors,t.setRenderTarget(this.renderTargetsHorizontal[0]),t.clear(),this._fsQuad.render(t),this._fsQuad.material=this.blendMaterial,this.copyUniforms.tDiffuse.value=this.renderTargetsHorizontal[0].texture,a&&t.state.buffers.stencil.setTest(!0),this.renderToScreen?(t.setRenderTarget(null),this._fsQuad.render(t)):(t.setRenderTarget(r),this._fsQuad.render(t)),t.setClearColor(this._oldClearColor,this._oldClearAlpha),t.autoClear=o}_getSeparableBlurMaterial(e){let t=[],n=e/3;for(let r=0;r<e;r++)t.push(.39894*Math.exp(-.5*r*r/(n*n))/n);return new Je({defines:{KERNEL_RADIUS:e},uniforms:{colorTexture:{value:null},invSize:{value:new m(.5,.5)},direction:{value:new m(.5,.5)},gaussianCoefficients:{value:t}},vertexShader:`

				varying vec2 vUv;

				void main() {

					vUv = uv;
					gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

				}`,fragmentShader:`

				#include <common>

				varying vec2 vUv;

				uniform sampler2D colorTexture;
				uniform vec2 invSize;
				uniform vec2 direction;
				uniform float gaussianCoefficients[KERNEL_RADIUS];

				void main() {

					float weightSum = gaussianCoefficients[0];
					vec3 diffuseSum = texture2D( colorTexture, vUv ).rgb * weightSum;

					for ( int i = 1; i < KERNEL_RADIUS; i ++ ) {

						float x = float( i );
						float w = gaussianCoefficients[i];
						vec2 uvOffset = direction * invSize * x;
						vec3 sample1 = texture2D( colorTexture, vUv + uvOffset ).rgb;
						vec3 sample2 = texture2D( colorTexture, vUv - uvOffset ).rgb;
						diffuseSum += ( sample1 + sample2 ) * w;

					}

					gl_FragColor = vec4( diffuseSum, 1.0 );

				}`})}_getCompositeMaterial(e){return new Je({defines:{NUM_MIPS:e},uniforms:{blurTexture1:{value:null},blurTexture2:{value:null},blurTexture3:{value:null},blurTexture4:{value:null},blurTexture5:{value:null},bloomStrength:{value:1},bloomFactors:{value:null},bloomTintColors:{value:null},bloomRadius:{value:0}},vertexShader:`

				varying vec2 vUv;

				void main() {

					vUv = uv;
					gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

				}`,fragmentShader:`

				varying vec2 vUv;

				uniform sampler2D blurTexture1;
				uniform sampler2D blurTexture2;
				uniform sampler2D blurTexture3;
				uniform sampler2D blurTexture4;
				uniform sampler2D blurTexture5;
				uniform float bloomStrength;
				uniform float bloomRadius;
				uniform float bloomFactors[NUM_MIPS];
				uniform vec3 bloomTintColors[NUM_MIPS];

				float lerpBloomFactor( const in float factor ) {

					float mirrorFactor = 1.2 - factor;
					return mix( factor, mirrorFactor, bloomRadius );

				}

				void main() {

					// 3.0 for backwards compatibility with previous alpha-based intensity
					vec3 bloom = 3.0 * bloomStrength * (
						lerpBloomFactor( bloomFactors[ 0 ] ) * bloomTintColors[ 0 ] * texture2D( blurTexture1, vUv ).rgb +
						lerpBloomFactor( bloomFactors[ 1 ] ) * bloomTintColors[ 1 ] * texture2D( blurTexture2, vUv ).rgb +
						lerpBloomFactor( bloomFactors[ 2 ] ) * bloomTintColors[ 2 ] * texture2D( blurTexture3, vUv ).rgb +
						lerpBloomFactor( bloomFactors[ 3 ] ) * bloomTintColors[ 3 ] * texture2D( blurTexture4, vUv ).rgb +
						lerpBloomFactor( bloomFactors[ 4 ] ) * bloomTintColors[ 4 ] * texture2D( blurTexture5, vUv ).rgb
					);

					float bloomAlpha = max( bloom.r, max( bloom.g, bloom.b ) );
					gl_FragColor = vec4( bloom, bloomAlpha );

				}`})}};Ya.BlurDirectionX=new m(1,0),Ya.BlurDirectionY=new m(0,1);var Xa={name:`OutputShader`,uniforms:{tDiffuse:{value:null},toneMappingExposure:{value:1}},vertexShader:`
		precision highp float;

		uniform mat4 modelViewMatrix;
		uniform mat4 projectionMatrix;

		attribute vec3 position;
		attribute vec2 uv;

		varying vec2 vUv;

		void main() {

			vUv = uv;
			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		precision highp float;

		uniform sampler2D tDiffuse;

		#include <tonemapping_pars_fragment>
		#include <colorspace_pars_fragment>

		varying vec2 vUv;

		void main() {

			gl_FragColor = texture2D( tDiffuse, vUv );

			// tone mapping

			#ifdef LINEAR_TONE_MAPPING

				gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );

			#elif defined( REINHARD_TONE_MAPPING )

				gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );

			#elif defined( CINEON_TONE_MAPPING )

				gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );

			#elif defined( ACES_FILMIC_TONE_MAPPING )

				gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );

			#elif defined( AGX_TONE_MAPPING )

				gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );

			#elif defined( NEUTRAL_TONE_MAPPING )

				gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );

			#elif defined( CUSTOM_TONE_MAPPING )

				gl_FragColor.rgb = CustomToneMapping( gl_FragColor.rgb );

			#endif

			// color space

			#ifdef SRGB_TRANSFER

				gl_FragColor = sRGBTransferOETF( gl_FragColor );

			#endif

		}`},Za=class extends za{constructor(){super(),this.isOutputPass=!0,this.uniforms=Ht.clone(Xa.uniforms),this.material=new $t({name:Xa.name,uniforms:this.uniforms,vertexShader:Xa.vertexShader,fragmentShader:Xa.fragmentShader}),this._fsQuad=new Ha(this.material),this._outputColorSpace=null,this._toneMapping=null}render(e,t,n){this.uniforms.tDiffuse.value=n.texture,this.uniforms.toneMappingExposure.value=e.toneMappingExposure,(this._outputColorSpace!==e.outputColorSpace||this._toneMapping!==e.toneMapping)&&(this._outputColorSpace=e.outputColorSpace,this._toneMapping=e.toneMapping,this.material.defines={},ze.getTransfer(this._outputColorSpace)===`srgb`&&(this.material.defines.SRGB_TRANSFER=``),this._toneMapping===1?this.material.defines.LINEAR_TONE_MAPPING=``:this._toneMapping===2?this.material.defines.REINHARD_TONE_MAPPING=``:this._toneMapping===3?this.material.defines.CINEON_TONE_MAPPING=``:this._toneMapping===4?this.material.defines.ACES_FILMIC_TONE_MAPPING=``:this._toneMapping===6?this.material.defines.AGX_TONE_MAPPING=``:this._toneMapping===7?this.material.defines.NEUTRAL_TONE_MAPPING=``:this._toneMapping===5&&(this.material.defines.CUSTOM_TONE_MAPPING=``),this.material.needsUpdate=!0),this.renderToScreen===!0?(e.setRenderTarget(null),this._fsQuad.render(e)):(e.setRenderTarget(t),this.clear&&e.clear(e.autoClearColor,e.autoClearDepth,e.autoClearStencil),this._fsQuad.render(e))}dispose(){this.material.dispose(),this._fsQuad.dispose()}},Qa=`
  precision highp float;

  uniform sampler2D tDiffuse;
  uniform float uVignette;
  uniform float uSaturation;
  uniform float uWarmth;

  #include <tonemapping_pars_fragment>
  #include <colorspace_pars_fragment>

  varying vec2 vUv;

  void main() {
    vec4 sampleColor = texture2D(tDiffuse, vUv);
    vec3 color = sampleColor.rgb;
    float luma = dot(color, vec3(0.2126, 0.7152, 0.0722));
    color = mix(vec3(luma), color, uSaturation);
    float shadow = 1.0 - smoothstep(0.02, 0.55, luma);
    color += vec3(uWarmth, uWarmth * 0.45, 0.0) * shadow;
    vec2 p = vUv * 2.0 - 1.0;
    float vig = smoothstep(1.22, 0.28, length(p * vec2(0.82, 1.0)));
    color *= mix(1.0 - uVignette, 1.0, vig);
    gl_FragColor = vec4(max(color, 0.0), 1.0);

    #ifdef LINEAR_TONE_MAPPING
      gl_FragColor.rgb = LinearToneMapping(gl_FragColor.rgb);
    #elif defined(REINHARD_TONE_MAPPING)
      gl_FragColor.rgb = ReinhardToneMapping(gl_FragColor.rgb);
    #elif defined(CINEON_TONE_MAPPING)
      gl_FragColor.rgb = CineonToneMapping(gl_FragColor.rgb);
    #elif defined(ACES_FILMIC_TONE_MAPPING)
      gl_FragColor.rgb = ACESFilmicToneMapping(gl_FragColor.rgb);
    #elif defined(AGX_TONE_MAPPING)
      gl_FragColor.rgb = AgXToneMapping(gl_FragColor.rgb);
    #elif defined(NEUTRAL_TONE_MAPPING)
      gl_FragColor.rgb = NeutralToneMapping(gl_FragColor.rgb);
    #elif defined(CUSTOM_TONE_MAPPING)
      gl_FragColor.rgb = CustomToneMapping(gl_FragColor.rgb);
    #endif

    #ifdef SRGB_TRANSFER
      gl_FragColor = sRGBTransferOETF(gl_FragColor);
    #endif
  }
`;function $a(e){let n=new m;e.getSize(n);let r=e.getPixelRatio(),i=new I(Math.max(1,Math.floor(n.x*r)),Math.max(1,Math.floor(n.y*r)),{type:ke,depthBuffer:!0,stencilBuffer:!1,samples:0});i.texture.name=`chrono-post-target`;let a=new Ka(e,i),o=new qa(new t,new wt),s=new Ya(n.clone(),.14,.18,1.35),c=new Za;s.nMips=3;let l=s.setSize.bind(s);s.setSize=(e,t)=>{l(Math.max(1,Math.round(e/2)),Math.max(1,Math.round(t/2)))};let u=s.compositeMaterial.uniforms.bloomFactors.value;u[3]=0,u[4]=0,c.uniforms.uVignette={value:.34},c.uniforms.uSaturation={value:1.06},c.uniforms.uWarmth={value:.04};let d={vignette:.34,saturation:1.06,warmth:.04};function f({vignette:e=d.vignette,saturation:t=d.saturation,warmth:n=d.warmth}={}){c.uniforms.uVignette.value=e,c.uniforms.uSaturation.value=t,c.uniforms.uWarmth.value=n}c.material.fragmentShader=Qa,c.material.depthTest=!1,c.material.depthWrite=!1,c.material.needsUpdate=!0,a.addPass(o),a.addPass(s),a.addPass(c);let p=!0,h=null,g=0,_=0;function v(){s.enabled=p&&Y.get(`bloom`)!==!1}function y(){e.getSize(n),a.setPixelRatio(e.getPixelRatio());let t=Math.max(1,n.x),r=Math.max(1,n.y);(t!==g||r!==_)&&(a.setSize(t,r),g=t,_=r);for(let e=3;e<s.renderTargetsHorizontal.length;e+=1)s.renderTargetsHorizontal[e].setSize(1,1),s.renderTargetsVertical[e].setSize(1,1)}function b(t,n){if(!p){e.render(t,n);return}o.scene=t,o.camera=n,a.render()}let x=s.render.bind(s);s.render=function(...e){h?.begin(`bloom`),x(...e),h?.endIf(`bloom`)};let S=c.render.bind(c);c.render=function(...e){h?.begin(`final`),S(...e),h?.endIf(`final`)},v(),y();let C=Y.subscribe((e,t)=>{(t===`bloom`||t===`options`||t===`all`)&&v(),(t===`renderScale`||t===`options`||t===`all`)&&y()});window.addEventListener(`resize`,y);function w(){C(),window.removeEventListener(`resize`,y),s.dispose(),c.dispose(),a.dispose()}return{render:b,resize:y,dispose:w,setGrade:f,resetGrade(){f(d)},setEnabled(e){p=!!e,v()},isEnabled:()=>p,setGpuTimer(e){h=e}}}function eo(){let e=new t;return e.background=new q(1710638),e}function to(){let e=new w(Y.get(`fov`),window.innerWidth/window.innerHeight,.1,1800);e.position.set(3,3,5),e.lookAt(0,0,0);function t(){e.aspect=window.innerWidth/window.innerHeight,e.updateProjectionMatrix()}function n(){let t=Y.get(`fov`);e.fov!==t&&(e.fov=t,e.updateProjectionMatrix())}let r=Y.subscribe(n);window.addEventListener(`resize`,t);function i(){r(),window.removeEventListener(`resize`,t)}return{camera:e,resize:t,dispose:i}}function no(){let e=new Xe;return e.connect(document),{getDelta:t=>(e.update(t),e.getDelta())}}var ro=.1;function io({renderer:e,scene:t,camera:n,clock:r,afterRender:i,render:a,instrumentation:o}){let s=a??((t,n)=>e.render(t,n)),c=[];function l(e){c.push(e)}function u(a){o?.beginFrame(a);let l=Math.min(r.getDelta(a),ro);o?.beginUpdate();for(let e of c)e(l);o?.endUpdate(),o?.beginDraw();let d=e.domElement.clientWidth,f=e.domElement.clientHeight;e.autoClear=!1,e.setScissorTest(!1),e.setViewport(0,0,d,f),e.setScissor(0,0,d,f),e.clear(),s(t,n),o?.endDraw(),i&&i(e),o?.endFrame(),requestAnimationFrame(u)}function d(){requestAnimationFrame(u)}return{add:l,start:d}}function ao(e,t=!1){let n=e[0].index!==null,r=new Set(Object.keys(e[0].attributes)),i=new Set(Object.keys(e[0].morphAttributes)),a={},o={},s=e[0].morphTargetsRelative,c=new We,l=0;for(let u=0;u<e.length;++u){let d=e[u],f=0;if(n!==(d.index!==null))return console.error(`THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index `+u+`. All geometries must have compatible attributes; make sure index attribute exists among all geometries, or in none of them.`),null;for(let e in d.attributes){if(!r.has(e))return console.error(`THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index `+u+`. All geometries must have compatible attributes; make sure "`+e+`" attribute exists among all geometries, or in none of them.`),null;a[e]===void 0&&(a[e]=[]),a[e].push(d.attributes[e]),f++}if(f!==r.size)return console.error(`THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index `+u+`. Make sure all geometries have the same number of attributes.`),null;if(s!==d.morphTargetsRelative)return console.error(`THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index `+u+`. .morphTargetsRelative must be consistent throughout all geometries.`),null;for(let e in d.morphAttributes){if(!i.has(e))return console.error(`THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index `+u+`.  .morphAttributes must be consistent throughout all geometries.`),null;o[e]===void 0&&(o[e]=[]),o[e].push(d.morphAttributes[e])}if(t){let e;if(n)e=d.index.count;else if(d.attributes.position!==void 0)e=d.attributes.position.count;else return console.error(`THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index `+u+`. The geometry must have either an index or a position attribute`),null;c.addGroup(l,e,u),l+=e}}if(n){let t=0,n=[];for(let r=0;r<e.length;++r){let i=e[r].index;for(let e=0;e<i.count;++e)n.push(i.getX(e)+t);t+=e[r].attributes.position.count}c.setIndex(n)}for(let e in a){let t=oo(a[e]);if(!t)return console.error(`THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the `+e+` attribute.`),null;c.setAttribute(e,t)}for(let e in o){let t=o[e][0].length;if(t!==0){c.morphAttributes=c.morphAttributes||{},c.morphAttributes[e]=[];for(let n=0;n<t;++n){let t=[];for(let r=0;r<o[e].length;++r)t.push(o[e][r][n]);let r=oo(t);if(!r)return console.error(`THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the `+e+` morphAttribute.`),null;c.morphAttributes[e].push(r)}}}return c}function oo(e){let t,n,r,i=-1,a=0;for(let o=0;o<e.length;++o){let s=e[o];if(t===void 0&&(t=s.array.constructor),t!==s.array.constructor)return console.error(`THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.array must be of consistent array types across matching attributes.`),null;if(n===void 0&&(n=s.itemSize),n!==s.itemSize)return console.error(`THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.itemSize must be consistent across matching attributes.`),null;if(r===void 0&&(r=s.normalized),r!==s.normalized)return console.error(`THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.normalized must be consistent across matching attributes.`),null;if(i===-1&&(i=s.gpuType),i!==s.gpuType)return console.error(`THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.gpuType must be consistent across matching attributes.`),null;a+=s.count*n}let o=new t(a),s=new Rt(o,n,r),c=0;for(let t=0;t<e.length;++t){let r=e[t];if(r.isInterleavedBufferAttribute){let e=c/n;for(let t=0,i=r.count;t<i;t++)for(let i=0;i<n;i++){let n=r.getComponent(t,i);s.setComponent(t+e,i,n)}}else o.set(r.array,c);c+=r.count*n}return i!==void 0&&(s.gpuType=i),s}function so(e,t){if(t===0)return console.warn(`THREE.BufferGeometryUtils.toTrianglesDrawMode(): Geometry already defined as triangles.`),e;if(t===2||t===1){let n=e.getIndex();if(n===null){let t=[],r=e.getAttribute(`position`);if(r!==void 0){for(let e=0;e<r.count;e++)t.push(e);e.setIndex(t),n=e.getIndex()}else return console.error(`THREE.BufferGeometryUtils.toTrianglesDrawMode(): Undefined position attribute. Processing not possible.`),e}let r=n.count-2,i=[];if(t===2)for(let e=1;e<=r;e++)i.push(n.getX(0)),i.push(n.getX(e)),i.push(n.getX(e+1));else for(let e=0;e<r;e++)e%2==0?(i.push(n.getX(e)),i.push(n.getX(e+1)),i.push(n.getX(e+2))):(i.push(n.getX(e+2)),i.push(n.getX(e+1)),i.push(n.getX(e)));i.length/3!==r&&console.error(`THREE.BufferGeometryUtils.toTrianglesDrawMode(): Unable to generate correct amount of triangles.`);let a=e.clone();return a.setIndex(i),a.clearGroups(),a}return console.error(`THREE.BufferGeometryUtils.toTrianglesDrawMode(): Unknown draw mode:`,t),e}function co(e){let t=new Map,n=new Map,r=e.clone();return lo(e,r,function(e,r){t.set(r,e),n.set(e,r)}),r.traverse(function(e){if(!e.isSkinnedMesh)return;let r=e,i=t.get(e),a=i.skeleton.bones;r.skeleton=i.skeleton.clone(),r.bindMatrix.copy(i.bindMatrix),r.skeleton.bones=a.map(function(e){return n.get(e)}),r.bind(r.skeleton,r.bindMatrix)}),r}function lo(e,t,n){n(e,t);for(let r=0;r<e.children.length;r++)lo(e.children[r],t.children[r],n)}var uo=class extends Zt{constructor(e){super(e),this.dracoLoader=null,this.ktx2Loader=null,this.meshoptDecoder=null,this.pluginCallbacks=[],this.register(function(e){return new vo(e)}),this.register(function(e){return new yo(e)}),this.register(function(e){return new Oo(e)}),this.register(function(e){return new ko(e)}),this.register(function(e){return new Ao(e)}),this.register(function(e){return new xo(e)}),this.register(function(e){return new So(e)}),this.register(function(e){return new Co(e)}),this.register(function(e){return new wo(e)}),this.register(function(e){return new _o(e)}),this.register(function(e){return new To(e)}),this.register(function(e){return new bo(e)}),this.register(function(e){return new Do(e)}),this.register(function(e){return new Eo(e)}),this.register(function(e){return new ho(e)}),this.register(function(e){return new jo(e,mo.EXT_MESHOPT_COMPRESSION)}),this.register(function(e){return new jo(e,mo.KHR_MESHOPT_COMPRESSION)}),this.register(function(e){return new Mo(e)})}load(e,t,n,r){let i=this,a;if(this.resourcePath!==``)a=this.resourcePath;else if(this.path!==``){let t=Be.extractUrlBase(e);a=Be.resolveURL(t,this.path)}else a=Be.extractUrlBase(e);this.manager.itemStart(e);let o=function(t){r?r(t):console.error(t),i.manager.itemError(e),i.manager.itemEnd(e)},s=new T(this.manager);s.setPath(this.path),s.setResponseType(`arraybuffer`),s.setRequestHeader(this.requestHeader),s.setWithCredentials(this.withCredentials),s.load(e,function(n){try{i.parse(n,a,function(n){t(n),i.manager.itemEnd(e)},o)}catch(e){o(e)}},n,o)}setDRACOLoader(e){return this.dracoLoader=e,this}setKTX2Loader(e){return this.ktx2Loader=e,this}setMeshoptDecoder(e){return this.meshoptDecoder=e,this}register(e){return this.pluginCallbacks.indexOf(e)===-1&&this.pluginCallbacks.push(e),this}unregister(e){return this.pluginCallbacks.indexOf(e)!==-1&&this.pluginCallbacks.splice(this.pluginCallbacks.indexOf(e),1),this}parse(e,t,n,r){let i,a={},o={},s=new TextDecoder;if(typeof e==`string`)i=JSON.parse(e);else if(e instanceof ArrayBuffer){if(s.decode(new Uint8Array(e,0,4))===No){try{a[mo.KHR_BINARY_GLTF]=new Io(e)}catch(e){r&&r(e);return}i=JSON.parse(a[mo.KHR_BINARY_GLTF].content)}else i=JSON.parse(s.decode(e))}else i=e;if(i.asset===void 0||i.asset.version[0]<2){r&&r(Error(`THREE.GLTFLoader: Unsupported asset. glTF versions >=2.0 are supported.`));return}let c=new cs(i,{path:t||this.resourcePath||``,crossOrigin:this.crossOrigin,requestHeader:this.requestHeader,manager:this.manager,ktx2Loader:this.ktx2Loader,meshoptDecoder:this.meshoptDecoder});c.fileLoader.setRequestHeader(this.requestHeader);for(let e=0;e<this.pluginCallbacks.length;e++){let t=this.pluginCallbacks[e](c);t.name||console.error(`THREE.GLTFLoader: Invalid plugin found: missing name`),o[t.name]=t,a[t.name]=!0}if(i.extensionsUsed)for(let e=0;e<i.extensionsUsed.length;++e){let t=i.extensionsUsed[e],n=i.extensionsRequired||[];switch(t){case mo.KHR_MATERIALS_UNLIT:a[t]=new go;break;case mo.KHR_DRACO_MESH_COMPRESSION:a[t]=new Lo(i,this.dracoLoader);break;case mo.KHR_TEXTURE_TRANSFORM:a[t]=new Ro;break;case mo.KHR_MESH_QUANTIZATION:a[t]=new zo;break;default:n.indexOf(t)>=0&&o[t]===void 0&&console.warn(`THREE.GLTFLoader: Unknown extension "`+t+`".`)}}c.setExtensions(a),c.setPlugins(o),c.parse(n,r)}parseAsync(e,t){let n=this;return new Promise(function(r,i){n.parse(e,t,r,i)})}};function fo(){let e={};return{get:function(t){return e[t]},add:function(t,n){e[t]=n},remove:function(t){delete e[t]},removeAll:function(){e={}}}}function po(e,t,n){let r=e.json.materials[t];return r.extensions&&r.extensions[n]?r.extensions[n]:null}var mo={KHR_BINARY_GLTF:`KHR_binary_glTF`,KHR_DRACO_MESH_COMPRESSION:`KHR_draco_mesh_compression`,KHR_LIGHTS_PUNCTUAL:`KHR_lights_punctual`,KHR_MATERIALS_CLEARCOAT:`KHR_materials_clearcoat`,KHR_MATERIALS_DISPERSION:`KHR_materials_dispersion`,KHR_MATERIALS_IOR:`KHR_materials_ior`,KHR_MATERIALS_SHEEN:`KHR_materials_sheen`,KHR_MATERIALS_SPECULAR:`KHR_materials_specular`,KHR_MATERIALS_TRANSMISSION:`KHR_materials_transmission`,KHR_MATERIALS_IRIDESCENCE:`KHR_materials_iridescence`,KHR_MATERIALS_ANISOTROPY:`KHR_materials_anisotropy`,KHR_MATERIALS_UNLIT:`KHR_materials_unlit`,KHR_MATERIALS_VOLUME:`KHR_materials_volume`,KHR_TEXTURE_BASISU:`KHR_texture_basisu`,KHR_TEXTURE_TRANSFORM:`KHR_texture_transform`,KHR_MESH_QUANTIZATION:`KHR_mesh_quantization`,KHR_MATERIALS_EMISSIVE_STRENGTH:`KHR_materials_emissive_strength`,EXT_MATERIALS_BUMP:`EXT_materials_bump`,EXT_TEXTURE_WEBP:`EXT_texture_webp`,EXT_TEXTURE_AVIF:`EXT_texture_avif`,EXT_MESHOPT_COMPRESSION:`EXT_meshopt_compression`,KHR_MESHOPT_COMPRESSION:`KHR_meshopt_compression`,EXT_MESH_GPU_INSTANCING:`EXT_mesh_gpu_instancing`},ho=class{constructor(e){this.parser=e,this.name=mo.KHR_LIGHTS_PUNCTUAL,this.cache={refs:{},uses:{}}}_markDefs(){let e=this.parser,t=this.parser.json.nodes||[];for(let n=0,r=t.length;n<r;n++){let r=t[n];r.extensions&&r.extensions[this.name]&&r.extensions[this.name].light!==void 0&&e._addNodeRef(this.cache,r.extensions[this.name].light)}}_loadLight(e){let t=this.parser,n=`light:`+e,r=t.cache.get(n);if(r)return r;let i=t.json,a=((i.extensions&&i.extensions[this.name]||{}).lights||[])[e],o,s=new q(16777215);a.color!==void 0&&s.setRGB(a.color[0],a.color[1],a.color[2],Fe);let c=a.range===void 0?0:a.range;switch(a.type){case`directional`:o=new ce(s),o.target.position.set(0,0,-1),o.add(o.target);break;case`point`:o=new j(s),o.distance=c;break;case`spot`:o=new ft(s),o.distance=c,a.spot=a.spot||{},a.spot.innerConeAngle=a.spot.innerConeAngle===void 0?0:a.spot.innerConeAngle,a.spot.outerConeAngle=a.spot.outerConeAngle===void 0?Math.PI/4:a.spot.outerConeAngle,o.angle=a.spot.outerConeAngle,o.penumbra=1-a.spot.innerConeAngle/a.spot.outerConeAngle,o.target.position.set(0,0,-1),o.add(o.target);break;default:throw Error(`THREE.GLTFLoader: Unexpected light type: `+a.type)}return o.position.set(0,0,0),es(o,a),a.intensity!==void 0&&(o.intensity=a.intensity),o.name=t.createUniqueName(a.name||`light_`+e),r=Promise.resolve(o),t.cache.add(n,r),r}getDependency(e,t){if(e===`light`)return this._loadLight(t)}createNodeAttachment(e){let t=this,n=this.parser,r=n.json.nodes[e],i=(r.extensions&&r.extensions[this.name]||{}).light;return i===void 0?null:this._loadLight(i).then(function(e){return n._getNodeRef(t.cache,i,e)})}},go=class{constructor(){this.name=mo.KHR_MATERIALS_UNLIT}getMaterialType(){return dt}extendParams(e,t,n){let r=[];e.color=new q(1,1,1),e.opacity=1;let i=t.pbrMetallicRoughness;if(i){if(Array.isArray(i.baseColorFactor)){let t=i.baseColorFactor;e.color.setRGB(t[0],t[1],t[2],Fe),e.opacity=t[3]}i.baseColorTexture!==void 0&&r.push(n.assignTexture(e,`map`,i.baseColorTexture,Me))}return Promise.all(r)}},_o=class{constructor(e){this.parser=e,this.name=mo.KHR_MATERIALS_EMISSIVE_STRENGTH}extendMaterialParams(e,t){let n=po(this.parser,e,this.name);return n===null||n.emissiveStrength!==void 0&&(t.emissiveIntensity=n.emissiveStrength),Promise.resolve()}},vo=class{constructor(e){this.parser=e,this.name=mo.KHR_MATERIALS_CLEARCOAT}getMaterialType(e){return po(this.parser,e,this.name)===null?null:ue}extendMaterialParams(e,t){let n=po(this.parser,e,this.name);if(n===null)return Promise.resolve();let r=[];if(n.clearcoatFactor!==void 0&&(t.clearcoat=n.clearcoatFactor),n.clearcoatTexture!==void 0&&r.push(this.parser.assignTexture(t,`clearcoatMap`,n.clearcoatTexture)),n.clearcoatRoughnessFactor!==void 0&&(t.clearcoatRoughness=n.clearcoatRoughnessFactor),n.clearcoatRoughnessTexture!==void 0&&r.push(this.parser.assignTexture(t,`clearcoatRoughnessMap`,n.clearcoatRoughnessTexture)),n.clearcoatNormalTexture!==void 0&&(r.push(this.parser.assignTexture(t,`clearcoatNormalMap`,n.clearcoatNormalTexture)),n.clearcoatNormalTexture.scale!==void 0)){let e=n.clearcoatNormalTexture.scale;t.clearcoatNormalScale=new m(e,e)}return Promise.all(r)}},yo=class{constructor(e){this.parser=e,this.name=mo.KHR_MATERIALS_DISPERSION}getMaterialType(e){return po(this.parser,e,this.name)===null?null:ue}extendMaterialParams(e,t){let n=po(this.parser,e,this.name);return n===null||(t.dispersion=n.dispersion===void 0?0:n.dispersion),Promise.resolve()}},bo=class{constructor(e){this.parser=e,this.name=mo.KHR_MATERIALS_IRIDESCENCE}getMaterialType(e){return po(this.parser,e,this.name)===null?null:ue}extendMaterialParams(e,t){let n=po(this.parser,e,this.name);if(n===null)return Promise.resolve();let r=[];return n.iridescenceFactor!==void 0&&(t.iridescence=n.iridescenceFactor),n.iridescenceTexture!==void 0&&r.push(this.parser.assignTexture(t,`iridescenceMap`,n.iridescenceTexture)),n.iridescenceIor!==void 0&&(t.iridescenceIOR=n.iridescenceIor),t.iridescenceThicknessRange===void 0&&(t.iridescenceThicknessRange=[100,400]),n.iridescenceThicknessMinimum!==void 0&&(t.iridescenceThicknessRange[0]=n.iridescenceThicknessMinimum),n.iridescenceThicknessMaximum!==void 0&&(t.iridescenceThicknessRange[1]=n.iridescenceThicknessMaximum),n.iridescenceThicknessTexture!==void 0&&r.push(this.parser.assignTexture(t,`iridescenceThicknessMap`,n.iridescenceThicknessTexture)),Promise.all(r)}},xo=class{constructor(e){this.parser=e,this.name=mo.KHR_MATERIALS_SHEEN}getMaterialType(e){return po(this.parser,e,this.name)===null?null:ue}extendMaterialParams(e,t){let n=po(this.parser,e,this.name);if(n===null)return Promise.resolve();let r=[];if(t.sheenColor=new q(0,0,0),t.sheenRoughness=0,t.sheen=1,n.sheenColorFactor!==void 0){let e=n.sheenColorFactor;t.sheenColor.setRGB(e[0],e[1],e[2],Fe)}return n.sheenRoughnessFactor!==void 0&&(t.sheenRoughness=n.sheenRoughnessFactor),n.sheenColorTexture!==void 0&&r.push(this.parser.assignTexture(t,`sheenColorMap`,n.sheenColorTexture,Me)),n.sheenRoughnessTexture!==void 0&&r.push(this.parser.assignTexture(t,`sheenRoughnessMap`,n.sheenRoughnessTexture)),Promise.all(r)}},So=class{constructor(e){this.parser=e,this.name=mo.KHR_MATERIALS_TRANSMISSION}getMaterialType(e){return po(this.parser,e,this.name)===null?null:ue}extendMaterialParams(e,t){let n=po(this.parser,e,this.name);if(n===null)return Promise.resolve();let r=[];return n.transmissionFactor!==void 0&&(t.transmission=n.transmissionFactor),n.transmissionTexture!==void 0&&r.push(this.parser.assignTexture(t,`transmissionMap`,n.transmissionTexture)),Promise.all(r)}},Co=class{constructor(e){this.parser=e,this.name=mo.KHR_MATERIALS_VOLUME}getMaterialType(e){return po(this.parser,e,this.name)===null?null:ue}extendMaterialParams(e,t){let n=po(this.parser,e,this.name);if(n===null)return Promise.resolve();let r=[];t.thickness=n.thicknessFactor===void 0?0:n.thicknessFactor,n.thicknessTexture!==void 0&&r.push(this.parser.assignTexture(t,`thicknessMap`,n.thicknessTexture)),t.attenuationDistance=n.attenuationDistance||1/0;let i=n.attenuationColor||[1,1,1];return t.attenuationColor=new q().setRGB(i[0],i[1],i[2],Fe),Promise.all(r)}},wo=class{constructor(e){this.parser=e,this.name=mo.KHR_MATERIALS_IOR}getMaterialType(e){return po(this.parser,e,this.name)===null?null:ue}extendMaterialParams(e,t){let n=po(this.parser,e,this.name);return n===null?Promise.resolve():(t.ior=n.ior===void 0?1.5:n.ior,t.ior===0&&(t.ior=1e3),Promise.resolve())}},To=class{constructor(e){this.parser=e,this.name=mo.KHR_MATERIALS_SPECULAR}getMaterialType(e){return po(this.parser,e,this.name)===null?null:ue}extendMaterialParams(e,t){let n=po(this.parser,e,this.name);if(n===null)return Promise.resolve();let r=[];t.specularIntensity=n.specularFactor===void 0?1:n.specularFactor,n.specularTexture!==void 0&&r.push(this.parser.assignTexture(t,`specularIntensityMap`,n.specularTexture));let i=n.specularColorFactor||[1,1,1];return t.specularColor=new q().setRGB(i[0],i[1],i[2],Fe),n.specularColorTexture!==void 0&&r.push(this.parser.assignTexture(t,`specularColorMap`,n.specularColorTexture,Me)),Promise.all(r)}},Eo=class{constructor(e){this.parser=e,this.name=mo.EXT_MATERIALS_BUMP}getMaterialType(e){return po(this.parser,e,this.name)===null?null:ue}extendMaterialParams(e,t){let n=po(this.parser,e,this.name);if(n===null)return Promise.resolve();let r=[];return t.bumpScale=n.bumpFactor===void 0?1:n.bumpFactor,n.bumpTexture!==void 0&&r.push(this.parser.assignTexture(t,`bumpMap`,n.bumpTexture)),Promise.all(r)}},Do=class{constructor(e){this.parser=e,this.name=mo.KHR_MATERIALS_ANISOTROPY}getMaterialType(e){return po(this.parser,e,this.name)===null?null:ue}extendMaterialParams(e,t){let n=po(this.parser,e,this.name);if(n===null)return Promise.resolve();let r=[];return n.anisotropyStrength!==void 0&&(t.anisotropy=n.anisotropyStrength),n.anisotropyRotation!==void 0&&(t.anisotropyRotation=n.anisotropyRotation),n.anisotropyTexture!==void 0&&r.push(this.parser.assignTexture(t,`anisotropyMap`,n.anisotropyTexture)),Promise.all(r)}},Oo=class{constructor(e){this.parser=e,this.name=mo.KHR_TEXTURE_BASISU}loadTexture(e){let t=this.parser,n=t.json,r=n.textures[e];if(!r.extensions||!r.extensions[this.name])return null;let i=r.extensions[this.name],a=t.options.ktx2Loader;if(!a){if(n.extensionsRequired&&n.extensionsRequired.indexOf(this.name)>=0)throw Error(`THREE.GLTFLoader: setKTX2Loader must be called before loading KTX2 textures`);return null}return t.loadTextureImage(e,i.source,a)}},ko=class{constructor(e){this.parser=e,this.name=mo.EXT_TEXTURE_WEBP}loadTexture(e){let t=this.name,n=this.parser,r=n.json,i=r.textures[e];if(!i.extensions||!i.extensions[t])return null;let a=i.extensions[t],o=r.images[a.source],s=n.textureLoader;if(o.uri){let e=n.options.manager.getHandler(o.uri);e!==null&&(s=e)}return n.loadTextureImage(e,a.source,s)}},Ao=class{constructor(e){this.parser=e,this.name=mo.EXT_TEXTURE_AVIF}loadTexture(e){let t=this.name,n=this.parser,r=n.json,i=r.textures[e];if(!i.extensions||!i.extensions[t])return null;let a=i.extensions[t],o=r.images[a.source],s=n.textureLoader;if(o.uri){let e=n.options.manager.getHandler(o.uri);e!==null&&(s=e)}return n.loadTextureImage(e,a.source,s)}},jo=class{constructor(e,t){this.name=t,this.parser=e}loadBufferView(e){let t=this.parser.json,n=t.bufferViews[e];if(n.extensions&&n.extensions[this.name]){let e=n.extensions[this.name],r=this.parser.getDependency(`buffer`,e.buffer),i=this.parser.options.meshoptDecoder;if(!i||!i.supported){if(t.extensionsRequired&&t.extensionsRequired.indexOf(this.name)>=0)throw Error(`THREE.GLTFLoader: setMeshoptDecoder must be called before loading compressed files`);return null}return r.then(function(t){let n=e.byteOffset||0,r=e.byteLength||0,a=e.count,o=e.byteStride,s=new Uint8Array(t,n,r);return i.decodeGltfBufferAsync?i.decodeGltfBufferAsync(a,o,s,e.mode,e.filter).then(function(e){return e.buffer}):i.ready.then(function(){let t=new ArrayBuffer(a*o);return i.decodeGltfBuffer(new Uint8Array(t),a,o,s,e.mode,e.filter),t})})}return null}},Mo=class{constructor(e){this.name=mo.EXT_MESH_GPU_INSTANCING,this.parser=e}createNodeMesh(e){let t=this.parser.json,r=t.nodes[e];if(!r.extensions||!r.extensions[this.name]||r.mesh===void 0)return null;let i=t.meshes[r.mesh];for(let e of i.primitives)if(e.mode!==Uo.TRIANGLES&&e.mode!==Uo.TRIANGLE_STRIP&&e.mode!==Uo.TRIANGLE_FAN&&e.mode!==void 0)return null;let a=r.extensions[this.name].attributes,o=[],s={};for(let e in a)o.push(this.parser.getDependency(`accessor`,a[e]).then(t=>(s[e]=t,s[e])));return o.length<1?null:(o.push(this.parser.createNodeMesh(e)),Promise.all(o).then(e=>{let t=e.pop(),r=t.isGroup?t.children:[t],i=e[0].count,a=[];for(let e of r){let t=new h,r=new R,o=new n,c=new R(1,1,1),l=new Lt(e.geometry,e.material,i);for(let e=0;e<i;e++)s.TRANSLATION&&r.fromBufferAttribute(s.TRANSLATION,e),s.ROTATION&&o.fromBufferAttribute(s.ROTATION,e),s.SCALE&&c.fromBufferAttribute(s.SCALE,e),l.setMatrixAt(e,t.compose(r,o,c));for(let t in s)if(t===`_COLOR_0`){let e=s[t];l.instanceColor=new Ye(e.array,e.itemSize,e.normalized)}else t!==`TRANSLATION`&&t!==`ROTATION`&&t!==`SCALE`&&e.geometry.setAttribute(t,s[t]);Ee.prototype.copy.call(l,e),this.parser.assignFinalMaterial(l),a.push(l)}return t.isGroup?(t.clear(),t.add(...a),t):a[0]}))}},No=`glTF`,Po=12,Fo={JSON:1313821514,BIN:5130562},Io=class{constructor(e){this.name=mo.KHR_BINARY_GLTF,this.content=null,this.body=null;let t=new DataView(e,0,Po),n=new TextDecoder;if(this.header={magic:n.decode(new Uint8Array(e.slice(0,4))),version:t.getUint32(4,!0),length:t.getUint32(8,!0)},this.header.magic!==No)throw Error(`THREE.GLTFLoader: Unsupported glTF-Binary header.`);if(this.header.version<2)throw Error(`THREE.GLTFLoader: Legacy binary file detected.`);let r=this.header.length-Po,i=new DataView(e,Po),a=0;for(;a<r;){let t=i.getUint32(a,!0);a+=4;let r=i.getUint32(a,!0);if(a+=4,r===Fo.JSON){let r=new Uint8Array(e,Po+a,t);this.content=n.decode(r)}else if(r===Fo.BIN){let n=Po+a;this.body=e.slice(n,n+t)}a+=t}if(this.content===null)throw Error(`THREE.GLTFLoader: JSON content not found.`)}},Lo=class{constructor(e,t){if(!t)throw Error(`THREE.GLTFLoader: No DRACOLoader instance provided.`);this.name=mo.KHR_DRACO_MESH_COMPRESSION,this.json=e,this.dracoLoader=t,this.dracoLoader.preload()}decodePrimitive(e,t){let n=this.json,r=this.dracoLoader,i=e.extensions[this.name].bufferView,a=e.extensions[this.name].attributes,o={},s={},c={};for(let e in a){let t=Jo[e]||e.toLowerCase();o[t]=a[e]}for(let t in e.attributes){let r=Jo[t]||t.toLowerCase();if(a[t]!==void 0){let i=n.accessors[e.attributes[t]];c[r]=Wo[i.componentType].name,s[r]=i.normalized===!0}}return t.getDependency(`bufferView`,i).then(function(e){return new Promise(function(t,n){r.decodeDracoFile(e,function(e){for(let t in e.attributes){let n=e.attributes[t],r=s[t];r!==void 0&&(n.normalized=r)}t(e)},o,c,Fe,n)})})}},Ro=class{constructor(){this.name=mo.KHR_TEXTURE_TRANSFORM}extendTexture(e,t){return(t.texCoord===void 0||t.texCoord===e.channel)&&t.offset===void 0&&t.rotation===void 0&&t.scale===void 0?e:(e=e.clone(),t.texCoord!==void 0&&(e.channel=t.texCoord),t.offset!==void 0&&e.offset.fromArray(t.offset),t.rotation!==void 0&&(e.rotation=t.rotation),t.scale!==void 0&&e.repeat.fromArray(t.scale),e.needsUpdate=!0,e)}},zo=class{constructor(){this.name=mo.KHR_MESH_QUANTIZATION}},Bo=class extends Re{constructor(e,t,n,r){super(e,t,n,r)}copySampleValue_(e){let t=this.resultBuffer,n=this.sampleValues,r=this.valueSize,i=e*r*3+r;for(let e=0;e!==r;e++)t[e]=n[i+e];return t}interpolate_(e,t,n,r){let i=this.resultBuffer,a=this.sampleValues,o=this.valueSize,s=o*2,c=o*3,l=r-t,u=(n-t)/l,d=u*u,f=d*u,p=e*c,m=p-c,h=-2*f+3*d,g=f-d,_=1-h,v=g-d+u;for(let e=0;e!==o;e++){let t=a[m+e+o],n=a[m+e+s]*l,r=a[p+e+o],c=a[p+e]*l;i[e]=_*t+v*n+h*r+g*c}return i}},Vo=new n,Ho=class extends Bo{interpolate_(e,t,n,r){let i=super.interpolate_(e,t,n,r);return Vo.fromArray(i).normalize().toArray(i),i}},Uo={FLOAT:5126,FLOAT_MAT3:35675,FLOAT_MAT4:35676,FLOAT_VEC2:35664,FLOAT_VEC3:35665,FLOAT_VEC4:35666,LINEAR:9729,REPEAT:10497,SAMPLER_2D:35678,POINTS:0,LINES:1,LINE_LOOP:2,LINE_STRIP:3,TRIANGLES:4,TRIANGLE_STRIP:5,TRIANGLE_FAN:6,UNSIGNED_BYTE:5121,UNSIGNED_SHORT:5123},Wo={5120:Int8Array,5121:Uint8Array,5122:Int16Array,5123:Uint16Array,5125:Uint32Array,5126:Float32Array},Go={9728:ne,9729:gt,9984:tn,9985:et,9986:he,9987:rt},Ko={33071:Vt,33648:A,10497:Oe},qo={SCALAR:1,VEC2:2,VEC3:3,VEC4:4,MAT2:4,MAT3:9,MAT4:16},Jo={POSITION:`position`,NORMAL:`normal`,TANGENT:`tangent`,TEXCOORD_0:`uv`,TEXCOORD_1:`uv1`,TEXCOORD_2:`uv2`,TEXCOORD_3:`uv3`,COLOR_0:`color`,WEIGHTS_0:`skinWeight`,JOINTS_0:`skinIndex`},Yo={scale:`scale`,translation:`position`,rotation:`quaternion`,weights:`morphTargetInfluences`},Xo={CUBICSPLINE:void 0,LINEAR:Ft,STEP:Ct},Zo={OPAQUE:`OPAQUE`,MASK:`MASK`,BLEND:`BLEND`};function Qo(e){return e.DefaultMaterial===void 0&&(e.DefaultMaterial=new x({color:16777215,emissive:0,metalness:1,roughness:1,transparent:!1,depthTest:!0,side:0})),e.DefaultMaterial}function $o(e,t,n){for(let r in n.extensions)e[r]===void 0&&(t.userData.gltfExtensions=t.userData.gltfExtensions||{},t.userData.gltfExtensions[r]=n.extensions[r])}function es(e,t){t.extras!==void 0&&(typeof t.extras==`object`?Object.assign(e.userData,t.extras):console.warn(`THREE.GLTFLoader: Ignoring primitive type .extras, `+t.extras))}function ts(e,t,n){let r=!1,i=!1,a=!1;for(let e=0,n=t.length;e<n;e++){let n=t[e];if(n.POSITION!==void 0&&(r=!0),n.NORMAL!==void 0&&(i=!0),n.COLOR_0!==void 0&&(a=!0),r&&i&&a)break}if(!r&&!i&&!a)return Promise.resolve(e);let o=[],s=[],c=[];for(let l=0,u=t.length;l<u;l++){let u=t[l];if(r){let t=u.POSITION===void 0?e.attributes.position:n.getDependency(`accessor`,u.POSITION);o.push(t)}if(i){let t=u.NORMAL===void 0?e.attributes.normal:n.getDependency(`accessor`,u.NORMAL);s.push(t)}if(a){let t=u.COLOR_0===void 0?e.attributes.color:n.getDependency(`accessor`,u.COLOR_0);c.push(t)}}return Promise.all([Promise.all(o),Promise.all(s),Promise.all(c)]).then(function(t){let n=t[0],o=t[1],s=t[2];return r&&(e.morphAttributes.position=n),i&&(e.morphAttributes.normal=o),a&&(e.morphAttributes.color=s),e.morphTargetsRelative=!0,e})}function ns(e,t){if(e.updateMorphTargets(),t.weights!==void 0)for(let n=0,r=t.weights.length;n<r;n++)e.morphTargetInfluences[n]=t.weights[n];if(t.extras&&Array.isArray(t.extras.targetNames)){let n=t.extras.targetNames;if(e.morphTargetInfluences.length===n.length){e.morphTargetDictionary={};for(let t=0,r=n.length;t<r;t++)e.morphTargetDictionary[n[t]]=t}else console.warn(`THREE.GLTFLoader: Invalid extras.targetNames length. Ignoring names.`)}}function rs(e){let t,n=e.extensions&&e.extensions[mo.KHR_DRACO_MESH_COMPRESSION];if(t=n?`draco:`+n.bufferView+`:`+n.indices+`:`+is(n.attributes):e.indices+`:`+is(e.attributes)+`:`+e.mode,e.targets!==void 0)for(let n=0,r=e.targets.length;n<r;n++)t+=`:`+is(e.targets[n]);return t}function is(e){let t=``,n=Object.keys(e).sort();for(let r=0,i=n.length;r<i;r++)t+=n[r]+`:`+e[n[r]]+`;`;return t}function as(e){switch(e){case Int8Array:return 1/127;case Uint8Array:return 1/255;case Int16Array:return 1/32767;case Uint16Array:return 1/65535;default:throw Error(`THREE.GLTFLoader: Unsupported normalized accessor component type.`)}}function os(e){return e.search(/\.jpe?g($|\?)/i)>0||e.search(/^data\:image\/jpeg/)===0?`image/jpeg`:e.search(/\.webp($|\?)/i)>0||e.search(/^data\:image\/webp/)===0?`image/webp`:e.search(/\.ktx2($|\?)/i)>0||e.search(/^data\:image\/ktx2/)===0?`image/ktx2`:`image/png`}var ss=new h,cs=class{constructor(t={},n={}){this.json=t,this.extensions={},this.plugins={},this.options=n,this.cache=new fo,this.associations=new Map,this.primitiveCache={},this.nodeCache={},this.meshCache={refs:{},uses:{}},this.cameraCache={refs:{},uses:{}},this.lightCache={refs:{},uses:{}},this.sourceCache={},this.textureCache={},this.nodeNamesUsed={};let r=!1,i=-1,a=!1,o=-1;if(typeof navigator<`u`&&navigator.userAgent!==void 0){let e=navigator.userAgent;r=/^((?!chrome|android).)*safari/i.test(e)===!0;let t=e.match(/Version\/(\d+)/);i=r&&t?parseInt(t[1],10):-1,a=e.indexOf(`Firefox`)>-1,o=a?e.match(/Firefox\/([0-9]+)\./)[1]:-1}this.textureLoader=typeof createImageBitmap>`u`||r&&i<17||a&&o<98?new Ge(this.options.manager):new e(this.options.manager),this.textureLoader.setCrossOrigin(this.options.crossOrigin),this.textureLoader.setRequestHeader(this.options.requestHeader),this.fileLoader=new T(this.options.manager),this.fileLoader.setResponseType(`arraybuffer`),this.options.crossOrigin===`use-credentials`&&this.fileLoader.setWithCredentials(!0)}setExtensions(e){this.extensions=e}setPlugins(e){this.plugins=e}parse(e,t){let n=this,r=this.json,i=this.extensions;this.cache.removeAll(),this.nodeCache={},this._invokeAll(function(e){return e._markDefs&&e._markDefs()}),Promise.all(this._invokeAll(function(e){return e.beforeRoot&&e.beforeRoot()})).then(function(){return Promise.all([n.getDependencies(`scene`),n.getDependencies(`animation`),n.getDependencies(`camera`)])}).then(function(t){let a={scene:t[0][r.scene||0],scenes:t[0],animations:t[1],cameras:t[2],asset:r.asset,parser:n,userData:{}};return $o(i,a,r),es(a,r),Promise.all(n._invokeAll(function(e){return e.afterRoot&&e.afterRoot(a)})).then(function(){for(let e of a.scenes)e.updateMatrixWorld();e(a)})}).catch(t)}_markDefs(){let e=this.json.nodes||[],t=this.json.skins||[],n=this.json.meshes||[];for(let n=0,r=t.length;n<r;n++){let r=t[n].joints;for(let t=0,n=r.length;t<n;t++)e[r[t]].isBone=!0}for(let t=0,r=e.length;t<r;t++){let r=e[t];r.mesh!==void 0&&(this._addNodeRef(this.meshCache,r.mesh),r.skin!==void 0&&(n[r.mesh].isSkinnedMesh=!0)),r.camera!==void 0&&this._addNodeRef(this.cameraCache,r.camera)}}_addNodeRef(e,t){t!==void 0&&(e.refs[t]===void 0&&(e.refs[t]=e.uses[t]=0),e.refs[t]++)}_getNodeRef(e,t,n){if(e.refs[t]<=1)return n;let r=n.clone(),i=(e,t)=>{let n=this.associations.get(e);n!=null&&this.associations.set(t,n);for(let[n,r]of e.children.entries())i(r,t.children[n])};return i(n,r),r.name+=`_instance_`+e.uses[t]++,r}_invokeOne(e){let t=Object.values(this.plugins);t.push(this);for(let n=0;n<t.length;n++){let r=e(t[n]);if(r)return r}return null}_invokeAll(e){let t=Object.values(this.plugins);t.unshift(this);let n=[];for(let r=0;r<t.length;r++){let i=e(t[r]);i&&n.push(i)}return n}getDependency(e,t){let n=e+`:`+t,r=this.cache.get(n);if(!r){switch(e){case`scene`:r=this.loadScene(t);break;case`node`:r=this._invokeOne(function(e){return e.loadNode&&e.loadNode(t)});break;case`mesh`:r=this._invokeOne(function(e){return e.loadMesh&&e.loadMesh(t)});break;case`accessor`:r=this.loadAccessor(t);break;case`bufferView`:r=this._invokeOne(function(e){return e.loadBufferView&&e.loadBufferView(t)});break;case`buffer`:r=this.loadBuffer(t);break;case`material`:r=this._invokeOne(function(e){return e.loadMaterial&&e.loadMaterial(t)});break;case`texture`:r=this._invokeOne(function(e){return e.loadTexture&&e.loadTexture(t)});break;case`skin`:r=this.loadSkin(t);break;case`animation`:r=this._invokeOne(function(e){return e.loadAnimation&&e.loadAnimation(t)});break;case`camera`:r=this.loadCamera(t);break;default:if(r=this._invokeOne(function(n){return n!=this&&n.getDependency&&n.getDependency(e,t)}),!r)throw Error(`Unknown type: `+e)}this.cache.add(n,r)}return r}getDependencies(e){let t=this.cache.get(e);if(!t){let n=this,r=this.json[e+(e===`mesh`?`es`:`s`)]||[];t=Promise.all(r.map(function(t,r){return n.getDependency(e,r)})),this.cache.add(e,t)}return t}loadBuffer(e){let t=this.json.buffers[e],n=this.fileLoader;if(t.type&&t.type!==`arraybuffer`)throw Error(`THREE.GLTFLoader: `+t.type+` buffer type is not supported.`);if(t.uri===void 0&&e===0)return Promise.resolve(this.extensions[mo.KHR_BINARY_GLTF].body);let r=this.options;return new Promise(function(e,i){n.load(Be.resolveURL(t.uri,r.path),e,void 0,function(){i(Error(`THREE.GLTFLoader: Failed to load buffer "`+t.uri+`".`))})})}loadBufferView(e){let t=this.json.bufferViews[e];return this.getDependency(`buffer`,t.buffer).then(function(e){let n=t.byteLength||0,r=t.byteOffset||0;return e.slice(r,r+n)})}loadAccessor(e){let t=this,n=this.json,r=this.json.accessors[e];if(r.bufferView===void 0&&r.sparse===void 0){let e=qo[r.type],t=Wo[r.componentType],n=r.normalized===!0,i=new t(r.count*e);return Promise.resolve(new Rt(i,e,n))}let i=[];return r.bufferView===void 0?i.push(null):i.push(this.getDependency(`bufferView`,r.bufferView)),r.sparse!==void 0&&(i.push(this.getDependency(`bufferView`,r.sparse.indices.bufferView)),i.push(this.getDependency(`bufferView`,r.sparse.values.bufferView))),Promise.all(i).then(function(e){let i=e[0],a=qo[r.type],o=Wo[r.componentType],s=o.BYTES_PER_ELEMENT,c=s*a,l=r.byteOffset||0,u=r.bufferView===void 0?void 0:n.bufferViews[r.bufferView].byteStride,d=r.normalized===!0,f,p;if(u&&u!==c){let e=Math.floor(l/u),n=`InterleavedBuffer:`+r.bufferView+`:`+r.componentType+`:`+e+`:`+r.count,c=t.cache.get(n);c||(f=new o(i,e*u,r.count*u/s),c=new jt(f,u/s),t.cache.add(n,c)),p=new at(c,a,l%u/s,d)}else f=i===null?new o(r.count*a):new o(i,l,r.count*a),p=new Rt(f,a,d);if(r.sparse!==void 0){let t=qo.SCALAR,n=Wo[r.sparse.indices.componentType],s=r.sparse.indices.byteOffset||0,c=r.sparse.values.byteOffset||0,l=new n(e[1],s,r.sparse.count*t),u=new o(e[2],c,r.sparse.count*a);i!==null&&(p=new Rt(p.array.slice(),p.itemSize,p.normalized)),p.normalized=!1;for(let e=0,t=l.length;e<t;e++){let t=l[e];if(p.setX(t,u[e*a]),a>=2&&p.setY(t,u[e*a+1]),a>=3&&p.setZ(t,u[e*a+2]),a>=4&&p.setW(t,u[e*a+3]),a>=5)throw Error(`THREE.GLTFLoader: Unsupported itemSize in sparse BufferAttribute.`)}p.normalized=d}return p})}loadTexture(e){let t=this.json,n=this.options,r=t.textures[e].source,i=t.images[r],a=this.textureLoader;if(i.uri){let e=n.manager.getHandler(i.uri);e!==null&&(a=e)}return this.loadTextureImage(e,r,a)}loadTextureImage(e,t,n){let r=this,i=this.json,a=i.textures[e],o=i.images[t],s=(o.uri||o.bufferView)+`:`+a.sampler;if(this.textureCache[s])return this.textureCache[s];let c=this.loadImageSource(t,n).then(function(t){t.flipY=!1,t.name=a.name||o.name||``,t.name===``&&typeof o.uri==`string`&&o.uri.startsWith(`data:image/`)===!1&&(t.name=o.uri);let n=(i.samplers||{})[a.sampler]||{};return t.magFilter=Go[n.magFilter]||1006,t.minFilter=Go[n.minFilter]||1008,t.wrapS=Ko[n.wrapS]||1e3,t.wrapT=Ko[n.wrapT]||1e3,t.generateMipmaps=!t.isCompressedTexture&&t.minFilter!==1003&&t.minFilter!==1006,r.associations.set(t,{textures:e}),t}).catch(function(){return null});return this.textureCache[s]=c,c}loadImageSource(e,t){let n=this,r=this.json,i=this.options;if(this.sourceCache[e]!==void 0)return this.sourceCache[e].then(e=>e.clone());let a=r.images[e],o=self.URL||self.webkitURL,s=a.uri||``,c=!1;if(a.bufferView!==void 0)s=n.getDependency(`bufferView`,a.bufferView).then(function(e){c=!0;let t=new Blob([e],{type:a.mimeType});return s=o.createObjectURL(t),s});else if(a.uri===void 0)throw Error(`THREE.GLTFLoader: Image `+e+` is missing URI and bufferView`);let l=Promise.resolve(s).then(function(e){return new Promise(function(n,r){let a=n;t.isImageBitmapLoader===!0&&(a=function(e){let t=new zt(e);t.needsUpdate=!0,n(t)}),t.load(Be.resolveURL(e,i.path),a,void 0,r)})}).then(function(e){return c===!0&&o.revokeObjectURL(s),es(e,a),e.userData.mimeType=a.mimeType||os(a.uri),e}).catch(function(e){throw console.error(`THREE.GLTFLoader: Couldn't load texture`,s),e});return this.sourceCache[e]=l,l}assignTexture(e,t,n,r){let i=this;return this.getDependency(`texture`,n.index).then(function(a){if(!a)return null;if(n.texCoord!==void 0&&n.texCoord>0&&(a=a.clone(),a.channel=n.texCoord),i.extensions[mo.KHR_TEXTURE_TRANSFORM]){let e=n.extensions===void 0?void 0:n.extensions[mo.KHR_TEXTURE_TRANSFORM];if(e){let t=i.associations.get(a);a=i.extensions[mo.KHR_TEXTURE_TRANSFORM].extendTexture(a,e),i.associations.set(a,t)}}return r!==void 0&&(a.colorSpace=r),e[t]=a,a})}assignFinalMaterial(e){let t=e.geometry,n=e.material,r=t.attributes.tangent===void 0,i=t.attributes.color!==void 0,a=t.attributes.normal===void 0;if(e.isPoints){let e=`PointsMaterial:`+n.uuid,t=this.cache.get(e);t||(t=new Ae,Kt.prototype.copy.call(t,n),t.color.copy(n.color),t.map=n.map,t.sizeAttenuation=!1,this.cache.add(e,t)),n=t}else if(e.isLine){let e=`LineBasicMaterial:`+n.uuid,t=this.cache.get(e);t||(t=new Ke,Kt.prototype.copy.call(t,n),t.color.copy(n.color),t.map=n.map,this.cache.add(e,t)),n=t}if(r||i||a){let e=`ClonedMaterial:`+n.uuid+`:`;r&&(e+=`derivative-tangents:`),i&&(e+=`vertex-colors:`),a&&(e+=`flat-shading:`);let t=this.cache.get(e);t||(t=n.clone(),i&&(t.vertexColors=!0),a&&(t.flatShading=!0),r&&(t.normalScale&&(t.normalScale.y*=-1),t.clearcoatNormalScale&&(t.clearcoatNormalScale.y*=-1)),this.cache.add(e,t),this.associations.set(t,this.associations.get(n))),n=t}e.material=n}getMaterialType(){return x}loadMaterial(e){let t=this,n=this.json,r=this.extensions,i=n.materials[e],a,o={},s=i.extensions||{},c=[];if(s[mo.KHR_MATERIALS_UNLIT]){let e=r[mo.KHR_MATERIALS_UNLIT];a=e.getMaterialType(),c.push(e.extendParams(o,i,t))}else{let n=i.pbrMetallicRoughness||{};if(o.color=new q(1,1,1),o.opacity=1,Array.isArray(n.baseColorFactor)){let e=n.baseColorFactor;o.color.setRGB(e[0],e[1],e[2],Fe),o.opacity=e[3]}n.baseColorTexture!==void 0&&c.push(t.assignTexture(o,`map`,n.baseColorTexture,Me)),o.metalness=n.metallicFactor===void 0?1:n.metallicFactor,o.roughness=n.roughnessFactor===void 0?1:n.roughnessFactor,n.metallicRoughnessTexture!==void 0&&(c.push(t.assignTexture(o,`metalnessMap`,n.metallicRoughnessTexture)),c.push(t.assignTexture(o,`roughnessMap`,n.metallicRoughnessTexture))),a=this._invokeOne(function(t){return t.getMaterialType&&t.getMaterialType(e)}),c.push(Promise.all(this._invokeAll(function(t){return t.extendMaterialParams&&t.extendMaterialParams(e,o)})))}i.doubleSided===!0&&(o.side=2);let l=i.alphaMode||Zo.OPAQUE;if(l===Zo.BLEND?(o.transparent=!0,o.depthWrite=!1):(o.transparent=!1,l===Zo.MASK&&(o.alphaTest=i.alphaCutoff===void 0?.5:i.alphaCutoff)),i.normalTexture!==void 0&&a!==dt&&(c.push(t.assignTexture(o,`normalMap`,i.normalTexture)),o.normalScale=new m(1,1),i.normalTexture.scale!==void 0)){let e=i.normalTexture.scale;o.normalScale.set(e,e)}if(i.occlusionTexture!==void 0&&a!==dt&&(c.push(t.assignTexture(o,`aoMap`,i.occlusionTexture)),i.occlusionTexture.strength!==void 0&&(o.aoMapIntensity=i.occlusionTexture.strength)),i.emissiveFactor!==void 0&&a!==dt){let e=i.emissiveFactor;o.emissive=new q().setRGB(e[0],e[1],e[2],Fe)}return i.emissiveTexture!==void 0&&a!==dt&&c.push(t.assignTexture(o,`emissiveMap`,i.emissiveTexture,Me)),Promise.all(c).then(function(){let n=new a(o);return i.name&&(n.name=i.name),es(n,i),t.associations.set(n,{materials:e}),i.extensions&&$o(r,n,i),n})}createUniqueName(e){let t=Ne.sanitizeNodeName(e||``);return t in this.nodeNamesUsed?t+`_`+ ++this.nodeNamesUsed[t]:(this.nodeNamesUsed[t]=0,t)}loadGeometries(e){let t=this,n=this.extensions,r=this.primitiveCache;function i(e){return n[mo.KHR_DRACO_MESH_COMPRESSION].decodePrimitive(e,t).then(function(n){return us(n,e,t)})}let a=[];for(let n=0,o=e.length;n<o;n++){let o=e[n],s=rs(o),c=r[s];if(c)a.push(c.promise);else{let e;e=o.extensions&&o.extensions[mo.KHR_DRACO_MESH_COMPRESSION]?i(o):us(new We,o,t),r[s]={primitive:o,promise:e},a.push(e)}}return Promise.all(a)}loadMesh(e){let t=this,n=this.json,r=this.extensions,i=n.meshes[e],a=i.primitives,o=[];for(let e=0,t=a.length;e<t;e++){let t=a[e].material===void 0?Qo(this.cache):this.getDependency(`material`,a[e].material);o.push(t)}return o.push(t.loadGeometries(a)),Promise.all(o).then(function(n){let o=n.slice(0,n.length-1),s=n[n.length-1],c=[];for(let n=0,l=s.length;n<l;n++){let l=s[n],u=a[n],d,f=o[n];if(u.mode===Uo.TRIANGLES||u.mode===Uo.TRIANGLE_STRIP||u.mode===Uo.TRIANGLE_FAN||u.mode===void 0)d=i.isSkinnedMesh===!0?new St(l,f):new z(l,f),d.isSkinnedMesh===!0&&d.normalizeSkinWeights(),u.mode===Uo.TRIANGLE_STRIP?d.geometry=so(d.geometry,1):u.mode===Uo.TRIANGLE_FAN&&(d.geometry=so(d.geometry,2));else if(u.mode===Uo.LINES)d=new Et(l,f);else if(u.mode===Uo.LINE_STRIP)d=new Bt(l,f);else if(u.mode===Uo.LINE_LOOP)d=new Ze(l,f);else if(u.mode===Uo.POINTS)d=new je(l,f);else throw Error(`THREE.GLTFLoader: Primitive mode unsupported: `+u.mode);Object.keys(d.geometry.morphAttributes).length>0&&ns(d,i),d.name=t.createUniqueName(i.name||`mesh_`+e),es(d,i),u.extensions&&$o(r,d,u),t.assignFinalMaterial(d),c.push(d)}for(let n=0,r=c.length;n<r;n++)t.associations.set(c[n],{meshes:e,primitives:n});if(c.length===1)return i.extensions&&$o(r,c[0],i),c[0];let l=new U;i.extensions&&$o(r,l,i),t.associations.set(l,{meshes:e});for(let e=0,t=c.length;e<t;e++)l.add(c[e]);return l})}loadCamera(e){let t,n=this.json.cameras[e],r=n[n.type];if(!r){console.warn(`THREE.GLTFLoader: Missing camera parameters.`);return}return n.type===`perspective`?t=new w(B.radToDeg(r.yfov),r.aspectRatio||1,r.znear||1,r.zfar||2e6):n.type===`orthographic`&&(t=new Se(-r.xmag,r.xmag,r.ymag,-r.ymag,r.znear,r.zfar)),n.name&&(t.name=this.createUniqueName(n.name)),es(t,n),Promise.resolve(t)}loadSkin(e){let t=this.json.skins[e],n=[];for(let e=0,r=t.joints.length;e<r;e++)n.push(this._loadNodeShallow(t.joints[e]));return t.inverseBindMatrices===void 0?n.push(null):n.push(this.getDependency(`accessor`,t.inverseBindMatrices)),Promise.all(n).then(function(e){let n=e.pop(),r=e,i=[],a=[];for(let e=0,o=r.length;e<o;e++){let o=r[e];if(o){i.push(o);let t=new h;n!==null&&t.fromArray(n.array,e*16),a.push(t)}else console.warn(`THREE.GLTFLoader: Joint "%s" could not be found.`,t.joints[e])}return new Le(i,a)})}loadAnimation(e){let t=this.json,n=this,r=t.animations[e],i=r.name?r.name:`animation_`+e,a=[],o=[],s=[],c=[],l=[];for(let e=0,t=r.channels.length;e<t;e++){let t=r.channels[e],n=r.samplers[t.sampler],i=t.target,u=i.node,d=r.parameters===void 0?n.input:r.parameters[n.input],f=r.parameters===void 0?n.output:r.parameters[n.output];i.node!==void 0&&(a.push(this.getDependency(`node`,u)),o.push(this.getDependency(`accessor`,d)),s.push(this.getDependency(`accessor`,f)),c.push(n),l.push(i))}return Promise.all([Promise.all(a),Promise.all(o),Promise.all(s),Promise.all(c),Promise.all(l)]).then(function(e){let t=e[0],a=e[1],o=e[2],s=e[3],c=e[4],l=[];for(let e=0,r=t.length;e<r;e++){let r=t[e],i=a[e],u=o[e],d=s[e],f=c[e];if(r===void 0)continue;r.updateMatrix&&r.updateMatrix();let p=n._createAnimationTracks(r,i,u,d,f);if(p)for(let e=0;e<p.length;e++)l.push(p[e])}let u=new kt(i,void 0,l);return es(u,r),u})}createNodeMesh(e){let t=this.json,n=this,r=t.nodes[e];return r.mesh===void 0?null:n.getDependency(`mesh`,r.mesh).then(function(e){let t=n._getNodeRef(n.meshCache,r.mesh,e);return r.weights!==void 0&&t.traverse(function(e){if(e.isMesh)for(let t=0,n=r.weights.length;t<n;t++)e.morphTargetInfluences[t]=r.weights[t]}),t})}loadNode(e){let t=this.json,n=this,r=t.nodes[e],i=n._loadNodeShallow(e),a=[],o=r.children||[];for(let e=0,t=o.length;e<t;e++)a.push(n.getDependency(`node`,o[e]));let s=r.skin===void 0?Promise.resolve(null):n.getDependency(`skin`,r.skin);return Promise.all([i,Promise.all(a),s]).then(function(e){let t=e[0],n=e[1],r=e[2];r!==null&&t.traverse(function(e){e.isSkinnedMesh&&e.bind(r,ss)});for(let e=0,r=n.length;e<r;e++)t.add(n[e]);if(t.userData.pivot!==void 0&&n.length>0){let e=t.userData.pivot,r=n[0];t.pivot=new R().fromArray(e),t.position.x-=e[0],t.position.y-=e[1],t.position.z-=e[2],r.position.set(0,0,0),delete t.userData.pivot}return t})}_loadNodeShallow(e){let t=this.json,n=this.extensions,r=this;if(this.nodeCache[e]!==void 0)return this.nodeCache[e];let i=t.nodes[e],a=i.name?r.createUniqueName(i.name):``,o=[],s=r._invokeOne(function(t){return t.createNodeMesh&&t.createNodeMesh(e)});return s&&o.push(s),i.camera!==void 0&&o.push(r.getDependency(`camera`,i.camera).then(function(e){return r._getNodeRef(r.cameraCache,i.camera,e)})),r._invokeAll(function(t){return t.createNodeAttachment&&t.createNodeAttachment(e)}).forEach(function(e){o.push(e)}),this.nodeCache[e]=Promise.all(o).then(function(t){let o;if(o=i.isBone===!0?new Mt:t.length>1?new U:t.length===1?t[0]:new Ee,o!==t[0])for(let e=0,n=t.length;e<n;e++)o.add(t[e]);if(i.name&&(o.userData.name=i.name,o.name=a),es(o,i),i.extensions&&$o(n,o,i),i.matrix!==void 0){let e=new h;e.fromArray(i.matrix),o.applyMatrix4(e)}else i.translation!==void 0&&o.position.fromArray(i.translation),i.rotation!==void 0&&o.quaternion.fromArray(i.rotation),i.scale!==void 0&&o.scale.fromArray(i.scale);if(!r.associations.has(o))r.associations.set(o,{});else if(i.mesh!==void 0&&r.meshCache.refs[i.mesh]>1){let e=r.associations.get(o);r.associations.set(o,{...e})}return r.associations.get(o).nodes=e,o}),this.nodeCache[e]}loadScene(e){let t=this.extensions,n=this.json.scenes[e],r=this,i=new U;n.name&&(i.name=r.createUniqueName(n.name)),es(i,n),n.extensions&&$o(t,i,n);let a=n.nodes||[],o=[];for(let e=0,t=a.length;e<t;e++)o.push(r.getDependency(`node`,a[e]));return Promise.all(o).then(function(e){for(let t=0,n=e.length;t<n;t++){let n=e[t];n.parent===null?i.add(n):i.add(co(n))}return r.associations=(e=>{let t=new Map;for(let[e,n]of r.associations)(e instanceof Kt||e instanceof zt)&&t.set(e,n);return e.traverse(e=>{let n=r.associations.get(e);n!=null&&t.set(e,n)}),t})(i),i})}_createAnimationTracks(e,t,n,r,a){let o=[],s=e.name?e.name:e.uuid,c=[];function u(e){e.morphTargetInfluences&&c.push(e.name?e.name:e.uuid)}Yo[a.path]===Yo.weights?(u(e),e.isGroup&&e.children.forEach(u)):c.push(s);let d;switch(Yo[a.path]){case Yo.weights:d=l;break;case Yo.rotation:d=qe;break;case Yo.translation:case Yo.scale:d=i;break;default:switch(n.itemSize){case 1:d=l;break;default:d=i}}let f=r.interpolation===void 0?Ft:Xo[r.interpolation],p=this._getArrayFromAccessor(n);for(let e=0,n=c.length;e<n;e++){let n=new d(c[e]+`.`+Yo[a.path],t.array,p,f);r.interpolation===`CUBICSPLINE`&&this._createCubicSplineTrackInterpolant(n),o.push(n)}return o}_getArrayFromAccessor(e){let t=e.array;if(e.normalized){let e=as(t.constructor),n=new Float32Array(t.length);for(let r=0,i=t.length;r<i;r++)n[r]=t[r]*e;t=n}return t}_createCubicSplineTrackInterpolant(e){e.createInterpolant=function(e){return new(this instanceof qe?Ho:Bo)(this.times,this.values,this.getValueSize()/3,e)},e.createInterpolant.isInterpolantFactoryMethodGLTFCubicSpline=!0}};function ls(e,t,n){let r=t.attributes,i=new Ve;if(r.POSITION!==void 0){let e=n.json.accessors[r.POSITION],t=e.min,a=e.max;if(t!==void 0&&a!==void 0){if(i.set(new R(t[0],t[1],t[2]),new R(a[0],a[1],a[2])),e.normalized){let t=as(Wo[e.componentType]);i.min.multiplyScalar(t),i.max.multiplyScalar(t)}}else{console.warn(`THREE.GLTFLoader: Missing min/max properties for accessor POSITION.`);return}}else return;let a=t.targets;if(a!==void 0){let e=new R,t=new R;for(let r=0,i=a.length;r<i;r++){let i=a[r];if(i.POSITION!==void 0){let r=n.json.accessors[i.POSITION],a=r.min,o=r.max;if(a!==void 0&&o!==void 0){if(t.setX(Math.max(Math.abs(a[0]),Math.abs(o[0]))),t.setY(Math.max(Math.abs(a[1]),Math.abs(o[1]))),t.setZ(Math.max(Math.abs(a[2]),Math.abs(o[2]))),r.normalized){let e=as(Wo[r.componentType]);t.multiplyScalar(e)}e.max(t)}else console.warn(`THREE.GLTFLoader: Missing min/max properties for accessor POSITION.`)}}i.expandByVector(e)}e.boundingBox=i;let o=new Pt;i.getCenter(o.center),o.radius=i.min.distanceTo(i.max)/2,e.boundingSphere=o}function us(e,t,n){let r=t.attributes,i=[];function a(t,r){return n.getDependency(`accessor`,t).then(function(t){e.setAttribute(r,t)})}for(let t in r){let n=Jo[t]||t.toLowerCase();n in e.attributes||i.push(a(r[t],n))}if(t.indices!==void 0&&!e.index){let r=n.getDependency(`accessor`,t.indices).then(function(t){e.setIndex(t)});i.push(r)}return ze.workingColorSpace!==`srgb-linear`&&`COLOR_0`in r&&console.warn(`THREE.GLTFLoader: Converting vertex colors from "srgb-linear" to "${ze.workingColorSpace}" not supported.`),es(e,t),ls(e,t,n),Promise.all(i).then(function(){return t.targets===void 0?e:ts(e,t.targets,n)})}var ds=Uint8Array,fs=Uint16Array,ps=Int32Array,ms=new ds([0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0,0,0,0]),hs=new ds([0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13,0,0]),gs=new ds([16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15]),_s=function(e,t){for(var n=new fs(31),r=0;r<31;++r)n[r]=t+=1<<e[r-1];for(var i=new ps(n[30]),r=1;r<30;++r)for(var a=n[r];a<n[r+1];++a)i[a]=a-n[r]<<5|r;return{b:n,r:i}},vs=_s(ms,2),ys=vs.b,bs=vs.r;ys[28]=258,bs[258]=28;var xs=_s(hs,0),Ss=xs.b;xs.r;for(var Cs=new fs(32768),ws=0;ws<32768;++ws){var Ts=(ws&43690)>>1|(ws&21845)<<1;Ts=(Ts&52428)>>2|(Ts&13107)<<2,Ts=(Ts&61680)>>4|(Ts&3855)<<4,Cs[ws]=((Ts&65280)>>8|(Ts&255)<<8)>>1}for(var Es=(function(e,t,n){for(var r=e.length,i=0,a=new fs(t);i<r;++i)e[i]&&++a[e[i]-1];var o=new fs(t);for(i=1;i<t;++i)o[i]=o[i-1]+a[i-1]<<1;var s;if(n){s=new fs(1<<t);var c=15-t;for(i=0;i<r;++i)if(e[i])for(var l=i<<4|e[i],u=t-e[i],d=o[e[i]-1]++<<u,f=d|(1<<u)-1;d<=f;++d)s[Cs[d]>>c]=l}else for(s=new fs(r),i=0;i<r;++i)e[i]&&(s[i]=Cs[o[e[i]-1]++]>>15-e[i]);return s}),Ds=new ds(288),ws=0;ws<144;++ws)Ds[ws]=8;for(var ws=144;ws<256;++ws)Ds[ws]=9;for(var ws=256;ws<280;++ws)Ds[ws]=7;for(var ws=280;ws<288;++ws)Ds[ws]=8;for(var Os=new ds(32),ws=0;ws<32;++ws)Os[ws]=5;var ks=Es(Ds,9,1),As=Es(Os,5,1),js=function(e){for(var t=e[0],n=1;n<e.length;++n)e[n]>t&&(t=e[n]);return t},Ms=function(e,t,n){var r=t/8|0;return(e[r]|e[r+1]<<8)>>(t&7)&n},Ns=function(e,t){var n=t/8|0;return(e[n]|e[n+1]<<8|e[n+2]<<16)>>(t&7)},Ps=function(e){return(e+7)/8|0},Fs=function(e,t,n){return(t==null||t<0)&&(t=0),(n==null||n>e.length)&&(n=e.length),new ds(e.subarray(t,n))},Is=[`unexpected EOF`,`invalid block type`,`invalid length/literal`,`invalid distance`,`stream finished`,`no stream handler`,,`no callback`,`invalid UTF-8 data`,`extra field too long`,`date not in range 1980-2099`,`filename too long`,`stream finishing`,`invalid zip data`],Ls=function(e,t,n){var r=Error(t||Is[e]);if(r.code=e,Error.captureStackTrace&&Error.captureStackTrace(r,Ls),!n)throw r;return r},Rs=function(e,t,n,r){var i=e.length,a=r?r.length:0;if(!i||t.f&&!t.l)return n||new ds(0);var o=!n,s=o||t.i!=2,c=t.i;o&&(n=new ds(i*3));var l=function(e){var t=n.length;if(e>t){var r=new ds(Math.max(t*2,e));r.set(n),n=r}},u=t.f||0,d=t.p||0,f=t.b||0,p=t.l,m=t.d,h=t.m,g=t.n,_=i*8;do{if(!p){u=Ms(e,d,1);var v=Ms(e,d+1,3);if(d+=3,!v){var y=Ps(d)+4,b=e[y-4]|e[y-3]<<8,x=y+b;if(x>i){c&&Ls(0);break}s&&l(f+b),n.set(e.subarray(y,x),f),t.b=f+=b,t.p=d=x*8,t.f=u;continue}if(v==1)p=ks,m=As,h=9,g=5;else if(v==2){var S=Ms(e,d,31)+257,C=Ms(e,d+10,15)+4,w=S+Ms(e,d+5,31)+1;d+=14;for(var T=new ds(w),E=new ds(19),D=0;D<C;++D)E[gs[D]]=Ms(e,d+D*3,7);d+=C*3;for(var O=js(E),k=(1<<O)-1,A=Es(E,O,1),D=0;D<w;){var j=A[Ms(e,d,k)];d+=j&15;var y=j>>4;if(y<16)T[D++]=y;else{var ee=0,M=0;for(y==16?(M=3+Ms(e,d,3),d+=2,ee=T[D-1]):y==17?(M=3+Ms(e,d,7),d+=3):y==18&&(M=11+Ms(e,d,127),d+=7);M--;)T[D++]=ee}}var N=T.subarray(0,S),P=T.subarray(S);h=js(N),g=js(P),p=Es(N,h,1),m=Es(P,g,1)}else Ls(1);if(d>_){c&&Ls(0);break}}s&&l(f+131072);for(var te=(1<<h)-1,F=(1<<g)-1,ne=d;;ne=d){var ee=p[Ns(e,d)&te],re=ee>>4;if(d+=ee&15,d>_){c&&Ls(0);break}if(ee||Ls(2),re<256)n[f++]=re;else if(re==256){ne=d,p=null;break}else{var I=re-254;if(re>264){var D=re-257,L=ms[D];I=Ms(e,d,(1<<L)-1)+ys[D],d+=L}var ie=m[Ns(e,d)&F],ae=ie>>4;ie||Ls(3),d+=ie&15;var P=Ss[ae];if(ae>3){var L=hs[ae];P+=Ns(e,d)&(1<<L)-1,d+=L}if(d>_){c&&Ls(0);break}s&&l(f+131072);var oe=f+I;if(f<P){var se=a-P,R=Math.min(P,oe);for(se+f<0&&Ls(3);f<R;++f)n[f]=r[se+f]}for(;f<oe;++f)n[f]=n[f-P]}}t.l=p,t.p=ne,t.b=f,t.f=u,p&&(u=1,t.m=h,t.d=m,t.n=g)}while(!u);return f!=n.length&&o?Fs(n,0,f):n.subarray(0,f)},zs=new ds(0),Bs=function(e,t){return((e[0]&15)!=8||e[0]>>4>7||(e[0]<<8|e[1])%31)&&Ls(6,`invalid zlib data`),(e[1]>>5&1)==+!t&&Ls(6,`invalid zlib data: `+(e[1]&32?`need`:`unexpected`)+` dictionary`),(e[1]>>3&4)+2};function Vs(e,t){return Rs(e.subarray(Bs(e,t&&t.dictionary),-4),{i:2},t&&t.out,t&&t.dictionary)}var Hs=typeof TextDecoder<`u`&&new TextDecoder;try{Hs.decode(zs,{stream:!0})}catch{}function Us(e,t,n){let r=n.length-e-1;if(t>=n[r])return r-1;if(t<=n[e])return e;let i=e,a=r,o=Math.floor((i+a)/2);for(;t<n[o]||t>=n[o+1];)t<n[o]?a=o:i=o,o=Math.floor((i+a)/2);return o}function Ws(e,t,n,r){let i=[],a=[],o=[];i[0]=1;for(let s=1;s<=n;++s){a[s]=t-r[e+1-s],o[s]=r[e+s]-t;let n=0;for(let e=0;e<s;++e){let t=o[e+1],r=a[s-e],c=i[e]/(t+r);i[e]=n+t*c,n=r*c}i[s]=n}return i}function Gs(e,t,n,r){let i=Us(e,r,t),a=Ws(i,r,e,t),o=new ut(0,0,0,0);for(let t=0;t<=e;++t){let r=n[i-e+t],s=a[t],c=r.w*s;o.x+=r.x*c,o.y+=r.y*c,o.z+=r.z*c,o.w+=r.w*s}return o}function Ks(e,t,n,r,i){let a=[];for(let e=0;e<=n;++e)a[e]=0;let o=[];for(let e=0;e<=r;++e)o[e]=a.slice(0);let s=[];for(let e=0;e<=n;++e)s[e]=a.slice(0);s[0][0]=1;let c=a.slice(0),l=a.slice(0);for(let r=1;r<=n;++r){c[r]=t-i[e+1-r],l[r]=i[e+r]-t;let n=0;for(let e=0;e<r;++e){let t=l[e+1],i=c[r-e];s[r][e]=t+i;let a=s[e][r-1]/s[r][e];s[e][r]=n+t*a,n=i*a}s[r][r]=n}for(let e=0;e<=n;++e)o[0][e]=s[e][n];for(let e=0;e<=n;++e){let t=0,i=1,c=[];for(let e=0;e<=n;++e)c[e]=a.slice(0);c[0][0]=1;for(let a=1;a<=r;++a){let r=0,l=e-a,u=n-a;e>=a&&(c[i][0]=c[t][0]/s[u+1][l],r=c[i][0]*s[l][u]);let d=l>=-1?1:-l,f=e-1<=u?a-1:n-e;for(let e=d;e<=f;++e)c[i][e]=(c[t][e]-c[t][e-1])/s[u+1][l+e],r+=c[i][e]*s[l+e][u];e<=u&&(c[i][a]=-c[t][a-1]/s[u+1][e],r+=c[i][a]*s[e][u]),o[a][e]=r;let p=t;t=i,i=p}}let u=n;for(let e=1;e<=r;++e){for(let t=0;t<=n;++t)o[e][t]*=u;u*=n-e}return o}function qs(e,t,n,r,i){let a=i<e?i:e,o=[],s=Us(e,r,t),c=Ks(s,r,e,a,t),l=[];for(let e=0;e<n.length;++e){let t=n[e].clone(),r=t.w;t.x*=r,t.y*=r,t.z*=r,l[e]=t}for(let t=0;t<=a;++t){let n=l[s-e].clone().multiplyScalar(c[t][0]);for(let r=1;r<=e;++r)n.add(l[s-e+r].clone().multiplyScalar(c[t][r]));o[t]=n}for(let e=a+1;e<=i+1;++e)o[e]=new ut(0,0,0);return o}function Js(e,t){let n=1;for(let t=2;t<=e;++t)n*=t;let r=1;for(let e=2;e<=t;++e)r*=e;for(let n=2;n<=e-t;++n)r*=n;return n/r}function Ys(e){let t=e.length,n=[],r=[];for(let i=0;i<t;++i){let t=e[i];n[i]=new R(t.x,t.y,t.z),r[i]=t.w}let i=[];for(let e=0;e<t;++e){let t=n[e].clone();for(let n=1;n<=e;++n)t.sub(i[e-n].clone().multiplyScalar(Js(e,n)*r[n]));i[e]=t.divideScalar(r[0])}return i}function Xs(e,t,n,r,i){return Ys(qs(e,t,n,r,i))}var Zs=class extends g{constructor(e,t,n,r,i){super();let a=t?t.length-1:0,o=n?n.length:0;this.degree=e,this.knots=t,this.controlPoints=[],this.startKnot=r||0,this.endKnot=i||a;for(let e=0;e<o;++e){let t=n[e];this.controlPoints[e]=new ut(t.x,t.y,t.z,t.w)}}getPoint(e,t=new R){let n=t,r=this.knots[this.startKnot]+e*(this.knots[this.endKnot]-this.knots[this.startKnot]),i=Gs(this.degree,this.knots,this.controlPoints,r);return i.w!==1&&i.divideScalar(i.w),n.set(i.x,i.y,i.z)}getTangent(e,t=new R){let n=t,r=this.knots[0]+e*(this.knots[this.knots.length-1]-this.knots[0]),i=Xs(this.degree,this.knots,this.controlPoints,r,1);return n.copy(i[1]).normalize(),n}toJSON(){let e=super.toJSON();return e.degree=this.degree,e.knots=[...this.knots],e.controlPoints=this.controlPoints.map(e=>e.toArray()),e.startKnot=this.startKnot,e.endKnot=this.endKnot,e}fromJSON(e){return super.fromJSON(e),this.degree=e.degree,this.knots=[...e.knots],this.controlPoints=e.controlPoints.map(e=>new ut(e[0],e[1],e[2],e[3])),this.startKnot=e.startKnot,this.endKnot=e.endKnot,this}},Qs,$s,ec,tc=class extends Zt{constructor(e){super(e)}load(e,t,n,r){let i=this,a=i.path===``?Be.extractUrlBase(e):i.path,o=new T(this.manager);o.setPath(i.path),o.setResponseType(`arraybuffer`),o.setRequestHeader(i.requestHeader),o.setWithCredentials(i.withCredentials),o.load(e,function(n){try{t(i.parse(n,a))}catch(t){r?r(t):console.error(t),i.manager.itemError(e)}},n,r)}parse(e,t){if(lc(e))Qs=new oc().parse(e);else{let t=bc(e);if(!uc(t))throw Error(`THREE.FBXLoader: Unknown format.`);if(dc(t)<7e3)throw Error(`THREE.FBXLoader: FBX version not supported, FileVersion: `+dc(t));Qs=new ac().parse(t)}return new nc(new Ge(this.manager).setPath(this.resourcePath||t).setCrossOrigin(this.crossOrigin),this.manager).parse(Qs)}},nc=class{constructor(e,t){this.textureLoader=e,this.manager=t}parse(){$s=this.parseConnections();let e=this.parseImages(),t=this.parseTextures(e),n=this.parseMaterials(t),r=this.parseDeformers(),i=new rc().parse(r);return this.parseScene(r,i,n),ec}parseConnections(){let e=new Map;return`Connections`in Qs&&Qs.Connections.connections.forEach(function(t){let n=t[0],r=t[1],i=t[2];e.has(n)||e.set(n,{parents:[],children:[]});let a={ID:r,relationship:i};e.get(n).parents.push(a),e.has(r)||e.set(r,{parents:[],children:[]});let o={ID:n,relationship:i};e.get(r).children.push(o)}),e}parseImages(){let e={},t={};if(`Video`in Qs.Objects){let n=Qs.Objects.Video;for(let r in n){let i=n[r],a=parseInt(r);if(e[a]=i.RelativeFilename||i.Filename,`Content`in i){let e=i.Content instanceof ArrayBuffer&&i.Content.byteLength>0,a=typeof i.Content==`string`&&i.Content!==``;if(e||a){let e=this.parseImage(n[r]);t[i.RelativeFilename||i.Filename]=e}}}}for(let n in e){let r=e[n];e[n]=t[r]===void 0?e[n].split(`\\`).pop():t[r]}return e}parseImage(e){let t=e.Content,n=e.RelativeFilename||e.Filename,r=n.slice(n.lastIndexOf(`.`)+1).toLowerCase(),i;switch(r){case`bmp`:i=`image/bmp`;break;case`jpg`:case`jpeg`:i=`image/jpeg`;break;case`png`:i=`image/png`;break;case`tif`:i=`image/tiff`;break;case`tga`:this.manager.getHandler(`.tga`)===null&&console.warn(`FBXLoader: TGA loader not found, skipping `,n),i=`image/tga`;break;case`webp`:i=`image/webp`;break;default:console.warn(`FBXLoader: Image type "`+r+`" is not supported.`);return}if(typeof t==`string`)return`data:`+i+`;base64,`+t;{let e=new Uint8Array(t);return window.URL.createObjectURL(new Blob([e],{type:i}))}}parseTextures(e){let t=new Map;if(`Texture`in Qs.Objects){let n=Qs.Objects.Texture;for(let r in n){let i=this.parseTexture(n[r],e);t.set(parseInt(r),i)}}return t}parseTexture(e,t){let n=this.loadTexture(e,t);n.ID=e.id,n.name=e.attrName;let r=e.WrapModeU,i=e.WrapModeV,a=r===void 0?0:r.value,o=i===void 0?0:i.value;if(n.wrapS=a===0?Oe:Vt,n.wrapT=o===0?Oe:Vt,`Scaling`in e){let t=e.Scaling.value;n.repeat.x=t[0],n.repeat.y=t[1]}if(`Translation`in e){let t=e.Translation.value;n.offset.x=t[0],n.offset.y=t[1]}return n}loadTexture(e,t){let n=e.FileName.split(`.`).pop().toLowerCase(),r=this.manager.getHandler(`.${n}`);r===null&&(r=this.textureLoader);let i=r.path;i||r.setPath(this.textureLoader.path);let a=$s.get(e.id).children,o;if(a!==void 0&&a.length>0&&t[a[0].ID]!==void 0&&(o=t[a[0].ID],(o.indexOf(`blob:`)===0||o.indexOf(`data:`)===0)&&r.setPath(void 0)),o===void 0)return console.warn(`FBXLoader: Undefined filename, creating placeholder texture.`),new zt;let s=r.load(o);return r.setPath(i),s}parseMaterials(e){let t=new Map;if(`Material`in Qs.Objects){let n=Qs.Objects.Material;for(let r in n){let i=this.parseMaterial(n[r],e);i!==null&&t.set(parseInt(r),i)}}return t}parseMaterial(e,t){let n=e.id,r=e.attrName,i=e.ShadingModel;if(typeof i==`object`&&(i=i.value),!$s.has(n))return null;let a=this.parseParameters(e,t,n),o;switch(i.toLowerCase()){case`phong`:o=new oe;break;case`lambert`:o=new L;break;default:console.warn(`THREE.FBXLoader: unknown material type "%s". Defaulting to MeshPhongMaterial.`,i),o=new oe}return o.setValues(a),o.name=r,o}parseParameters(e,t,n){let r={};e.BumpFactor&&(r.bumpScale=e.BumpFactor.value),e.Diffuse?r.color=ze.colorSpaceToWorking(new q().fromArray(e.Diffuse.value),Me):e.DiffuseColor&&(e.DiffuseColor.type===`Color`||e.DiffuseColor.type===`ColorRGB`)&&(r.color=ze.colorSpaceToWorking(new q().fromArray(e.DiffuseColor.value),Me)),e.DisplacementFactor&&(r.displacementScale=e.DisplacementFactor.value),e.Emissive?r.emissive=ze.colorSpaceToWorking(new q().fromArray(e.Emissive.value),Me):e.EmissiveColor&&(e.EmissiveColor.type===`Color`||e.EmissiveColor.type===`ColorRGB`)&&(r.emissive=ze.colorSpaceToWorking(new q().fromArray(e.EmissiveColor.value),Me)),e.EmissiveFactor&&(r.emissiveIntensity=parseFloat(e.EmissiveFactor.value)),r.opacity=1-(e.TransparencyFactor?parseFloat(e.TransparencyFactor.value):0),(r.opacity===1||r.opacity===0)&&(r.opacity=e.Opacity?parseFloat(e.Opacity.value):null,r.opacity===null&&(r.opacity=1)),r.opacity<1&&(r.transparent=!0),e.ReflectionFactor&&(r.reflectivity=e.ReflectionFactor.value),e.Shininess&&(r.shininess=e.Shininess.value),e.Specular?r.specular=ze.colorSpaceToWorking(new q().fromArray(e.Specular.value),Me):e.SpecularColor&&e.SpecularColor.type===`Color`&&(r.specular=ze.colorSpaceToWorking(new q().fromArray(e.SpecularColor.value),Me));let i=this;return $s.get(n).children.forEach(function(e){let n=e.relationship;switch(n){case`Bump`:r.bumpMap=i.getTexture(t,e.ID);break;case`Maya|TEX_ao_map`:r.aoMap=i.getTexture(t,e.ID);break;case`DiffuseColor`:case`Maya|TEX_color_map`:r.map=i.getTexture(t,e.ID),r.map!==void 0&&(r.map.colorSpace=Me);break;case`DisplacementColor`:r.displacementMap=i.getTexture(t,e.ID);break;case`EmissiveColor`:r.emissiveMap=i.getTexture(t,e.ID),r.emissiveMap!==void 0&&(r.emissiveMap.colorSpace=Me);break;case`NormalMap`:case`Maya|TEX_normal_map`:r.normalMap=i.getTexture(t,e.ID);break;case`ReflectionColor`:r.envMap=i.getTexture(t,e.ID),r.envMap!==void 0&&(r.envMap.mapping=303,r.envMap.colorSpace=Me);break;case`SpecularColor`:r.specularMap=i.getTexture(t,e.ID),r.specularMap!==void 0&&(r.specularMap.colorSpace=Me);break;case`TransparentColor`:case`TransparencyFactor`:r.alphaMap=i.getTexture(t,e.ID),r.transparent=!0;break;default:console.warn(`THREE.FBXLoader: %s map is not supported in three.js, skipping texture.`,n)}}),r}getTexture(e,t){return`LayeredTexture`in Qs.Objects&&t in Qs.Objects.LayeredTexture&&(console.warn(`THREE.FBXLoader: layered textures are not supported in three.js. Discarding all but first layer.`),t=$s.get(t).children[0].ID),e.get(t)}parseDeformers(){let e={},t={};if(`Deformer`in Qs.Objects){let n=Qs.Objects.Deformer;for(let r in n){let i=n[r],a=$s.get(parseInt(r));if(i.attrType===`Skin`){let t=this.parseSkeleton(a,n);t.ID=r,a.parents.length>1&&console.warn(`THREE.FBXLoader: skeleton attached to more than one geometry is not supported.`),t.geometryID=a.parents[0].ID,e[r]=t}else if(i.attrType===`BlendShape`){let e={id:r};e.rawTargets=this.parseMorphTargets(a,n),e.id=r,a.parents.length>1&&console.warn(`THREE.FBXLoader: morph target attached to more than one geometry is not supported.`),t[r]=e}}}return{skeletons:e,morphTargets:t}}parseSkeleton(e,t){let n=[];return e.children.forEach(function(e){let r=t[e.ID];if(r.attrType!==`Cluster`)return;let i={ID:e.ID,indices:[],weights:[],transformLink:new h().fromArray(r.TransformLink.a)};`Indexes`in r&&(i.indices=r.Indexes.a,i.weights=r.Weights.a),n.push(i)}),{rawBones:n,bones:[]}}parseMorphTargets(e,t){let n=[];for(let r=0;r<e.children.length;r++){let i=e.children[r],a=t[i.ID],o={name:a.attrName,initialWeight:a.DeformPercent,id:a.id,fullWeights:a.FullWeights.a};if(a.attrType!==`BlendShapeChannel`)return;o.geoID=$s.get(parseInt(i.ID)).children.filter(function(e){return e.relationship===void 0})[0].ID,n.push(o)}return n}parseScene(e,t,n){ec=new U;let r=this.parseModels(e.skeletons,t,n),i=Qs.Objects.Model,a=this;r.forEach(function(e){let t=i[e.ID];a.setLookAtProperties(e,t),$s.get(e.ID).parents.forEach(function(t){let n=r.get(t.ID);n!==void 0&&n.add(e)}),e.parent===null&&ec.add(e)}),this.addGlobalSceneSettings(),ec.traverse(function(e){if(e.userData.transformData){e.parent&&(e.userData.transformData.parentMatrix=e.parent.matrix,e.userData.transformData.parentMatrixWorld=e.parent.matrixWorld);let t=_c(e.userData.transformData);e.applyMatrix4(t),e.updateWorldMatrix()}});let o=this.parsePoseNodes(),s=new Set;for(let t in e.skeletons)e.skeletons[t].rawBones.forEach(function(n,r){let i=e.skeletons[t].bones[r];i&&s.add(i.ID)});let c=new h;ec.traverse(function(e){if(e.isBone&&e.ID!==void 0&&!s.has(e.ID)){let t=o[e.ID];t!==void 0&&(e.parent?(c.copy(e.parent.matrixWorld).invert(),c.multiply(t)):c.copy(t),c.decompose(e.position,e.quaternion,e.scale),e.updateMatrix(),e.matrixWorld.copy(t))}}),this.bindSkeleton(e.skeletons,t,r);let l=new ic().parse();ec.children.length===1&&ec.children[0].isGroup&&(ec.children[0].animations=l,ec=ec.children[0]),ec.animations=l,`GlobalSettings`in Qs&&`UpAxis`in Qs.GlobalSettings&&Qs.GlobalSettings.UpAxis.value===2&&(console.warn(`THREE.FBXLoader: You are loading an asset with a Z-UP coordinate system. The loader just rotates the asset to transform it into Y-UP. The vertex data are not converted.`),ec.rotation.set(-Math.PI/2,0,0))}parseModels(e,t,n){let r=new Map,i=Qs.Objects.Model;for(let a in i){let o=parseInt(a),s=i[a],c=$s.get(o),l=this.buildSkeleton(c,e,o,s.attrName);if(!l){switch(s.attrType){case`Camera`:l=this.createCamera(c);break;case`Light`:l=this.createLight(c);break;case`Mesh`:l=this.createMesh(c,t,n);break;case`NurbsCurve`:l=this.createCurve(c,t);break;case`LimbNode`:case`Root`:l=new Mt;break;default:l=new U}l.name=s.attrName?Ne.sanitizeNodeName(s.attrName):``,l.userData.originalName=s.attrName,l.ID=o}this.getTransformData(l,s),r.set(o,l)}return r}buildSkeleton(e,t,n,r){let i=null;return e.parents.forEach(function(e){for(let a in t){let o=t[a];o.rawBones.forEach(function(t,a){if(t.ID===e.ID){let e=i;i=new Mt,i.matrixWorld.copy(t.transformLink),i.name=r?Ne.sanitizeNodeName(r):``,i.userData.originalName=r,i.ID=n,o.bones[a]=i,e!==null&&i.add(e)}})}}),i}createCamera(e){let t,n;if(e.children.forEach(function(e){let t=Qs.Objects.NodeAttribute[e.ID];t!==void 0&&(n=t)}),n===void 0)t=new Ee;else{let e=0;n.CameraProjectionType!==void 0&&n.CameraProjectionType.value===1&&(e=1);let r=1;n.NearPlane!==void 0&&(r=n.NearPlane.value/1e3);let i=1e3;n.FarPlane!==void 0&&(i=n.FarPlane.value/1e3);let a=window.innerWidth,o=window.innerHeight;n.AspectWidth!==void 0&&n.AspectHeight!==void 0&&(a=n.AspectWidth.value,o=n.AspectHeight.value);let s=a/o,c=45;n.FieldOfView!==void 0&&(c=n.FieldOfView.value);let l=n.FocalLength?n.FocalLength.value:null;switch(e){case 0:t=new w(c,s,r,i),l!==null&&t.setFocalLength(l);break;case 1:console.warn(`THREE.FBXLoader: Orthographic cameras not supported yet.`),t=new Ee;break;default:console.warn(`THREE.FBXLoader: Unknown camera type `+e+`.`),t=new Ee}}return t}createLight(e){let t,n;if(e.children.forEach(function(e){let t=Qs.Objects.NodeAttribute[e.ID];t!==void 0&&(n=t)}),n===void 0)t=new Ee;else{let e;e=n.LightType===void 0?0:n.LightType.value;let r=16777215;n.Color!==void 0&&(r=ze.colorSpaceToWorking(new q().fromArray(n.Color.value),Me));let i=n.Intensity===void 0?1:n.Intensity.value/100;n.CastLightOnObject!==void 0&&n.CastLightOnObject.value===0&&(i=0);let a=0;switch(n.FarAttenuationEnd!==void 0&&(a=n.EnableFarAttenuation!==void 0&&n.EnableFarAttenuation.value===0?0:n.FarAttenuationEnd.value),e){case 0:t=new j(r,i,a,1);break;case 1:t=new ce(r,i);break;case 2:let e=Math.PI/3,o=0;n.OuterAngle===void 0?n.InnerAngle!==void 0&&(e=B.degToRad(n.InnerAngle.value)):(e=B.degToRad(n.OuterAngle.value),n.InnerAngle!==void 0&&(o=1-n.InnerAngle.value/n.OuterAngle.value,o=Math.max(0,o))),t=new ft(r,i,a,e,o,1);break;default:console.warn(`THREE.FBXLoader: Unknown light type `+n.LightType.value+`, defaulting to a PointLight.`),t=new j(r,i)}n.CastShadows!==void 0&&n.CastShadows.value===1&&(t.castShadow=!0)}return t}createMesh(e,t,n){let r,i=null,a=null,o=[];if(e.children.forEach(function(e){t.has(e.ID)&&(i=t.get(e.ID)),n.has(e.ID)&&o.push(n.get(e.ID))}),o.length>1?a=o:o.length>0?a=o[0]:(a=new oe({name:Zt.DEFAULT_MATERIAL_NAME,color:13421772}),o.push(a)),`color`in i.attributes&&o.forEach(function(e){e.vertexColors=!0}),i.groups.length>0){let e=!1;for(let t=0,n=i.groups.length;t<n;t++){let n=i.groups[t];(n.materialIndex<0||n.materialIndex>=o.length)&&(n.materialIndex=o.length,e=!0)}if(e){let e=new oe;o.push(e)}}return i.FBX_Deformer?(r=new St(i,a),r.normalizeSkinWeights()):r=new z(i,a),r}createCurve(e,t){let n=e.children.reduce(function(e,n){return t.has(n.ID)&&(e=t.get(n.ID)),e},null),r=new Ke({name:Zt.DEFAULT_MATERIAL_NAME,color:3342591,linewidth:1});return new Bt(n,r)}getTransformData(e,t){let n={};`InheritType`in t&&(n.inheritType=parseInt(t.InheritType.value)),n.eulerOrder=`RotationOrder`in t?vc(t.RotationOrder.value):vc(0),`Lcl_Translation`in t&&(n.translation=t.Lcl_Translation.value),`PreRotation`in t&&(n.preRotation=t.PreRotation.value),`Lcl_Rotation`in t&&(n.rotation=t.Lcl_Rotation.value),`PostRotation`in t&&(n.postRotation=t.PostRotation.value),`Lcl_Scaling`in t&&(n.scale=t.Lcl_Scaling.value),`ScalingOffset`in t&&(n.scalingOffset=t.ScalingOffset.value),`ScalingPivot`in t&&(n.scalingPivot=t.ScalingPivot.value),`RotationOffset`in t&&(n.rotationOffset=t.RotationOffset.value),`RotationPivot`in t&&(n.rotationPivot=t.RotationPivot.value),e.userData.transformData=n}setLookAtProperties(e,t){`LookAtProperty`in t&&$s.get(e.ID).children.forEach(function(t){if(t.relationship===`LookAtProperty`){let n=Qs.Objects.Model[t.ID];if(`Lcl_Translation`in n){let t=n.Lcl_Translation.value;e.target===void 0?e.lookAt(new R().fromArray(t)):(e.target.position.fromArray(t),ec.add(e.target))}}})}bindSkeleton(e,t,n){for(let r in e){let i=e[r],a=[];for(let e=0,t=i.bones.length;e<t;e++){let t=new h;i.bones[e]&&i.rawBones[e]&&t.copy(i.rawBones[e].transformLink).invert(),a.push(t)}$s.get(parseInt(i.ID)).parents.forEach(function(e){if(t.has(e.ID)){let t=e.ID;$s.get(t).parents.forEach(function(e){if(n.has(e.ID)){let t=n.get(e.ID);t.updateMatrixWorld(!0),t.bind(new Le(i.bones,a),t.matrixWorld)}})}})}}parsePoseNodes(){let e={};if(`Pose`in Qs.Objects){let t=Qs.Objects.Pose;for(let n in t)if(t[n].attrType===`BindPose`&&t[n].NbPoseNodes>0){let r=t[n].PoseNode;Array.isArray(r)?r.forEach(function(t){e[t.Node]=new h().fromArray(t.Matrix.a)}):e[r.Node]=new h().fromArray(r.Matrix.a)}}return e}addGlobalSceneSettings(){if(`GlobalSettings`in Qs){if(`AmbientColor`in Qs.GlobalSettings){let e=Qs.GlobalSettings.AmbientColor.value,t=e[0],n=e[1],r=e[2];if(t!==0||n!==0||r!==0){let e=new q().setRGB(t,n,r,Me);ec.add(new _t(e,1))}}`UnitScaleFactor`in Qs.GlobalSettings&&(ec.userData.unitScaleFactor=Qs.GlobalSettings.UnitScaleFactor.value)}}},rc=class{constructor(){this.negativeMaterialIndices=!1}parse(e){let t=new Map;if(`Geometry`in Qs.Objects){let n=Qs.Objects.Geometry;for(let r in n){let i=$s.get(parseInt(r)),a=this.parseGeometry(i,n[r],e);t.set(parseInt(r),a)}}return this.negativeMaterialIndices===!0&&console.warn(`THREE.FBXLoader: The FBX file contains invalid (negative) material indices. The asset might not render as expected.`),t}parseGeometry(e,t,n){switch(t.attrType){case`Mesh`:return this.parseMeshGeometry(e,t,n);case`NurbsCurve`:return this.parseNurbsGeometry(t)}}parseMeshGeometry(e,t,n){let r=n.skeletons,i=[],a=e.parents.map(function(e){return Qs.Objects.Model[e.ID]});if(a.length===0)return;let o=e.children.reduce(function(e,t){return r[t.ID]!==void 0&&(e=r[t.ID]),e},null);e.children.forEach(function(e){n.morphTargets[e.ID]!==void 0&&i.push(n.morphTargets[e.ID])});let s=a[0],c={};`RotationOrder`in s&&(c.eulerOrder=vc(s.RotationOrder.value)),`InheritType`in s&&(c.inheritType=parseInt(s.InheritType.value)),`GeometricTranslation`in s&&(c.translation=s.GeometricTranslation.value),`GeometricRotation`in s&&(c.rotation=s.GeometricRotation.value),`GeometricScaling`in s&&(c.scale=s.GeometricScaling.value);let l=_c(c);return this.genGeometry(t,o,i,l)}genGeometry(e,t,n,r){let i=new We;e.attrName&&(i.name=e.attrName);let a=this.parseGeoNode(e,t),o=this.genBuffers(a),s=new be(o.vertex,3);if(s.applyMatrix4(r),i.setAttribute(`position`,s),o.colors.length>0&&i.setAttribute(`color`,new be(o.colors,3)),t&&(i.setAttribute(`skinIndex`,new $e(o.weightsIndices,4)),i.setAttribute(`skinWeight`,new be(o.vertexWeights,4)),i.FBX_Deformer=t),o.normal.length>0){let e=new v().getNormalMatrix(r),t=new be(o.normal,3);t.applyNormalMatrix(e),i.setAttribute(`normal`,t)}if(o.uvs.forEach(function(e,t){let n=t===0?`uv`:`uv${t}`;i.setAttribute(n,new be(o.uvs[t],2))}),a.material&&a.material.mappingType!==`AllSame`){let e=o.materialIndex[0],t=0;if(o.materialIndex.forEach(function(n,r){n!==e&&(i.addGroup(t,r-t,e),e=n,t=r)}),i.groups.length>0){let t=i.groups[i.groups.length-1],n=t.start+t.count;n!==o.materialIndex.length&&i.addGroup(n,o.materialIndex.length-n,e)}i.groups.length===0&&i.addGroup(0,o.materialIndex.length,o.materialIndex[0])}return this.addMorphTargets(i,e,n,r),i}parseGeoNode(e,t){let n={};if(n.vertexPositions=e.Vertices===void 0?[]:e.Vertices.a,n.vertexIndices=e.PolygonVertexIndex===void 0?[]:e.PolygonVertexIndex.a,e.LayerElementColor&&e.LayerElementColor[0].Colors&&(n.color=this.parseVertexColors(e.LayerElementColor[0])),e.LayerElementMaterial&&(n.material=this.parseMaterialIndices(e.LayerElementMaterial[0])),e.LayerElementNormal&&(n.normal=this.parseNormals(e.LayerElementNormal[0])),e.LayerElementUV){n.uv=[];let t=0;for(;e.LayerElementUV[t];)e.LayerElementUV[t].UV&&n.uv.push(this.parseUVs(e.LayerElementUV[t])),t++}return n.weightTable={},t!==null&&(n.skeleton=t,t.rawBones.forEach(function(e,t){e.indices.forEach(function(r,i){n.weightTable[r]===void 0&&(n.weightTable[r]=[]),n.weightTable[r].push({id:t,weight:e.weights[i]})})})),n}genBuffers(e){let t={vertex:[],normal:[],colors:[],uvs:[],materialIndex:[],vertexWeights:[],weightsIndices:[]},n=0,r=0,i=!1,a=[],o=[],s=[],c=[],l=[],u=[],d=this;return e.vertexIndices.forEach(function(f,p){let m,h=!1;f<0&&(f^=-1,h=!0);let g=[],_=[];if(a.push(f*3,f*3+1,f*3+2),e.color){let t=mc(p,n,f,e.color);s.push(t[0],t[1],t[2])}if(e.skeleton){if(e.weightTable[f]!==void 0&&e.weightTable[f].forEach(function(e){_.push(e.weight),g.push(e.id)}),_.length>4){i||=(console.warn(`THREE.FBXLoader: Vertex has more than 4 skinning weights assigned to vertex. Deleting additional weights.`),!0);let e=[0,0,0,0],t=[0,0,0,0];_.forEach(function(n,r){let i=n,a=g[r];t.forEach(function(t,n,r){if(i>t){r[n]=i,i=t;let o=e[n];e[n]=a,a=o}})}),g=e,_=t}for(;_.length<4;)_.push(0),g.push(0);for(let e=0;e<4;++e)l.push(_[e]),u.push(g[e])}if(e.normal){let t=mc(p,n,f,e.normal);o.push(t[0],t[1],t[2])}e.material&&e.material.mappingType!==`AllSame`&&(m=mc(p,n,f,e.material)[0],m<0&&(d.negativeMaterialIndices=!0,m=0)),e.uv&&e.uv.forEach(function(e,t){let r=mc(p,n,f,e);c[t]===void 0&&(c[t]=[]),c[t].push(r[0]),c[t].push(r[1])}),r++,h&&(d.genFace(t,e,a,m,o,s,c,l,u,r),n++,r=0,a=[],o=[],s=[],c=[],l=[],u=[])}),t}getNormalNewell(e){let t=new R(0,0,0);for(let n=0;n<e.length;n++){let r=e[n],i=e[(n+1)%e.length];t.x+=(r.y-i.y)*(r.z+i.z),t.y+=(r.z-i.z)*(r.x+i.x),t.z+=(r.x-i.x)*(r.y+i.y)}return t.normalize(),t}getNormalTangentAndBitangent(e){let t=this.getNormalNewell(e),n=(Math.abs(t.z)>.5?new R(0,1,0):new R(0,0,1)).cross(t).normalize();return{normal:t,tangent:n,bitangent:t.clone().cross(n).normalize()}}flattenVertex(e,t,n){return new m(e.dot(t),e.dot(n))}genFace(e,t,n,r,i,a,o,s,c,l){let u;if(l>3){let e=[],r=t.baseVertexPositions||t.vertexPositions;for(let t=0;t<n.length;t+=3)e.push(new R(r[n[t]],r[n[t+1]],r[n[t+2]]));let{tangent:i,bitangent:a}=this.getNormalTangentAndBitangent(e),o=[];for(let t of e)o.push(this.flattenVertex(t,i,a));u=At.triangulateShape(o,[])}else u=[[0,1,2]];for(let[l,d,f]of u)e.vertex.push(t.vertexPositions[n[l*3]]),e.vertex.push(t.vertexPositions[n[l*3+1]]),e.vertex.push(t.vertexPositions[n[l*3+2]]),e.vertex.push(t.vertexPositions[n[d*3]]),e.vertex.push(t.vertexPositions[n[d*3+1]]),e.vertex.push(t.vertexPositions[n[d*3+2]]),e.vertex.push(t.vertexPositions[n[f*3]]),e.vertex.push(t.vertexPositions[n[f*3+1]]),e.vertex.push(t.vertexPositions[n[f*3+2]]),t.skeleton&&(e.vertexWeights.push(s[l*4]),e.vertexWeights.push(s[l*4+1]),e.vertexWeights.push(s[l*4+2]),e.vertexWeights.push(s[l*4+3]),e.vertexWeights.push(s[d*4]),e.vertexWeights.push(s[d*4+1]),e.vertexWeights.push(s[d*4+2]),e.vertexWeights.push(s[d*4+3]),e.vertexWeights.push(s[f*4]),e.vertexWeights.push(s[f*4+1]),e.vertexWeights.push(s[f*4+2]),e.vertexWeights.push(s[f*4+3]),e.weightsIndices.push(c[l*4]),e.weightsIndices.push(c[l*4+1]),e.weightsIndices.push(c[l*4+2]),e.weightsIndices.push(c[l*4+3]),e.weightsIndices.push(c[d*4]),e.weightsIndices.push(c[d*4+1]),e.weightsIndices.push(c[d*4+2]),e.weightsIndices.push(c[d*4+3]),e.weightsIndices.push(c[f*4]),e.weightsIndices.push(c[f*4+1]),e.weightsIndices.push(c[f*4+2]),e.weightsIndices.push(c[f*4+3])),t.color&&(e.colors.push(a[l*3]),e.colors.push(a[l*3+1]),e.colors.push(a[l*3+2]),e.colors.push(a[d*3]),e.colors.push(a[d*3+1]),e.colors.push(a[d*3+2]),e.colors.push(a[f*3]),e.colors.push(a[f*3+1]),e.colors.push(a[f*3+2])),t.material&&t.material.mappingType!==`AllSame`&&(e.materialIndex.push(r),e.materialIndex.push(r),e.materialIndex.push(r)),t.normal&&(e.normal.push(i[l*3]),e.normal.push(i[l*3+1]),e.normal.push(i[l*3+2]),e.normal.push(i[d*3]),e.normal.push(i[d*3+1]),e.normal.push(i[d*3+2]),e.normal.push(i[f*3]),e.normal.push(i[f*3+1]),e.normal.push(i[f*3+2])),t.uv&&t.uv.forEach(function(t,n){e.uvs[n]===void 0&&(e.uvs[n]=[]),e.uvs[n].push(o[n][l*2]),e.uvs[n].push(o[n][l*2+1]),e.uvs[n].push(o[n][d*2]),e.uvs[n].push(o[n][d*2+1]),e.uvs[n].push(o[n][f*2]),e.uvs[n].push(o[n][f*2+1])})}addMorphTargets(e,t,n,r){if(n.length===0)return;e.morphTargetsRelative=!0,e.morphAttributes.position=[];let i=r.clone().setPosition(0,0,0),a=this;n.forEach(function(n){n.rawTargets.forEach(function(n){let r=Qs.Objects.Geometry[n.geoID];r!==void 0&&a.genMorphGeometry(e,t,r,i,n.name)})})}genMorphGeometry(e,t,n,r,i){let a=t.Vertices===void 0?[]:t.Vertices.a,o=t.PolygonVertexIndex===void 0?[]:t.PolygonVertexIndex.a,s=n.Vertices===void 0?[]:n.Vertices.a,c=n.Indexes===void 0?[]:n.Indexes.a,l=e.attributes.position.count*3,u=new Float32Array(l);for(let e=0;e<c.length;e++){let t=c[e]*3;u[t]=s[e*3],u[t+1]=s[e*3+1],u[t+2]=s[e*3+2]}let d={vertexIndices:o,vertexPositions:u,baseVertexPositions:a},f=this.genBuffers(d),p=new be(f.vertex,3);p.name=i||n.attrName,p.applyMatrix4(r),e.morphAttributes.position.push(p)}parseNormals(e){let t=e.MappingInformationType,n=e.ReferenceInformationType,r=e.Normals.a,i=[];return n===`IndexToDirect`&&(`NormalIndex`in e?i=e.NormalIndex.a:`NormalsIndex`in e&&(i=e.NormalsIndex.a)),{dataSize:3,buffer:r,indices:i,mappingType:t,referenceType:n}}parseUVs(e){let t=e.MappingInformationType,n=e.ReferenceInformationType,r=e.UV.a,i=[];return n===`IndexToDirect`&&(i=e.UVIndex.a),{dataSize:2,buffer:r,indices:i,mappingType:t,referenceType:n}}parseVertexColors(e){let t=e.MappingInformationType,n=e.ReferenceInformationType,r=e.Colors.a,i=[];n===`IndexToDirect`&&(i=e.ColorIndex.a);for(let e=0,t=new q;e<r.length;e+=4)t.fromArray(r,e),ze.colorSpaceToWorking(t,Me),t.toArray(r,e);return{dataSize:4,buffer:r,indices:i,mappingType:t,referenceType:n}}parseMaterialIndices(e){let t=e.MappingInformationType,n=e.ReferenceInformationType;if(t===`NoMappingInformation`)return{dataSize:1,buffer:[0],indices:[0],mappingType:`AllSame`,referenceType:n};let r=e.Materials.a,i=[];for(let e=0;e<r.length;++e)i.push(e);return{dataSize:1,buffer:r,indices:i,mappingType:t,referenceType:n}}parseNurbsGeometry(e){let t=parseInt(e.Order);if(isNaN(t))return console.error(`THREE.FBXLoader: Invalid Order %s given for geometry ID: %s`,e.Order,e.id),new We;let n=t-1,r=e.KnotVector.a,i=[],a=e.Points.a;for(let e=0,t=a.length;e<t;e+=4)i.push(new ut().fromArray(a,e));let o,s;if(e.Form===`Closed`)i.push(i[0]);else if(e.Form===`Periodic`){o=n,s=r.length-1-o;for(let e=0;e<n;++e)i.push(i[e])}let c=new Zs(n,r,i,o,s).getPoints(i.length*12);return new We().setFromPoints(c)}},ic=class{parse(){let e=[],t=this.parseClips();if(t!==void 0)for(let n in t){let r=t[n],i=this.addClip(r);e.push(i)}return e}parseClips(){if(Qs.Objects.AnimationCurve===void 0)return;let e=this.parseAnimationCurveNodes();this.parseAnimationCurves(e);let t=this.parseAnimationLayers(e);return this.parseAnimStacks(t)}parseAnimationCurveNodes(){let e=Qs.Objects.AnimationCurveNode,t=new Map;for(let n in e){let r=e[n];if(r.attrName.match(/S|R|T|DeformPercent/)!==null){let e={id:r.id,attr:r.attrName,curves:{}};t.set(e.id,e)}}return t}parseAnimationCurves(e){let t=Qs.Objects.AnimationCurve;for(let n in t){let r={id:t[n].id,times:t[n].KeyTime.a.map(fc),values:t[n].KeyValueFloat.a},i=$s.get(r.id);if(i!==void 0){let t=i.parents[0].ID,n=i.parents[0].relationship;n.match(/X/)?e.get(t).curves.x=r:n.match(/Y/)?e.get(t).curves.y=r:n.match(/Z/)?e.get(t).curves.z=r:n.match(/DeformPercent/)&&e.has(t)&&(e.get(t).curves.morph=r)}}}parseAnimationLayers(e){let t=Qs.Objects.AnimationLayer,n=new Map;for(let r in t){let t=[],i=$s.get(parseInt(r));i!==void 0&&(i.children.forEach(function(n,r){if(e.has(n.ID)){let i=e.get(n.ID);if(i.curves.x!==void 0||i.curves.y!==void 0||i.curves.z!==void 0){if(t[r]===void 0){let e=$s.get(n.ID).parents.filter(function(e){return e.relationship!==void 0});if(e.length===0)return;let i=e[0].ID;if(i!==void 0){let e=Qs.Objects.Model[i.toString()];if(e===void 0){console.warn(`THREE.FBXLoader: Encountered a unused curve.`,n);return}let a={modelName:e.attrName?Ne.sanitizeNodeName(e.attrName):``,ID:e.id,initialPosition:[0,0,0],initialRotation:[0,0,0],initialScale:[1,1,1]};ec.traverse(function(t){t.ID===e.id&&(a.transform=t.matrix,t.userData.transformData&&(a.eulerOrder=t.userData.transformData.eulerOrder,t.userData.transformData.rotation&&(a.initialRotation=t.userData.transformData.rotation)))}),a.transform||=new h,`PreRotation`in e&&(a.preRotation=e.PreRotation.value),`PostRotation`in e&&(a.postRotation=e.PostRotation.value),t[r]=a}}t[r]&&(t[r][i.attr]=i)}else if(i.curves.morph!==void 0){if(t[r]===void 0){let e=$s.get(n.ID).parents.filter(function(e){return e.relationship!==void 0});if(e.length===0)return;let i=e[0].ID,a=$s.get(i).parents[0].ID,o=$s.get(a).parents[0].ID,s=$s.get(o).parents[0].ID,c=Qs.Objects.Model[s],l={modelName:c.attrName?Ne.sanitizeNodeName(c.attrName):``,morphName:Qs.Objects.Deformer[i].attrName};t[r]=l}t[r][i.attr]=i}}}),n.set(parseInt(r),t))}return n}parseAnimStacks(e){let t=Qs.Objects.AnimationStack,n={};for(let r in t){let i=$s.get(parseInt(r)).children;i.length>1&&console.warn(`THREE.FBXLoader: Encountered an animation stack with multiple layers, this is currently not supported. Ignoring subsequent layers.`);let a=e.get(i[0].ID);n[r]={name:t[r].attrName,layer:a}}return n}addClip(e){let t=[],n=this;return e.layer.forEach(function(e){t=t.concat(n.generateTracks(e))}),new kt(e.name,-1,t)}generateTracks(e){let t=[],r=new R,i=new R;if(e.transform&&e.transform.decompose(r,new n,i),r=r.toArray(),i=i.toArray(),e.T!==void 0&&Object.keys(e.T.curves).length>0){let n=this.generateVectorTrack(e.modelName,e.T.curves,r,`position`);n!==void 0&&t.push(n)}if(e.R!==void 0&&Object.keys(e.R.curves).length>0){let n=this.generateRotationTrack(e.modelName,e.R.curves,e.preRotation,e.postRotation,e.eulerOrder,e.initialRotation);n!==void 0&&t.push(n)}if(e.S!==void 0&&Object.keys(e.S.curves).length>0){let n=this.generateVectorTrack(e.modelName,e.S.curves,i,`scale`);n!==void 0&&t.push(n)}if(e.DeformPercent!==void 0){let n=this.generateMorphTrack(e);n!==void 0&&t.push(n)}return t}generateVectorTrack(e,t,n,r){let a=this.getTimesForAllAxes(t),o=this.getKeyframeTrackValues(a,t,n);return new i(e+`.`+r,a,o)}generateRotationTrack(e,t,r,i,a,o){let s,c;if(t.x!==void 0||t.y!==void 0||t.z!==void 0){let e=this.getTimesForAllAxes(t);if(e.length>0){let n=o||[0,0,0],r=this.synchronizeCurve(t.x,e,n[0]),i=this.synchronizeCurve(t.y,e,n[1]),l=this.synchronizeCurve(t.z,e,n[2]),u=this.interpolateRotations(r,i,l,a);s=u[0],c=u[1]}}let l=vc(0);r!==void 0&&(r=r.map(B.degToRad),r.push(l),r=new fe().fromArray(r),r=new n().setFromEuler(r)),i!==void 0&&(i=i.map(B.degToRad),i.push(l),i=new fe().fromArray(i),i=new n().setFromEuler(i).invert());let u=new n,d=new fe,f=[];if(!(!c||!s)){for(let e=0;e<c.length;e+=3)d.set(c[e],c[e+1],c[e+2],a),u.setFromEuler(d),r!==void 0&&u.premultiply(r),i!==void 0&&u.multiply(i),e>2&&new n().fromArray(f,(e-3)/3*4).dot(u)<0&&u.set(-u.x,-u.y,-u.z,-u.w),u.toArray(f,e/3*4);return new qe(e+`.quaternion`,s,f)}}generateMorphTrack(e){let t=e.DeformPercent.curves.morph,n=t.values.map(function(e){return e/100}),r=ec.getObjectByName(e.modelName).morphTargetDictionary[e.morphName];return new l(e.modelName+`.morphTargetInfluences[`+r+`]`,t.times,n)}getTimesForAllAxes(e){let t=[];if(e.x!==void 0&&(t=t.concat(e.x.times)),e.y!==void 0&&(t=t.concat(e.y.times)),e.z!==void 0&&(t=t.concat(e.z.times)),t=t.sort(function(e,t){return e-t}),t.length>1){let e=1,n=t[0];for(let r=1;r<t.length;r++){let i=t[r];i!==n&&(t[e]=i,n=i,e++)}t=t.slice(0,e)}return t}getKeyframeTrackValues(e,t,n){let r=n,i=[],a=-1,o=-1,s=-1;return e.forEach(function(e){if(t.x&&(a=t.x.times.indexOf(e)),t.y&&(o=t.y.times.indexOf(e)),t.z&&(s=t.z.times.indexOf(e)),a!==-1){let e=t.x.values[a];i.push(e),r[0]=e}else i.push(r[0]);if(o!==-1){let e=t.y.values[o];i.push(e),r[1]=e}else i.push(r[1]);if(s!==-1){let e=t.z.values[s];i.push(e),r[2]=e}else i.push(r[2])}),i}synchronizeCurve(e,t,n){if(e===void 0)return{times:t,values:t.map(()=>n)};if(e.times.length===t.length)return e;let r=[];for(let i=0;i<t.length;i++)r.push(this.sampleCurveValue(e,t[i],n));return{times:t,values:r}}sampleCurveValue(e,t,n){let r=e.times,i=e.values;if(t<=r[0])return i[0];if(t>=r[r.length-1])return i[i.length-1];for(let e=0;e<r.length-1;e++)if(t>=r[e]&&t<=r[e+1]){if(r[e]===t)return i[e];let n=(t-r[e])/(r[e+1]-r[e]);return i[e]*(1-n)+i[e+1]*n}return n}interpolateRotations(e,t,r,i){let a=[],o=[];a.push(e.times[0]),o.push(B.degToRad(e.values[0])),o.push(B.degToRad(t.values[0])),o.push(B.degToRad(r.values[0]));for(let s=1;s<e.values.length;s++){let c=[e.values[s-1],t.values[s-1],r.values[s-1]];if(isNaN(c[0])||isNaN(c[1])||isNaN(c[2]))continue;let l=c.map(B.degToRad),u=[e.values[s],t.values[s],r.values[s]];if(isNaN(u[0])||isNaN(u[1])||isNaN(u[2]))continue;let d=u.map(B.degToRad),f=[u[0]-c[0],u[1]-c[1],u[2]-c[2]],p=[Math.abs(f[0]),Math.abs(f[1]),Math.abs(f[2])];if(p[0]>=180||p[1]>=180||p[2]>=180){let t=Math.max(...p)/180,r=new fe(...l,i),c=new fe(...d,i),u=new n().setFromEuler(r),f=new n().setFromEuler(c);u.dot(f)<0&&f.set(-f.x,-f.y,-f.z,-f.w);let m=e.times[s-1],h=e.times[s]-m,g=new n,_=new fe;for(let e=0;e<1;e+=1/t)g.copy(u.clone().slerp(f.clone(),e)),a.push(m+e*h),_.setFromQuaternion(g,i),o.push(_.x),o.push(_.y),o.push(_.z)}else a.push(e.times[s]),o.push(B.degToRad(e.values[s])),o.push(B.degToRad(t.values[s])),o.push(B.degToRad(r.values[s]))}return[a,o]}},ac=class{getPrevNode(){return this.nodeStack[this.currentIndent-2]}getCurrentNode(){return this.nodeStack[this.currentIndent-1]}getCurrentProp(){return this.currentProp}pushStack(e){this.nodeStack.push(e),this.currentIndent+=1}popStack(){this.nodeStack.pop(),--this.currentIndent}setCurrentProp(e,t){this.currentProp=e,this.currentPropName=t}parse(e){this.currentIndent=0,this.allNodes=new cc,this.nodeStack=[],this.currentProp=[],this.currentPropName=``;let t=this,n=e.split(/[\r\n]+/);return n.forEach(function(e,r){let i=e.match(/^[\s\t]*;/),a=e.match(/^[\s\t]*$/);if(i||a)return;let o=e.match(`^\\t{`+t.currentIndent+`}(\\w+):(.*){`,``),s=e.match(`^\\t{`+t.currentIndent+`}(\\w+):[\\s\\t\\r\\n](.*)`),c=e.match(`^\\t{`+(t.currentIndent-1)+`}}`);o?t.parseNodeBegin(e,o):s?t.parseNodeProperty(e,s,n[++r]):c?t.popStack():e.match(/^[^\s\t}]/)&&t.parseNodePropertyContinued(e)}),this.allNodes}parseNodeBegin(e,t){let n=t[1].trim().replace(/^"/,``).replace(/"$/,``),r=t[2].split(`,`).map(function(e){return e.trim().replace(/^"/,``).replace(/"$/,``)}),i={name:n},a=this.parseNodeAttr(r),o=this.getCurrentNode();this.currentIndent===0?this.allNodes.add(n,i):n in o?(n===`PoseNode`?o.PoseNode.push(i):o[n].id!==void 0&&(o[n]={},o[n][o[n].id]=o[n]),a.id!==``&&(o[n][a.id]=i)):typeof a.id==`number`?(o[n]={},o[n][a.id]=i):n!==`Properties70`&&(o[n]=n===`PoseNode`?[i]:i),typeof a.id==`number`&&(i.id=a.id),a.name!==``&&(i.attrName=a.name),a.type!==``&&(i.attrType=a.type),this.pushStack(i)}parseNodeAttr(e){let t=e[0];e[0]!==``&&(t=parseInt(e[0]),isNaN(t)&&(t=e[0]));let n=``,r=``;return e.length>1&&(n=e[1].replace(/^(\w+)::/,``),r=e[2]),{id:t,name:n,type:r}}parseNodeProperty(e,t,n){let r=t[1].replace(/^"/,``).replace(/"$/,``).trim(),i=t[2].replace(/^"/,``).replace(/"$/,``).trim();r===`Content`&&i===`,`&&(i=n.replace(/"/g,``).replace(/,$/,``).trim());let a=this.getCurrentNode();if(a.name===`Properties70`){this.parseNodeSpecialProperty(e,r,i);return}if(r===`C`){let e=i.split(`,`).slice(1),t=parseInt(e[0]),n=parseInt(e[1]),o=i.split(`,`).slice(3);o=o.map(function(e){return e.trim().replace(/^"/,``)}),r=`connections`,i=[t,n],xc(i,o),a[r]===void 0&&(a[r]=[])}r===`Node`&&(a.id=i),r in a&&Array.isArray(a[r])?a[r].push(i):r===`a`?a.a=i:a[r]=i,this.setCurrentProp(a,r),r===`a`&&i.slice(-1)!==`,`&&(a.a=yc(i))}parseNodePropertyContinued(e){let t=this.getCurrentNode();t.a+=e,e.slice(-1)!==`,`&&(t.a=yc(t.a))}parseNodeSpecialProperty(e,t,n){let r=n.split(`",`).map(function(e){return e.trim().replace(/^\"/,``).replace(/\s/,`_`)}),i=r[0],a=r[1],o=r[2],s=r[3],c=r[4];switch(a){case`int`:case`enum`:case`bool`:case`ULongLong`:case`double`:case`Number`:case`FieldOfView`:c=parseFloat(c);break;case`Color`:case`ColorRGB`:case`Vector3D`:case`Lcl_Translation`:case`Lcl_Rotation`:case`Lcl_Scaling`:c=yc(c)}this.getPrevNode()[i]={type:a,type2:o,flag:s,value:c},this.setCurrentProp(this.getPrevNode(),i)}},oc=class{parse(e){let t=new sc(e);t.skip(23);let n=t.getUint32();if(n<6400)throw Error(`THREE.FBXLoader: FBX version not supported, FileVersion: `+n);let r=new cc;for(;!this.endOfContent(t);){let e=this.parseNode(t,n);e!==null&&r.add(e.name,e)}return r}endOfContent(e){return e.size()%16==0?(e.getOffset()+160+16&-16)>=e.size():e.getOffset()+160+16>=e.size()}parseNode(e,t){let n={},r=t>=7500?e.getUint64():e.getUint32(),i=t>=7500?e.getUint64():e.getUint32();t>=7500?e.getUint64():e.getUint32();let a=e.getUint8(),o=e.getString(a);if(r===0)return null;let s=[];for(let t=0;t<i;t++)s.push(this.parseProperty(e));let c=s.length>0?s[0]:``,l=s.length>1?s[1]:``,u=s.length>2?s[2]:``;for(n.singleProperty=i===1&&e.getOffset()===r;r>e.getOffset();){let r=this.parseNode(e,t);r!==null&&this.parseSubNode(o,n,r)}return n.propertyList=s,typeof c==`number`&&(n.id=c),l!==``&&(n.attrName=l),u!==``&&(n.attrType=u),o!==``&&(n.name=o),n}parseSubNode(e,t,n){if(n.singleProperty===!0){let e=n.propertyList[0];Array.isArray(e)?(t[n.name]=n,n.a=e):t[n.name]=e}else if(e===`Connections`&&n.name===`C`){let e=[];n.propertyList.forEach(function(t,n){n!==0&&e.push(t)}),t.connections===void 0&&(t.connections=[]),t.connections.push(e)}else if(n.name===`Properties70`)Object.keys(n).forEach(function(e){t[e]=n[e]});else if(e===`Properties70`&&n.name===`P`){let e=n.propertyList[0],r=n.propertyList[1],i=n.propertyList[2],a=n.propertyList[3],o;e.indexOf(`Lcl `)===0&&(e=e.replace(`Lcl `,`Lcl_`)),r.indexOf(`Lcl `)===0&&(r=r.replace(`Lcl `,`Lcl_`)),o=r===`Color`||r===`ColorRGB`||r===`Vector`||r===`Vector3D`||r.indexOf(`Lcl_`)===0?[n.propertyList[4],n.propertyList[5],n.propertyList[6]]:n.propertyList[4],t[e]={type:r,type2:i,flag:a,value:o}}else t[n.name]===void 0?typeof n.id==`number`?(t[n.name]={},t[n.name][n.id]=n):t[n.name]=n:n.name===`PoseNode`?(Array.isArray(t[n.name])||(t[n.name]=[t[n.name]]),t[n.name].push(n)):t[n.name][n.id]===void 0&&(t[n.name][n.id]=n)}parseProperty(e){let t=e.getString(1),n;switch(t){case`C`:return e.getBoolean();case`D`:return e.getFloat64();case`F`:return e.getFloat32();case`I`:return e.getInt32();case`L`:return e.getInt64();case`R`:return n=e.getUint32(),e.getArrayBuffer(n);case`S`:return n=e.getUint32(),e.getString(n);case`Y`:return e.getInt16();case`b`:case`c`:case`d`:case`f`:case`i`:case`l`:let r=e.getUint32(),i=e.getUint32(),a=e.getUint32();if(i===0)switch(t){case`b`:case`c`:return e.getBooleanArray(r);case`d`:return e.getFloat64Array(r);case`f`:return e.getFloat32Array(r);case`i`:return e.getInt32Array(r);case`l`:return e.getInt64Array(r)}let o=new sc(Vs(new Uint8Array(e.getArrayBuffer(a))).buffer);switch(t){case`b`:case`c`:return o.getBooleanArray(r);case`d`:return o.getFloat64Array(r);case`f`:return o.getFloat32Array(r);case`i`:return o.getInt32Array(r);case`l`:return o.getInt64Array(r)}break;default:throw Error(`THREE.FBXLoader: Unknown property type `+t)}}},sc=class{constructor(e,t){this.dv=new DataView(e),this.offset=0,this.littleEndian=t===void 0||t,this._textDecoder=new TextDecoder}getOffset(){return this.offset}size(){return this.dv.buffer.byteLength}skip(e){this.offset+=e}getBoolean(){return(this.getUint8()&1)==1}getBooleanArray(e){let t=[];for(let n=0;n<e;n++)t.push(this.getBoolean());return t}getUint8(){let e=this.dv.getUint8(this.offset);return this.offset+=1,e}getInt16(){let e=this.dv.getInt16(this.offset,this.littleEndian);return this.offset+=2,e}getInt32(){let e=this.dv.getInt32(this.offset,this.littleEndian);return this.offset+=4,e}getInt32Array(e){let t=[];for(let n=0;n<e;n++)t.push(this.getInt32());return t}getUint32(){let e=this.dv.getUint32(this.offset,this.littleEndian);return this.offset+=4,e}getInt64(){let e,t;return this.littleEndian?(e=this.getUint32(),t=this.getUint32()):(t=this.getUint32(),e=this.getUint32()),t&2147483648?(t=~t&4294967295,e=~e&4294967295,e===4294967295&&(t=t+1&4294967295),e=e+1&4294967295,-(t*4294967296+e)):t*4294967296+e}getInt64Array(e){let t=[];for(let n=0;n<e;n++)t.push(this.getInt64());return t}getUint64(){let e,t;return this.littleEndian?(e=this.getUint32(),t=this.getUint32()):(t=this.getUint32(),e=this.getUint32()),t*4294967296+e}getFloat32(){let e=this.dv.getFloat32(this.offset,this.littleEndian);return this.offset+=4,e}getFloat32Array(e){let t=[];for(let n=0;n<e;n++)t.push(this.getFloat32());return t}getFloat64(){let e=this.dv.getFloat64(this.offset,this.littleEndian);return this.offset+=8,e}getFloat64Array(e){let t=[];for(let n=0;n<e;n++)t.push(this.getFloat64());return t}getArrayBuffer(e){let t=this.dv.buffer.slice(this.offset,this.offset+e);return this.offset+=e,t}getString(e){let t=this.offset,n=new Uint8Array(this.dv.buffer,t,e);this.skip(e);let r=n.indexOf(0);return r>=0&&(n=new Uint8Array(this.dv.buffer,t,r)),this._textDecoder.decode(n)}},cc=class{add(e,t){this[e]=t}};function lc(e){return e.byteLength>=21&&bc(e,0,21)===`Kaydara FBX Binary  \0`}function uc(e){let t=[`K`,`a`,`y`,`d`,`a`,`r`,`a`,`\\`,`F`,`B`,`X`,`\\`,`B`,`i`,`n`,`a`,`r`,`y`,`\\`,`\\`],n=0;function r(t){let r=e[t-1];return e=e.slice(n+t),n++,r}for(let e=0;e<t.length;++e)if(r(1)===t[e])return!1;return!0}function dc(e){let t=e.match(/FBXVersion: (\d+)/);if(t)return parseInt(t[1]);throw Error(`THREE.FBXLoader: Cannot find the version number for the file given.`)}function fc(e){return e/46186158e3}var pc=[];function mc(e,t,n,r){let i;switch(r.mappingType){case`ByPolygonVertex`:i=e;break;case`ByPolygon`:i=t;break;case`ByVertice`:i=n;break;case`AllSame`:i=r.indices[0];break;default:console.warn(`THREE.FBXLoader: unknown attribute mapping type `+r.mappingType)}r.referenceType===`IndexToDirect`&&(i=r.indices[i]);let a=i*r.dataSize,o=a+r.dataSize;return Sc(pc,r.buffer,a,o)}var hc=new fe,gc=new R;function _c(e){let t=new h,n=new h,r=new h,i=new h,a=new h,o=new h,s=new h,c=new h,l=new h,u=new h,d=new h,f=new h,p=e.inheritType?e.inheritType:0;e.translation&&t.setPosition(gc.fromArray(e.translation));let m=vc(0);if(e.preRotation){let t=e.preRotation.map(B.degToRad);t.push(m),n.makeRotationFromEuler(hc.fromArray(t))}if(e.rotation){let t=e.rotation.map(B.degToRad);t.push(e.eulerOrder||m),r.makeRotationFromEuler(hc.fromArray(t))}if(e.postRotation){let t=e.postRotation.map(B.degToRad);t.push(m),i.makeRotationFromEuler(hc.fromArray(t)),i.invert()}e.scale&&a.scale(gc.fromArray(e.scale)),e.scalingOffset&&s.setPosition(gc.fromArray(e.scalingOffset)),e.scalingPivot&&o.setPosition(gc.fromArray(e.scalingPivot)),e.rotationOffset&&c.setPosition(gc.fromArray(e.rotationOffset)),e.rotationPivot&&l.setPosition(gc.fromArray(e.rotationPivot)),e.parentMatrixWorld&&(d.copy(e.parentMatrix),u.copy(e.parentMatrixWorld));let g=n.clone().multiply(r).multiply(i),_=new h;_.extractRotation(u);let v=new h;v.copyPosition(u);let y=v.clone().invert().multiply(u),b=_.clone().invert().multiply(y),x=a,S=new h;if(p===0)S.copy(_).multiply(g).multiply(b).multiply(x);else if(p===1)S.copy(_).multiply(b).multiply(g).multiply(x);else{let e=new h().scale(new R().setFromMatrixScale(d)).clone().invert(),t=b.clone().multiply(e);S.copy(_).multiply(g).multiply(t).multiply(x)}let C=l.clone().invert(),w=o.clone().invert(),T=t.clone().multiply(c).multiply(l).multiply(n).multiply(r).multiply(i).multiply(C).multiply(s).multiply(o).multiply(a).multiply(w),E=new h().copyPosition(T),D=u.clone().multiply(E);return f.copyPosition(D),T=f.clone().multiply(S),T.premultiply(u.invert()),T}function vc(e){e||=0;let t=[`ZYX`,`YZX`,`XZY`,`ZXY`,`YXZ`,`XYZ`];return e===6?(console.warn(`THREE.FBXLoader: unsupported Euler Order: Spherical XYZ. Animations and rotations may be incorrect.`),t[0]):t[e]}function yc(e){return e.split(`,`).map(function(e){return parseFloat(e)})}function bc(e,t,n){return t===void 0&&(t=0),n===void 0&&(n=e.byteLength),new TextDecoder().decode(new Uint8Array(e,t,n))}function xc(e,t){for(let n=0,r=e.length,i=t.length;n<i;n++,r++)e[r]=t[n]}function Sc(e,t,n,r){for(let i=n,a=0;i<r;i++,a++)e[a]=t[i];return e}var Cc=`modulepreload`,wc=function(e,t){return new URL(e,t).href},Tc={},Ec=function(e,t,n){let r=Promise.resolve();if(t&&t.length>0){let e=document.getElementsByTagName(`link`),i=document.querySelector(`meta[property=csp-nonce]`),a=i?.nonce||i?.getAttribute(`nonce`);function o(e){return Promise.all(e.map(e=>Promise.resolve(e).then(e=>({status:`fulfilled`,value:e}),e=>({status:`rejected`,reason:e}))))}function s(e){return import.meta.resolve?import.meta.resolve(e):new URL(e,import.meta.url).href}r=o(t.map(t=>{if(t=wc(t,n),t=s(t),t in Tc)return;Tc[t]=!0;let r=t.endsWith(`.css`);for(let n=e.length-1;n>=0;n--){let i=e[n];if(i.href===t&&(!r||i.rel===`stylesheet`))return}let i=document.createElement(`link`);if(i.rel=r?`stylesheet`:Cc,r||(i.as=`script`),i.crossOrigin=``,i.href=t,a&&i.setAttribute(`nonce`,a),document.head.appendChild(i),r)return new Promise((e,n)=>{i.addEventListener(`load`,e),i.addEventListener(`error`,()=>n(Error(`Unable to preload CSS for ${t}`)))})}))}function i(e){let t=new Event(`vite:preloadError`,{cancelable:!0});if(t.payload=e,window.dispatchEvent(t),!t.defaultPrevented)throw e}return r.then(t=>{for(let e of t||[])e.status===`rejected`&&i(e.reason);return e().catch(i)})};function Dc(){let e=new Yt,t=new uo(e),n=new tc(e),r=null,i=null;function a(){return r?Promise.resolve():(i||=Ec(async()=>{let{DRACOLoader:e}=await import(`./DRACOLoader-RyA7e7Ou.js`);return{DRACOLoader:e}},__vite__mapDeps([0,1]),import.meta.url).then(({DRACOLoader:n})=>{r=new n(e),t.setDRACOLoader(r)}),i)}let o=new Set,s=new Set,c=new Set;e.onProgress=(e,t,n)=>{for(let r of o)r(n>0?t/n:1,{url:e,loaded:t,total:n})},e.onLoad=()=>{for(let e of s)e()},e.onError=e=>{console.error(`[assets] failed to load ${e}`);for(let t of c)t(e)};function l(e,t){return e.add(t),()=>e.delete(t)}async function u(e,{draco:n=!0}={}){return n&&await a(),new Promise((n,r)=>{t.load(e,n,void 0,r)})}function d(e){return new Promise((t,r)=>{n.load(e,t,void 0,r)})}function f(){r&&r.dispose(),o.clear(),s.clear(),c.clear()}return{manager:e,loadModel:u,loadFbx:d,onProgress:e=>l(o,e),onLoad:e=>l(s,e),onError:e=>l(c,e),dispose:f}}function Oc(e){let t=new Set(e);if(!t.size||t.size!==e.length)throw Error(`Expected unique loading task names`);let n=new Set(t),r=new Set,i=!1;function a(){return{progress:(t.size-n.size)/t.size,ready:!i&&n.size===0,failed:i}}function o(){let e=a();for(let t of r)t(e)}function s(e){if(!t.has(e))throw Error(`Unknown loading task: ${e}`);n.delete(e)&&o()}function c(){i||(i=!0,o())}function l(e,n){if(!t.has(e))throw Error(`Unknown loading task: ${e}`);return Promise.resolve(n).then(t=>(s(e),t),e=>{throw c(),e})}return{complete:s,fail:c,track:l,get ready(){return!i&&n.size===0},subscribe(e){return r.add(e),e(a()),()=>r.delete(e)}}}var kc={position:new R(0,0,0),yaw:0};function Ac({scene:e,interaction:t,assets:n,hud:r,player:i,camera:a,respawn:o,loadingScreen:s,timeSystem:c,renderer:l,levels:u,onEnter:d,onLeave:f,onInputStateChange:p}){let m=u.map(e=>e.state),h=new Map(u.map(e=>[e.state,e.create])),g=new Map(u.map(e=>[e.state,e.load])),_=new Map,v=new Set(u.filter(e=>e.keepPrevious).map(e=>e.state)),y=null,b=null,x=0,S=null,C=!1,w=null,T={scene:e,interaction:t,assets:n,hud:r,timeSystem:c,player:i,camera:a,respawn:o,renderer:l,advance:P,beginCinematic(){o.cancel(),p?.()}};function E(){console.log(`[music ${new Date().toISOString()} t=${performance.now().toFixed(1)}] level-manager teardown currentState=${b} hasCurrent=${!!y}`),f&&f(),S&&=(S.dispose(),null),y&&=(y.dispose(),null)}function D(e,t,n){let s=v.has(e)&&y;if(s?(S=y,y=null):E(),c?.resetForLevel({preserveEnergy:t}),b=e,w=n,y=h.get(e)(n?{...T,...n}:T),!s){let e=y.checkpoint??kc;o.setCheckpoint(e.position,e.yaw,e),i.setPose(e.position,e.yaw),a.setYaw&&a.setYaw(e.yaw??0),a.setPitch&&a.setPitch(e.pitch),a.snap(),typeof a.update==`function`&&i?.mesh&&a.update(0,i.mesh,null),r.setObjective(y.objective??``)}console.log(`[music ${new Date().toISOString()} t=${performance.now().toFixed(1)}] level-manager onEnter("${e}") preserve=${!!s} pendingToken=${x}`),d&&d(e)}function O(e){C=e,e&&t.setEnabled(!1),p?.()}function k(e){if(h.get(e))return Promise.resolve(h.get(e));if(!_.has(e)){let t=Promise.resolve().then(()=>g.get(e)()).then(t=>{if(typeof t!=`function`)throw Error(`level-manager: invalid factory for "${e}"`);return h.set(e,t),t}).finally(()=>_.delete(e));_.set(e,t)}return _.get(e)}function A(e){if(!h.has(e))throw Error(`level-manager: unknown state "${e}"`);return k(e).catch(t=>(console.warn(`[level-manager] prefetch failed for "${e}"; transition will retry`,t),null))}function j(e,t){if(!h.has(e))throw Error(`level-manager: unknown state "${e}"`);x+=1,y&&E(),b=e,w=null,y=t,C=!1;let n=t.checkpoint??kc;o.setCheckpoint(n.position,n.yaw,n),r.setObjective(t.objective??``),c?.resetForLevel({preserveEnergy:!1}),d&&d(e)}function ee(e,{preserveEnergy:n=!1,levelOptions:r=null}={}){if(!h.has(e))throw Error(`level-manager: unknown state "${e}"`);console.log(`[music ${new Date().toISOString()} t=${performance.now().toFixed(1)}] level-manager enter("${e}") currentState=${b} pendingToken=${x}`);let i=++x;O(!0),o.reset();function a(t){i===x&&(s.show(),s.setError?.(),console.error(`[level-manager] failed to enter "${e}"`,t))}function c(o){function c(){if(i===x)try{if(D(e,n,r),o){s.hide(),O(!1);return}requestAnimationFrame(()=>{i===x&&(s.hide(),O(!1),p||t.setEnabled(!0))})}catch(e){a(e)}}h.get(e)?c():k(e).then(c,a)}if(v.has(e)&&y){c(!0);return}s.show(),t.setEnabled(!1),requestAnimationFrame(()=>requestAnimationFrame(()=>{i===x&&c(!1)}))}function M(){b&&(m.indexOf(b)===m.length-1?ee(m[0]):ee(b,{levelOptions:w}))}function N(){x+=1,o.reset(),E(),c?.resetForRun(),b=null,s.hide(),O(!1),t.setEnabled(!1)}function P(){let e=m.indexOf(b);e>=0&&e<m.length-1&&ee(m[e+1],{preserveEnergy:!0})}function te(e){!C&&y?.update&&y.update(e)}function F(e,t){return!y||typeof y.handleAction!=`function`?!1:!!y.handleAction(e,t)}function ne(){N()}return{enter:ee,prefetch:A,adopt:j,restart:M,unload:N,advance:P,update:te,handleAction:F,setPresentationPaused:e=>y?.setPresentationPaused?.(e),dispose:ne,getState:()=>b,isTransitioning:()=>C,isCinematic:()=>!!y?.isCinematic,get bounds(){return y&&y.bounds?y.bounds:null},get obstacles(){return y&&y.obstacles?y.obstacles:null},get groundHeightAt(){return y&&y.groundHeightAt?y.groundHeightAt:null},get supports(){return y&&y.supports?y.supports:null},get voids(){return y&&y.voids?y.voids:null},get guards(){return y&&typeof y.getGuards==`function`?y.getGuards():null},get carriageVolumes(){return y&&typeof y.getCarriageVolumes==`function`?y.getCarriageVolumes():null}}}function jc({gameStarted:e,creditsOpen:t,paused:n,transitioning:r,caught:i,cinematic:a,editor:o}){return e?t?`CREDITS`:n?`PAUSED`:o?`EDITOR`:r?`TRANSITION`:i?`CAUGHT`:a?`CINEMATIC`:`PLAYING`:`TITLE`}var Mc=null,Nc=null;function Pc(){if(Y.get(`mute`))return 0;let e=Y.get(`masterVolume`);return typeof e==`number`&&Number.isFinite(e)?e:.5}function Fc(){Nc&&(Nc.gain.value=Pc())}function Ic(){Mc||(Mc=new(window.AudioContext||window.webkitAudioContext),Nc=Mc.createGain(),Fc(),Nc.connect(Mc.destination),console.log(`Audio context created, state: `+Mc.state))}function Lc(){return Mc}function Rc(){return Nc}Y.subscribe((e,t)=>{(t===void 0||t===`masterVolume`||t===`mute`||t===`options`||t===`all`)&&Fc()});function zc(){if(!Mc)return;console.log(`Audio context state before resume: `+Mc.state);let e=Mc.resume();if(e&&typeof e.then==`function`)return e.then(()=>{console.log(`Audio context state after resume: `+Mc.state)});console.log(`Audio context state after resume: `+Mc.state)}var Bc=.85,Vc={SLOW:new URL(``+new URL(`sfx-slow-DGuZivRV.wav`,import.meta.url).href,``+import.meta.url),FREEZE:new URL(``+new URL(`sfx-freeze-DStk3Z-F.wav`,import.meta.url).href,``+import.meta.url),REWIND:new URL(``+new URL(`sfx-rewind-DmwbHXjF.wav`,import.meta.url).href,``+import.meta.url),GHOST:new URL(``+new URL(`sfx-ghost-DM53xA0X.wav`,import.meta.url).href,``+import.meta.url)},Hc={SLOW:null,FREEZE:null,REWIND:null,GHOST:null},Uc=null,Wc=null;function Gc(){let e=Lc(),t=Rc();return!e||!t?null:(Uc||(Uc=e.createGain(),Uc.gain.value=Bc,Uc.connect(t)),{ctx:e,bus:Uc})}function Kc(e,t){return new Promise((n,r)=>{let i=e.decodeAudioData(t,n,r);i&&typeof i.then==`function`&&i.then(n,r)})}async function qc(e){if(Hc[e])return Hc[e];let t=Lc();if(!t)return null;let n=Vc[e],r=`ability-sfx:decode:${e}`;console.time(r);let i=await fetch(n);if(!i.ok)throw Error(`[ability-sfx] failed to fetch ${n} (${i.status})`);let a=await i.arrayBuffer();return Hc[e]=await Kc(t,a),console.timeEnd(r),console.log(`[ability-sfx] preloaded ${e} duration=${Hc[e].duration.toFixed(3)}s channels=${Hc[e].numberOfChannels} bytes=${a.byteLength}`),Hc[e]}function Jc(){return Lc()?Wc||(console.log(`[ability-sfx] preload start`),Wc=Promise.all(Object.keys(Vc).map(e=>qc(e))).then(e=>{let t=Object.keys(Vc).filter(e=>Hc[e]),n=Object.keys(Vc).filter(e=>!Hc[e]);console.log(`[ability-sfx] preload finished ready=[${t.join(`, `)}] missing=[${n.join(`, `)||`none`}] count=${e.filter(Boolean).length}/4`)}).catch(e=>{Wc=null;let t=Object.keys(Vc).filter(e=>Hc[e]);console.error(`[ability-sfx] preload failed`,e,`ready so far`,t)}),Wc):(console.warn(`[ability-sfx] preload skipped — no AudioContext yet`),Promise.resolve())}function Yc(e){let t=Gc(),n=Hc[e];if(!t||!n)return;let{ctx:r,bus:i}=t,a=r.createBufferSource();a.buffer=n,a.loop=!1,a.connect(i),a.start(),a.onended=()=>{try{a.disconnect()}catch{}}}function Xc(e){if(!Vc[e])return;let t=e===`GHOST`;if(t&&console.time(`ability-sfx:GHOST`),Hc[e]){console.log(`[ability-sfx] ${e} cache HIT duration=${Hc[e].duration.toFixed(3)}s`),Yc(e),t&&console.timeEnd(`ability-sfx:GHOST`);return}console.warn(`[ability-sfx] ${e} cache MISS — decoding lazily (this can hitch)`),Jc().then(()=>{Yc(e),t&&console.timeEnd(`ability-sfx:GHOST`)})}var Zc=.86,Qc=1.44,$c=1.5,el=1.66,tl=.86,nl=.105,rl=.62,il=.072,al=.225,ol=.115,sl={coat:2896976,trousers:1974830,leather:1316384,skin:12618334,hat:2304576,accent:9387068,cap:`flat`},cl={coat:6103588,trousers:2237999,leather:1513501,skin:12090447,hat:1843241,accent:13083210,cap:`peaked`};function ll({pivotX:e,pivotY:t,length:n,radius:r,material:i,parent:a}){let o=new U;o.position.set(e,t,0);let s=new z(new tt(r,Math.max(.01,n-r*2),4,10),i);return s.position.y=-n/2,s.castShadow=!0,o.add(s),a.add(o),o}function ul(e=sl){let t=new U,n=new U;t.add(n);let r=new x({color:e.coat,roughness:.78,metalness:.04}),i=new x({color:e.trousers,roughness:.85,metalness:.02}),a=new x({color:e.leather,roughness:.45,metalness:.12}),o=new x({color:e.skin,roughness:.86,metalness:0}),s=new x({color:e.hat,roughness:.74,metalness:.05}),c=new x({color:e.accent,roughness:.8,metalness:.05}),l=new p(.245,.2,.58+.08,16);l.scale(1,1,.62);let u=new z(l,r);u.position.y=1.17,u.castShadow=!0,n.add(u);let d=new p(.215,.305,.44,16);d.scale(1,1,.68);let f=new z(d,r);f.position.y=.8099999999999999,f.castShadow=!0,n.add(f);let m=new p(.222,.222,.07,16);m.scale(1,1,.66);let h=new z(m,a);h.position.y=.98,n.add(h);let g=new He(.095,12,10);for(let e of[-.225,al]){let t=new z(g,r);t.position.set(e,Qc,0),t.castShadow=!0,n.add(t)}let _=new z(new p(.062,.07,.12,10),o);_.position.y=$c,n.add(_);let v=new Tt(.105,.048,8,18);v.rotateX(Math.PI/2),v.scale(1,1,.78);let y=new z(v,c);y.position.y=1.52,y.castShadow=!0,n.add(y);let b=new He(.145,18,14);b.scale(.94,1.08,.98);let S=new z(b,o);S.position.y=el,S.castShadow=!0,n.add(S);let C=new He(.021,8,6),w=new x({color:1316380,roughness:.3});for(let e of[-.055,.055]){let t=new z(C,w);t.position.set(e,1.6849999999999998,.124),n.add(t)}if(e.cap!==`none`){let t=new He(.155,16,10,0,Math.PI*2,0,Math.PI/2);t.scale(1,e.cap===`peaked`?.72:.55,1.02);let r=new z(t,s);r.position.y=1.7349999999999999,r.castShadow=!0,n.add(r);let i=new p(.165,.165,.022,16);i.scale(1,1,1.15);let a=new z(i,s);if(a.position.set(0,1.7349999999999999,.075),a.castShadow=!0,n.add(a),e.cap===`peaked`){let e=new z(new p(.157,.157,.035,16),c);e.position.y=1.742,n.add(e)}}let T=ll({pivotX:-.225,pivotY:Qc,length:rl,radius:il,material:r,parent:n}),E=ll({pivotX:al,pivotY:Qc,length:rl,radius:il,material:r,parent:n}),D=ll({pivotX:-.115,pivotY:Zc,length:tl,radius:nl,material:i,parent:t}),O=ll({pivotX:ol,pivotY:Zc,length:tl,radius:nl,material:i,parent:t}),k=new He(.082,10,8);for(let e of[T,E]){let t=new z(k,a);t.position.y=-.6,t.castShadow=!0,e.add(t)}let A=new K(.145,.11,.28);for(let e of[D,O]){let t=new z(A,a);t.position.set(0,-.86+.055,.05),t.castShadow=!0,e.add(t)}return{group:t,body:n,leftArm:T,rightArm:E,leftLeg:D,rightLeg:O}}var dl=.01,fl=.3,pl=.12,ml=12.8/18,hl={idle:new URL(``+new URL(`Idle-D7f4iRCk.fbx`,import.meta.url).href,``+import.meta.url),run:new URL(``+new URL(`Running-Hiytofz4.fbx`,import.meta.url).href,``+import.meta.url),jumpIdle:new URL(``+new URL(`Jump-Cp2l22g1.fbx`,import.meta.url).href,``+import.meta.url),jumpRun:new URL(``+new URL(`Standing Jump Running-BKprU4JD.fbx`,import.meta.url).href,``+import.meta.url),cast:new URL(``+new URL(`Standing 1H Cast Spell 01-Djlj4D2O.fbx`,import.meta.url).href,``+import.meta.url),standToCrouch:new URL(``+new URL(`Standing To Crouch-DYRvTiwF.fbx`,import.meta.url).href,``+import.meta.url),crouchIdle:new URL(``+new URL(`Crouch Idle 02 Looking Around-Cqzw2biL.fbx`,import.meta.url).href,``+import.meta.url),crouchWalk:new URL(``+new URL(`Crouch Walk Forward-CIisw82i.fbx`,import.meta.url).href,``+import.meta.url),crouchToStand:new URL(``+new URL(`Crouch To Standing-MQzGOywN.fbx`,import.meta.url).href,``+import.meta.url),throw:new URL(``+new URL(`Throw-NimADMgA.fbx`,import.meta.url).href,``+import.meta.url)},gl=new Set([`standToCrouch`,`crouchToStand`]),_l=new Set([`cast`,`throw`]),vl=24/30;function yl(e,t){let n=e?.animations?.[0];return n?(n.name=t,n):null}var bl=/(?:^|mixamorig[:.]?)Hips\.position$/,xl=/(?:^|mixamorig[:.]?)Hips\.position\[([xyz])\]$/;function Sl(e){let t=[];return e?.tracks&&(e.tracks=e.tracks.filter(e=>{let n=e.name.match(xl);if(n)return n[1]===`y`?(t.push(`kept ${e.name}`),!0):(t.push(`removed ${e.name}`),!1);if(bl.test(e.name)){if((typeof e.getValueSize==`function`?e.getValueSize():3)===3){let n=e.values.length/3;for(let t=0;t<e.values.length;t+=3)e.values[t]=0,e.values[t+2]=0;return t.push(`zeroed X/Z on ${e.name} (${n} keys, Y kept)`),!0}return t.push(`removed ${e.name}`),!1}return!0})),t}function Cl(e,t){let n=e?.tracks.find(e=>bl.test(e.name));if(!n||n.getValueSize()!==3||n.times.length<2)return null;let r=n.values.length-3,i=n.times[n.times.length-1]-n.times[0];if(!(i>0))return null;let a=Math.hypot(n.values[r]-n.values[0],n.values[r+2]-n.values[2])*t;return{distance:a,span:i,speed:a/i}}function wl(e){let t=e.tracks.find(e=>bl.test(e.name));if(!t||t.getValueSize()!==3||t.times.length<3)return 0;let n=t.values[1],r=e=>t.values[e*3+1],i=0,a=n,o=!1;for(let e=1;e<t.times.length;e++){let t=r(e),s=r(e-1);if(t<s-.05)o=!0,t<a&&(a=t,i=e);else if(o&&t>s+.05&&n-a>2)break}if(n-a<=2)return 0;let s=n-Math.max(1,(n-a)*.05);for(let e=i+1;e<t.times.length;e++)if(r(e)>=s)return t.times[e];return 0}function Tl(e,t){let n=e.tracks.find(e=>bl.test(e.name));if(!n||n.getValueSize()!==3)return e.duration;let r=n.values[1],i=e=>n.values[e*3+1],a=0;for(let e=0;e<n.times.length;e++)if(n.times[e]>=t){a=e;break}let o=a,s=i(a);for(let e=a;e<n.times.length;e++)i(e)>s&&(s=i(e),o=e);for(let e=o+1;e<n.times.length;e++)if(i(e)<=r)return n.times[e];return e.duration}function El(e){let t=wl(e);if(t<=.05)return e;let n=Ie.subclip(e,e.name,t*30,e.duration*30+1,30);return n.name=e.name,console.log(`[detective] ${e.name} skipped ${t.toFixed(3)}s crouch wind-up (${e.duration.toFixed(3)}s → ${n.duration.toFixed(3)}s)`),n}function Dl(e,t){return e.loadFbx(t).catch(e=>(console.warn(`[detective] failed to load ${t}`,e),null))}function Ol(e){let t=e.geometry,n=t?.getAttribute(`position`);if(!n)return;t.deleteAttribute(`normal`),t.computeVertexNormals();let r=t.getAttribute(`normal`);if(!r||n.count===0)return;let i=new Map;for(let e=0;e<n.count;e++){let t=`${n.getX(e).toFixed(5)},${n.getY(e).toFixed(5)},${n.getZ(e).toFixed(5)}`,a=i.get(t);a||(a=new R,i.set(t,a)),a.x+=r.getX(e),a.y+=r.getY(e),a.z+=r.getZ(e)}for(let e of i.values())e.normalize();for(let e=0;e<n.count;e++){let t=`${n.getX(e).toFixed(5)},${n.getY(e).toFixed(5)},${n.getZ(e).toFixed(5)}`,a=i.get(t);r.setXYZ(e,a.x,a.y,a.z)}r.needsUpdate=!0}function kl(e){if(!e)return e;if(e.isMeshStandardMaterial||e.isMeshPhysicalMaterial)return e.flatShading=!1,e.needsUpdate=!0,e;let t=new x;return t.name=e.name,e.color&&t.color.copy(e.color),e.emissive&&t.emissive.copy(e.emissive),t.map=e.map??null,t.normalMap=e.normalMap??null,t.emissiveMap=e.emissiveMap??null,t.alphaMap=e.alphaMap??null,t.aoMap=e.aoMap??null,t.transparent=!!e.transparent,t.opacity=e.opacity,t.side=e.side,t.alphaTest=e.alphaTest,t.vertexColors=e.vertexColors,t.flatShading=!1,t.roughness=e.isMeshPhongMaterial?.55:.75,t.metalness=.04,t.needsUpdate=!0,t}function Al(e){let t=new U;t.name=`detective`,t.add(e),e.updateMatrixWorld(!0);let n=new Ve().setFromObject(t).getSize(new R),r=n.y>10?dl:1;e.scale.setScalar(r),t.updateMatrixWorld(!0);let i=new Ve().setFromObject(t);Number.isFinite(i.min.y)&&(t.position.y-=i.min.y),e.traverse(e=>{if(!e.isMesh)return;Ol(e);let t=(Array.isArray(e.material)?e.material:[e.material]).map(kl);e.material=Array.isArray(e.material)?t:t[0],e.castShadow=!0,e.receiveShadow=!0,e.isSkinnedMesh&&(e.frustumCulled=!1)});let a=i.getSize(new R);return{wrapper:t,scale:r,rawHeight:n.y,worldHeight:a.y,rotation:e.rotation.clone()}}async function jl(e,{crouchSpeed:t=0,crouchSettleTime:n=0}={}){let[r,i,a,o,s,c,l,u,d,p]=await Promise.all([e.loadFbx(hl.idle.href),Dl(e,hl.run.href),Dl(e,hl.jumpIdle.href),Dl(e,hl.jumpRun.href),Dl(e,hl.cast.href),Dl(e,hl.standToCrouch.href),Dl(e,hl.crouchIdle.href),Dl(e,hl.crouchWalk.href),Dl(e,hl.crouchToStand.href),Dl(e,hl.throw.href)]),m=Al(r);console.log(`[detective] scale=${m.scale} rawHeight=${m.rawHeight.toFixed(1)} worldHeight=${m.worldHeight.toFixed(2)}m feetY=${m.wrapper.position.y.toFixed(3)} rootRot=(${m.rotation.x.toFixed(3)}, ${m.rotation.y.toFixed(3)}, ${m.rotation.z.toFixed(3)})`);let h=new it(r),g={idle:yl(r,`idle`),run:yl(i,`run`),jumpIdle:yl(a,`jumpIdle`),jumpRun:yl(o,`jumpRun`),cast:yl(s,`cast`),standToCrouch:yl(c,`standToCrouch`),crouchIdle:yl(l,`crouchIdle`),crouchWalk:yl(u,`crouchWalk`),crouchToStand:yl(d,`crouchToStand`),throw:yl(p,`throw`)},_=Cl(g.crouchWalk,m.scale);for(let e of[`run`,`jumpIdle`,`jumpRun`,`standToCrouch`,`crouchIdle`,`crouchWalk`,`crouchToStand`,`throw`]){let t=g[e];if(!t)continue;let n=Sl(t),r=t.tracks.filter(e=>e.name.endsWith(`.position`)&&!bl.test(e.name)).map(e=>e.name);console.log(`[detective] ${e} root motion: `+(n.length?n.join(`; `):`no Hips.position tracks`)+(r.length?` | other position tracks left as-is: ${r.join(`, `)}`:``))}let v=0,y=1;if(g.jumpIdle){let e=wl(g.jumpIdle),t=Tl(g.jumpIdle,e);v=Math.max(.05,e>0?t-e:t),g.jumpIdle=El(g.jumpIdle),console.log(`[detective] jumpIdle phases airborne=${v.toFixed(3)}s landing=${Math.max(0,g.jumpIdle.duration-v).toFixed(3)}s (plays at 1.0x)`)}g.jumpRun&&=El(g.jumpRun);let b=new Set([`idle`,`run`,`crouchIdle`,`crouchWalk`]),x={};for(let[e,t]of Object.entries(g)){if(!t){console.warn(`[detective] clip ${e}: MISSING`);continue}console.log(`[detective] clip ${e}: duration=${t.duration.toFixed(3)}s tracks=${t.tracks.length}`);let n=h.clipAction(t);n.enabled=!1,n.setEffectiveWeight(1),b.has(e)?n.setLoop(f):(n.setLoop(_e,1),n.clampWhenFinished=!0),x[e]=n}let S=ml;function C(e){let t=B.clamp(e,.25,2);x.jumpRun&&g.jumpRun?.duration&&(x.jumpRun.timeScale=g.jumpRun.duration/t),v>0&&(y=v/t)}function w(){let e=x.jumpIdle;!e||E!==`jumpIdle`||(e.timeScale=e.time>=v?1:y)}C(ml),x.jumpIdle&&console.log(`[detective] jumpIdle airborne timeScale=${y.toFixed(2)} (${v.toFixed(2)}s clip → ${ml.toFixed(2)}s air) landing=1.0x`),x.jumpRun&&g.jumpRun&&console.log(`[detective] jumpRun LoopOnce timeScale=${x.jumpRun.timeScale.toFixed(2)} (clip ${g.jumpRun.duration.toFixed(2)}s → assumed airtime ${ml.toFixed(2)}s)`),x.crouchWalk&&(_&&_.speed>0&&t>0?(x.crouchWalk.timeScale=t/_.speed,console.log(`[detective] crouchWalk timeScale=${x.crouchWalk.timeScale.toFixed(3)} (player ${t.toFixed(3)} m/s ÷ clip ${_.speed.toFixed(3)} m/s = ${_.distance.toFixed(3)}m over ${_.span.toFixed(3)}s)`)):console.warn(`[detective] crouchWalk timeScale left at 1: `+(_?`crouchSpeed=${t}`:`no Hips travel found in the clip`)));for(let e of gl){let t=x[e],r=g[e];!t||!r?.duration||(n>0?(t.timeScale=r.duration/n,console.log(`[detective] ${e} timeScale=${t.timeScale.toFixed(2)} (clip ${r.duration.toFixed(3)}s → crouch settle ${n.toFixed(3)}s)`)):console.warn(`[detective] ${e} timeScale left at 1: crouchSettleTime=${n}`))}let T=null,E=null,D=!1,O=null,k=r.getObjectByName(`mixamorigRightHand`),A=`idle`,j=null,ee=!1,M=null,N=!1,P=!1,te=!1,F=`standing`;function ne(e){return(e||E===`run`||(x.run?.getEffectiveWeight()??0)>.45)&&x.jumpRun?`jumpRun`:x.jumpIdle?`jumpIdle`:x.jumpRun?`jumpRun`:null}function re(e,t=fl,{restart:n=!1}={}){let r=x[e]??x.idle;if(!r)return;let i=r===x[e]?e:`idle`;i===E&&!_l.has(e)&&!n||(r.enabled=!0,r.reset(),r.setEffectiveWeight(1),r.play(),t>0&&T&&T!==r?T.crossFadeTo(r,t,!1):T&&T!==r&&(T.stop(),T.setEffectiveWeight(0)),T=r,E=i)}h.addEventListener(`finished`,e=>{if(M&&e.action===x[M]){M=null,A=te?I(P):L(P),ie(`transition finished`),re(A,pl);return}(e.action===x.cast||e.action===x.throw)&&e.action===T&&(e.action===x.throw&&O&&(O.finished=!0,O=null),D=!1,re(A,fl))}),x.idle?(re(`idle`,0),console.log(`[detective] idle started playing=${x.idle.isRunning()} weight=${x.idle.getEffectiveWeight().toFixed(2)}`)):console.warn(`[detective] no idle clip — mesh will stay in bind pose (T-pose)`);function I(e){return e?x.crouchWalk?`crouchWalk`:x.run?`run`:`idle`:x.crouchIdle?`crouchIdle`:`idle`}function L(e){return e&&x.run?`run`:`idle`}function ie(e){let t=M??(te?I(P):`standing`);t!==F&&(console.log(`[detective] crouch ${F} → ${t} (${e}, moving=${P})`),F=t)}function ae(e){ie(oe(e))}function oe({moving:e,airborne:t,crouching:n,jumpStarted:r}){let i=n&&!ee,a=!n&&ee;ee=n,P=e,te=n;let o=i?`crouch pressed`:a?`stand`:`input`;if(O)return A=n?I(e):L(e),`throwing`;if(r){let t=ne(e);if(t)return j=t,A=t,D=!1,M=null,re(t,0,{restart:!0}),t===`jumpIdle`&&x.jumpIdle&&(x.jumpIdle.timeScale=y),`jump`}if(t)M=null,o=`airborne`,A=j&&x[j]?j:e?`run`:`idle`;else if(!n&&j===`jumpIdle`&&x.jumpIdle&&!x.jumpIdle.paused)return x.jumpIdle.time<v&&(x.jumpIdle.time=v),x.jumpIdle.timeScale=1,A=`jumpIdle`,`landing`;else j=null,i||a?M?(M=null,o=`toggled mid-transition`):i&&x.standToCrouch?(M=`standToCrouch`,N=e):a&&x.crouchToStand&&(M=`crouchToStand`,N=e):M&&e!==N&&(M=null,o=`moving changed mid-transition`),A=M??(n?I(e):L(e));if(D)return A!==`idle`&&(D=!1,re(A,fl)),o;let s=gl.has(A)||gl.has(E);return re(A,s?pl:fl),o}function se(e){let t=j?x[j]:x.jumpIdle??x.jumpRun;if(!(e>0)||!t)return;let n=t.time,r=n/(t.timeScale||1);S=e,C(e);let i=j===`jumpIdle`?`airborne=${y.toFixed(2)} landing=1.00`:`nextTimeScale=${t.timeScale.toFixed(2)}`;console.log(`[detective] ${j??`jump`} airtime measured=${e.toFixed(3)}s clipTime=${n.toFixed(3)}s (raw clip timeline, not wall clock) wallPlayed=${r.toFixed(3)}s (clipTime/timeScale) `+i)}function z(){O||x.cast&&A===`idle`&&(D=!0,re(`cast`,fl))}function ce(){return O?null:x.throw?(D=!1,M=null,j=null,O={released:!1,finished:!1,cancelled:!1,releasePosition:null},re(`throw`,.12),O):{released:!0,finished:!0,cancelled:!1}}function le(){O&&(O.cancelled=!0,O=null,re(A,fl))}let ue=0;function de(e){O?.cancelled&&le();let t=O;if(h.update(e),t&&!t.cancelled&&!t.released&&x.throw.time>=Math.min(vl,g.throw.duration)&&(k&&(m.wrapper.updateWorldMatrix(!0,!0),t.releasePosition=k.getWorldPosition(new R)),t.released=!0),w(),ue+=1,ue===1||ue%60==0){let t=e=>(x[e]?.getEffectiveWeight()??0).toFixed(2);console.log(`[detective] mixer.update #${ue} delta=${e.toFixed(4)} idle=${t(`idle`)} run=${t(`run`)} jumpIdle=${t(`jumpIdle`)} jumpRun=${t(`jumpRun`)} cast=${t(`cast`)} throw=${t(`throw`)} standToCrouch=${t(`standToCrouch`)} crouchIdle=${t(`crouchIdle`)} crouchWalk=${t(`crouchWalk`)} crouchToStand=${t(`crouchToStand`)} airborneJump=${j??`none`} crouchTransition=${M??`none`} lastAirtime=${S.toFixed(2)}s idleTime=${(x.idle?.time??0).toFixed(2)} runTime=${(x.run?.time??0).toFixed(2)}`)}}function fe(){le(),h.stopAllAction(),h.uncacheRoot(r)}return{root:m.wrapper,mixer:h,actions:x,setLocomotion:ae,playCast:z,playThrow:ce,cancelThrow:le,noteJumpAirtime:se,update:de,dispose:fe}}function Ml(e,t,n=0){if(!t)return;let r=Math.max(0,n||0);for(let n of t){if(n.enabled===!1)continue;if(r<=0){if(e.x>n.minX&&e.x<n.maxX&&e.z>n.minZ&&e.z<n.maxZ){let t=e.x-n.minX,r=n.maxX-e.x,i=e.z-n.minZ,a=n.maxZ-e.z,o=Math.min(t,r,i,a);o===t?e.x=n.minX:o===r?e.x=n.maxX:e.z=o===i?n.minZ:n.maxZ}continue}let t=Math.max(n.minX,Math.min(e.x,n.maxX)),i=Math.max(n.minZ,Math.min(e.z,n.maxZ)),a=e.x-t,o=e.z-i,s=a*a+o*o;if(e.x>n.minX&&e.x<n.maxX&&e.z>n.minZ&&e.z<n.maxZ){let t=e.x-n.minX,i=n.maxX-e.x,a=e.z-n.minZ,o=n.maxZ-e.z,s=Math.min(t,i,a,o);s===t?e.x=n.minX-r:s===i?e.x=n.maxX+r:e.z=s===a?n.minZ-r:n.maxZ+r;continue}if(s>=r*r)continue;let c=Math.sqrt(s);if(c>1e-6){let t=r-c;e.x+=a/c*t,e.z+=o/c*t}}}function Nl(e,t){if(t)for(let n of t){let t=e.x-n.x,r=e.z-n.z,i=t*t+r*r;if(i>=n.radius*n.radius)continue;let a=Math.sqrt(i);if(a>1e-4){let i=n.radius-a;e.x+=t/a*i,e.z+=r/a*i}else e.x+=n.radius;n.onCollide&&n.onCollide()}}var Pl=4,Fl=1.7,Il=.42,Ll=14,Rl=.72,zl=2.4,Bl=.035,Vl=.13,Hl=18,Ul=6.4,Wl=.8,Gl=8,Kl=.18,ql=.08,Jl=-.85,Yl=1.35,Xl=.24,Zl=.25,Ql=.35,$l=10,eu=-1.55,tu=2.32,nu=.48;function ru(e){let t=null;return e.traverse(e=>{t||!e.isMesh||!e.material||(t=Array.isArray(e.material)?e.material[0]:e.material)}),t??new x({color:1381658,roughness:.8})}function iu(e){e.updateMatrixWorld(!0);let t=e.parent;if(!t)return null;t.updateMatrixWorld(!0);let n=new Ve().setFromObject(e);if(n.isEmpty())return null;let r=n.min,i=n.max,a=[new R(r.x,r.y,r.z),new R(r.x,r.y,i.z),new R(r.x,i.y,r.z),new R(r.x,i.y,i.z),new R(i.x,r.y,r.z),new R(i.x,r.y,i.z),new R(i.x,i.y,r.z),new R(i.x,i.y,i.z)],o=new Ve;o.makeEmpty();for(let e of a)t.worldToLocal(e),o.expandByPoint(e);return o}function au(e,t){let n=new z(e,t);return n.castShadow=!0,n.receiveShadow=!0,n}function ou(e,t){let n=e.parent;if(!n)throw Error(`player: ${t} has no parent`);let r=iu(e),i=new R,a=new R;r?(r.getSize(i),r.getCenter(a)):(i.set(.42,1.65,.42),a.copy(e.position));let o=i.y,s=Math.max(Math.min(i.x,i.z),.28),c=B.clamp(s*.38,.11,o*.12),l=Math.min(c*.9,o*.1),u=o-l,d=u*.5,f=u*.5,m=new U;m.name=`${t}-hip`,m.position.set(a.x,r?r.max.y:a.y+o*.5,a.z);let h=ru(e),g=au(new p(c*1.05,c*.95,d,10),h);g.name=`${t}-thigh`,g.position.y=-d*.5,m.add(g);let _=new U;_.name=`${t}-knee`,_.position.y=-d,m.add(_);let v=au(new He(c*1.02,10,7),h);v.name=`${t}-knee-cap`,_.add(v);let y=au(new p(c*.92,c*.8,f,10),h);y.name=`${t}-shin`,y.position.y=-f*.5,_.add(y);let b=new U;b.name=`${t}-ankle`,b.position.y=-f,_.add(b);let x=au(new K(c*1.55,l,c*2.5),h);return x.name=`${t}-foot`,x.position.set(0,-l*.5,c*.55),b.add(x),n.add(m),e.visible=!1,{hip:m,knee:_,ankle:b,thighLength:d,shinLength:f,basePosition:m.position.clone()}}function su(){let{group:e,body:t,leftArm:n,rightArm:r,leftLeg:i,rightLeg:a}=ul(sl);e.name=`player`,e.position.set(0,0,-8),e.updateMatrixWorld(!0);let o=ou(i,`left-leg`),s=ou(a,`right-leg`),c=t.position.y,l=0,u=0,d=0,f=e.position.y,p=0,m=0,h=0,g=!1,_=!1,v=!1,y=!1,b=!1,x=0,S=!1,C=!1,w=!1,T=!1,E=null;function D(e){t.visible=e,n.visible=e,r.visible=e,o.hip.visible=e,s.hip.visible=e}async function O(t){if(E)return E;try{E=await jl(t,{crouchSpeed:Pl*Il,crouchSettleTime:Math.log(20)/$l}),e.add(E.root),D(!1)}catch(e){console.warn(`[player] detective FBX failed, keeping humanoid`,e),E=null}return E}function k(e){E?.update(e)}function A(){E?.playCast()}function j(){return E?E.playThrow():{released:!0,finished:!0,cancelled:!1}}function ee(t,n,r){let i=Math.atan2(t,n)-u;for(;i>Math.PI;)i-=Math.PI*2;for(;i<-Math.PI;)i+=Math.PI*2;u+=i*Math.min(1,r*Ll),e.rotation.y=u}function M(e,t,n,r,i){e.hip.rotation.x+=(t-e.hip.rotation.x)*i,e.knee.rotation.x+=(n-e.knee.rotation.x)*i;let a=e.basePosition.y+r;e.hip.position.y+=(a-e.hip.position.y)*i}function N(e,t=!1){let n=t?eu:Jl,r=t?tu:Yl,i=n*e,a=r*e,c=(o.thighLength+s.thighLength)*.5,l=(o.shinLength+s.shinLength)*.5,u=c+l,d=c*Math.cos(i)+l*Math.cos(i+a);return Math.max(0,u-d)}function P(){t.position.y=c,t.rotation.x=0,n.rotation.x=0,r.rotation.x=0,o.hip.position.copy(o.basePosition),s.hip.position.copy(s.basePosition),o.hip.rotation.x=0,s.hip.rotation.x=0,o.knee.rotation.x=0,s.knee.rotation.x=0}function te(t,n=0){E?.cancelThrow(),e.position.copy(t),e.rotation.y=n,u=n,f=t.y,p=0,m=0,h=0,g=!1,_=!1,d=0,T=!1,l=0,P()}function F(e,t,n){if(!n)return!1;for(let r of n)if(e>r.minX&&e<r.maxX&&t>r.minZ&&t<r.maxZ)return!0;return!1}function ne(e,t,n,r){if(!r)return null;let i=null;for(let a of r){if(e<a.minX||e>a.maxX||n<a.minZ||n>a.maxZ)continue;let r=a.y;t>=r-1&&t<=r+.55&&(i==null||r>i)&&(i=r)}return i}function re(i,{keyboard:a,crouchPressed:u=!1,runPressed:D=!1,cameraYaw:O,bounds:k,obstacles:A,groundHeightAt:j,supports:P,voids:te}){let re=Math.sin(O),I=Math.cos(O),L=0,ie=0;a.forward&&(L+=re,ie+=I),a.back&&(L-=re,ie-=I),a.left&&(L+=I,ie-=re),a.right&&(L-=I,ie+=re);let ae=Math.hypot(L,ie);w=ae>0,w&&(L/=ae,ie/=ae);let oe=!!a.jump,se=oe&&!_;_=oe,y=!1;let R=Y.get(`crouchMode`)===`hold`;R?T=!1:(u&&(T=!T),T&&(se||D)&&(T=!1,se=!1)),S=((R?!!a.duck:T)||!!e.userData.wreckLowCeiling)&&!g;let z=S&&!!e.userData.tightCrouchCamera;C=!!a.run&&w&&!S;function ce(t){if(typeof j!=`function`)return t;let n=j(e.position.x,e.position.z,t);return Number.isFinite(n)?n:t}function le(t,n){let r=Math.max(1,Math.ceil(Math.hypot(t,n)/ql)),i=t/r,a=n/r;for(let t=0;t<r;t++)e.position.x+=i,e.position.z+=a,A&&Ml(e.position,A,Kl)}if(g||(f=ce(e.position.y),e.position.y=f),g){if(w){let e=Pl*(C?Fl:1)*Wl,t=Math.min(1,i*Gl);m+=(L*e-m)*t,h+=(ie*e-h)*t}le(m*i,h*i),f=ce(f),p-=Hl*i,e.position.y+=p*i,Math.hypot(m,h)>.001&&ee(m,h,i);let t=ne(e.position.x,e.position.y,e.position.z,P);p<=0&&t!=null?(e.position.y=t,f=t,p=0,m=0,h=0,g=!1):!F(e.position.x,e.position.z,te)&&e.position.y<=f&&(e.position.y=f,p=0,m=0,h=0,g=!1)}else if(se&&!S){let e=C?Pl*Fl:Pl;m=w?L*e*Wl:0,h=w?ie*e*Wl:0,p=Ul,g=!0,y=!0,b=!0,x=0,w&&ee(L,ie,i)}else if(w){let t=1;S?t=Il:C&&(t=Fl);let n=Pl*t*i;le(L*n,ie*n),f=ce(e.position.y),e.position.y=f,ee(L,ie,i),l+=n*zl}else l*=Math.max(0,1-i*10);if(!g){let t=ne(e.position.x,e.position.y,e.position.z,P);t==null?F(e.position.x,e.position.z,te)&&(g=!0,p=0,m=0,h=0):(e.position.y=t,f=t)}if(d+=(+!!S-d)*Math.min(1,i*$l),b&&(g?x+=i:v&&(E?.noteJumpAirtime(x),b=!1,x=0)),v=g,E)E.setLocomotion({moving:w,airborne:g,crouching:S,jumpStarted:y});else{let e=Math.min(1,i*14);if(g){let i=p>0,a=i?-.35:-.12,l=i?.35:.12,u=i?.72:.28,d=i?.45:.28;M(o,a,u,0,e),M(s,l,d,0,e),t.position.y+=(c-t.position.y)*e,t.rotation.x+=(.08-t.rotation.x)*e,n.rotation.x+=(.35-n.rotation.x)*e,r.rotation.x+=(-.35-r.rotation.x)*e}else{let a=Math.sin(l),u=w?Math.abs(a)*Bl:0,f=B.lerp(1,Zl,d),p=a*Rl*f,m=Math.max(0,a)*.38,h=Math.max(0,-a)*.38,g=(z?eu:Jl)*d,_=(z?tu:Yl)*d,v=g+p,y=g-p,b=_+m*(1-d*.6)-p*d*.25,x=_+h*(1-d*.6)+p*d*.25,S=N(d,z),T=u*(1-d*.5)-S;M(o,v,b,T,e),M(s,y,x,T,e);let E=c+T;t.position.y+=(E-t.position.y)*e;let D=C?Vl:(z?nu:Xl)*d;t.rotation.x+=(D-t.rotation.x)*Math.min(1,i*9);let O=B.lerp(1,Ql,d),k=-p*.8*O+d*.18,A=p*.8*O+d*.18;n.rotation.x+=(k-n.rotation.x)*e,r.rotation.x+=(A-r.rotation.x)*e}}A&&Ml(e.position,A,Kl),k&&(e.position.x=B.clamp(e.position.x,k.minX,k.maxX),e.position.z=B.clamp(e.position.z,k.minZ,k.maxZ))}return{mesh:e,update:re,setPose:te,loadVisual:O,updateVisual:k,playCast:A,playThrow:j,isCrouching:()=>S,isRunning:()=>C,isAirborne:()=>g,isMoving:()=>w}}var cu=.01,lu={x:-.19,y:7.5,z:2.39},uu={x:.01265,y:.45633,z:.17537},du=200,fu={walk:new URL(``+new URL(`Walking With Shopping Bag-DOcNQnc_.fbx`,import.meta.url).href,``+import.meta.url),idle:new URL(``+new URL(`Unarmed Idle Looking Ver. 2-BL-7jioH.fbx`,import.meta.url).href,``+import.meta.url),turn:new URL(``+new URL(`Catwalk Twist L To Walk 180-DvLaJ0Rm.fbx`,import.meta.url).href,``+import.meta.url),torch:new URL(``+new URL(`guard-torch-glnN8rZR.glb`,import.meta.url).href,``+import.meta.url)},pu=/(?:^|mixamorig[:.]?)Hips\.position$/,mu=/(?:^|mixamorig[:.]?)Hips\.position\[([xyz])\]$/;function hu(e,t){let n=e?.animations?.[0];return n?(n.name=t,n):null}function gu(e){let t=[];return e?.tracks&&(e.tracks=e.tracks.filter(e=>{let n=e.name.match(mu);if(n)return n[1]===`y`?(t.push(`kept ${e.name}`),!0):(t.push(`removed ${e.name}`),!1);if(pu.test(e.name)){if((typeof e.getValueSize==`function`?e.getValueSize():3)===3){let n=e.values.length/3;for(let t=0;t<e.values.length;t+=3)e.values[t]=0,e.values[t+2]=0;return t.push(`zeroed X/Z on ${e.name} (${n} keys, Y kept)`),!0}return t.push(`removed ${e.name}`),!1}return!0})),t}function _u(e,t){if(!t)return;let n=gu(t),r=t.tracks.filter(e=>e.name.endsWith(`.position`)&&!pu.test(e.name)).map(e=>e.name);console.log(`[police] ${e} root motion: `+(n.length?n.join(`; `):`no Hips.position tracks`)+(r.length?` | other position tracks left as-is: ${r.join(`, `)}`:``))}function vu(e){let t=e.geometry,n=t?.getAttribute(`position`);if(!n)return;t.deleteAttribute(`normal`),t.computeVertexNormals();let r=t.getAttribute(`normal`);if(!r||n.count===0)return;let i=new Map;for(let e=0;e<n.count;e++){let t=`${n.getX(e).toFixed(5)},${n.getY(e).toFixed(5)},${n.getZ(e).toFixed(5)}`,a=i.get(t);a||(a=new R,i.set(t,a)),a.x+=r.getX(e),a.y+=r.getY(e),a.z+=r.getZ(e)}for(let e of i.values())e.normalize();for(let e=0;e<n.count;e++){let t=`${n.getX(e).toFixed(5)},${n.getY(e).toFixed(5)},${n.getZ(e).toFixed(5)}`,a=i.get(t);r.setXYZ(e,a.x,a.y,a.z)}r.needsUpdate=!0}function yu(e){if(!e)return e;if(e.isMeshStandardMaterial||e.isMeshPhysicalMaterial)return e.flatShading=!1,e.needsUpdate=!0,e;let t=new x;return t.name=e.name,e.color&&t.color.copy(e.color),e.emissive&&t.emissive.copy(e.emissive),t.map=e.map??null,t.normalMap=e.normalMap??null,t.emissiveMap=e.emissiveMap??null,t.alphaMap=e.alphaMap??null,t.aoMap=e.aoMap??null,t.transparent=!!e.transparent,t.opacity=e.opacity,t.side=e.side,t.alphaTest=e.alphaTest,t.vertexColors=e.vertexColors,t.flatShading=!1,t.roughness=e.isMeshPhongMaterial?.55:.75,t.metalness=.04,t.needsUpdate=!0,t}function bu(e){let t=new U;t.name=`police`,t.add(e),e.updateMatrixWorld(!0);let n=new Ve().setFromObject(t).getSize(new R),r=n.y>10?cu:1;e.scale.setScalar(r),t.updateMatrixWorld(!0);let i=new Ve().setFromObject(t);Number.isFinite(i.min.y)&&(t.position.y-=i.min.y),e.traverse(e=>{if(!e.isMesh)return;vu(e);let t=(Array.isArray(e.material)?e.material:[e.material]).map(yu);e.material=Array.isArray(e.material)?t:t[0],e.castShadow=!0,e.receiveShadow=!0,e.isSkinnedMesh&&(e.frustumCulled=!1)});let a=i.getSize(new R);return{wrapper:t,model:e,scale:r,rawHeight:n.y,worldHeight:a.y,rotation:e.rotation.clone()}}function xu(e,t){let n=[`mixamorig${t}`,`mixamorig:${t}`,t],r=null;return e.traverse(e=>{r||!e.isBone||n.includes(e.name)&&(r=e)}),r}function Su(e){e&&(e.position.set(lu.x,lu.y,lu.z),e.rotation.set(uu.x,uu.y,uu.z),e.scale.setScalar(du))}function Cu(e){e.updateMatrixWorld(!0);let t=[];e.traverse(e=>{e.isMesh&&t.push(e)});for(let e of t)e.geometry=e.geometry.clone(),e.geometry.applyMatrix4(e.matrixWorld),e.geometry.computeVertexNormals(),e.geometry.computeBoundingBox(),e.geometry.computeBoundingSphere();e.traverse(e=>{e.position.set(0,0,0),e.quaternion.identity(),e.rotation.set(0,0,0),e.scale.set(1,1,1),e.updateMatrix()}),e.updateMatrixWorld(!0)}function wu(e){let t=0;return e.traverse(e=>{if(!e.isMesh)return;t+=1,e.castShadow=!0,e.receiveShadow=!0,e.frustumCulled=!1,e.visible=!0;let n=(Array.isArray(e.material)?e.material:[e.material]).map(e=>{if(!e)return e;let t=e.clone();return t.transparent=!1,t.depthWrite=!0,t.opacity=1,t.alphaTest=0,t.side=2,`transmission`in t&&(t.transmission=0),t.emissiveMap&&(t.emissive.set(16777215),t.emissiveIntensity=Math.max(t.emissiveIntensity||0,1.4)),t.needsUpdate=!0,t});e.material=Array.isArray(e.material)?n:n[0]}),Cu(e),t}function Tu(e,t){e.updateMatrixWorld(!0);let n=new Ve().setFromObject(e),r=n.getSize(new R),i=n.getCenter(new R),a=`z`;r.x>=r.y&&r.x>=r.z?a=`x`:r.y>=r.x&&r.y>=r.z&&(a=`y`);let o=Math.abs(n.max[a])>=Math.abs(n.min[a]),s=o?n.max[a]:n.min[a];t.position.copy(i),t.position[a]=s;let c=new R;c[a]=o?1:-1,t.quaternion.setFromUnitVectors(new R(0,0,1),c)}function Eu(e){let t=e.clone(!0),n=new U;for(n.name=`torch-model`;t.children.length;)n.add(t.children[0]);return t.isMesh&&n.add(t),n}function Du(e){let t=new U;t.name=`torch`;let n=Eu(e);t.add(n);let r=new U;r.name=`torch-beam`,Tu(t,r);let i=new ft(16760954,22,9,Math.PI/4.5,.55,2);i.name=`torch-spot`,i.castShadow=!1;let a=new Ee;return a.name=`torch-spot-target`,a.position.set(0,0,12),r.add(i,a),i.target=a,t.add(r),Su(t),{torch:t,beamOrigin:r}}function Ou(e,t){if(!t)return console.warn(`[police] torch attach skipped — torchScene is null (GLTF did not load)`),{torch:null,beamOrigin:null};let n=xu(e,`RightHand`);if(!n)return console.warn(`[police] mixamorigRightHand missing — torch not attached`),{torch:null,beamOrigin:null};let{torch:r,beamOrigin:i}=Du(t);return n.add(r),{torch:r,beamOrigin:i}}var ku=null,Au=null;async function ju(e){let[t,n,r,i]=await Promise.all([e.loadFbx(fu.walk.href),e.loadFbx(fu.idle.href).catch(e=>(console.warn(`[police] idle clip failed to load`,e),null)),e.loadFbx(fu.turn.href).catch(e=>(console.warn(`[police] turn clip failed to load (unused for now)`,e),null)),e.loadModel(fu.torch.href,{draco:!1}).catch(e=>(console.warn(`[police] torch GLTF failed to load`,e),null))]),a=bu(t);console.log(`[police] scale=${a.scale} rawHeight=${a.rawHeight.toFixed(1)} worldHeight=${a.worldHeight.toFixed(2)}m feetY=${a.wrapper.position.y.toFixed(3)} rootRot=(${a.rotation.x.toFixed(3)}, ${a.rotation.y.toFixed(3)}, ${a.rotation.z.toFixed(3)})`);let o=hu(t,`walk`);if(!o)throw Error(`[police] Walking With Shopping Bag.fbx has no animation clip`);_u(`walk`,o),console.log(`[police] clip walk: duration=${o.duration.toFixed(3)}s tracks=${o.tracks.length}`);let s=hu(n,`idle`);s?(_u(`idle`,s),console.log(`[police] clip idle: duration=${s.duration.toFixed(3)}s tracks=${s.tracks.length}`)):console.warn(`[police] Unarmed Idle Looking clip missing — stopped guards have no idle`);let c=hu(r,`turn`);c?(_u(`turn`,c),console.log(`[police] clip turn: duration=${c.duration.toFixed(3)}s tracks=${c.tracks.length} (loaded, unused)`)):console.warn(`[police] Catwalk Twist clip missing — walk still works`);let l=null;return i?.scene?(l=i.scene,wu(l)||console.warn(`[police] torch GLTF has zero meshes after prepare`)):console.warn(`[police] flashlight GLTF missing — guards have no torch`),{wrapper:a.wrapper,walkClip:o,idleClip:s,turnClip:c,torchScene:l,scale:a.scale,worldHeight:a.worldHeight,feetY:a.wrapper.position.y}}function Mu(e){return!e?.loadFbx||!e?.loadModel?Promise.resolve(null):(ku||=ju(e).then(e=>(Au=e,e)).catch(e=>(console.warn(`[police] FBX failed, guards keep humanoid`,e),ku=null,Au=null,null)),ku)}function Nu(){return Au}function Pu(e=Au){if(!e?.wrapper||!e.walkClip)return null;let t=co(e.wrapper);t.name=`police`;let n=t.children[0]??t,{beamOrigin:r}=Ou(t,e.torchScene),i=new it(n),a=i.clipAction(e.walkClip);a.enabled=!1,a.setEffectiveWeight(1),a.setLoop(f);let o=e.idleClip?i.clipAction(e.idleClip):null;o&&(o.enabled=!0,o.setEffectiveWeight(1),o.setLoop(f),o.play());let s=!1;function c(e){let t=!!e;t!==s&&(s=t,s?(o&&(o.stop(),o.enabled=!1,o.setEffectiveWeight(0)),a.enabled=!0,a.reset(),a.setEffectiveWeight(1),a.play()):(a.stop(),a.enabled=!1,a.setEffectiveWeight(0),o&&(o.enabled=!0,o.reset(),o.setEffectiveWeight(1),o.play())))}function l(e){i.update(e)}function u(){i.stopAllAction(),i.uncacheRoot(n),t.traverse(e=>{e.skeleton?.boneTexture&&e.skeleton.dispose()})}function d(e){return r?r.getWorldPosition(e):null}return{root:t,mixer:i,walkAction:a,idleAction:o,setWalking:c,update:l,dispose:u,getBeamWorldPosition:d}}var Fu=Ea.filter(e=>e.held).map(e=>e.id),Iu=new Set([`Space`,`ArrowUp`,`ArrowDown`,`ArrowLeft`,`ArrowRight`,`PageUp`,`PageDown`,`Home`,`End`,`Tab`]);function Lu(){let e={};for(let t of Fu)e[t]=!1;let t=new Map,n=new Set,r=new Map,i=!0;function a(){let e=new Map,t=Y.getBindings();for(let n of Ea)for(let r of t[n.id]??[])r&&e.set(r,n.id);r=e}a();let o=Y.subscribe((e,t)=>{(t===`bindings`||t===`all`)&&(a(),c())});function s(e,n){return t.has(e)||t.set(e,new Set),t.get(e).add(n),()=>{let r=t.get(e);r&&(r.delete(n),r.size===0&&t.delete(e))}}function c(){for(let t of Fu)e[t]=!1;n.clear()}function l(e){return n.delete(e)}function u(a){if(!i)return;let o=[`ControlLeft`,`ControlRight`,`AltLeft`,`AltRight`,`MetaLeft`,`MetaRight`].includes(a.code),s=r.get(a.code);if((a.ctrlKey||a.altKey||a.metaKey)&&!o){a.preventDefault(),s&&s in e&&(e[s]=!0);return}s&&(Iu.has(a.code)&&a.preventDefault(),s in e&&(e[s]=!0),a.repeat||(n.add(s),t.get(s)?.forEach(e=>e(a))))}function d(t){let n=r.get(t.code);n&&n in e&&(e[n]=!1)}function f(){c()}window.addEventListener(`keydown`,u),window.addEventListener(`keyup`,d),window.addEventListener(`blur`,f);function p(e){i=e,e||c()}function m(){window.removeEventListener(`keydown`,u),window.removeEventListener(`keyup`,d),window.removeEventListener(`blur`,f),o(),t.clear()}return{state:e,onAction:s,consumePress:l,setEnabled:p,reset:c,dispose:m}}var Ru=`KeyW.KeyT.KeyN.KeyR.KeyP.KeyS.KeyD.KeyF.KeyH.KeyJ.KeyL.KeyO.KeyQ.KeyU.Digit1.Digit2.Digit3.Digit4.Digit5.Digit6.Digit7.Digit8.Digit9.Digit0.Tab.ControlLeft.ControlRight.AltLeft.AltRight.MetaLeft.MetaRight`.split(`.`),zu=new Set([`ControlLeft`,`ControlRight`,`AltLeft`,`AltRight`,`MetaLeft`,`MetaRight`,`Tab`]);function Bu(){let e=new Set(Ru),t=Y.getBindings();for(let n of Object.values(t))for(let t of n)t&&e.add(t);for(let t of Oa)e.delete(t);return[...e]}function Vu(e){let t=typeof navigator<`u`&&navigator.keyboard!=null&&typeof navigator.keyboard.lock==`function`,n=!1;function r(){return document.fullscreenElement!=null}function i(){!t||!n||!r()||Y.get(`captureShortcuts`)&&Promise.resolve(navigator.keyboard.lock(Bu())).catch(()=>{})}function a(){if(t)try{navigator.keyboard.unlock()}catch{}}let o=Y.subscribe((e,t)=>{(t===`bindings`||t===`all`)&&i(),(t===`captureShortcuts`||t===`all`)&&(e.captureShortcuts?i():a())});function s(){r()?i():a()}document.addEventListener(`fullscreenchange`,s);function c(){if(!Y.get(`captureShortcuts`)){n=!1;return}if(n=!0,r()){i();return}let t=e.requestFullscreen?.();t&&typeof t.then==`function`&&t.then(i,()=>{})}function l({exitFullscreen:e=!0}={}){if(n=!1,a(),e&&r()){let e=document.exitFullscreen?.();e&&typeof e.catch==`function`&&e.catch(()=>{})}}function u(){l(),document.removeEventListener(`fullscreenchange`,s),o()}return{engage:c,release:l,dispose:u,isSupported:()=>t}}var Hu=new Pt,Uu=Ee.prototype.raycast,Wu=z.prototype.raycast,Gu=256,Ku=32,qu=new WeakMap,Ju=new WeakMap,Yu=new h,Xu=new s,Zu=new R,Qu=new R,$u=new R,ed=new R,td=new R,nd=new R;function rd(e,t,n){let r=t*3+n;return e.index?e.index.getX(r):r}function id(e){let t=e.attributes.position,n=(e.index?e.index.count:t.count)/3;e.boundingBox===null&&e.computeBoundingBox();let{min:r,max:i}=e.boundingBox,a=Math.max((i.x-r.x)/Ku,1e-6),o=Math.max((i.z-r.z)/Ku,1e-6),s=(e,t,n)=>Math.min(31,Math.max(0,Math.floor((e-t)/n))),c=Array.from({length:1024},()=>[]);for(let i=0;i<n;i++){let n=1/0,l=-1/0,u=1/0,d=-1/0;for(let r=0;r<3;r++){let a=rd(e,i,r),o=t.getX(a),s=t.getZ(a);n=Math.min(n,o),l=Math.max(l,o),u=Math.min(u,s),d=Math.max(d,s)}for(let e=s(n,r.x,a);e<=s(l,r.x,a);e++)for(let t=s(u,r.z,o);t<=s(d,r.z,o);t++)c[t*Ku+e].push(i)}return{min:r,max:i,cellX:a,cellZ:o,cell:s,cells:c,stamp:new Uint32Array(n),mark:0}}function ad(e){if(Ju.has(e))return Ju.get(e);let t=e.geometry,n=e.isMesh&&!e.isSkinnedMesh&&!e.isInstancedMesh&&!e.isBatchedMesh&&e.raycast===Wu&&e.material&&!Array.isArray(e.material)&&!t.morphAttributes.position&&t.groups.length===0&&t.drawRange.start===0&&t.drawRange.count===1/0&&(t.index?t.index.count:t.attributes.position.count)/3>=Gu,r=null;return n&&(r={layers:e.layers,children:[],updateWorldMatrix:(...t)=>e.updateWorldMatrix(...t),raycast:(t,n)=>od(e,t,n)}),Ju.set(e,r),r}function od(e,t,n){let{ray:r,near:i,far:a}=t;if(!Number.isFinite(a))return e.raycast(t,n);let o=e.geometry,s=qu.get(o);s||qu.set(o,s=id(o)),Yu.copy(e.matrixWorld).invert(),Xu.copy(r).applyMatrix4(Yu),Zu.copy(r.direction).multiplyScalar(a).add(r.origin).applyMatrix4(Yu);let{min:c,max:l,cellX:u,cellZ:d,cell:f,cells:p,stamp:m}=s,h=Math.min(Xu.origin.x,Zu.x),g=Math.max(Xu.origin.x,Zu.x),_=Math.min(Xu.origin.z,Zu.z),v=Math.max(Xu.origin.z,Zu.z);if(g<c.x||h>l.x||v<c.z||_>l.z)return;++s.mark===4294967295&&(m.fill(0),s.mark=1);let y=s.mark,b=e.material.side,x=o.attributes.position;for(let t=f(h,c.x,u);t<=f(g,c.x,u);t++)for(let s=f(_,c.z,d);s<=f(v,c.z,d);s++)for(let c of p[s*Ku+t]){if(m[c]===y)continue;m[c]=y;let t=rd(o,c,0),s=rd(o,c,1),l=rd(o,c,2);if(Qu.fromBufferAttribute(x,t),$u.fromBufferAttribute(x,s),ed.fromBufferAttribute(x,l),(b===1?Xu.intersectTriangle(ed,$u,Qu,!0,td):Xu.intersectTriangle(Qu,$u,ed,b===0,td))===null)continue;nd.copy(td).applyMatrix4(e.matrixWorld);let u=r.origin.distanceTo(nd);if(u<i||u>a)continue;let d=new R;ht.getNormal(Qu,$u,ed,d),n.push({distance:u,point:nd.clone(),object:e,face:{a:t,b:s,c:l,normal:d,materialIndex:0},faceIndex:c})}}function sd(e){let t=null;return e.isSkinnedMesh||(e.isInstancedMesh||e.isBatchedMesh?(e.boundingSphere===null&&e.computeBoundingSphere(),t=e.boundingSphere):e.geometry&&(e.geometry.boundingSphere===null&&e.geometry.computeBoundingSphere(),t=e.geometry.boundingSphere),!t)?null:Hu.copy(t).applyMatrix4(e.matrixWorld)}function cd({slack:e=4,maxAge:t=.5}={}){let n=[],r=new Set,i=new R,a=[],o=null,s=0,c=-1/0,l=!1,u=0;function d(e){if(e.length!==a.length)return!1;for(let t=0;t<e.length;t++)if(e[t]!==a[t])return!1;return!0}function f(e){let t=new Set;for(let n of e){let e=n;for(;e.parent;)e=e.parent;t.add(e)}for(let e of t)e.updateMatrixWorld()}function p(t,p,m,h){(!l||!d(t))&&f(t),n.length=0,r.clear(),s=Math.max(s,m);let g=s+e,_=e=>{if(e.raycast===Uu)return;let t=sd(e);t&&t.center.distanceTo(p)-t.radius>g||(e.isMesh&&!e.isSkinnedMesh&&e.geometry.boundingBox===null&&e.geometry.computeBoundingBox(),n.push(ad(e)??e))},v=e=>{if(!(e===h||r.has(e))){r.add(e),_(e);for(let t of e.children)v(t)}};for(let e of t)v(e);a=t.slice(),o=h,i.copy(p),c=performance.now(),l=!0,u++}function m(r,a,u,f=null){let m=Array.isArray(r)?r:[r];return(!l||u>s||!d(m)||f!==o||a.distanceToSquared(i)>(e/2)**2||performance.now()-c>t*1e3)&&p(m,a,u,f),n}function h(){l=!1}return{get:m,invalidate:h,get version(){return u}}}var ld=1.2,ud=1.5,dd=.25,fd=.92,pd=.12,md=2.35,hd=.12,gd=4,_d=.0025,vd=-.35,yd=.6;function bd(e,t){let n=e;for(;n;){if(n===t)return!0;n=n.parent}return!1}function xd(e,t){let n=0,r=.25,i=!0,a=new Set;function o(e){if(!i||document.pointerLockElement!==t)return;let a=_d*Y.get(`mouseSensitivity`),o=Y.get(`invertY`)?-e.movementY:e.movementY;n-=e.movementX*a,r=B.clamp(r-o*a,vd,yd)}function s(){i&&l()}function c(){if(i&&document.pointerLockElement!==t)for(let e of a)e()}function l(){let e=t.requestPointerLock();e&&typeof e.catch==`function`&&e.catch(()=>{})}t.addEventListener(`click`,s),document.addEventListener(`mousemove`,o),document.addEventListener(`pointerlockchange`,c);let u=new R,d=new R,f=new R,p=new we,m=cd(),h=Y.get(`cameraDistance`),g=!1;function _(t,i,a,o={}){let s=!!o.crouching&&!!i?.userData?.tightCrouchCamera,c=s?fd:ud,l=s?pd:ld,_=s?hd:dd;u.set(i.position.x,i.position.y+c,i.position.z);let v=s?Math.min(Y.get(`cameraDistance`),md):Y.get(`cameraDistance`);if(!g)d.copy(u),h=v,g=!0;else{let e=1-.84**(t*60);d.lerp(u,e)}let y=Math.cos(r);f.set(-Math.sin(n)*y,Math.sin(r),-Math.cos(n)*y);let b=v;if(a){p.set(d,f),p.far=v;let e=m.get(a,d,v,i),t=p.intersectObjects(e,!1);for(let e of t){if(bd(e.object,i)||e.object.userData.noCameraCollision)continue;let t=e.object.userData.cameraClearance;if(typeof t==`number`){let n=Math.min(t,e.distance*.55);b=Math.min(v,Math.max(.35,e.distance-n))}else b=Math.max(l,e.distance-_);break}}b<h?h=b:h+=(b-h)*Math.min(1,t*gd),e.position.copy(d).addScaledVector(f,h),e.lookAt(d)}function v(){g=!1,m.invalidate()}function y(e){typeof e==`number`&&(n=e)}function b(e){r=typeof e==`number`?B.clamp(e,vd,yd):.25}function x(e){i=e,!e&&document.pointerLockElement===t&&document.exitPointerLock()}function S(e){return a.add(e),()=>a.delete(e)}function C(){t.removeEventListener(`click`,s),document.removeEventListener(`mousemove`,o),document.removeEventListener(`pointerlockchange`,c),a.clear()}return{update:_,snap:v,setYaw:y,setPitch:b,setEnabled:x,onLockLost:S,requestLock:l,dispose:C,getYaw:()=>n,getPitch:()=>r,get isEnabled(){return i}}}var Sd=1.62,Cd=1.08,wd=12;function Td(e){let t=new R,n=new R,r=new R,i=Sd,a=!1;function o(o,s,{yaw:c=0,pitch:l=0,crouching:u=!1}={}){if(!s)return;let d=u?Cd:Sd;a?i+=(d-i)*Math.min(1,o*wd):(i=d,a=!0),t.set(s.position.x,s.position.y+i,s.position.z),e.position.copy(t);let f=Math.cos(l);n.set(Math.sin(c)*f,-Math.sin(l),Math.cos(c)*f),r.copy(e.position).add(n),e.lookAt(r)}function s(e=!1){i=e?Cd:Sd,a=!1}return{update:o,snap:s}}function Ed(e,t,n){e.position.set(t.x+18+Math.min(n,3)*.5,9,t.z-15),e.lookAt(t.x,0,t.z-13)}var Dd={THIRD:`third`,FIRST:`first`};function Od({camera:e,domElement:t,player:n,hud:r}){let i=xd(e,t),a=Td(e),o=Dd.THIRD,s=!1;function c(e,{announce:t=!0}={}){(e===Dd.FIRST||e===Dd.THIRD)&&o!==e&&(o=e,o===Dd.FIRST?(n.mesh.visible=!1,a.snap(s),t&&r&&r.showToast(`FIRST-PERSON VIEW`,900)):(n.mesh.visible=!0,i.snap(),t&&r&&r.showToast(`THIRD-PERSON VIEW`,900)))}function l(){c(o===Dd.THIRD?Dd.FIRST:Dd.THIRD)}function u(e,t,n,r={}){s=!!r.crouching,o===Dd.FIRST?a.update(e,t,{yaw:i.getYaw(),pitch:i.getPitch(),crouching:s}):i.update(e,t,n,{crouching:s})}function d(){n.mesh.visible=o!==Dd.FIRST,i.snap(),a.snap(s)}function f(){c(Dd.THIRD,{announce:!1})}return{update:u,showWreckStop(t,r){n.mesh.visible=!0,Ed(e,t,r)},snap:d,reset:f,toggle:l,setMode:c,getMode:()=>o,setYaw:e=>i.setYaw(e),setPitch:e=>i.setPitch(e),getYaw:()=>i.getYaw(),getPitch:()=>i.getPitch(),setEnabled:e=>i.setEnabled(e),requestLock:()=>i.requestLock(),onLockLost:e=>i.onLockLost(e),dispose:()=>i.dispose()}}var kd=3,Ad=1.8,jd=1.1,Md=.35,Nd=.08,Pd=1e-7,Fd=3816004,Id=1.8;function Ld(e,t){let n=e;for(;n;){if(n===t)return!0;n=n.parent}return!1}function Rd(e){let t=e;for(;t;){if(!t.visible)return!1;t=t.parent}return!0}function zd(e){let t=e;for(;t;){if(t.userData?.interactionCollider)return!0;t=t.parent}return!1}function Bd(e){let t=e;for(;t;){if(t.userData?.noInteractionBlocker)return!0;t=t.parent}if(e.isPoints||e.isSprite||e.isLine)return!0;let n=Array.isArray(e.material)?e.material:e.material?[e.material]:[];return n.length>0&&n.every(e=>e.transparent&&(e.depthWrite===!1||e.opacity<.35))}function Vd(){let e=document.createElement(`div`);return e.id=`interaction-prompt`,Object.assign(e.style,{position:`fixed`,left:`50%`,bottom:`18%`,transform:`translateX(-50%)`,padding:`8px 14px`,font:`600 15px/1 system-ui, sans-serif`,color:`#fff`,background:`rgba(0, 0, 0, 0.55)`,border:`1px solid rgba(255, 255, 255, 0.25)`,borderRadius:`6px`,letterSpacing:`0.02em`,pointerEvents:`none`,userSelect:`none`,opacity:`0`,transition:`opacity 120ms ease-out`,zIndex:`10`}),document.body.appendChild(e),e}function Hd({camera:e,input:t}={}){let n=new Map,r=new Set,i=new R,a=new R,o=new R,s=new R,c=new R,l=new we,u=cd(),d=-1,f=Vd(),p=null,m=!0,h=0,g=null,_;function v(e,{prompt:t,onInteract:r,range:i=kd,verticalTolerance:a=Ad,isEligible:o,selectionMode:s=`forgiving`,aimMin:c=.72,onFocusChange:l}={}){if(!e||typeof r!=`function`)throw Error(`register(object, { prompt, onInteract }) requires an object and an onInteract callback`);let u={object:e,label:t??`Interact`,onInteract:r,range:i,verticalTolerance:a,isEligible:o,selectionMode:s,aimMin:c,onFocusChange:l};return n.set(e,u),function(){n.delete(e),p&&p.object===e&&S(null)}}function y(e){if(!e?.isObject3D)throw Error(`registerBlocker(object) requires a Three.js Object3D`);return r.add(e),function(){r.delete(e)}}function b(e,t){if(t){if(e.focusBases)return;let t=new Map;e.object.traverse(e=>{let n=e.material;if(!n||!n.emissive||t.has(n))return;let r={hex:n.emissive.getHex(),intensity:n.emissiveIntensity};t.set(n,r),r.hex===0?(n.emissive.setHex(Fd),n.emissiveIntensity=1):n.emissiveIntensity=r.intensity*Id}),e.focusBases=t}else if(e.focusBases){for(let[t,n]of e.focusBases)t.emissive.setHex(n.hex),t.emissiveIntensity=n.intensity;e.focusBases=null}}function x(){performance.now()<h||(p?(f.textContent=`${ja(Y.getBinding(`interact`))} — ${p.label}`,f.style.opacity=`1`):f.style.opacity=`0`)}function S(e){p!==e&&(p&&(b(p,!1),p.onFocusChange?.(!1)),p=e,p&&(b(p,!0),p.onFocusChange?.(!0))),x()}function C(e,t=1200){h=performance.now()+t,f.textContent=e,f.style.opacity=`1`}function w(t){let n,r;if(typeof t==`number`)n=Math.sin(t),r=Math.cos(t);else if(e){e.getWorldDirection(o);let t=Math.hypot(o.x,o.z)||1;n=o.x/t,r=o.z/t}else n=0,r=1;return{forwardX:n,forwardZ:r}}function T(e){if(r.size===0)return!0;s.copy(i),s.y+=jd,c.subVectors(a,s);let t=c.length();if(t<=Pd)return!0;c.multiplyScalar(1/t),l.set(s,c),l.far=Math.max(0,t-Nd);let n=u.get(Array.from(r),s,t);if(d!==u.version){for(let e of n)e.updateWorldMatrix(!0,!1);d=u.version}let o=l.intersectObjects(n,!1);for(let t of o)if(!Ld(t.object,e.object)&&!(!Rd(t.object)&&!zd(t.object))&&!Bd(t.object))return!1;return!0}function E(t,r){if(!m||n.size===0||!t)return null;t.getWorldPosition(i),d=-1;let{forwardX:l,forwardZ:u}=w(r);e&&e.getWorldDirection(o).normalize();let f=null,p=1/0;for(let r of n.values()){if(!r.object.parent||!Rd(r.object)||r.isEligible&&!r.isEligible({player:t,object:r.object}))continue;r.object.getWorldPosition(a);let n=a.x-i.x,d=a.z-i.z,m=Math.hypot(n,d);if(m>r.range||Math.abs(a.y-i.y)>r.verticalTolerance)continue;let h=m>1e-4?(n*l+d*u)/m:1;if(h<Md)continue;let g;if(r.selectionMode===`aim`&&e){s.copy(e.position),c.subVectors(a,s);let t=c.length();if(t<=Pd)continue;c.multiplyScalar(1/t);let n=o.dot(c);if(n<r.aimMin)continue;g=(1-n)*16+m*.035}else g=m-h;T(r)&&g<p&&(p=g,f=r)}return f}function D(e,t){g=e??null,_=t,S(E(g,_))}function O(){if(!m||!g||(S(E(g,_)),!p))return!1;let e=p;return e.onInteract({object:e.object,entry:e,player:g}),!0}let k=t?t.onAction(`interact`,()=>O()):null;function A(e){m=e,e||S(null)}function j(){k&&k(),p&&(b(p,!1),p.onFocusChange?.(!1)),f.remove(),n.clear(),r.clear(),p=null,g=null}return{register:v,registerBlocker:y,update:D,interact:O,flashPrompt:C,setEnabled:A,dispose:j,getFocused:()=>p&&p.object}}var Ud=-8,Wd=900,Gd=1450,Kd=3;function qd({player:e,hud:t,camera:n,timeSystem:r,onStateChange:i,setControlsEnabled:a}){let o=null,s=new Set,c=!1,l=!1,u=null,d=null,f=0,p=Kd,m=null,h=!1;function g(){t?.setLives?.(p,Kd)}function _(e,t=0,{restore:n=()=>{}}={}){o={position:new R().copy(e),yaw:t,restore:n,timeState:r?.captureCheckpointState?.()}}function v(){if(!o)return!1;e.setPose(o.position,o.yaw);try{o.restore?.()}catch(e){console.error(`respawn: level checkpoint cleanup failed after player was restored`,e)}try{r?.resetForCheckpoint?.(o.timeState)}catch(e){console.error(`respawn: time checkpoint cleanup failed after player was restored`,e)}return n?.setYaw?.(o.yaw),n?.snap?.(),!0}function y(){f+=1,d!==null&&clearTimeout(d),d=null}function b(){y(),c=!1,u=null,h=!1,t?.hideCaughtScreen?.(),a&&a(!0),i?.()}function x(){b(),o=null,l=!1}function S(e){if(e!==f||l||!c)return;d=null;let n=u;if(k()){for(let t of s)if(t(n,{lives:p,gameOver:!0}),e!==f)return;t?.hideCaughtScreen?.(),c=!1,u=null,h=!1,a&&a(!0),i?.(),m?.({reason:n});return}if(!v()){b();return}c=!1,u=null,h=!1,t?.hideCaughtScreen?.(),a&&a(!0);for(let t of s)if(t(n,{lives:p,gameOver:!1}),e!==f)return;i?.()}function C(){if(!c||l)return;let e=f;t?.showCaughtScreen?.(u,{lives:p,maxLives:Kd,gameOver:k()});let n=k()?Gd:Wd;d=setTimeout(()=>S(e),n)}function w(e=Kd){p=Math.max(1,Math.floor(e||Kd)),g()}function T(e=`caught`){return c||l||!o?!1:(c=!0,u=e,p=Math.max(0,p-1),h=p<=0,g(),a&&a(!1),i?.(),C(),!0)}function E(e){l!==e&&(l=e,c&&(y(),l?t?.hideCaughtScreen?.():C(),i?.()))}function D(e){return s.add(e),()=>{s.delete(e)}}function O(e){m=typeof e==`function`?e:null}function k(){return h&&!!m}function A(){e.mesh.position.y<Ud&&T(`fell`)}function j(){x(),s.clear(),m=null}return g(),{setCheckpoint:_,fail:T,onFail:D,respawn:v,cancel:b,reset:x,setPaused:E,resetLives:w,setGameOverHandler:O,getLives:()=>p,getMaxLives:()=>Kd,update:A,dispose:j,isFailing:()=>c}}function Jd(e){if(!e)return;let t=new Set,n=new Set,r=new Set,i=new Set;function a(e){if(e?.isTexture&&!r.has(e)){if(r.add(e),e.userData?.sharedTexture)return;e.dispose()}else Array.isArray(e)&&e.forEach(a)}function o(e){!e||n.has(e)||(n.add(e),Object.values(e).forEach(a),Object.values(e.uniforms??{}).forEach(e=>a(e.value)),e.dispose())}function s(e){if(i.has(e))return;i.add(e),e.geometry&&!t.has(e.geometry)&&(t.add(e.geometry),e.geometry.dispose());let n=e.material;Array.isArray(n)?n.forEach(o):n&&o(n),e.isInstancedMesh&&typeof e.dispose==`function`&&e.dispose(),e.skeleton?.boneTexture&&e.skeleton.dispose(),e.isLight&&typeof e.dispose==`function`&&e.dispose()}for(let t of Array.isArray(e)?e:[e])t?.traverse(s)}var Yd={coat:3718648,trousers:959977,leather:165063,skin:8246268,hat:223649,accent:14742270,cap:`flat`},Xd=.72,Zd=.035,Qd=8;function $d(){let{group:e,body:t,leftArm:n,rightArm:r,leftLeg:i,rightLeg:a}=ul(Yd),o=t.position.y;e.name=`time-ghost`;let s=[];e.traverse(e=>{if(e.isMesh){e.castShadow=!1,e.receiveShadow=!1;let t=e.material,n=new x({color:t?t.color:3718648,emissive:54527,emissiveIntensity:2.2,roughness:.2,metalness:.1,transparent:!0,opacity:.62,wireframe:!1,depthWrite:!1});e.material=n,s.push(n)}});let c=new M(.35,.55,32);c.rotateX(-Math.PI/2);let l=new dt({color:3718648,transparent:!0,opacity:.7,side:2}),u=new z(c,l);u.position.y=.03,e.add(u);let d=new j(61695,3,4);d.position.y=1.2,e.add(d);let f=[],p=0,m=!1,h=null,g=null,_=0;function v(t,{onTrigger:n,onComplete:r}={}){if(!t||t.length<2){r&&r();return}f=t,p=0,m=!0,g=n||null,h=r||null;let i=f[0];e.position.copy(i.position),e.rotation.y=i.rotationY,e.visible=!0}function y(t,n,r){if(!t||!r)return;let i=e.visible;e.visible=!0,t.compile(n,r),e.visible=i}function b(){let e=h;S(),e&&e()}function S(){m=!1,e.visible=!1,f=[],p=0,h=null,g=null,_=0,u.rotation.y=0}function C(s){_+=s,u.rotation.y+=s*2.5;let c=.5+Math.sin(_*8)*.25;if(l.opacity=c,d.intensity=2.5+Math.sin(_*12)*1,!m||f.length<2)return;p+=s;let h=f[f.length-1].time-f[0].time;if(p>=Math.max(0,h)){let s=f[f.length-1];e.position.copy(s.position),e.rotation.y=s.rotationY,i.rotation.x=a.rotation.x=0,n.rotation.x=r.rotation.x=0,t.position.y=o,g&&g(e.position),p>=Math.max(0,h)+Qd&&b();return}let v=f[0].time+p,y=0;for(;y<f.length-1&&f[y+1].time<v;)y++;let x=f[y],S=f[Math.min(y+1,f.length-1)],C=Math.max(1e-4,S.time-x.time),w=Math.min(1,Math.max(0,(v-x.time)/C));e.position.lerpVectors(x.position,S.position,w);let T=S.rotationY-x.rotationY;for(;T>Math.PI;)T-=Math.PI*2;for(;T<-Math.PI;)T+=Math.PI*2;e.rotation.y=x.rotationY+T*w;let E=x.stridePhase===void 0?0:x.stridePhase,D=Math.sin(E)*Xd;i.rotation.x=D,a.rotation.x=-D,n.rotation.x=-D*.8,r.rotation.x=D*.8,t.position.y=o+Math.abs(Math.sin(E))*Zd,g&&g(e.position)}function w(t,n=1){if(!m||Math.abs(e.position.y-t.y)>.25)return!1;let r=e.position.x-t.x,i=e.position.z-t.z;return Math.abs(r)<n&&Math.abs(i)<n}function T(){S(),Jd(e)}return e.visible=!1,{mesh:e,startReplay:v,stop:b,warm:y,cancel:S,update:C,isOccupying:w,isPlaying:()=>m,getRemainingSeconds:()=>!m||f.length<2?0:Math.max(0,Math.max(0,f[f.length-1].time-f[0].time)+Qd-p),getPosition:()=>e.position,dispose:T}}var ef={NORMAL:`NORMAL`,SLOW:`SLOW`,FREEZE:`FREEZE`,REWIND:`REWIND`},tf=100,nf=50,rf=15,af={SLOW:18,FREEZE:28,REWIND:32,GHOST:1.5},of=35,sf=5,cf=100,lf={SLOW:0,FREEZE:34,REWIND:8},uf=14,df=13,ff=8,pf=.05,mf=2.5,hf=10,gf=Object.freeze({SLOW:!0,FREEZE:!0,REWIND:!0,GHOST:!0});function _f({scene:e,player:t,hud:n,onTimeScale:r}){let i=ef.NORMAL,a=tf,o=$d(),s=gf;e.add(o.mesh);let c=[],l=new Set,u=new Set,d=0,f=0,p=0,m=0,h=0,g=!1,_=0,v=1,y={uTime:{value:0},uTimeScale:{value:1},uTimeMode:{value:0},uMode:{value:0},uIntensity:{value:0},uTimeDistortionIntensity:{value:0}};function b(e){let t=i;if(i===e)i=ef.NORMAL;else{if(e!==ef.NORMAL&&!s[e]){n&&n.showToast(`That chrono ability is offline`,1200);return}if(e!==ef.NORMAL&&a<10){n&&n.showToast(`Chrono Core energy depleted!`,1200);return}if(e===ef.FREEZE&&_>0){n&&n.showToast(`Chrono Interface overheated — FREEZE offline for ${_.toFixed(1)}s`,1400);return}i=e,g&&i===ef.FREEZE&&(h=Math.min(cf,h+uf))}i!==t&&(p=0),l.forEach(e=>{e.options.onSlow&&e.options.onSlow(i===ef.SLOW),e.options.onFreeze&&e.options.onFreeze(i===ef.FREEZE),e.options.onRewind&&e.options.onRewind(i===ef.REWIND)}),A(),S()}function x(){return i===ef.SLOW?.2:i===ef.FREEZE||i===ef.REWIND?0:o.isPlaying()?.55:1}function S(){r&&r(x())}function C(e){g=!!e,g||(h=0,_=0)}function w(e){v=e||1,A()}function T(e={}){s=Object.freeze({...gf,...e}),i!==ef.NORMAL&&!s[i]&&b(ef.NORMAL)}function E(){return s}function D(){o.cancel(),c.length=0,m=0,S()}function O(e,t){let n={center:e,halfSize:t};return u.add(n),()=>u.delete(n)}function k(){if(o.isPlaying()){o.stop();return}if(!s.GHOST){n&&n.showToast(`Time Ghost is offline`,1200);return}if(m>0){n&&n.showToast(`Time Ghost on cooldown!`,1e3);return}if(a<of){n&&n.showToast(`Not enough Chrono energy for Time Ghost!`,1200);return}let e=[...u].some(({center:e,halfSize:n})=>{let r=t.mesh.position;return Math.abs(r.y-e.y)<.25&&Math.abs(r.x-e.x)<n&&Math.abs(r.z-e.z)<n});if(!e&&c.length<5){n&&n.showToast(`Recording movement trajectory… try again in 1s`,1e3);return}a-=of,m=4;let r=e?[0,.001].map(e=>({time:e,position:t.mesh.position.clone(),rotationY:t.mesh.rotation.y,stridePhase:0})):c.map(e=>({time:e.time,position:e.position.clone(),rotationY:e.rotationY,stridePhase:e.stridePhase}));r.push({...r[r.length-1],time:r[r.length-1].time+.001,position:t.mesh.position.clone(),rotationY:t.mesh.rotation.y}),o.startReplay(r,{onComplete:()=>{S(),n&&n.showToast(`Time Ghost faded`,1e3)}}),S(),Xc(`GHOST`),t.playCast?.(),n&&n.showToast(e?`Ghost holding pad — move ahead! (8 seconds)`:`Time Ghost summoned!`,1800)}function A(){let e=1,t=0,n=0;switch(i){case ef.SLOW:e=.2,t=1,n=.5*v;break;case ef.FREEZE:e=0,t=2,n=.8*v;break;case ef.REWIND:e=-2.5,t=3,n=1*v;break;default:e=1,t=0,n=0}y.uTimeScale.value=e,y.uTimeMode.value=t,y.uMode.value=t,y.uIntensity.value=n,y.uTimeDistortionIntensity.value=n}function j(e,t={}){let n={object:e,options:t,snapshots:[]},r=ee(n);return r&&n.snapshots.push(r),l.add(n),function(){l.delete(n)}}function ee(e){return e.options.getSnapshot?e.options.getSnapshot():e.object?{position:e.object.position.clone(),rotation:e.object.rotation.clone()}:null}function M(e,r=performance.now()/1e3){if(y.uTime.value+=e,d+=e,m>0&&(m=Math.max(0,m-e)),g){_>0&&(_=Math.max(0,_-e),_===0&&n&&n.showToast(`Chrono Interface re-synchronised — FREEZE online`,1600));let t=lf[i]||0;t>0?(h=Math.min(cf,h+t*e),h>=cf&&i===ef.FREEZE&&(_=ff,b(ef.NORMAL),n&&n.showToast(`CHRONO INTERFACE OVERHEATED — FREEZE offline`,2400))):h=Math.max(0,h-df*e)}let s=o.isPlaying()?af.GHOST:0;if(i===ef.NORMAL&&s===0)a=Math.min(tf,a+rf*e);else if(i!==ef.REWIND){let t=((i===ef.NORMAL?0:af[i]||20)+s)*e;a-=t,a<=0&&(a=0,b(ef.NORMAL),o.isPlaying()&&o.stop(),n&&n.showToast(`Chrono energy depleted — time normalized`,1500))}if(t&&t.mesh){c.push({time:d,position:t.mesh.position.clone(),rotationY:t.mesh.rotation.y,stridePhase:d*4});let e=d-sf;for(;c.length>0&&c[0].time<e;)c.shift()}let u=1;if(i===ef.SLOW?u=.2:i===ef.FREEZE?u=0:i===ef.REWIND&&(u=-2.5),o.update(e),i===ef.REWIND){f=0;let t=!1,r=0;for(let e of l){let n=e.snapshots.length;n===0&&e.options.onUpdate&&(t=!0),r=Math.max(r,(n-1)*pf)}let i=t?1/0:Math.max(0,r-p)/mf,s=o.isPlaying()?af.GHOST:0,c=af.REWIND+s,d=Math.min(e,a/c,i);a=Math.max(0,a-d*c),p+=d*mf;let m=Math.floor((p+1e-9)/pf);p-=m*pf,l.forEach(e=>{if(e.snapshots.length>0)for(let t=0;t<m;t++){e.snapshots.length>1&&e.snapshots.pop();let t=e.snapshots[e.snapshots.length-1];e.options.restoreSnapshot?e.options.restoreSnapshot(t):e.object&&(t.position&&e.object.position.copy(t.position),t.rotation&&e.object.rotation.copy(t.rotation))}else e.options.onUpdate&&e.options.onUpdate(-d*mf,u,d)}),a<=1e-9?(a=0,b(ef.NORMAL),o.isPlaying()&&o.stop(),n?.showToast(`Chrono energy depleted — time normalized`,1500)):i<=e+1e-9&&(b(ef.NORMAL),n?.showToast(`Rewind history exhausted`,1200))}else{let t=e;for(;t>1e-9;){let e=Math.min(t,pf-f);f+=e,t-=e;let n=f>=.049999999;l.forEach(t=>{let r=!t.options.recordWhen||u>0&&t.options.recordWhen();if(t.options.onUpdate?.(e*u,u,e),n&&r){let e=ee(t);if(e){t.snapshots.push(e);let n=Math.round(hf/pf);t.snapshots.length>n&&t.snapshots.splice(+!!t.options.recordWhen,1)}}}),n&&(f=0)}}A()}function N(){b(ef.NORMAL),o.cancel(),S(),m=0,c.length=0,d=0,f=0,p=0,y.uTime.value=0}function P(){l.forEach(e=>{e.snapshots?.splice?.(0),e.accumulator=0,e.options?.onSlow?.(!1),e.options?.onFreeze?.(!1),e.options?.onRewind?.(!1)})}function te({preserveEnergy:e=!1}={}){N(),P(),l.clear(),u.clear(),C(!1),v=1,s=gf,a=e?Math.max(a,nf):tf,A()}function F(){te({preserveEnergy:!1})}function ne(){F()}function re(){return{energy:a,availability:{...s},levelMultiplier:v}}function I(e=re()){N(),h=0,_=0,a=Math.max(e?.energy??a,nf),s=Object.freeze(e?.availability?{...e.availability}:{...s}),v=e?.levelMultiplier??v;for(let e of l){e.snapshots?.splice?.(0),e.accumulator=0;let t=ee(e);t&&e.snapshots.push(t)}A()}function L(){F(),o&&(e.remove(o.mesh),o.dispose())}return{register:j,registerGhostPad:O,setMode:b,setLevelMultiplier:w,setAbilityAvailability:T,getAbilityAvailability:E,setStrainEnabled:C,resetRun:ne,resetForLevel:te,resetForRun:F,resetForCheckpoint:I,captureCheckpointState:re,triggerSlow:()=>b(ef.SLOW),triggerFreeze:()=>b(ef.FREEZE),triggerRewind:()=>b(ef.REWIND),triggerGhost:k,resetGhost:D,getMode:()=>i,getEnergy:()=>a,getMaxEnergy:()=>tf,getGhostCooldown:()=>m,getStrain:()=>h,getMaxStrain:()=>cf,isStrainEnabled:()=>g,getFreezeLockout:()=>_,getGhost:()=>o,getUniforms:()=>y,warmGhost(t,n){o&&o.warm&&o.warm(t,e,n)},update:M,dispose:L}}var vf={"menu-theme.mp3":new URL(``+new URL(`menu-theme-HHrRKJoS.mp3`,import.meta.url).href,``+import.meta.url),"level1-constance.mp3":new URL(``+new URL(`level1-constance-Cst5FbKW.mp3`,import.meta.url).href,``+import.meta.url),"level2-mistake-the-getaway.mp3":new URL(``+new URL(`level2-mistake-the-getaway-PGGBHhs7.mp3`,import.meta.url).href,``+import.meta.url),"level3-final-count.mp3":new URL(``+new URL(`level3-final-count-Cc1UD0t7.mp3`,import.meta.url).href,``+import.meta.url),"victory-theme.mp3":new URL(``+new URL(`victory-theme-BJlpihkx.mp3`,import.meta.url).href,``+import.meta.url)};function yf(e){let t=vf[String(e).split(`/`).pop()];if(!t)throw Error(`[level-music] unknown track "${e}"`);return t}var bf=new Map,xf=new Map,Sf=1,Cf=0,wf=0;function Tf(){return`${new Date().toISOString()} t=${performance.now().toFixed(1)}`}function Ef(e,t){return new Promise((n,r)=>{let i=e.decodeAudioData(t,n,r);i&&typeof i.then==`function`&&i.then(n,r)})}function Df(e){let t=String(e);if(bf.has(t))return Promise.resolve(bf.get(t));if(xf.has(t))return xf.get(t);let n=Lc();if(!n)return Promise.reject(Error(`[level-music] initialize AudioContext before loading music`));let r=(async()=>{let r=await fetch(e);if(!r.ok)throw Error(`[level-music] failed to fetch ${e} (${r.status})`);let i=await Ef(n,await r.arrayBuffer());return bf.set(t,i),i})().finally(()=>{xf.get(t)===r&&xf.delete(t)});return xf.set(t,r),r}var Of=class{constructor(e){this.id=Sf++,this.url=e,this.buffer=null,this.source=null,this.gain=null,this._disposed=!1,Cf+=1,console.log(`[music ${Tf()}] LevelMusicPlayer#${this.id} CONSTRUCT livePlayers=${Cf} liveSources=${wf} url=${String(e)}`)}async load(){if(this._disposed)return null;if(this.buffer)return this.buffer;let e=await Df(this.url);return this._disposed||(this.buffer=e),e}async playWhenReady(e){this._disposed||(await this.load(),!this._disposed&&this.play(e))}play({loop:e=!0,volume:t=.5}={}){if(this._disposed||!this.buffer)return;this.stop();let n=Lc(),r=Rc();this.gain=n.createGain(),this.gain.gain.value=t,this.gain.connect(r),this.source=n.createBufferSource(),this.source.buffer=this.buffer,this.source.loop=e,this.source.connect(this.gain),this.source.start(),wf+=1,console.log(`[music ${Tf()}] LevelMusicPlayer#${this.id} SOURCE START livePlayers=${Cf} liveSources=${wf}`)}stop(){if(this.source){try{this.source.stop()}catch{}this.source.disconnect(),this.source=null,wf=Math.max(0,wf-1),console.log(`[music ${Tf()}] LevelMusicPlayer#${this.id} SOURCE STOP livePlayers=${Cf} liveSources=${wf}`)}this.gain&&=(this.gain.disconnect(),null)}dispose(){this._disposed||(this._disposed=!0,this.stop(),this.buffer=null,Cf=Math.max(0,Cf-1),console.log(`[music ${Tf()}] LevelMusicPlayer#${this.id} DISPOSE livePlayers=${Cf} liveSources=${wf}`))}},kf=null,Af=0;function jf(){Af+=1,console.log(`[music ${Tf()}] stopLevelMusic token=${Af} active=${kf?`#`+kf.id:`none`} livePlayers=${Cf}`),kf&&=(kf.dispose(),null)}async function Mf(e,t={}){let n=++Af;console.log(`[music ${Tf()}] startLevelMusic begin token=${n} url=${String(e)} prevActive=${kf?`#`+kf.id:`none`}`),kf&&=(kf.dispose(),null);let r=new Of(e);kf=r;try{await r.load()}catch(e){if(n!==Af||r._disposed){r.dispose(),kf===r&&(kf=null);return}console.error(e),r.dispose(),kf===r&&(kf=null);return}if(n!==Af||r._disposed){console.log(`[music ${Tf()}] startLevelMusic SKIP play LevelMusicPlayer#${r.id} myToken=${n} token=${Af} disposed=${r._disposed}`),r.dispose(),kf===r&&(kf=null);return}let i=Lc(),a=r.buffer;console.log(`[music ${Tf()}] startLevelMusic play LevelMusicPlayer#${r.id} context=${i?i.state:`none`} duration=${a?a.duration:`none`}`),r.play(t)}var Nf=.002,Pf=.18,Ff=.08,If=180,Lf=550,Rf=900,zf=1.2,Bf=.15,Vf=.14,Hf=.35,Uf=2;function Wf(e,t){let n=e.sampleRate,r=Math.floor(n*t),i=e.createBuffer(1,r,n),a=i.getChannelData(0),o=0,s=0,c=0,l=0,u=0,d=0,f=0;for(let e=0;e<r;e++){let t=Math.random()*2-1;o=.99886*o+t*.0555179,s=.99332*s+t*.0750759,c=.969*c+t*.153852,l=.8665*l+t*.3104856,u=.55*u+t*.5329522,d=-.7616*d-t*.016898,a[e]=(o+s+c+l+u+d+f+t*.5362)*.11,f=t*.115926}return i}var Gf=null,Kf=1,qf=0;function Jf(){return`${new Date().toISOString()} t=${performance.now().toFixed(1)}`}var Yf=class{constructor(){if(Gf)return console.log(`[music ${Jf()}] MusicSystem#${Gf.id} REUSE (constructor hit while live) liveDrones=${qf}`),Gf;Gf=this,this.id=Kf++,qf+=1,console.log(`[music ${Jf()}] MusicSystem#${this.id} CONSTRUCT liveDrones=${qf}`);let e=Lc(),t=Rc();console.log(`Master gain value: `+t.gain.value),this.output=e.createGain(),this.output.gain.value=Nf,this.output.connect(t),this.filter=e.createBiquadFilter(),this.filter.type=`bandpass`,this.filter.frequency.value=Lf,this.filter.Q.value=zf,this.filter.connect(this.output),this.noise=e.createBufferSource(),this.noise.buffer=Wf(e,Uf),this.noise.loop=!0,this.noise.connect(this.filter),this.noise.start(),console.log(`Noise whoosh started, buffer duration: `+this.noise.buffer.duration),this.lfo=e.createOscillator(),this.lfo.type=`sine`,this.lfo.frequency.value=Ff,this.lfoGain=e.createGain(),this.lfoGain.gain.value=If,this.lfo.connect(this.lfoGain),this.lfoGain.connect(this.filter.frequency),this.lfo.start(),console.log(`output gain: `+this.output.gain.value+`, master gain: `+Rc().gain.value),this._disposed=!1}setTimeDilation(e){if(this._disposed)return;let t=Math.min(1,Math.max(0,e)),n=Lc().currentTime,r=t<1?Pf:Nf;this.output.gain.setTargetAtTime(r,n,Vf),this.noise.playbackRate.setTargetAtTime(Hf+t*.65,n,Bf)}setIntensity(e){if(this._disposed)return;let t=Lf+Math.min(1,Math.max(0,e))*Rf;this.filter.frequency.setTargetAtTime(t,Lc().currentTime,Bf)}dispose(){if(this._disposed)return;this._disposed=!0;let e=Lc();if(e&&this.output.gain.setValueAtTime(0,e.currentTime),this.noise){try{this.noise.stop()}catch{}this.noise.disconnect(),this.noise=null}this.lfo.stop(),this.lfo.disconnect(),this.lfoGain.disconnect(),this.filter.disconnect(),this.output.disconnect(),Gf===this&&(Gf=null),qf=Math.max(0,qf-1),console.log(`[music ${Jf()}] MusicSystem#${this.id} DISPOSE liveDrones=${qf}`)}};function Xf(e){let t=document.createElement(`button`);t.type=`button`,t.textContent=`Skip finale`,Object.assign(t.style,{position:`absolute`,right:`24px`,bottom:`24px`,padding:`10px 18px`,color:`#f0e6cf`,background:`#111820`,border:`1px solid #b08d3f`,borderRadius:`4px`,font:`inherit`,cursor:`pointer`,pointerEvents:`auto`,display:`none`}),e.appendChild(t);let n=null;function r(){n=null,t.style.display=`none`,document.activeElement===t&&t.blur()}function i(){let e=n;r(),e?.()}return t.addEventListener(`click`,i),{show(e){n=e,t.style.display=`block`,t.focus({preventScroll:!0})},hide:r,dispose(){r(),t.removeEventListener(`click`,i),t.remove()}}}function Zf(){let e=document.createElement(`div`);e.id=`hud`;let t=Xf(e);Object.assign(e.style,{position:`fixed`,inset:`0`,pointerEvents:`none`,userSelect:`none`,font:`600 14px/1.4 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif`,color:`#fff`,zIndex:`5`,overflow:`hidden`});let n=document.createElement(`div`);Object.assign(n.style,{position:`absolute`,inset:`0`,boxShadow:`inset 0 0 90px rgba(0, 212, 255, 0)`,pointerEvents:`none`,transition:`box-shadow 250ms ease, background 250ms ease`}),e.appendChild(n);let r=document.createElement(`div`);Object.assign(r.style,{position:`absolute`,top:`18px`,left:`50%`,transform:`translateX(-50%)`,padding:`7px 20px`,maxWidth:`85vw`,textAlign:`center`,background:`rgba(10, 14, 24, 0.75)`,border:`1px solid rgba(80, 160, 255, 0.25)`,backdropFilter:`blur(8px)`,borderRadius:`6px`,textShadow:`0 1px 4px rgba(0, 0, 0, 0.8)`,letterSpacing:`0.4px`,opacity:`0`,transition:`opacity 200ms ease-out`});let i=document.createElement(`div`);Object.assign(i.style,{position:`absolute`,top:`68px`,left:`50%`,transform:`translateX(-50%)`,padding:`7px 16px`,background:`rgba(20, 10, 15, 0.85)`,border:`1px solid rgba(255, 80, 100, 0.4)`,borderRadius:`4px`,backdropFilter:`blur(6px)`,boxShadow:`0 4px 14px rgba(0, 0, 0, 0.4)`,opacity:`0`,transition:`opacity 160ms ease-out`});let a=document.createElement(`div`);Object.assign(a.style,{position:`absolute`,left:`20px`,top:`56px`,maxWidth:`min(400px, 40vw)`,padding:`10px 14px`,background:`rgba(10, 14, 24, 0.82)`,border:`1px solid rgba(80, 160, 255, 0.28)`,borderLeft:`3px solid #38bdf8`,borderRadius:`5px`,backdropFilter:`blur(8px)`,boxShadow:`0 6px 20px rgba(0, 0, 0, 0.45)`,opacity:`0`,transform:`translateY(-6px)`,transition:`opacity 260ms ease-out, transform 260ms ease-out`,pointerEvents:`none`});let o=document.createElement(`div`);Object.assign(o.style,{fontSize:`10px`,letterSpacing:`1.4px`,textTransform:`uppercase`,color:`#38bdf8`,fontWeight:`700`,marginBottom:`3px`});let s=document.createElement(`div`);Object.assign(s.style,{fontSize:`13px`,lineHeight:`1.45`,color:`#e2e8f0`,textShadow:`0 1px 4px rgba(0, 0, 0, 0.8)`}),a.append(o,s);let c=[],l=null;function u(){a.style.opacity=`0`,a.style.transform=`translateY(-6px)`}function d(){if(c.length===0){u(),l=null;return}let e=c.shift();s.textContent=e,a.style.opacity=`1`,a.style.transform=`translateY(0)`;let t=Math.min(7e3,Math.max(2600,1400+e.length*48));l=setTimeout(d,t)}function f(e,{speaker:t=`HANDLER`}={}){clearTimeout(l),c=(Array.isArray(e)?e:[e]).filter(Boolean),o.textContent=t,d()}function p(){clearTimeout(l),l=null,c=[],u()}let m=document.createElement(`div`);Object.assign(m.style,{position:`absolute`,top:`18px`,left:`24px`,display:`flex`,alignItems:`center`,gap:`10px`,padding:`8px 12px`,background:`rgba(15, 23, 42, 0.82)`,border:`1px solid rgba(239, 68, 68, 0.32)`,borderRadius:`6px`,backdropFilter:`blur(6px)`});let h=document.createElement(`span`);h.textContent=`LIVES`,Object.assign(h.style,{fontSize:`11px`,fontWeight:`800`,letterSpacing:`1.1px`,color:`#fca5a5`});let g=document.createElement(`div`);Object.assign(g.style,{display:`flex`,gap:`6px`}),m.append(h,g),e.appendChild(m);function _(e=3,t=3){g.replaceChildren();for(let n=0;n<t;n++){let t=document.createElement(`span`);Object.assign(t.style,{width:`11px`,height:`11px`,display:`block`,transform:`rotate(45deg)`,borderRadius:`2px`,border:`1px solid rgba(252, 165, 165, 0.9)`,background:n<e?`#ef4444`:`rgba(239, 68, 68, 0.12)`,boxShadow:n<e?`0 0 8px rgba(239, 68, 68, 0.65)`:`none`}),g.appendChild(t)}}_(3,3);let v=document.createElement(`div`);Object.assign(v.style,{position:`absolute`,top:`18px`,right:`24px`,display:`flex`,flexDirection:`column`,alignItems:`flex-end`,gap:`4px`,padding:`8px 14px`,background:`rgba(15, 23, 42, 0.85)`,border:`1px solid rgba(245, 158, 11, 0.3)`,borderRadius:`6px`,backdropFilter:`blur(6px)`,opacity:`0`,transform:`translateY(-10px)`,transition:`opacity 200ms ease, transform 200ms ease`});let y=document.createElement(`div`);Object.assign(y.style,{display:`flex`,justifyContent:`space-between`,width:`140px`,fontSize:`11px`,fontWeight:`700`,letterSpacing:`0.8px`,color:`#f59e0b`});let b=document.createElement(`span`);b.textContent=`SUSPICION`;let x=document.createElement(`span`);x.textContent=`0%`,y.append(b,x);let S=document.createElement(`div`);Object.assign(S.style,{width:`140px`,height:`6px`,background:`rgba(255, 255, 255, 0.1)`,borderRadius:`3px`,overflow:`hidden`});let C=document.createElement(`div`);Object.assign(C.style,{height:`100%`,width:`0%`,background:`linear-gradient(90deg, #f59e0b, #ef4444)`,boxShadow:`0 0 8px rgba(245, 158, 11, 0.8)`,transition:`width 80ms ease-out`}),S.appendChild(C),v.append(y,S);let w=document.createElement(`div`);Object.assign(w.style,{position:`absolute`,inset:`0`,display:`flex`,flexDirection:`column`,alignItems:`center`,justifyContent:`center`,gap:`10px`,background:`rgba(10, 5, 8, 0.55)`,backdropFilter:`blur(3px)`,opacity:`0`,pointerEvents:`none`,transition:`opacity 200ms ease-out`});let T=document.createElement(`div`);Object.assign(T.style,{fontSize:`42px`,fontWeight:`800`,letterSpacing:`2px`,color:`#ef4444`,textShadow:`0 2px 12px rgba(0, 0, 0, 0.9)`});let E=document.createElement(`div`);Object.assign(E.style,{fontSize:`15px`,fontWeight:`500`,color:`rgba(255, 255, 255, 0.85)`,textShadow:`0 1px 6px rgba(0, 0, 0, 0.8)`}),w.append(T,E),e.appendChild(w);let D={"guard-sight":{title:`SPOTTED!`,message:`A guard spotted you!`},"guard-bump":{title:`CAUGHT!`,message:`You walked straight into a guard!`},camera:{title:`DETECTED!`,message:`A security camera caught you on film!`},laser:{title:`ALARM TRIPPED!`,message:`You walked into a laser gate!`},fell:{title:`FELL!`,message:`You fell off the train!`},caught:{title:`CAUGHT!`,message:`Security caught you!`}};function O(e,{lives:t=2,gameOver:n=!1}={}){let r=D[e]??D.caught;T.textContent=n?`RUN FAILED`:r.title,E.textContent=n?`All 3 lives lost — restarting from the beginning…`:`${r.message} ${t} ${t===1?`life`:`lives`} remaining.`,w.style.opacity=`1`}function k(){w.style.opacity=`0`}let A=document.createElement(`div`);A.id=`tutorial-overlay`,Object.assign(A.style,{position:`absolute`,inset:`0`,display:`flex`,alignItems:`center`,justifyContent:`center`,padding:`clamp(24px, 5vw, 72px)`,background:`radial-gradient(circle at 50% 40%, rgba(55, 42, 28, 0.30), rgba(5, 6, 12, 0.88) 58%, rgba(3, 4, 8, 0.95))`,backdropFilter:`blur(9px) saturate(0.82)`,WebkitBackdropFilter:`blur(9px) saturate(0.82)`,opacity:`0`,visibility:`hidden`,pointerEvents:`none`,transition:`opacity 180ms ease-out, visibility 180ms ease-out`,zIndex:`30`});let j=document.createElement(`div`);Object.assign(j.style,{position:`relative`,width:`min(940px, 88vw)`,minHeight:`min(500px, 66vh)`,maxHeight:`80vh`,boxSizing:`border-box`,display:`flex`,flexDirection:`column`,justifyContent:`center`,gap:`20px`,padding:`clamp(30px, 5vw, 60px)`,background:`linear-gradient(145deg, rgba(11, 15, 23, 0.985), rgba(29, 22, 18, 0.98))`,border:`1px solid rgba(211, 171, 82, 0.66)`,boxShadow:`0 34px 100px rgba(0, 0, 0, 0.76), 0 0 0 1px rgba(255, 238, 190, 0.035) inset, inset 0 0 70px rgba(176, 141, 63, 0.055)`,borderRadius:`16px`,transform:`translateY(12px) scale(0.985)`,transition:`transform 190ms ease-out`,overflow:`hidden`});let ee=document.createElement(`div`);Object.assign(ee.style,{position:`absolute`,top:`0`,left:`0`,right:`0`,height:`4px`,background:`linear-gradient(90deg, transparent 3%, #8b6a31 18%, #f0cf7a 50%, #8b6a31 82%, transparent 97%)`,boxShadow:`0 0 24px rgba(240, 207, 122, 0.28)`});let M=document.createElement(`div`);Object.assign(M.style,{position:`absolute`,right:`22px`,top:`20px`,width:`62px`,height:`62px`,borderTop:`1px solid rgba(240, 207, 122, 0.32)`,borderRight:`1px solid rgba(240, 207, 122, 0.32)`,borderRadius:`0 10px 0 0`,opacity:`0.75`});let N=document.createElement(`div`);Object.assign(N.style,{display:`inline-flex`,alignSelf:`flex-start`,padding:`6px 10px`,border:`1px solid rgba(211, 171, 82, 0.32)`,borderRadius:`999px`,background:`rgba(176, 141, 63, 0.08)`,fontSize:`10px`,fontWeight:`800`,letterSpacing:`0.28em`,textTransform:`uppercase`,color:`#b08d3f`});let P=document.createElement(`div`);Object.assign(P.style,{fontFamily:`Georgia, "Times New Roman", serif`,fontSize:`clamp(30px, 5vw, 54px)`,fontWeight:`700`,lineHeight:`1.05`,letterSpacing:`0.055em`,textTransform:`uppercase`,color:`#f0e6cf`,textShadow:`0 3px 18px rgba(0, 0, 0, 0.8)`});let te=document.createElement(`div`);Object.assign(te.style,{width:`100%`,height:`1px`,background:`linear-gradient(90deg, rgba(240, 207, 122, 0.9), rgba(176, 141, 63, 0.22) 55%, transparent)`});let F=document.createElement(`div`);Object.assign(F.style,{maxWidth:`760px`,fontSize:`clamp(15px, 2vw, 19px)`,fontWeight:`500`,lineHeight:`1.7`,color:`rgba(244, 235, 216, 0.86)`,letterSpacing:`0.015em`});let ne=document.createElement(`div`);Object.assign(ne.style,{display:`grid`,gridTemplateColumns:`repeat(auto-fit, minmax(180px, 1fr))`,gap:`12px`,width:`100%`});let re=document.createElement(`div`);Object.assign(re.style,{alignSelf:`flex-end`,marginTop:`10px`,padding:`9px 12px`,border:`1px solid rgba(240, 230, 207, 0.11)`,borderRadius:`999px`,background:`rgba(255, 255, 255, 0.025)`,fontSize:`11px`,fontWeight:`800`,letterSpacing:`0.25em`,textTransform:`uppercase`,color:`rgba(240, 230, 207, 0.55)`,textAlign:`right`}),j.append(ee,M),j.append(N,P,te,F,ne,re),A.appendChild(j),e.appendChild(A);let I=!1,L=[],ie=new Set;function ae(){ie.forEach(e=>e(I))}function oe(e){return e.key?String(e.key):e.action?ja(Y.getBinding(e.action)):Array.isArray(e.actions)?e.actions.map(e=>ja(Y.getBinding(e))).join(e.separator??`  `):``}function se(e={}){N.textContent=e.eyebrow??`Field Guide`,P.textContent=e.title??`New Mechanic`,F.textContent=e.text??``,ne.replaceChildren();let t=Array.isArray(e.controls)?e.controls:[];ne.style.display=t.length?`grid`:`none`,t.forEach(e=>{let t=document.createElement(`div`);Object.assign(t.style,{display:`flex`,flexDirection:`column`,gap:`7px`,minHeight:`82px`,padding:`14px 16px`,background:`linear-gradient(145deg, rgba(176, 141, 63, 0.10), rgba(255, 255, 255, 0.018))`,border:`1px solid rgba(211, 171, 82, 0.22)`,borderRadius:`10px`,boxShadow:`inset 0 1px 0 rgba(255,255,255,0.035), 0 8px 24px rgba(0,0,0,0.18)`});let n=document.createElement(`div`);n.textContent=oe(e),Object.assign(n.style,{alignSelf:`flex-start`,minWidth:`34px`,padding:`5px 9px`,background:`rgba(7, 10, 15, 0.78)`,border:`1px solid rgba(240, 207, 122, 0.42)`,borderBottomColor:`rgba(240, 207, 122, 0.72)`,borderRadius:`7px`,boxShadow:`inset 0 -2px 0 rgba(176, 141, 63, 0.22)`,fontSize:`clamp(16px, 2.3vw, 22px)`,fontWeight:`800`,letterSpacing:`0.08em`,color:`#fff2cf`});let r=document.createElement(`div`);r.textContent=e.label??``,Object.assign(r.style,{fontSize:`11px`,fontWeight:`700`,letterSpacing:`0.16em`,textTransform:`uppercase`,color:`rgba(240, 230, 207, 0.52)`}),t.append(n,r),ne.appendChild(t)}),re.textContent=e.footer??`Enter / Space — Continue`}function R(e){se(e),I=!0,A.style.visibility=`visible`,A.style.opacity=`1`,j.style.transform=`translateY(0) scale(1)`,ae()}function z(e={}){if(I){L.push(e);return}R(e)}function ce({clearQueue:e=!1}={}){if(e&&(L=[]),I){if(!e&&L.length>0){se(L.shift());return}I=!1,A.style.opacity=`0`,A.style.visibility=`hidden`,j.style.transform=`translateY(12px) scale(0.985)`,ae()}}function le(e){return typeof e==`function`?(ie.add(e),()=>ie.delete(e)):()=>{}}function ue(e){!I||e.repeat||(e.code===`Enter`||e.code===`Space`)&&(e.preventDefault(),e.stopImmediatePropagation(),ce())}window.addEventListener(`keydown`,ue,!0);let de=document.createElement(`div`);Object.assign(de.style,{position:`absolute`,bottom:`22px`,left:`50%`,transform:`translateX(-50%)`,display:`flex`,flexDirection:`column`,alignItems:`center`,gap:`8px`,padding:`10px 18px`,background:`rgba(9, 13, 22, 0.8)`,border:`1px solid rgba(0, 212, 255, 0.3)`,borderRadius:`10px`,backdropFilter:`blur(10px)`,boxShadow:`0 8px 32px rgba(0, 0, 0, 0.5), inset 0 0 12px rgba(0, 212, 255, 0.1)`});let fe=document.createElement(`div`);Object.assign(fe.style,{display:`flex`,alignItems:`center`,gap:`10px`,width:`100%`});let pe=document.createElement(`span`);pe.textContent=`CHRONO POWER`,Object.assign(pe.style,{fontSize:`11px`,letterSpacing:`1px`,color:`#38bdf8`,textTransform:`uppercase`,fontWeight:`700`});let me=document.createElement(`div`);Object.assign(me.style,{flex:`1`,height:`6px`,background:`rgba(255, 255, 255, 0.1)`,borderRadius:`3px`,overflow:`hidden`,minWidth:`160px`});let he=document.createElement(`div`);Object.assign(he.style,{height:`100%`,width:`100%`,background:`linear-gradient(90deg, #0284c7, #38bdf8, #a5f3fc)`,boxShadow:`0 0 8px rgba(56, 189, 248, 0.8)`,transition:`width 80ms ease-out`}),me.appendChild(he),fe.append(pe,me);let ge=document.createElement(`div`);Object.assign(ge.style,{display:`none`,alignItems:`center`,gap:`10px`,width:`100%`});let _e=document.createElement(`span`);_e.textContent=`CHRONO STRAIN`,Object.assign(_e.style,{fontSize:`11px`,letterSpacing:`1px`,color:`#f59e0b`,textTransform:`uppercase`,fontWeight:`700`});let ve=document.createElement(`div`);Object.assign(ve.style,{flex:`1`,height:`6px`,background:`rgba(255, 255, 255, 0.1)`,borderRadius:`3px`,overflow:`hidden`,minWidth:`160px`});let ye=document.createElement(`div`);Object.assign(ye.style,{height:`100%`,width:`0%`,background:`linear-gradient(90deg, #b45309, #f59e0b, #fde68a)`,boxShadow:`0 0 8px rgba(245, 158, 11, 0.7)`,transition:`width 80ms ease-out`}),ve.appendChild(ye),ge.append(_e,ve);let B=document.createElement(`div`);Object.assign(B.style,{display:`flex`,gap:`8px`,marginTop:`2px`});let be=[{id:`SLOW`,name:`Slow`,action:`slow`,color:`#38bdf8`},{id:`FREEZE`,name:`Freeze`,action:`freeze`,color:`#60a5fa`},{id:`REWIND`,name:`Rewind`,action:`rewind`,color:`#a855f7`},{id:`GHOST`,name:`Ghost`,action:`ghost`,color:`#2dd4bf`}],xe=new Map;be.forEach(e=>{let t=document.createElement(`div`);t.id=`ability-${e.id.toLowerCase()}`,Object.assign(t.style,{display:`flex`,flexDirection:`column`,alignItems:`center`,padding:`4px 10px`,background:`rgba(255, 255, 255, 0.05)`,border:`1px solid rgba(255, 255, 255, 0.15)`,borderRadius:`6px`,minWidth:`58px`,transition:`all 180ms ease`});let n=document.createElement(`span`);n.textContent=ja(Y.getBinding(e.action)),Object.assign(n.style,{fontSize:`10px`,color:`#94a3b8`,fontWeight:`700`});let r=document.createElement(`span`);r.textContent=e.name,Object.assign(r.style,{fontSize:`12px`,color:`#f1f5f9`,fontWeight:`600`}),t.append(n,r),B.appendChild(t),xe.set(e.id,{slot:t,ab:e,keyElem:n,nameElem:r})}),de.append(fe,ge,B);let V=document.createElement(`div`);Object.assign(V.style,{position:`absolute`,top:`18px`,left:`152px`,display:`flex`,flexDirection:`column`,alignItems:`flex-start`,gap:`2px`,padding:`6px 12px`,background:`rgba(9, 13, 22, 0.78)`,border:`1px solid rgba(0, 212, 255, 0.22)`,borderRadius:`6px`,backdropFilter:`blur(6px)`,transition:`border-color 200ms ease, box-shadow 200ms ease, opacity 200ms ease`});let Se=document.createElement(`div`);Se.textContent=`TIME`,Object.assign(Se.style,{fontSize:`10px`,fontWeight:`700`,letterSpacing:`1.4px`,color:`#38bdf8`,transition:`color 200ms ease`});let Ce=document.createElement(`div`);Ce.textContent=`00:00.0`,Object.assign(Ce.style,{fontSize:`18px`,fontWeight:`700`,fontVariantNumeric:`tabular-nums`,letterSpacing:`0.08em`,color:`#f1f5f9`,textShadow:`0 1px 4px rgba(0, 0, 0, 0.7)`,transition:`color 200ms ease, opacity 200ms ease, text-shadow 200ms ease`}),V.append(Se,Ce);let we=document.createElement(`div`);Object.assign(we.style,{position:`absolute`,top:`78px`,left:`20px`,padding:`4px 9px`,background:`rgba(9, 13, 22, 0.7)`,border:`1px solid rgba(255, 255, 255, 0.12)`,borderRadius:`4px`,fontSize:`11px`,fontVariantNumeric:`tabular-nums`,letterSpacing:`0.06em`,color:`#94a3b8`,display:`none`}),we.textContent=`-- FPS`,e.append(r,i,a,v,de,V,we),document.body.appendChild(e);function Te(){xe.forEach(({keyElem:e,ab:t})=>{e.textContent=ja(Y.getBinding(t.action))})}let Ee=Y.subscribe((e,t)=>{(t===`bindings`||t===`all`)&&Te(),(t===`showStats`||t===`options`||t===`all`)&&(we.style.display=e.showStats?`block`:`none`)});we.style.display=Y.get(`showStats`)?`block`:`none`;let De=0,Oe=0;function H(e){if(!Y.get(`showStats`)||(De+=e,Oe+=1,De<.5))return;let t=Math.round(Oe/De);we.textContent=`${t} FPS`,De=0,Oe=0}let ke=null,Ae=``,U=0,je=0,W=`NORMAL`,Me=null;function Ne(e){let t=Math.max(0,Math.floor(e*10+1e-6)),n=Math.floor(t/600),r=Math.floor(t%600/10),i=t%10;return`${String(n).padStart(2,`0`)}:${String(r).padStart(2,`0`)}.${i}`}function G(e,t){e===`SLOW`?(V.style.borderColor=`rgba(56, 189, 248, 0.55)`,V.style.boxShadow=`0 0 10px rgba(56, 189, 248, 0.18)`,V.style.opacity=`1`,Se.style.color=`#7dd3fc`,Ce.style.color=`#bae6fd`,Ce.style.opacity=`0.88`,Ce.style.textShadow=`0 0 8px rgba(56, 189, 248, 0.45)`):e===`FREEZE`?(V.style.borderColor=`rgba(96, 165, 250, 0.65)`,V.style.boxShadow=`0 0 12px rgba(96, 165, 250, 0.22)`,V.style.opacity=`1`,Se.style.color=`#93c5fd`,Ce.style.color=`#dbeafe`,Ce.style.opacity=`0.92`,Ce.style.textShadow=`0 0 10px rgba(147, 197, 253, 0.5)`):e===`REWIND`?(V.style.borderColor=`rgba(168, 85, 247, 0.55)`,V.style.boxShadow=`0 0 10px rgba(168, 85, 247, 0.2)`,V.style.opacity=`1`,Se.style.color=`#d8b4fe`,Ce.style.color=`#e9d5ff`,Ce.style.opacity=`0.9`,Ce.style.textShadow=`0 0 8px rgba(168, 85, 247, 0.45)`):t&&e===`NORMAL`?(V.style.borderColor=`rgba(168, 85, 247, 0.32)`,V.style.boxShadow=`none`,V.style.opacity=`0.72`,Se.style.color=`#c4b5fd`,Ce.style.color=`#ddd6fe`,Ce.style.opacity=`0.7`,Ce.style.textShadow=`0 0 6px rgba(139, 92, 246, 0.35)`):(V.style.borderColor=`rgba(0, 212, 255, 0.22)`,V.style.boxShadow=`none`,V.style.opacity=`1`,Se.style.color=`#38bdf8`,Ce.style.color=`#f1f5f9`,Ce.style.opacity=`1`,Ce.style.textShadow=`0 1px 4px rgba(0, 0, 0, 0.7)`)}function Pe(){je=0,W=`NORMAL`,Me=null,Ce.textContent=Ne(0),G(`NORMAL`,!1)}function Fe({elapsed:e,delta:t=0,mode:n=`NORMAL`,ghostActive:r=!1,running:i=!0}){let a=Math.max(0,e);if(!i){je=a,Me=null,W=`NORMAL`,Ce.textContent=Ne(je),G(`NORMAL`,!1);return}n===`FREEZE`?(W!==`FREEZE`&&(Me=je),je=Me??je):n===`REWIND`?(Me=null,je=Math.max(0,je-t*1.5)):(Me=null,je=je+.02<a?Math.min(a,je+t*10):a),W=n,Ce.textContent=Ne(je),G(n,r)}function Ie(e){Ae=e??``,r.textContent=Ae,r.style.opacity=Ae?`1`:`0`}function Le(e,t=2e3){i.textContent=e,i.style.opacity=`1`,clearTimeout(ke),t>0&&(ke=setTimeout(()=>{i.style.opacity=`0`},t))}function Re(e){let t=Math.max(0,Math.min(100,Math.round(e)));U=t,C.style.width=`${t}%`,x.textContent=`${t}%`,t>0?(v.style.opacity=`1`,v.style.transform=`translateY(0)`,t>60?(y.style.color=`#ef4444`,v.style.borderColor=`rgba(239, 68, 68, 0.6)`,C.style.background=`linear-gradient(90deg, #f97316, #ef4444)`,C.style.boxShadow=`0 0 10px rgba(239, 68, 68, 0.9)`):(y.style.color=`#f59e0b`,v.style.borderColor=`rgba(245, 158, 11, 0.3)`,C.style.background=`linear-gradient(90deg, #f59e0b, #ef4444)`,C.style.boxShadow=`0 0 8px rgba(245, 158, 11, 0.8)`)):(v.style.opacity=`0`,v.style.transform=`translateY(-10px)`)}function ze({mode:e,energy:t,maxEnergy:r,ghostCooldown:i,hasGhost:a,available:o,strain:s=0,maxStrain:c=100,strainEnabled:l=!1,freezeLockout:u=0}){let d=Math.max(0,Math.min(100,t/r*100));if(he.style.width=`${d}%`,d<20?(he.style.background=`linear-gradient(90deg, #dc2626, #ef4444)`,he.style.boxShadow=`0 0 8px rgba(239, 68, 68, 0.8)`):(he.style.background=`linear-gradient(90deg, #0284c7, #38bdf8, #a5f3fc)`,he.style.boxShadow=`0 0 8px rgba(56, 189, 248, 0.8)`),ge.style.display=l?`flex`:`none`,l){let e=Math.max(0,Math.min(100,s/c*100));ye.style.width=`${e}%`,u>0?(_e.textContent=`FREEZE OFFLINE ${u.toFixed(1)}s`,_e.style.color=`#ef4444`,ye.style.background=`linear-gradient(90deg, #991b1b, #ef4444, #fca5a5)`):(_e.textContent=`CHRONO STRAIN`,_e.style.color=e>70?`#f97316`:`#f59e0b`,ye.style.background=`linear-gradient(90deg, #b45309, #f59e0b, #fde68a)`)}xe.forEach(({slot:t,ab:n},r)=>{if(o&&o[r]===!1){t.style.opacity=`0.25`,t.style.filter=`grayscale(1)`,t.style.background=`rgba(255, 255, 255, 0.02)`,t.style.borderColor=`rgba(255, 255, 255, 0.06)`,t.style.boxShadow=`none`,t.style.transform=`scale(1.0)`;return}t.style.filter=`none`,t.style.opacity=`1`,r===`FREEZE`&&u>0?(t.style.opacity=`0.6`,t.style.background=`rgba(239, 68, 68, 0.18)`,t.style.borderColor=`#ef4444`,t.style.boxShadow=`0 0 12px rgba(239, 68, 68, 0.45)`,t.style.transform=`scale(1.0)`):r===`GHOST`?a?(t.style.background=`rgba(45, 212, 191, 0.25)`,t.style.borderColor=`#2dd4bf`,t.style.boxShadow=`0 0 12px rgba(45, 212, 191, 0.5)`):i>0?(t.style.opacity=`0.45`,t.style.background=`rgba(255, 255, 255, 0.03)`,t.style.borderColor=`rgba(255, 255, 255, 0.08)`,t.style.boxShadow=`none`):(t.style.opacity=`1`,t.style.background=`rgba(255, 255, 255, 0.05)`,t.style.borderColor=`rgba(255, 255, 255, 0.15)`,t.style.boxShadow=`none`):e===r?(t.style.background=`${n.color}33`,t.style.borderColor=n.color,t.style.boxShadow=`0 0 14px ${n.color}88`,t.style.transform=`scale(1.05)`):(t.style.background=`rgba(255, 255, 255, 0.05)`,t.style.borderColor=`rgba(255, 255, 255, 0.15)`,t.style.boxShadow=`none`,t.style.transform=`scale(1.0)`)}),e===`SLOW`?(n.style.boxShadow=`inset 0 0 90px rgba(56, 189, 248, 0.45)`,n.style.background=`rgba(2, 132, 199, 0.04)`):e===`FREEZE`?(n.style.boxShadow=`inset 0 0 100px rgba(96, 165, 250, 0.65)`,n.style.background=`rgba(30, 58, 138, 0.07)`):e===`REWIND`?(n.style.boxShadow=`inset 0 0 110px rgba(168, 85, 247, 0.65)`,n.style.background=`rgba(88, 28, 135, 0.08)`):(n.style.boxShadow=`inset 0 0 90px rgba(0, 212, 255, 0)`,n.style.background=`transparent`)}function Be(e){de.style.display=e?`flex`:`none`}function Ve(t){t||ce({clearQueue:!0}),e.style.display=t?`block`:`none`}function He(){t.dispose(),clearTimeout(ke),clearTimeout(l),ce({clearQueue:!0}),ie.clear(),window.removeEventListener(`keydown`,ue,!0),Ee(),e.remove()}return{root:e,showCinematicSkip:t.show,hideCinematicSkip:t.hide,setObjective:Ie,showToast:Le,showBriefing:f,clearBriefing:p,setSuspicion:Re,updateTimeState:ze,setChronoVisible:Be,updateRunTimer:Fe,resetRunTimer:Pe,formatRunClock:Ne,updateStats:H,setLives:_,setVisible:Ve,dispose:He,showCaughtScreen:O,hideCaughtScreen:k,showTutorial:z,hideTutorial:ce,isTutorialOpen:()=>I,onTutorialStateChange:le,getObjective:()=>Ae,getSuspicion:()=>U}}var Qf=7.5,$f=Math.PI/3.2,ep={ground:.02,obstacle:.05,beam:.08,actor:.12},tp={ground:1054239,wall:6583435,crate:11817737,seat:4873332,locker:6583435,player:6220500,guard:16347926,beam:16436245,alert:15680580};function np(e,t={}){return new dt({color:e,fog:!1,toneMapped:!1,depthTest:!1,depthWrite:!1,side:2,...t})}function rp(e){e.traverse(e=>{e.layers.set(1),e.raycast=()=>{}})}function ip(e){return e.rotateX(Math.PI/2),e}function ap(e,t){let n=new It;return n.moveTo(0,e),n.lineTo(-t,-e*.45),n.lineTo(t,-e*.45),n.closePath(),ip(new yt(n))}function op(e,t){let n=new It,r=t/2;n.moveTo(0,0);for(let i=0;i<=18;i++){let a=-r+t*i/18;n.lineTo(Math.sin(a)*e,Math.cos(a)*e)}return n.closePath(),ip(new yt(n))}var sp=new R;function cp(e,t){return!e||(e.getWorldDirection(sp),sp.x*sp.x+sp.z*sp.z<1e-10)?t:Math.atan2(sp.x,sp.z)}function lp(e){return e.kind===`crate`||e.kind===`trunk`||e.type===`crate`?`crate`:e.kind===`seat`?`seat`:e.kind===`locker`||e.kind===`relaybox`?`locker`:`wall`}function up(e,t,n){return!n||e>=n.minX&&e<=n.maxX&&t>=n.minZ&&t<=n.maxZ}function dp(e,t){return!t||e.maxX>=t.minX&&e.minX<=t.maxX&&e.maxZ>=t.minZ&&e.minZ<=t.maxZ}function fp({scene:e,player:t,getObstacles:n,getGuards:r}){let i=new U;i.name=`minimap-icons`,i.layers.set(1),e.add(i);let a=np(tp.wall),o=np(tp.crate),s=np(tp.seat),c=np(tp.locker),l=np(tp.player),u=np(tp.guard),d={color:tp.beam,transparent:!0,opacity:.28,side:2},f=new Ot(1,1);f.rotateX(-Math.PI/2);let p=ap(.85,.38),m=ap(.7,.32),h=op(Qf,$f),g=new G(16,48);g.rotateX(-Math.PI/2);let _=new z(g,np(tp.ground));_.renderOrder=0,rp(_),i.add(_);let v=new z(f,np(tp.ground));v.renderOrder=0,v.visible=!1,rp(v),i.add(v);let y=new z(p,l);y.renderOrder=4,rp(y),i.add(y);let b=[],x=[],S=null;function C(e){let t=lp(e);return t===`crate`?o:t===`seat`?s:t===`locker`?c:a}function w(e,t,n){for(;e.length<t;){let t=n();rp(t.root),i.add(t.root),e.push(t)}for(;e.length>t;){let t=e.pop();i.remove(t.root),t.dispose()}}function T(e,t,n){let r=e||[],i=r.filter(e=>dp(e,n)),o=n?.key??null;if(o&&o!==S){S=o;let e=r.slice(0,6).map(e=>({kind:e.kind||`wall`,x:+((e.minX+e.maxX)*.5).toFixed(2),z:+((e.minZ+e.maxZ)*.5).toFixed(2),pass:dp(e,n)}));console.log(`[minimap-obstacles] enter`,o,{created:r.length,afterFilter:i.length,clip:{minX:n.minX,maxX:n.maxX,minZ:+n.minZ.toFixed(2),maxZ:+n.maxZ.toFixed(2)},samples:e})}n||(S=null),w(b,i.length,()=>{let e=new z(f,a);return e.renderOrder=1,{root:e,dispose(){}}});for(let e=0;e<i.length;e++){let n=i[e],r=b[e].root,a=Math.max(.08,n.maxX-n.minX),o=Math.max(.08,n.maxZ-n.minZ);r.position.set((n.minX+n.maxX)*.5,t,(n.minZ+n.maxZ)*.5),r.scale.set(a,1,o),r.material=C(n)}}function E(e,t,n,r){let i=(e||[]).filter(e=>{let t=e.group.position;return up(t.x,t.z,r)});w(x,i.length,()=>{let e=new U,t=new z(h,np(tp.beam,d));t.renderOrder=2;let n=new z(m,u);return n.renderOrder=3,e.add(t,n),{root:e,beam:t,arrow:n,dispose(){t.material.dispose()}}});for(let e=0;e<i.length;e++){let r=i[e],a=x[e],o=r.group.position,s=cp(r.group,r.facing??r.group.rotation.y),c=cp(r.visionCone,s);a.root.position.set(o.x,0,o.z),a.root.rotation.y=0,a.arrow.position.y=n,a.arrow.rotation.y=s,a.beam.position.y=t,a.beam.rotation.y=c;let l=r.state===`ALERT`;a.beam.material.color.setHex(l?tp.alert:tp.beam),a.beam.material.opacity=l?.38:.28}}function D({clip:e=null,extraObstacles:i=null}={}){let a=t.mesh.position,o=t.mesh.rotation.y,s=a.y;e?(_.visible=!1,v.visible=!0,v.position.set((e.minX+e.maxX)*.5,s+ep.ground,(e.minZ+e.maxZ)*.5),v.scale.set(Math.max(.2,e.maxX-e.minX),1,Math.max(.2,e.maxZ-e.minZ))):(v.visible=!1,_.visible=!0,_.position.set(a.x,s+ep.ground,a.z)),y.position.set(a.x,s+ep.actor,a.z),y.rotation.y=cp(t.mesh,o),T([...n?.()??[],...i??[]],s+ep.obstacle,e),E(r?.()??null,s+ep.beam,s+ep.actor,e)}function O(){w(b,0,()=>({})),w(x,0,()=>({})),e.remove(i),_.material.dispose(),v.material.dispose(),l.dispose(),a.dispose(),o.dispose(),s.dispose(),c.dispose(),u.dispose(),f.dispose(),p.dispose(),m.dispose(),h.dispose(),g.dispose()}return{update:D,dispose:O,root:i,layer:1}}var pp=2.6,mp=pp,hp=1.12,gp=.82;function _p(e){return e?mp:pp}var vp=1.2,yp=.55,bp=.14,xp=1.15,Sp={halfX:.42,halfZ:.34,inset:.52};function Cp(e){let t=[];for(let n=-e+2;n<=e-2;n+=2.6)t.push(n);return t}function wp(e){let t=Cp(e),n=t.slice(1).map((e,n)=>(e+t[n])/2);return{bays:t,platform:{s:-1,z:n[1]},gear:{s:1,z:n[1]},poster:{s:1,z:n[3]},sconces:[{s:1,z:n[0]},{s:-1,z:n[0]},{s:-1,z:n[3]}],relays:[{label:`A`,s:1,z:n[2]},{label:`B`,s:1,z:n[4]},{label:`C`,s:-1,z:n[2]},{label:`D`,s:-1,z:n[4]}]}}var Tp=.36,Ep=.6;function Dp(e){let t=[];for(let n=-e+3;n<=e-1.6;n+=3)t.push(n);return t}var Op=[{key:`passenger`,length:20},{key:`security`,length:20},{key:`relay`,length:18},{key:`cargo`,length:28},{key:`mechanical`,length:30},{key:`convergence`,length:40},{key:`vault`,length:18}],kp={freightLength:36,shell:[1.5,31.5],decks:[[1.5,2.5],[6.7,11.5],[16.3,21.6],[26,31.5]],openings:[[2.5,6.7],[11.5,16.3],[21.6,26]],vaultDeck:5.2};function Ap(e){if(e)return Op.map(e=>({...e}));let t=Op.map(e=>({...e}));return t.splice(t.length-1,0,{key:`freight`,length:kp.freightLength}),t}var jp={z:1.5,halfZ:1.3,halfX:.95},Mp=[{z:-5.2,halfZ:1.3,halfX:.95},{z:7.6,halfZ:1.3,halfX:.95}],Np=[{z:-7,halfZ:1.3,halfX:.95},{z:9.5,halfZ:1.3,halfX:.95}],Pp=18.2;function Fp(e,t){return e===`cargo`?[jp]:e===`mechanical`?Mp:e===`convergence`?Np:[]}function Ip(e){if(!e)return[];let t=Op.map(e=>e.key);e.cab&&t.unshift(`cab`);let n=_p(!!e.cab),r=!!e.cab;return t.filter(t=>e[t]).map(t=>({key:t,damaged:r,minX:-n,maxX:n,minZ:e[t].minZ,maxZ:e[t].maxZ,sealedMin:t===`cab`||t===`passenger`&&!e.cab,sealedMax:t===`vault`}))}function Lp(e,t){if(!t||t.length===0)return null;for(let n=0;n<t.length;n++){let r=t[n],i=n===t.length-1;if(e>=r.minZ&&(i?e<=r.maxZ:e<r.maxZ))return r}let n=t[0],r=1/0;for(let i of t){let t=e<i.minZ?i.minZ-e:e>i.maxZ?e-i.maxZ:0;t<r&&(r=t,n=i)}return n}var Rp=.12,zp=.14;function Bp(e){if(!e)return[];let{minX:t,maxX:n,minZ:r,maxZ:i}=e,a=[{kind:`wall`,minX:t,maxX:t+Rp,minZ:r,maxZ:i},{kind:`wall`,minX:n-Rp,maxX:n,minZ:r,maxZ:i}],o=hp/2;function s(e,r,i){if(i){a.push({kind:`wall`,minX:t,maxX:n,minZ:e,maxZ:r});return}a.push({kind:`wall`,minX:t,maxX:-.56,minZ:e,maxZ:r}),a.push({kind:`wall`,minX:o,maxX:n,minZ:e,maxZ:r})}let c=Math.max(zp,(i-r)*.04);return s(r,r+c,!!e.sealedMin),s(i-c,i,!!e.sealedMax),a}function Vp(e,t,n,r,i){return{kind:e,minX:t-r,maxX:t+r,minZ:n-i,maxZ:n+i}}function Hp(e,t,n=pp,r=!1){let i=[];if(e===`passenger`&&r){let e=Math.max(1,Math.floor((t*2-4)/3.4));for(let n=0;n<e;n++){let e=-t+3+n*3.4;for(let t of[-1,1])i.push(Vp(`seat`,t*1.02,e,.35,.48))}}else if(e===`passenger`){let e=(n-.08-vp)/2;for(let r of Dp(t))for(let t of[-1,1]){for(let n of[-1,1]){let a=r+n*1.07;i.push(Vp(`seat`,t*(vp+e),a,e,.34500000000000003))}i.push(Vp(`seat`,t*(n-Sp.inset),r,Sp.halfX,Sp.halfZ))}}else if(e===`security`&&!r)for(let e of Cp(t))for(let t of[-1,1])i.push(Vp(`trunk`,t*(n-.45),e,.375,.5));else if(e!==`security`){if(e===`cargo`)for(let e=-t+2;e<=t-2;e+=2.2)i.push(Vp(`crate`,-(n-.45),e,.4,.4)),i.push(Vp(`crate`,n-.45,e,.4,.4)),(e|0)%2==0&&i.push(Vp(`crate`,-(n-.5),e,.4,.4));else if(e===`mechanical`&&!r)for(let e of Cp(t))for(let t of[-1,1])i.push(Vp(`trunk`,t*(n-.45),e,.375,.5));else if(e===`mechanical`)i.push(Vp(`grate`,0,t-.3,.35,.08)),i.push(Vp(`wheel`,-(n-.16),-t+3,.6,.6)),i.push(Vp(`ladder`,0,t-2.5-.55,.28,.2));else if(e===`vault`&&!r)for(let e of Cp(t))for(let t of[-1,1])i.push(Vp(`trunk`,t*(n-.45),e,.375,.5));else if(e===`convergence`&&!r)for(let e of Cp(t))for(let t of[-1,1])i.push(Vp(`trunk`,t*(n-.45),e,.375,.5));else if(e!==`convergence`){if(e===`relay`&&!r){let e=wp(t);for(let t of e.bays)for(let e of[-1,1])i.push(Vp(`trunk`,e*(n-.45),t,.375,.5));for(let t of e.relays)i.push(Vp(`relaybox`,t.s*(n-Tp/2),t.z,Tp/2,Ep/2))}else e===`relay`||e===`cab`&&(i.push(Vp(`backhead`,0,-t+.5,1.1,.18)),i.push(Vp(`firebox`,0,-t+.72,.45,.1)))}}return i}function Up(e){if(!e)return[];let t=(e.maxZ-e.minZ)/2,n=(e.minZ+e.maxZ)*.5;return Hp(e.key,t,e.maxX,!!e.damaged).map(e=>({...e,minZ:e.minZ+n,maxZ:e.maxZ+n}))}var Wp=14,Gp=48,Kp=150,qp=24,Jp=96,Yp=1.2,Xp=new Set([`MovingHeist`,`Timewreck`]);function Zp({scene:e,hudRoot:n,mainCamera:r,player:i,getObstacles:a,getGuards:o,getLevelState:s,getCarriageVolumes:c}){r.layers.enable(0),r.layers.disable(1);let l=new Se(-14,Wp,Wp,-14,1,80);l.name=`minimap`,l.up.set(0,0,1),l.layers.set(1);let u=new t,d=fp({scene:u,player:i,getObstacles:a,getGuards:o}),f=document.createElement(`div`);f.id=`minimap-frame`,Object.assign(f.style,{position:`absolute`,top:`${Jp}px`,right:`${qp}px`,width:`${Kp}px`,height:`${Kp}px`,boxSizing:`border-box`,display:`none`,pointerEvents:`none`,border:`2px solid rgba(176, 141, 63, 0.8)`,borderRadius:`8px`,boxShadow:`0 8px 28px rgba(0, 0, 0, 0.5), inset 0 0 0 1px rgba(0, 0, 0, 0.35)`,background:`rgba(6, 8, 16, 0.55)`}),n.appendChild(f);function p(e){l.left=-14,l.right=Wp,l.top=Wp,l.bottom=-14,l.updateProjectionMatrix(),l.position.set(e.x,e.y+Gp,e.z),l.lookAt(e.x,e.y,e.z)}function m(e,t){let n=(t.minX+t.maxX)*.5,r=(t.minZ+t.maxZ)*.5,i=(t.maxX-t.minX)*.5,a=(t.maxZ-t.minZ)*.5,o=Math.max(i,a)+Yp;l.left=-o,l.right=o,l.top=o,l.bottom=-o,l.updateProjectionMatrix(),l.position.set(n,e.y+Gp,r),l.lookAt(n,e.y,r)}function h(){let e=i.mesh.position,t=s?.()??null,n=Xp.has(t)?c?.()??null:null,r=n?Lp(e.z,n):null;if(r){m(e,r),d.update({clip:r,extraObstacles:[...Bp(r),...Up(r)]});return}p(e),d.update({clip:null})}function g(e){let t=e.domElement.clientWidth,n=e.domElement.clientHeight;return{x:t-qp-Kp,y:n-Jp-Kp,width:t,height:n,size:Kp}}function _(t){h();let{x:n,y:r,width:i,height:a,size:o}=g(t);t.setScissorTest(!0),t.setScissor(n,r,o,o),t.setViewport(n,r,o,o),t.clear(!0,!0,!1),u.background=e.background,t.render(u,l),t.setScissorTest(!1),t.setViewport(0,0,i,a),t.setScissor(0,0,i,a)}function v(e){f.style.display=e?`block`:`none`}function y(){d.dispose(),f.remove()}return{render:_,setVisible:v,dispose:y,camera:l}}function Qp(e,{tasks:t=null}={}){let n=document.createElement(`div`);n.id=`loading-screen`,Object.assign(n.style,{position:`fixed`,inset:`0`,display:`flex`,flexDirection:`column`,alignItems:`center`,justifyContent:`center`,gap:`18px`,background:`#12121f`,color:`#e8e8f0`,font:`600 16px/1 system-ui, sans-serif`,letterSpacing:`0.08em`,zIndex:`100`,opacity:`1`,transition:`opacity 260ms ease-out`});let r=document.createElement(`div`);r.textContent=`CHRONO EXPRESS`,r.style.fontSize=`22px`,r.style.letterSpacing=`0.22em`;let i=document.createElement(`div`);Object.assign(i.style,{width:`min(320px, 60vw)`,height:`4px`,background:`rgba(255, 255, 255, 0.15)`,borderRadius:`2px`,overflow:`hidden`});let a=document.createElement(`div`);Object.assign(a.style,{width:`0%`,height:`100%`,background:`#5a7cff`,transition:`width 160ms ease-out`}),i.appendChild(a);let o=document.createElement(`div`);o.textContent=`Loading`,o.style.fontSize=`12px`,o.style.opacity=`0.7`,n.append(r,i,o),document.body.appendChild(n);let s=!0,c=null;function l(e){let t=Math.round(Math.min(1,Math.max(0,e))*100);a.style.width=`${t}%`,o.textContent=`Loading ${t}%`}function u(){s=!0,clearTimeout(c),l(0),n.style.display=`flex`,n.offsetWidth,n.style.opacity=`1`}function d(){s&&(l(1),s=!1,n.style.opacity=`0`,c=setTimeout(()=>{s||(n.style.display=`none`)},300))}function f(){o.textContent=`Unable to load. Reload to try again.`}let p=e.onProgress(e=>{(!t||t.ready)&&l(e)}),m=e.onLoad(()=>{(!t||t.ready)&&l(1)}),h=t?.subscribe(e=>{e.failed?f():l(e.progress)});function g(){p(),m(),h?.(),clearTimeout(c),n.remove()}return{show:u,hide:d,setProgress:l,setError:f,dispose:g}}var X=23.4,$p=10.8,em=-1.4,tm=38.6,nm=18.6,rm=7.05,im=12.05,am=13.25,om=17.45,sm={minX:8.4,maxX:38.2,minZ:-7.5,maxZ:46,y:-.32},cm=new R(21.9,6.2,nm),lm={x:13.6,y:.05,z:nm,yaw:Math.PI/2,pitch:-.15},um={pivotHeight:1.5,distance:4.8,maxDistance:5};function dm(){let e=lm.pitch;return{x:lm.x-Math.cos(e)*um.distance,y:lm.y+um.pivotHeight+Math.sin(e)*um.distance,z:lm.z}}var fm={position:dm(),target:{x:lm.x,y:lm.y+um.pivotHeight,z:lm.z},driftX:.08,driftY:.04,driftZ:0,driftSpeed:.05},pm={minX:8.7,maxX:23.25,minZ:-3.6,maxZ:40.800000000000004,y:.05};function mm(e,t,n=0){let r=sm;return e>=r.minX-n&&e<=r.maxX+n&&t>=r.minZ-n&&t<=r.maxZ+n}var hm=`chrono-menu-styles`,gm=`
.cx-scroll {
  scrollbar-width: thin;
  scrollbar-color: rgba(176, 141, 63, 0.55) rgba(0, 0, 0, 0.3);
}
.cx-scroll::-webkit-scrollbar {
  width: 10px;
  height: 10px;
}
.cx-scroll::-webkit-scrollbar-track {
  background: rgba(0, 0, 0, 0.3);
  border-left: 1px solid rgba(176, 141, 63, 0.14);
}
.cx-scroll::-webkit-scrollbar-thumb {
  background: linear-gradient(180deg, rgba(176, 141, 63, 0.7), rgba(176, 141, 63, 0.42));
  background-clip: padding-box;
  border: 2px solid transparent;
  border-radius: 6px;
}
.cx-scroll::-webkit-scrollbar-thumb:hover {
  background: linear-gradient(180deg, rgba(214, 178, 92, 0.9), rgba(176, 141, 63, 0.65));
  background-clip: padding-box;
}
.cx-scroll::-webkit-scrollbar-thumb:active {
  background: rgba(214, 178, 92, 0.95);
  background-clip: padding-box;
}
/* Stepper arrows: the default pair reads as two light blocks pinned to the
   ends of the track, which no other control on these panels has. */
.cx-scroll::-webkit-scrollbar-button {
  display: none;
  width: 0;
  height: 0;
}
.cx-scroll::-webkit-scrollbar-corner {
  background: transparent;
}
@keyframes cx-credits-roll {
  from { transform: translateY(100vh); }
  to { transform: translateY(-100%); }
}
`;function _m(){if(document.getElementById(hm))return;let e=document.createElement(`style`);e.id=hm,e.textContent=gm,document.head.appendChild(e)}function vm(e){return _m(),e.classList.add(`cx-scroll`),e}var ym={brass:`#b08d3f`,brassSoft:`rgba(176, 141, 63, 0.4)`,brassFaint:`rgba(176, 141, 63, 0.12)`,parchment:`#f0e6cf`,parchmentDim:`rgba(240, 230, 207, 0.55)`,parchmentFaint:`rgba(240, 230, 207, 0.28)`,ink:`rgba(6, 6, 16, 0.92)`,serif:`Georgia, "Times New Roman", "Palatino Linotype", serif`,sans:`-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif`},bm={primary:{base:`rgba(176, 141, 63, 0.14)`,border:`rgba(176, 141, 63, 0.55)`,text:ym.parchment,glow:`rgba(176, 141, 63, 0.9)`},ghost:{base:`rgba(255, 255, 255, 0.03)`,border:`rgba(240, 230, 207, 0.18)`,text:`rgba(240, 230, 207, 0.8)`,glow:`rgba(240, 230, 207, 0.5)`},danger:{base:`rgba(180, 60, 60, 0.10)`,border:`rgba(220, 90, 90, 0.35)`,text:`rgba(255, 205, 205, 0.85)`,glow:`rgba(230, 100, 100, 0.75)`}};function xm(e,{variant:t=`primary`,onClick:n,wide:r=!1,size:i=`medium`}={}){let a=bm[t]??bm.primary,o=document.createElement(`button`);o.textContent=e,o.type=`button`;let s=i===`large`?`clamp(12px, 2vh, 18px) clamp(32px, 7vw, 64px)`:i===`small`?`7px 14px`:`10px 26px`;Object.assign(o.style,{padding:s,width:r?`100%`:`auto`,fontSize:i===`large`?`clamp(14px, 2vw, 20px)`:i===`small`?`11px`:`13px`,fontWeight:`700`,letterSpacing:i===`large`?`0.22em`:`0.16em`,color:a.text,background:a.base,border:`1px solid ${a.border}`,borderRadius:`2px`,cursor:`pointer`,transition:`background 180ms ease, border-color 180ms ease, box-shadow 180ms ease, transform 120ms ease, color 180ms ease`,textTransform:`uppercase`,fontFamily:ym.sans,outline:`none`,backdropFilter:`blur(6px)`,WebkitBackdropFilter:`blur(6px)`});function c(e){if(o.disabled){o.style.background=`rgba(255, 255, 255, 0.02)`,o.style.borderColor=`rgba(240, 230, 207, 0.08)`,o.style.color=`rgba(240, 230, 207, 0.22)`,o.style.boxShadow=`none`,o.style.transform=`scale(1)`,o.style.cursor=`default`;return}o.style.cursor=`pointer`,e===`hover`?(o.style.background=a.base.replace(/[\d.]+\)$/,`0.28)`),o.style.borderColor=a.glow,o.style.boxShadow=`0 0 20px ${a.base.replace(/[\d.]+\)$/,`0.35)`)}`,o.style.transform=`scale(1.03)`,o.style.color=t===`primary`?`#fff5e0`:a.text):e===`active`?(o.style.transform=`scale(0.97)`,o.style.background=a.base.replace(/[\d.]+\)$/,`0.38)`)):(o.style.background=a.base,o.style.borderColor=a.border,o.style.boxShadow=`none`,o.style.transform=`scale(1)`,o.style.color=a.text)}return o.addEventListener(`mouseenter`,()=>c(`hover`)),o.addEventListener(`mouseleave`,()=>c(`default`)),o.addEventListener(`mousedown`,()=>c(`active`)),o.addEventListener(`mouseup`,()=>c(`hover`)),o.addEventListener(`focus`,()=>c(`hover`)),o.addEventListener(`blur`,()=>c(`default`)),n&&o.addEventListener(`click`,n),o.refresh=()=>c(`default`),o}function Sm(e,{size:t=`clamp(20px, 3.2vw, 32px)`}={}){let n=document.createElement(`h2`);return n.textContent=e,Object.assign(n.style,{margin:`0`,fontFamily:ym.serif,fontSize:t,fontWeight:`700`,letterSpacing:`0.18em`,color:ym.parchment,textTransform:`uppercase`,textShadow:`0 2px 12px rgba(0, 0, 0, 0.8)`}),n}function Cm(e){let t=document.createElement(`div`);return t.textContent=e,Object.assign(t.style,{fontSize:`10px`,fontWeight:`700`,letterSpacing:`0.28em`,color:`rgba(176, 141, 63, 0.8)`,textTransform:`uppercase`,padding:`2px 0 8px`,borderBottom:`1px solid ${ym.brassFaint}`,marginBottom:`10px`}),t}function wm(e,t){let n=document.createElement(`div`);Object.assign(n.style,{display:`flex`,alignItems:`center`,justifyContent:`space-between`,gap:`18px`,padding:`10px 2px`,borderBottom:`1px solid rgba(240, 230, 207, 0.06)`});let r=document.createElement(`div`);Object.assign(r.style,{display:`flex`,flexDirection:`column`,gap:`3px`,minWidth:`0`});let i=document.createElement(`span`);if(i.textContent=e,Object.assign(i.style,{fontSize:`13px`,fontWeight:`600`,color:ym.parchment,letterSpacing:`0.04em`}),r.appendChild(i),t){let e=document.createElement(`span`);e.textContent=t,Object.assign(e.style,{fontSize:`11px`,color:ym.parchmentFaint,lineHeight:`1.4`,fontWeight:`400`}),r.appendChild(e)}return n.appendChild(r),{row:n,text:r}}function Tm({label:e,hint:t,value:n,choices:r,onChange:i}){let{row:a}=wm(e,t),o=document.createElement(`div`);Object.assign(o.style,{display:`flex`,flex:`0 0 auto`,border:`1px solid ${ym.brassSoft}`,borderRadius:`4px`,overflow:`hidden`});let s=n,c=r.map(e=>{let t=document.createElement(`button`);return t.type=`button`,t.textContent=e.label,Object.assign(t.style,{border:`none`,borderRight:`1px solid ${ym.brassSoft}`,background:`transparent`,color:ym.parchmentDim,font:`inherit`,fontSize:`11px`,letterSpacing:`0.06em`,padding:`6px 10px`,cursor:`pointer`}),t.addEventListener(`click`,()=>{t.disabled||s===e.value||(s=e.value,u(),i&&i(e.value))}),o.appendChild(t),{choice:e,button:t}}),l=c[c.length-1];l&&(l.button.style.borderRight=`none`);function u(){for(let{choice:e,button:t}of c){let n=e.value===s;t.style.background=n?`rgba(176, 141, 63, 0.28)`:`transparent`,t.style.color=n?ym.brass:ym.parchmentDim,t.setAttribute(`aria-pressed`,String(n))}}return u(),a.appendChild(o),{row:a,setValue(e){s=e,u()},setEnabled(e){for(let{button:t}of c)t.disabled=!e;a.style.opacity=e?`1`:`0.4`}}}function Em({label:e,hint:t,min:n,max:r,step:i,value:a,format:o,onInput:s}){let{row:c}=wm(e,t),l=document.createElement(`div`);Object.assign(l.style,{display:`flex`,alignItems:`center`,gap:`12px`,flex:`0 0 auto`});let u=document.createElement(`input`);u.type=`range`,u.min=String(n),u.max=String(r),u.step=String(i),u.value=String(a),Object.assign(u.style,{width:`clamp(120px, 18vw, 200px)`,accentColor:ym.brass,cursor:`pointer`,background:`transparent`});let d=document.createElement(`span`);Object.assign(d.style,{fontSize:`12px`,fontVariantNumeric:`tabular-nums`,color:`rgba(176, 141, 63, 0.95)`,fontWeight:`700`,minWidth:`56px`,textAlign:`right`});function f(e){d.textContent=o?o(e):String(e)}return f(a),u.addEventListener(`input`,()=>{let e=Number(u.value);f(e),s&&s(e)}),l.append(u,d),c.appendChild(l),{row:c,setValue(e){u.value=String(e),f(e)},setEnabled(e){u.disabled=!e,c.style.opacity=e?`1`:`0.4`}}}function Dm({label:e,hint:t,value:n,onChange:r}){let{row:i}=wm(e,t),a=document.createElement(`button`);a.type=`button`,a.setAttribute(`role`,`switch`),Object.assign(a.style,{position:`relative`,width:`46px`,height:`24px`,flex:`0 0 auto`,borderRadius:`12px`,border:`1px solid ${ym.brassSoft}`,background:`rgba(0, 0, 0, 0.35)`,cursor:`pointer`,transition:`background 180ms ease, border-color 180ms ease`,outline:`none`,padding:`0`});let o=document.createElement(`span`);Object.assign(o.style,{position:`absolute`,top:`2px`,left:`2px`,width:`18px`,height:`18px`,borderRadius:`50%`,background:ym.parchmentDim,transition:`transform 180ms ease, background 180ms ease`}),a.appendChild(o);let s=!!n;function c(){a.setAttribute(`aria-checked`,String(s)),o.style.transform=s?`translateX(22px)`:`translateX(0)`,o.style.background=s?ym.brass:ym.parchmentFaint,a.style.background=s?`rgba(176, 141, 63, 0.22)`:`rgba(0, 0, 0, 0.35)`,a.style.borderColor=s?ym.brass:ym.brassSoft}return c(),a.addEventListener(`click`,()=>{a.disabled||(s=!s,c(),r&&r(s))}),i.appendChild(a),{row:i,setValue(e){s=!!e,c()},setEnabled(e){a.disabled=!e,i.style.opacity=e?`1`:`0.4`,a.style.cursor=e?`pointer`:`default`}}}function Om(e,{interactive:t=!1}={}){let n=document.createElement(t?`button`:`span`);return t&&(n.type=`button`),n.textContent=e,Object.assign(n.style,{display:`inline-flex`,alignItems:`center`,justifyContent:`center`,minWidth:`54px`,padding:`5px 10px`,fontSize:`11px`,fontWeight:`700`,letterSpacing:`0.08em`,fontFamily:ym.sans,color:ym.parchment,background:`rgba(255, 255, 255, 0.05)`,border:`1px solid rgba(240, 230, 207, 0.18)`,borderRadius:`4px`,boxShadow:`inset 0 -2px 0 rgba(0, 0, 0, 0.35)`,cursor:t?`pointer`:`default`,outline:`none`,transition:`all 150ms ease`}),n}function km(e,t){let n=document.createElement(`div`);return n.id=e,Object.assign(n.style,{position:`fixed`,inset:`0`,zIndex:String(t),display:`none`,alignItems:`center`,justifyContent:`center`,background:`rgba(4, 5, 12, 0.72)`,backdropFilter:`blur(7px)`,WebkitBackdropFilter:`blur(7px)`,opacity:`0`,transition:`opacity 220ms ease`,userSelect:`none`,fontFamily:ym.sans,color:ym.parchment,colorScheme:`dark`}),_m(),n}var Am=`CHRONO EXPRESS`,jm=`THE LAST HEIST`;function Mm({camera:e,player:t,renderer:n,settingsMenu:r,unlockAudio:i,onCredits:a,isCreditsOpen:o}){let s=document.createElement(`div`);s.id=`main-menu`,Object.assign(s.style,{position:`fixed`,inset:`0`,zIndex:`50`,display:`flex`,flexDirection:`column`,alignItems:`center`,justifyContent:`flex-end`,opacity:`0`,transition:`opacity 600ms ease`,pointerEvents:`none`,userSelect:`none`,overflow:`hidden`});let c=document.createElement(`div`);Object.assign(c.style,{position:`absolute`,inset:`0`,background:[`linear-gradient(to bottom,`,`rgba(6, 6, 16, 0.58) 0%,`,`rgba(6, 6, 16, 0.26) 16%,`,`rgba(6, 6, 16, 0.04) 40%,`,`rgba(6, 6, 16, 0.55) 78%,`,`rgba(6, 6, 16, 0.90) 100%)`].join(` `),pointerEvents:`none`}),s.appendChild(c);for(let e of[`top`,`bottom`]){let t=document.createElement(`div`);Object.assign(t.style,{position:`absolute`,[e]:`0`,left:`0`,right:`0`,height:`clamp(18px, 4.5vh, 56px)`,background:`rgba(0, 0, 0, 0.55)`,pointerEvents:`none`}),s.appendChild(t)}let l=document.createElement(`div`);Object.assign(l.style,{display:`flex`,flexDirection:`column`,alignItems:`center`,gap:`0`,marginBottom:`auto`,marginTop:`clamp(80px, 16vh, 200px)`,opacity:`0`,transform:`translateY(24px)`,transition:`opacity 900ms ease 200ms, transform 900ms ease 200ms`});let u=document.createElement(`div`);Object.assign(u.style,{display:`flex`,alignItems:`center`,gap:`12px`,marginBottom:`14px`});let d=`width: clamp(24px, 6vw, 64px); height: 1px; background: rgba(176, 141, 63, 0.5);`,f=document.createElement(`div`);f.style.cssText=d;let p=document.createElement(`div`);p.style.cssText=d;let m=document.createElement(`span`);m.textContent=`A CHRONO HEIST`,Object.assign(m.style,{fontSize:`clamp(9px, 1.4vw, 12px)`,fontWeight:`600`,letterSpacing:`0.32em`,color:`rgba(176, 141, 63, 0.75)`,textTransform:`uppercase`}),u.append(f,m,p);let h=document.createElement(`h1`);h.textContent=Am,Object.assign(h.style,{margin:`0`,fontSize:`clamp(30px, 7.5vw, 86px)`,fontWeight:`800`,letterSpacing:`0.14em`,color:`#f0e6cf`,textShadow:[`0 0 60px rgba(255, 200, 100, 0.25)`,`0 2px 12px rgba(0, 0, 0, 0.85)`,`0 0 3px rgba(255, 220, 150, 0.45)`].join(`, `),textAlign:`center`,lineHeight:`1.05`,fontFamily:`Georgia, "Times New Roman", "Palatino Linotype", serif`});let g=document.createElement(`div`);g.textContent=jm,Object.assign(g.style,{fontSize:`clamp(11px, 2vw, 18px)`,fontWeight:`600`,letterSpacing:`0.5em`,color:`rgba(176, 141, 63, 0.8)`,marginTop:`clamp(6px, 1.2vh, 16px)`,textShadow:`0 1px 6px rgba(0, 0, 0, 0.7)`,textTransform:`uppercase`}),l.append(u,h,g);let _=document.createElement(`div`);Object.assign(_.style,{display:`flex`,flexDirection:`column`,alignItems:`center`,gap:`14px`,marginBottom:`clamp(60px, 13vh, 150px)`,opacity:`0`,transform:`translateY(18px)`,transition:`opacity 700ms ease 650ms, transform 700ms ease 650ms`});let v=xm(`New Game`,{variant:`primary`,size:`large`}),y=xm(`Settings`,{variant:`ghost`,onClick:()=>{i&&i(),r&&r.open(()=>{w&&v.focus()})}}),b=xm(`Credits`,{variant:`ghost`,onClick:()=>{i&&i(),a&&a()}}),x=document.createElement(`div`);x.textContent=`Click or press Enter to begin`,Object.assign(x.style,{fontSize:`clamp(10px, 1.2vw, 12px)`,color:`rgba(240, 230, 207, 0.30)`,letterSpacing:`0.1em`,fontWeight:`400`}),_.append(v,y,b,x);let S=document.createElement(`div`);S.textContent=`v0.1 — CGV Project`,Object.assign(S.style,{position:`absolute`,bottom:`clamp(8px, 1.5vh, 18px)`,right:`clamp(10px, 2vw, 20px)`,fontSize:`10px`,color:`rgba(240, 230, 207, 0.18)`,letterSpacing:`0.06em`,pointerEvents:`none`}),s.append(l,_,S),document.body.appendChild(s);let C=null,w=!1,T=!1,E=0;function D(){!w||T||r&&r.isOpen||o&&o()||(i&&i(),T=!0,setTimeout(()=>{j(),C&&setTimeout(()=>C(),650)},120))}v.addEventListener(`click`,D);function O(e){!w||T||r&&r.isOpen||o&&o()||(e.code===`Enter`||e.code===`Space`)&&(e.preventDefault(),D())}window.addEventListener(`keydown`,O);function k(){t?.setPose&&t.setPose(lm,lm.yaw)}function A(){w=!0,k(),T=!1,E=0,s.style.display=`flex`,s.style.pointerEvents=`auto`,s.offsetWidth,s.style.opacity=`1`,requestAnimationFrame(()=>{l.style.opacity=`1`,l.style.transform=`translateY(0)`,_.style.opacity=`1`,_.style.transform=`translateY(0)`}),setTimeout(()=>v.focus(),700)}function j(){w=!1,s.style.opacity=`0`,s.style.pointerEvents=`none`,setTimeout(()=>{s.style.display=`none`},650)}function ee(e){C=e}function M(t){if(!w)return;E+=t;let n=E,r=fm.driftSpeed,i=fm.position,a=fm.target;e.position.set(i.x+Math.sin(n*r)*fm.driftX,i.y+Math.sin(n*r*1.35+.6)*fm.driftY,i.z+Math.cos(n*r*.65)*fm.driftZ),e.lookAt(a.x,a.y,a.z)}function N(){window.removeEventListener(`keydown`,O),s.remove()}return{show:A,hide:j,onStart:ee,updateCinematicCamera:M,dispose:N,get isVisible(){return w}}}var Nm=[{id:`display`,label:`Display`},{id:`audio`,label:`Audio`},{id:`gameplay`,label:`Gameplay`},{id:`controls`,label:`Controls`}],Pm={display:`Display`,audio:`Audio`,gameplay:`Gameplay`},Fm=[{label:`Look Around`,keys:`Mouse`},{label:`Pause / Back`,keys:`Esc`},{label:`Re-capture Mouse`,keys:`Click`}];function Im(){let e=km(`settings-menu`,80),t=document.createElement(`div`);Object.assign(t.style,{display:`flex`,flexDirection:`column`,width:`min(92vw, 820px)`,maxHeight:`88vh`,background:`linear-gradient(180deg, rgba(12, 13, 22, 0.97), rgba(8, 8, 14, 0.97))`,border:`1px solid ${ym.brassSoft}`,borderRadius:`4px`,boxShadow:`0 30px 90px rgba(0, 0, 0, 0.7), inset 0 1px 0 rgba(240, 230, 207, 0.06)`,overflow:`hidden`,transform:`translateY(12px) scale(0.99)`,transition:`transform 220ms ease`});let n=document.createElement(`div`);Object.assign(n.style,{padding:`clamp(16px, 3vh, 26px) clamp(18px, 3.5vw, 34px) 0`,borderBottom:`1px solid ${ym.brassFaint}`});let r=document.createElement(`div`);Object.assign(r.style,{display:`flex`,alignItems:`baseline`,justifyContent:`space-between`,gap:`16px`,flexWrap:`wrap`});let i=document.createElement(`div`);i.textContent=`Saved automatically to this browser`,Object.assign(i.style,{fontSize:`11px`,letterSpacing:`0.16em`,textTransform:`uppercase`,color:ym.parchmentFaint}),r.append(Sm(`Settings`),i);let a=document.createElement(`div`);Object.assign(a.style,{display:`flex`,gap:`clamp(6px, 2vw, 20px)`,marginTop:`16px`});let o=Nm[0].id,s=new Map;for(let e of Nm){let t=document.createElement(`button`);t.type=`button`,t.textContent=e.label,Object.assign(t.style,{background:`none`,border:`none`,borderBottom:`2px solid transparent`,padding:`8px 4px`,fontSize:`12px`,fontWeight:`700`,letterSpacing:`0.2em`,textTransform:`uppercase`,color:ym.parchmentFaint,cursor:`pointer`,fontFamily:ym.sans,transition:`color 160ms ease, border-color 160ms ease`,outline:`none`}),t.addEventListener(`click`,()=>E(e.id)),t.addEventListener(`mouseenter`,()=>{o!==e.id&&(t.style.color=ym.parchmentDim)}),t.addEventListener(`mouseleave`,()=>{o!==e.id&&(t.style.color=ym.parchmentFaint)}),s.set(e.id,t),a.appendChild(t)}n.append(r,a);let c=document.createElement(`div`);Object.assign(c.style,{padding:`clamp(12px, 2.5vh, 22px) clamp(18px, 3.5vw, 34px)`,overflowY:`auto`,flex:`1 1 auto`,minHeight:`0`}),vm(c);let l=document.createElement(`div`);Object.assign(l.style,{display:`flex`,alignItems:`center`,justifyContent:`space-between`,gap:`12px`,padding:`clamp(12px, 2vh, 18px) clamp(18px, 3.5vw, 34px)`,borderTop:`1px solid ${ym.brassFaint}`,background:`rgba(0, 0, 0, 0.25)`});let u=xm(`Reset to Defaults`,{variant:`ghost`,size:`small`,onClick:()=>{o===`controls`?Y.resetBindings():Y.resetOptions(),T()}}),d=xm(`Back`,{variant:`primary`,onClick:()=>k()});l.append(u,d),t.append(n,c,l),e.appendChild(t),document.body.appendChild(e);let f=!1,p=null,m=null,h=document.createElement(`div`);Object.assign(h.style,{fontSize:`11px`,color:`rgba(176, 141, 63, 0.95)`,minHeight:`14px`,marginBottom:`6px`,opacity:`0`,transition:`opacity 200ms ease`});let g=null;function _(e){h.textContent=e,h.style.opacity=`1`,clearTimeout(g),g=setTimeout(()=>{h.style.opacity=`0`},2600)}function v(){clearTimeout(g),h.textContent=``,h.style.opacity=`0`}function y(e){let t=document.createElement(`div`),n=Sa.filter(t=>t.group===e),r=[];for(let e of n){let n={label:e.label,hint:e.hint,value:Y.get(e.id)},a=e.type===`toggle`?Dm({...n,onChange:t=>{Y.set(e.id,t),i()}}):e.type===`choice`?Tm({...n,choices:e.choices,onChange:t=>Y.set(e.id,t)}):Em({...n,min:e.min,max:e.max,step:e.step,format:e.format,onInput:t=>Y.set(e.id,t)});r.push({def:e,control:a}),t.appendChild(a.row)}function i(){for(let{def:e,control:t}of r)e.dependsOn&&t.setEnabled(!!Y.get(e.dependsOn))}return i(),t}function b(){let e=document.createElement(`div`),t=document.createElement(`div`);t.textContent=`Click a key to rebind it. Esc cancels, Backspace clears the slot.`,Object.assign(t.style,{fontSize:`11px`,color:ym.parchmentFaint,marginBottom:`14px`,letterSpacing:`0.04em`}),e.appendChild(t),e.appendChild(h);let n=[];for(let e of Ea){let t=n.find(t=>t.name===e.group);t||(t={name:e.group,actions:[]},n.push(t)),t.actions.push(e)}for(let t of n){let n=document.createElement(`div`);n.style.marginBottom=`18px`,n.appendChild(Cm(t.name));for(let e of t.actions)n.appendChild(x(e));e.appendChild(n)}let r=document.createElement(`div`);r.appendChild(Cm(`Fixed`));for(let e of Fm){let t=document.createElement(`div`);Object.assign(t.style,{display:`flex`,alignItems:`center`,justifyContent:`space-between`,padding:`8px 2px`,borderBottom:`1px solid rgba(240, 230, 207, 0.06)`,opacity:`0.55`});let n=document.createElement(`span`);n.textContent=e.label,Object.assign(n.style,{fontSize:`13px`,color:ym.parchment});let i=Om(e.keys);t.append(n,i),r.appendChild(t)}return e.appendChild(r),e}function x(e){let t=document.createElement(`div`);Object.assign(t.style,{display:`flex`,alignItems:`center`,justifyContent:`space-between`,gap:`16px`,padding:`7px 2px`,borderBottom:`1px solid rgba(240, 230, 207, 0.06)`});let n=document.createElement(`span`);n.textContent=e.label,Object.assign(n.style,{fontSize:`13px`,color:ym.parchment,fontWeight:`600`});let r=document.createElement(`div`);Object.assign(r.style,{display:`flex`,gap:`8px`,flex:`0 0 auto`});for(let t=0;t<2;t+=1){let n=Om(Aa(Y.getBinding(e.id)[t]),{interactive:!0});Y.getBinding(e.id)[t]||(n.style.color=ym.parchmentFaint),n.addEventListener(`mouseenter`,()=>{m||(n.style.borderColor=ym.brass,n.style.background=`rgba(176, 141, 63, 0.15)`)}),n.addEventListener(`mouseleave`,()=>{m&&m.cap===n||(n.style.borderColor=`rgba(240, 230, 207, 0.18)`,n.style.background=`rgba(255, 255, 255, 0.05)`)}),n.addEventListener(`click`,()=>S(e.id,t,n)),r.appendChild(n)}return t.append(n,r),t}function S(e,t,n){m&&C(),m={action:e,slot:t,cap:n},n.textContent=`Press a key…`,n.style.borderColor=ym.brass,n.style.background=`rgba(176, 141, 63, 0.25)`,n.style.color=`#fff5e0`}function C(){m&&(m=null,T())}function w(e){if(!m)return;let{action:t,slot:n}=m,r=e?Y.findConflict(e,t):null;if(Y.setBinding(t,n,e),m=null,T(),r){let t=Ea.find(e=>e.id===r);_(`${Aa(e)} was unbound from ${t?t.label:r}.`)}else e&&zu.has(e)&&_(Y.get(`captureShortcuts`)?`${Aa(e)} is a browser shortcut key; it only works fullscreen.`:`${Aa(e)} is a browser shortcut key. Turn on Capture Browser Shortcuts, or it may close the tab.`)}function T(){for(let e of Nm){let t=s.get(e.id),n=e.id===o;t.style.color=n?ym.parchment:ym.parchmentFaint,t.style.borderBottomColor=n?ym.brass:`transparent`}c.replaceChildren(),o===`controls`?(c.appendChild(b()),u.textContent=`Reset Key Bindings`):(c.appendChild(y(Pm[o]??`Display`)),u.textContent=`Reset to Defaults`)}function E(e){o!==e&&(C(),v(),o=e,c.scrollTop=0,T())}function D(e){if(f){if(e.stopPropagation(),m){e.preventDefault(),e.code===`Escape`?C():e.code===`Backspace`||e.code===`Delete`?w(null):Oa.includes(e.code)||w(e.code);return}e.code===`Escape`&&(e.preventDefault(),k())}}window.addEventListener(`keydown`,D,!0);function O(n){p=n??null,f=!0,o=Nm[0].id,v(),T(),e.style.display=`flex`,e.offsetWidth,e.style.opacity=`1`,t.style.transform=`translateY(0) scale(1)`}function k(){if(!f)return;f=!1,m=null,e.style.opacity=`0`,t.style.transform=`translateY(12px) scale(0.99)`,setTimeout(()=>{f||(e.style.display=`none`)},240);let n=p;p=null,n&&n()}function A(){clearTimeout(g),window.removeEventListener(`keydown`,D,!0),e.remove()}return{open:O,close:k,dispose:A,get isOpen(){return f}}}var Lm={Boarding:`Level 1 — Boarding the Express`,MovingHeist:`Level 2 — The Moving Heist`,Timewreck:`Level 3 — Timewreck`,Complete:`Heist Complete`},Rm=[`forward`,`run`,`jump`,`duck`,`interact`,`toggleView`,`slow`,`freeze`,`rewind`,`ghost`];function zm(e){let t=Math.max(0,Math.floor(e)),n=Math.floor(t/60);return`${String(n).padStart(2,`0`)}:${String(t%60).padStart(2,`0`)}`}function Bm({settingsMenu:e,getStatus:t,onPause:n,onResume:r,onRestart:i,onQuit:a,canPause:o}){let s=km(`pause-menu`,70),c=document.createElement(`div`);Object.assign(c.style,{display:`flex`,flexDirection:`column`,width:`min(92vw, 720px)`,maxHeight:`88vh`,background:`linear-gradient(180deg, rgba(12, 13, 22, 0.96), rgba(8, 8, 14, 0.96))`,border:`1px solid ${ym.brassSoft}`,borderRadius:`4px`,boxShadow:`0 30px 90px rgba(0, 0, 0, 0.7), inset 0 1px 0 rgba(240, 230, 207, 0.06)`,overflow:`hidden`,transform:`translateY(12px) scale(0.99)`,transition:`transform 220ms ease`});let l=document.createElement(`div`);Object.assign(l.style,{padding:`clamp(18px, 3.5vh, 28px) clamp(20px, 4vw, 34px) clamp(14px, 2vh, 18px)`,borderBottom:`1px solid ${ym.brassFaint}`,textAlign:`center`});let u=document.createElement(`div`);Object.assign(u.style,{marginTop:`8px`,fontSize:`12px`,letterSpacing:`0.24em`,textTransform:`uppercase`,color:`rgba(176, 141, 63, 0.9)`,fontWeight:`700`});let d=document.createElement(`div`);Object.assign(d.style,{marginTop:`8px`,fontSize:`13px`,color:ym.parchmentDim,fontStyle:`italic`,lineHeight:`1.5`}),l.append(Sm(`Paused`),u,d);let f=document.createElement(`div`);Object.assign(f.style,{display:`grid`,gridTemplateColumns:`repeat(auto-fit, minmax(240px, 1fr))`,gap:`clamp(16px, 3vw, 30px)`,padding:`clamp(16px, 3vh, 24px) clamp(20px, 4vw, 34px)`,overflowY:`auto`,flex:`1 1 auto`,minHeight:`0`}),vm(f);let p=document.createElement(`div`),m=document.createElement(`div`);p.appendChild(Cm(`Run Status`)),m.appendChild(Cm(`Controls`));let h=document.createElement(`div`);Object.assign(h.style,{display:`flex`,flexDirection:`column`,gap:`2px`}),p.appendChild(h);let g=document.createElement(`div`);Object.assign(g.style,{display:`flex`,flexDirection:`column`,gap:`2px`}),m.appendChild(g),f.append(p,m);function _(e,t,n){let r=document.createElement(`div`);Object.assign(r.style,{display:`flex`,flexDirection:`column`,gap:`5px`,padding:`8px 0`,borderBottom:`1px solid rgba(240, 230, 207, 0.06)`});let i=document.createElement(`div`);Object.assign(i.style,{display:`flex`,alignItems:`baseline`,justifyContent:`space-between`,gap:`12px`});let a=document.createElement(`span`);a.textContent=e,Object.assign(a.style,{fontSize:`12px`,color:ym.parchmentFaint,letterSpacing:`0.1em`,textTransform:`uppercase`});let o=document.createElement(`span`);if(o.textContent=t,Object.assign(o.style,{fontSize:`14px`,fontWeight:`700`,color:ym.parchment,fontVariantNumeric:`tabular-nums`}),i.append(a,o),r.appendChild(i),n){let e=document.createElement(`div`);Object.assign(e.style,{height:`4px`,borderRadius:`2px`,background:`rgba(255, 255, 255, 0.08)`,overflow:`hidden`});let t=document.createElement(`div`);Object.assign(t.style,{height:`100%`,width:`${Math.max(0,Math.min(100,n.percent))}%`,background:n.color,boxShadow:`0 0 8px ${n.color}`}),e.appendChild(t),r.appendChild(e)}h.appendChild(r)}function v(e,t){let n=document.createElement(`div`);Object.assign(n.style,{display:`flex`,alignItems:`center`,justifyContent:`space-between`,gap:`12px`,padding:`6px 0`,borderBottom:`1px solid rgba(240, 230, 207, 0.06)`});let r=document.createElement(`span`);r.textContent=e,Object.assign(r.style,{fontSize:`12px`,color:ym.parchmentDim}),n.append(r,Om(t)),g.appendChild(n)}let y=document.createElement(`div`);Object.assign(y.style,{display:`flex`,flexWrap:`wrap`,gap:`10px`,padding:`clamp(14px, 2.5vh, 20px) clamp(20px, 4vw, 34px)`,borderTop:`1px solid ${ym.brassFaint}`,background:`rgba(0, 0, 0, 0.25)`});let b=xm(`Resume`,{variant:`primary`,onClick:()=>k()}),x=xm(`Restart Level`,{variant:`ghost`,onClick:()=>{O(),i&&i()}}),S=xm(`Settings`,{variant:`ghost`,onClick:()=>{e.open(()=>{T&&b.focus()})}}),C=xm(`Quit to Title`,{variant:`danger`,onClick:()=>{O(),a&&a()}}),w=document.createElement(`div`);w.style.flex=`1 1 auto`,y.append(b,x,S,w,C),c.append(l,f,y),s.appendChild(c),document.body.appendChild(s);let T=!1;function E(){h.replaceChildren(),g.replaceChildren();let e=(t?t():null)??{};u.textContent=Lm[e.level]??`In Transit`,d.textContent=e.objective?`“${e.objective}”`:``,_(`Elapsed`,zm(e.elapsed??0));let n=e.maxEnergy||100,r=Math.round((e.energy??n)/n*100);_(`Chrono Power`,`${r}%`,{percent:r,color:`#38bdf8`});let i=Math.round(e.suspicion??0);_(`Suspicion`,`${i}%`,{percent:i,color:i>60?`#ef4444`:`#f59e0b`}),_(`Lives`,`${e.lives??3} / ${e.maxLives??3}`),_(`Checkpoint Resets`,String(e.resets??0));let a=e.timeMode&&e.timeMode!==`NORMAL`?e.timeMode:`Normal Flow`;_(`Time State`,a.charAt(0)+a.slice(1).toLowerCase());for(let e of Rm){let t=Ea.find(t=>t.id===e);if(t){if(e===`forward`){v(`Move`,[`forward`,`left`,`back`,`right`].map(e=>Y.getBinding(e)[0]).filter(Boolean).map(Aa).join(` `)||`Unbound`);continue}v(e===`duck`?`Crouch (${Y.get(`crouchMode`)===`hold`?`hold`:`toggle`})`:t.label,ja(Y.getBinding(e)))}}v(`Look`,`Mouse`),v(`Pause`,`Esc`)}function D(){T||(T=!0,E(),s.style.display=`flex`,s.offsetWidth,s.style.opacity=`1`,c.style.transform=`translateY(0) scale(1)`,setTimeout(()=>{T&&b.focus()},120))}function O(){T&&(T=!1,s.style.opacity=`0`,c.style.transform=`translateY(12px) scale(0.99)`,setTimeout(()=>{T||(s.style.display=`none`)},240))}function k(){O(),r&&r()}function A(){T||o&&!o()||(n?n():D())}function j(){T?k():A()}function ee(t){t.code!==`Escape`||t.repeat||e&&e.isOpen||(t.preventDefault(),j())}window.addEventListener(`keydown`,ee);function M(){window.removeEventListener(`keydown`,ee),s.remove()}return{open:D,close:O,toggle:j,requestOpen:A,dispose:M,get isOpen(){return T}}}var Vm=50,Hm=500;function Um(e,t){let n=document.createElement(`div`);Object.assign(n.style,{display:`flex`,flexDirection:`column`,alignItems:`center`,gap:`10px`,width:`100%`});for(let e of t)n.appendChild(e);return e.appendChild(n),n}function Wm(e,t=`clamp(22px, 4vw, 42px)`){let n=document.createElement(`div`);return n.textContent=e,Object.assign(n.style,{fontFamily:ym.serif,fontSize:t,fontWeight:`700`,letterSpacing:`0.18em`,color:ym.parchment,textTransform:`uppercase`,textShadow:`0 2px 12px rgba(0, 0, 0, 0.8)`,textAlign:`center`}),n}function Gm(e){let t=document.createElement(`div`);return t.textContent=e,Object.assign(t.style,{fontSize:`11px`,fontWeight:`700`,letterSpacing:`0.28em`,color:`rgba(176, 141, 63, 0.85)`,textTransform:`uppercase`,paddingBottom:`6px`,borderBottom:`1px solid ${ym.brassFaint}`,marginBottom:`4px`}),t}function Km(e,{dim:t=!1,italic:n=!1,size:r=`15px`}={}){let i=document.createElement(`div`);return i.textContent=e,Object.assign(i.style,{fontSize:r,lineHeight:`1.55`,letterSpacing:`0.04em`,color:t?ym.parchmentFaint:ym.parchmentDim,fontStyle:n?`italic`:`normal`,textAlign:`center`,maxWidth:`36em`}),i}function qm(e=36){let t=document.createElement(`div`);return t.style.height=`${e}px`,t}function Jm(){let e=document.createElement(`div`);Object.assign(e.style,{display:`flex`,flexDirection:`column`,alignItems:`center`,gap:`28px`,width:`min(92vw, 640px)`,padding:`0 24px 50vh`,textAlign:`center`,willChange:`transform`});let t=Um(e,[Wm(`Heist Complete`,`clamp(18px, 3.2vw, 32px)`),Km(`Completion Time: 00:00.0`,{size:`16px`})]);return t.dataset.heistComplete=`1`,t.style.display=`none`,t.lastElementChild.dataset.completionTime=`1`,Um(e,[Wm(`Chrono Express`),Km(`A Time-Manipulation Stealth Heist`,{size:`13px`})]),Um(e,[Gm(`Music`),Km(`All music by Kevin MacLeod (incompetech.com)`),Km(`Licensed under Creative Commons: By Attribution 4.0`,{dim:!0}),Km(`creativecommons.org/licenses/by/4.0/`,{dim:!0,size:`13px`}),qm(8),Km(`"Constance" — Level 1 (Boarding)`),Km(`"Mistake the Getaway" — Level 2 (Moving Heist)`),Km(`"Final Count" — Level 3 (Timewreck)`),Km(`"Vibing Over Venus" — Main Menu`),Km(`"Take a Chance" — Victory`)]),Um(e,[Gm(`Sound Effects`),Km(`"Freeze Sound Effect FX" by antonsoederberg (Freesound.org) — CC0`),Km(`"Quick Zoom Slow Down" by bevibeldesign (Freesound.org) — CC0`),Km(`"Vinyl Rewind" by tasmanianpower (Freesound.org) — CC0`),Km(`"Ghost Noise" by whiprealgood (Freesound.org) — CC0`)]),Um(e,[Gm(`3D Models & Animations`),Km(`"Character (Type Detective)" by LokitoBlu (Sketchfab)`),Km(`Licensed under Creative Commons Attribution 4.0`,{dim:!0}),qm(8),Km(`"Character (Type Male Police)" by LokitoBlu (Sketchfab)`),Km(`Licensed under Creative Commons Attribution 4.0`,{dim:!0}),qm(8),Km(`"Flashlight" by MAR.COS. (Sketchfab)`),Km(`Licensed under Creative Commons Attribution 4.0`,{dim:!0}),qm(8),Km(`Character animations from Adobe Mixamo (mixamo.com)`)]),Um(e,[Gm(`Cast & Crew`),Km(`[ Placeholder: add team names and roles here ]`,{italic:!0,dim:!0})]),Um(e,[Gm(`Additional Assets`),Km(`Physics library: cannon-es`),Km(`Built with Three.js`,{size:`13px`}),qm(8),Km(`Sky scattering adapted from the three.js Sky example`),Km(`Preetham daylight model (Rayleigh + Mie), MIT License`,{dim:!0}),Km(`github.com/mrdoob/three.js — examples/jsm/objects/Sky.js`,{dim:!0,size:`13px`}),qm(8),Km(`Nature models and surface textures from Poly Haven`),Km(`polyhaven.com — CC0`,{dim:!0}),Km(`Pine Sapling Small`,{size:`13px`}),Km(`Fir Sapling`,{size:`13px`}),Km(`Fir Sapling Medium`,{size:`13px`}),Km(`Pine Sapling Medium`,{size:`13px`}),Km(`Fern 02`,{size:`13px`}),Km(`Rock Moss Set 01`,{size:`13px`}),Km(`Rock Moss Set 02`,{size:`13px`}),Km(`Dead Tree Trunk`,{size:`13px`}),Km(`Tree Stump 01`,{size:`13px`}),Km(`Castle Brick 02 Red`,{size:`13px`}),Km(`Corrugated Iron`,{size:`13px`}),Km(`Forest Ground 01`,{size:`13px`}),Km(`Rock Face`,{size:`13px`})]),Um(e,[qm(24),Km(`Press any key to return to menu`,{size:`12px`})]),e}function Ym(e){let t=Math.max(0,Math.floor(e*10+1e-6)),n=Math.floor(t/600),r=Math.floor(t%600/10),i=t%10;return`${String(n).padStart(2,`0`)}:${String(r).padStart(2,`0`)}.${i}`}function Xm({onDismiss:e}={}){let t=km(`credits`,90);t.style.overflow=`hidden`,t.style.alignItems=`flex-start`,t.style.justifyContent=`center`;let n=Jm(),r=n.querySelector(`[data-heist-complete]`),i=n.querySelector(`[data-completion-time]`);t.appendChild(n),document.body.appendChild(t);let a=!1,o=`menu`,s=0;function c(){o===`complete`?(t.style.background=`rgba(0, 0, 0, 0.6)`,t.style.backdropFilter=`none`,t.style.WebkitBackdropFilter=`none`):(t.style.background=`rgba(4, 5, 12, 0.94)`,t.style.backdropFilter=`blur(7px)`,t.style.WebkitBackdropFilter=`blur(7px)`)}function l(){n.style.animation=`none`,n.offsetHeight;let e=n.offsetHeight+window.innerHeight,t=Math.max(12,e/Vm);n.style.animation=`cx-credits-roll ${t}s linear forwards`}function u({source:e=`menu`,completionTime:n}={}){a||(o=e,a=!0,s=performance.now()+Hm,o===`complete`&&n!=null&&Number.isFinite(n)?(r.style.display=`flex`,i.textContent=`Completion Time: ${Ym(n)}`):r.style.display=`none`,c(),t.style.display=`flex`,t.style.pointerEvents=`auto`,t.offsetWidth,t.style.opacity=`1`,l())}function d(){if(!a)return;a=!1,n.style.animation=`none`,t.style.opacity=`0`,t.style.pointerEvents=`none`;let r=o;setTimeout(()=>{a||(t.style.display=`none`)},220),e&&e(r)}function f(e){if(a){if(performance.now()<s){e&&e.stopPropagation();return}e&&(e.preventDefault(),e.stopPropagation()),d()}}function p(e){!a||e.repeat||f(e)}function m(e){f(e)}window.addEventListener(`keydown`,p,!0),t.addEventListener(`click`,m);function h(){window.removeEventListener(`keydown`,p,!0),t.remove()}return{open:u,close:d,dispose:h,get isOpen(){return a}}}var Zm=new Map,Qm=new Map;function $m(e,t){let n=Zm.get(e);return n||(n=t(),Zm.set(e,n)),n}function eh(e,t=e){let n=document.createElement(`canvas`);return n.width=e,n.height=t,n}function th(e){let t=e>>>0||1;return()=>(t=t*1664525+1013904223>>>0,t/4294967296)}function nh(e,t,n){let r=new Float32Array(t*t);for(let e=0;e<r.length;e++)r[e]=n();let i=e=>e*e*(3-2*e),a=new Float32Array(e*e),o=t/e;for(let n=0;n<e;n++){let s=n*o,c=Math.floor(s)%t,l=(c+1)%t,u=i(s-Math.floor(s));for(let s=0;s<e;s++){let d=s*o,f=Math.floor(d)%t,p=(f+1)%t,m=i(d-Math.floor(d)),h=r[c*t+f]*(1-m)+r[c*t+p]*m,g=r[l*t+f]*(1-m)+r[l*t+p]*m;a[n*e+s]=h*(1-u)+g*u}}return a}function rh(e,t,n,r=4){let i=new Float32Array(e*e),a=1,o=0,s=r;for(let r=0;r<t;r++){let t=nh(e,s,n);for(let e=0;e<i.length;e++)i[e]+=t[e]*a;o+=a,a*=.5,s*=2}for(let e=0;e<i.length;e++)i[e]/=o;return i}function ih(e,t,n){return e+(t-e)*n}function ah(e,t){let n=e.width,r=e.getContext(`2d`).getImageData(0,0,n,n).data,i=(e,t)=>{let i=(e+n)%n,a=((t+n)%n*n+i)*4;return(r[a]*.299+r[a+1]*.587+r[a+2]*.114)/255},a=eh(n),o=a.getContext(`2d`),s=o.createImageData(n,n);for(let e=0;e<n;e++)for(let r=0;r<n;r++){let a=(i(r-1,e)-i(r+1,e))*t,o=(i(r,e-1)-i(r,e+1))*t,c=Math.hypot(a,o,1),l=(e*n+r)*4;s.data[l]=(a/c*.5+.5)*255,s.data[l+1]=(o/c*.5+.5)*255,s.data[l+2]=(1/c*.5+.5)*255,s.data[l+3]=255}return o.putImageData(s,0,0),a}function oh(e,t,n){let r=`${e}:${n?`srgb`:`linear`}`,i=Qm.get(r);return i||(i=new mt(t),i.name=r,i.wrapS=Oe,i.wrapT=Oe,i.anisotropy=8,n&&(i.colorSpace=Me),i.userData.sharedTexture=!0,Qm.set(r,i)),i}function sh(e,t,n,{srgb:r=!0}={}){let i=oh(e,t,r).clone();return delete i.userData.sharedTexture,i.repeat.set(n[0],n[1]),i}function ch(e,t,n,r){let i=rh(e,4,th(t)),a=eh(e),o=a.getContext(`2d`),s=o.createImageData(e,e),c=new q(n),l=new q(r);for(let t=0;t<e;t++)for(let n=0;n<e;n++){let r=t*e+n,a=Math.sin(n/e*Math.PI*2*7+i[r]*7)*.5+.5,o=Math.min(1,a*.55+i[r]*.45),u=r*4;s.data[u]=ih(l.r,c.r,o)*255,s.data[u+1]=ih(l.g,c.g,o)*255,s.data[u+2]=ih(l.b,c.b,o)*255,s.data[u+3]=255}return o.putImageData(s,0,0),a}function lh(e,t,n,r,i,a){let o=rh(e,5,th(t)),s=eh(e),c=s.getContext(`2d`),l=c.createImageData(e,e),u=new q(n),d=new q(r),f=new q(i),p=e/a;for(let t=0;t<e;t++)for(let n=0;n<e;n++){let r=t*e+n,i=(1-Math.abs(o[r]*2-1))**6,a=ih(u.r,d.r,i),s=ih(u.g,d.g,i),c=ih(u.b,d.b,i),m=Math.min(n%p,p-n%p,t%p,p-t%p);if(m<2.5){let e=1-m/2.5;a=ih(a,f.r,e),s=ih(s,f.g,e),c=ih(c,f.b,e)}let h=r*4;l.data[h]=a*255,l.data[h+1]=s*255,l.data[h+2]=c*255,l.data[h+3]=255}return c.putImageData(l,0,0),s}function uh(e,t,n,r){let i=th(t),a=rh(e,5,i,32),o=rh(e,3,i,4),s=eh(e),c=s.getContext(`2d`),l=c.createImageData(e,e),u=new q(n),d=new q(r);for(let t=0;t<e;t++)for(let n=0;n<e;n++){let r=t*e+n,i=Math.abs(Math.sin(n/e*Math.PI*8)*Math.sin(t/e*Math.PI*8)),s=Math.min(1,i**3*.55+o[r]*.2),c=.82+a[r]*.36,f=r*4;l.data[f]=ih(u.r,d.r,s)*c*255,l.data[f+1]=ih(u.g,d.g,s)*c*255,l.data[f+2]=ih(u.b,d.b,s)*c*255,l.data[f+3]=255}return c.putImageData(l,0,0),s}function dh(e,t,n){let r=th(t),i=rh(e,4,r,64),a=rh(e,3,r,6),o=eh(e),s=o.getContext(`2d`),c=s.createImageData(e,e),l=new q(n);for(let t=0;t<e;t++)for(let n=0;n<e;n++){let r=t*e+n,o=.78+i[t*e+n*3%e]*.3+a[r]*.12,s=r*4;c.data[s]=Math.min(255,l.r*o*255),c.data[s+1]=Math.min(255,l.g*o*255),c.data[s+2]=Math.min(255,l.b*o*255),c.data[s+3]=255}return s.putImageData(c,0,0),o}function fh(e,t,n){let r=rh(e,5,th(t),8),i=eh(e),a=i.getContext(`2d`),o=a.createImageData(e,e),s=new q(n);for(let t=0;t<e;t++)for(let n=0;n<e;n++){let i=t*e+n,a=.86+r[i]*.28,c=i*4;o.data[c]=Math.min(255,s.r*a*255),o.data[c+1]=Math.min(255,s.g*a*255),o.data[c+2]=Math.min(255,s.b*a*255),o.data[c+3]=255}return a.putImageData(o,0,0),i}function ph(e,t,n){let r=th(n),i=eh(e,t),a=i.getContext(`2d`),o=a.createLinearGradient(0,0,0,t);o.addColorStop(0,`#131a2e`),o.addColorStop(.55,`#0d1120`),o.addColorStop(1,`#070a12`),a.fillStyle=o,a.fillRect(0,0,e,t);for(let n=0;n<90;n++){let n=r()*e,i=t*(.25+r()*.6),o=12+r()*70,s=.12+r()*.5,c=r()>.35,l=a.createLinearGradient(n,i,n+o,i),u=c?`255,196,120`:`150,190,255`;l.addColorStop(0,`rgba(${u},0)`),l.addColorStop(.5,`rgba(${u},${s})`),l.addColorStop(1,`rgba(${u},0)`),a.fillStyle=l,a.fillRect(n,i-1,o,2+r()*2)}a.fillStyle=`#05070d`,a.beginPath(),a.moveTo(0,t);for(let n=0;n<=e;n+=16)a.lineTo(n,t*(.78+Math.sin(n*.03)*.05+r()*.03));return a.lineTo(e,t),a.closePath(),a.fill(),i}function mh(e,t){e.font=`700 ${t}px Arial, Helvetica, sans-serif`}function hh(e,t,n,r){let i=r;for(mh(e,i);i>18&&e.measureText(t).width>n;)i-=2,mh(e,i);return i}function gh(e,t,n,r,i){let a=eh(r,i),o=a.getContext(`2d`),s=`#${new q(t).getHexString()}`,c=`#${new q(n).getHexString()}`;o.fillStyle=s,o.fillRect(0,0,r,i);let l=Math.max(10,Math.floor(r*.035));o.strokeStyle=c,o.lineWidth=Math.max(3,Math.floor(i*.035)),o.strokeRect(l*.45,l*.45,r-l*.9,i-l*.9);let u=r-l*2;o.textAlign=`center`,o.textBaseline=`middle`,o.fillStyle=c;let d=e.indexOf(` - `),f=[e],p=hh(o,e,u,Math.floor(i*.46));d>0&&p<i*.3&&(f=[e.slice(0,d),e.slice(d+3)],p=Math.min(hh(o,f[0],u,Math.floor(i*.34)),hh(o,f[1],u,Math.floor(i*.34)))),mh(o,p);let m=p*1.15,h=i/2-(f.length-1)*m/2;o.lineWidth=Math.max(3,p*.12),o.strokeStyle=`#140e08`;for(let e=0;e<f.length;e+=1){let t=h+e*m;o.strokeText(f[e],r/2,t),o.fillText(f[e],r/2,t)}return a}function _h({repeat:e=[1,1],seed:t=11,light:n=9067059,dark:r=4860951,roughness:i=.62}={}){let a=`wood:${t}:${n}:${r}`,o=$m(a,()=>ch(256,t,n,r)),s=$m(`${a}:n`,()=>ah(o,1.4));return new x({map:sh(a,o,e),normalMap:sh(`${a}:n`,s,e,{srgb:!1}),roughness:i,metalness:.04})}function vh({repeat:e=[1,1],seed:t=23,base:n=12102551,vein:r=7168597,grout:i=4866616,tiles:a=4,roughness:o=.82}={}){let s=`marble:${t}:${n}:${r}:${a}`,c=$m(s,()=>lh(512,t,n,r,i,a)),l=$m(`${s}:n`,()=>ah(c,2.2));return new x({map:sh(s,c,e),normalMap:sh(`${s}:n`,l,e,{srgb:!1}),roughness:o,metalness:.02})}function yh({repeat:e=[1,1],seed:t=37,base:n=6038064,accent:r=9263668}={}){let i=`carpet:${t}:${n}:${r}`,a=$m(i,()=>uh(256,t,n,r)),o=$m(`${i}:n`,()=>ah(a,2.6));return new x({map:sh(i,a,e),normalMap:sh(`${i}:n`,o,e,{srgb:!1}),roughness:.94,metalness:0})}function bh({repeat:e=[1,1],seed:t=53,base:n=9211798,roughness:r=.42,metalness:i=.85}={}){let a=`metal:${t}:${n}`,o=$m(a,()=>dh(256,t,n)),s=$m(`${a}:n`,()=>ah(o,1.1));return new x({map:sh(a,o,e),normalMap:sh(`${a}:n`,s,e,{srgb:!1}),roughness:r,metalness:i})}function xh(e,t,n,r){let i=eh(e),a=i.getContext(`2d`),o=th(t);a.fillStyle=`#${new q(n).getHexString()}`,a.fillRect(0,0,e,e);let s=e/8,c=e/20,l=new q(r);for(let e=0;e<20;e+=1){let t=e%2?s*.5:0;for(let n=-1;n<=8;n+=1){let r=.78+o()*.32,i=Math.min(255,l.r*r*255),u=Math.min(255,l.g*r*255),d=Math.min(255,l.b*r*255);a.fillStyle=`rgb(${i|0},${u|0},${d|0})`,a.fillRect(n*s+t+1.5,e*c+1.5,s-3,c-3)}}return i}function Sh({repeat:e=[1,1],seed:t=17,mortar:n=6972508,brick:r=8010546,roughness:i=.86}={}){let a=`brick:${t}:${n}:${r}`,o=$m(a,()=>xh(256,t,n,r)),s=$m(`${a}:n`,()=>ah(o,2.4));return new x({map:sh(a,o,e),normalMap:sh(`${a}:n`,s,e,{srgb:!1}),roughness:i,metalness:.02})}function Ch({repeat:e=[1,1],seed:t=71,base:n=10984586,roughness:r=.82}={}){let i=`plaster:${t}:${n}`,a=$m(i,()=>fh(256,t,n)),o=$m(`${i}:n`,()=>ah(a,1.6));return new x({map:sh(i,a,e),normalMap:sh(`${i}:n`,o,e,{srgb:!1}),roughness:r,metalness:.02})}function wh({repeat:e=[1,1],seed:t=91,emissiveIntensity:n=.9}={}){let r=`night:${t}`,i=$m(r,()=>ph(512,256,t));return new x({map:sh(r,i,e),emissiveMap:sh(r,i,e),emissive:16777215,emissiveIntensity:n,roughness:.15,metalness:0})}function Th({text:e=`PLATFORM 1`,background:t=1315085,foreground:n=14267486,width:r=512,height:i=128,emissiveIntensity:a=1.1}={}){let o=`sign:${e}:${t}:${n}:${r}x${i}`,s=$m(o,()=>gh(e,t,n,r,i));return new x({map:sh(o,s,[1,1]),emissiveMap:sh(o,s,[1,1]),emissive:16777215,emissiveIntensity:a,roughness:.5,metalness:.2})}var Eh=new Map,Dh=new WeakMap;function Oh(){return Ph(`platform-stone`,()=>{let e=jh(512),t=e.getContext(`2d`),n=Mh(181);t.fillStyle=`#383631`,t.fillRect(0,0,512,512);for(let e=0;e<4;e++)for(let r=-1;r<3;r++){let i=r*256+e%2*128;t.fillStyle=Nh(10127986,.83+n()*.22),t.fillRect(i+2,e*128+2,252,124)}return Lh(t,512,n,2600,3156772,.12,2),e})}function kh(){return Ph(`platform-paving`,()=>{let e=jh(512),t=e.getContext(`2d`),n=Mh(182);t.fillStyle=`#24272b`,t.fillRect(0,0,512,512);for(let e=0;e<4;e++)for(let r=0;r<2;r++)t.fillStyle=Nh(7828330,.62+n()*.25),t.fillRect(r*256+2,e*128+2,252,124);return Lh(t,512,n,3e3,2238772,.14,3),e})}function Ah(){return Ph(`platform-chrono-poster`,()=>{let e=jh(512,768),t=e.getContext(`2d`);t.fillStyle=`#101c23`,t.fillRect(0,0,512,768);for(let e=0;e<4;e++)t.fillStyle=[`#8c7753`,`#6a6353`,`#414c48`,`#26383c`][e],t.beginPath(),t.moveTo(0,390+e*75),t.lineTo(160,245+e*70),t.lineTo(290,380+e*30),t.lineTo(420,270+e*80),t.lineTo(512,370+e*70),t.lineTo(512,768),t.lineTo(0,768),t.fill();return t.fillStyle=`#10171a`,t.fillRect(130,525,295,90),t.beginPath(),t.arc(400,567,53,0,Math.PI*2),t.fill(),t.fillRect(370,460,30,65),t.strokeStyle=`#d3b37b`,t.lineWidth=5,t.strokeRect(16,16,480,736),t.fillStyle=`#dfbd81`,t.textAlign=`center`,t.font=`52px Georgia`,t.fillText(`CHRONO`,256,110),t.fillText(`EXPRESS`,256,175),t.font=`19px Georgia`,t.fillText(`THE NIGHT BELONGS TO YOU`,256,710),e})}function jh(e,t=e){let n=document.createElement(`canvas`);return n.width=e,n.height=t,n}function Mh(e){let t=e>>>0;return()=>(t=t*1664525+1013904223>>>0,t/4294967296)}function Nh(e,t=1,n=1){let r=new q(e);return`rgba(${Math.min(255,Math.max(0,r.r*t*255))|0},${Math.min(255,Math.max(0,r.g*t*255))|0},${Math.min(255,Math.max(0,r.b*t*255))|0},${n})`}function Ph(e,t){return Eh.has(e)||Eh.set(e,t()),Eh.get(e)}function Fh(e,t){let{width:n,height:r}=e,i=jh(n,r),a=e.getContext(`2d`).getImageData(0,0,n,r).data,o=i.getContext(`2d`),s=o.createImageData(n,r),c=s.data;if(!c||!a)return i;let l=(e,t)=>{let i=((t+r)%r*n+(e+n)%n)*4;return(a[i]+a[i+1]+a[i+2])/765};for(let e=0;e<r;e+=1)for(let r=0;r<n;r+=1){let i=(l(r+1,e)-l(r-1,e))*t,a=(l(r,e+1)-l(r,e-1))*t,o=Math.hypot(i,a,1),s=(e*n+r)*4;c[s]=(-i/o*.5+.5)*255,c[s+1]=(a/o*.5+.5)*255,c[s+2]=(1/o*.5+.5)*255,c[s+3]=255}return o.putImageData(s,0,0),i}function Ih(e,t,{repeat:n=[1,1],srgb:r=!0,normal:i=0}={}){let a=Ph(e,t),o=i?Ph(`${e}:n${i}`,()=>Fh(a,i)):a,s=new mt(o),c=Dh.get(o);return c?s.source=c:Dh.set(o,s.source),s.wrapS=Oe,s.wrapT=Oe,s.repeat.set(n[0],n[1]),s.anisotropy=4,r&&!i&&(s.colorSpace=Me),s}function Lh(e,t,n,r,i,a,o){for(let s=0;s<r;s+=1){e.fillStyle=Nh(i,.7+n()*.6,a*n());let r=o*(.3+n());e.fillRect(n()*t,n()*t,r,r)}}function Rh(e,t,n,r,i){e.strokeStyle=Nh(r,1,i),e.lineWidth=.6+n()*1.4,e.beginPath();let a=n()*t,o=n()*t;e.moveTo(a,o);for(let r=0;r<6;r+=1)a+=(n()-.3)*t*.25,o+=(n()-.5)*t*.25,e.lineTo(a,o);e.stroke()}function zh(e=0){return Ph(`station-window:${e}`,()=>{let t=jh(256,512),n=t.getContext(`2d`),r=n.createLinearGradient(0,0,256,512);if(r.addColorStop(0,`#e8c78c`),r.addColorStop(.55,`#b99559`),r.addColorStop(1,`#756044`),n.fillStyle=r,n.fillRect(0,0,256,512),e===1)for(let e of[0,1]){n.fillStyle=`#59402c`,n.beginPath(),n.moveTo(e?256:0,0),n.lineTo(e?186:70,0),n.quadraticCurveTo(e?216:40,210,e?242:14,460),n.lineTo(e?256:0,512),n.closePath(),n.fill(),n.strokeStyle=`#846349`,n.lineWidth=3;for(let t=8;t<65;t+=12)n.beginPath(),n.moveTo(e?256-t:t,0),n.lineTo(e?256-t*.22:t*.22,490),n.stroke()}else if(e===2){n.fillStyle=`#9c8055`,n.fillRect(0,0,256,300),n.strokeStyle=`#564934`,n.lineWidth=3;for(let e=10;e<300;e+=16)n.beginPath(),n.moveTo(0,e),n.lineTo(256,e),n.stroke();n.fillStyle=`#352e25`,n.fillRect(190,0,2,328)}return Lh(n,256,Mh(903+e),180,3746330,.09,2),t})}function Bh(){return Ph(`checker`,()=>{let e=jh(512),t=e.getContext(`2d`),n=Mh(41);for(let e=0;e<4;e+=1)for(let r=0;r<4;r+=1){let i=(e+r)%2==1;t.fillStyle=Nh(i?2894638:14208178,.94+n()*.1),t.fillRect(r*128,e*128,128,128),t.save(),t.beginPath(),t.rect(r*128,e*128,128,128),t.clip();for(let e=0;e<4;e+=1)Rh(t,512,n,i?7828588:10260344,i?.35:.3);t.restore(),t.fillStyle=`rgba(255,255,255,0.08)`,t.fillRect(r*128,e*128,128,3),t.fillRect(r*128,e*128,3,128),t.fillStyle=`rgba(0,0,0,0.25)`,t.fillRect(r*128,e*128+128-3,128,3),t.fillRect(r*128+128-3,e*128,3,128)}return Lh(t,512,n,1400,0,.06,1.5),e})}function Vh(){return Ph(`glazed-brick`,()=>{let e=jh(256),t=e.getContext(`2d`),n=Mh(7);t.fillStyle=Nh(9405811),t.fillRect(0,0,256,256);let r=256/6;for(let e=0;e<6;e+=1){let i=e%2?64:0;for(let a=-1;a<=2;a+=1){let o=a*128+i+2,s=e*r+2,c=.9+n()*.14,l=t.createLinearGradient(o,s,o,s+r);l.addColorStop(0,Nh(15129796,c*1.05)),l.addColorStop(.5,Nh(14273969,c)),l.addColorStop(1,Nh(12892055,c*.95)),t.fillStyle=l,t.fillRect(o,s,124,38.666666666666664),t.fillStyle=`rgba(255,255,255,0.18)`,t.fillRect(o+3,s+2,116,2),n()<.25&&(t.fillStyle=Nh(7037006,1,.5),t.fillRect(o+n()*128,s+n()*r*.6,2+n()*4,1+n()*3))}}let i=t.createLinearGradient(0,140.8,0,256);return i.addColorStop(0,`rgba(40,32,20,0)`),i.addColorStop(1,`rgba(40,32,20,0.12)`),t.fillStyle=i,t.fillRect(0,0,256,256),e})}function Hh(){return Ph(`green-tile`,()=>{let e=jh(256),t=e.getContext(`2d`),n=Mh(13);t.fillStyle=Nh(857360),t.fillRect(0,0,256,256);for(let e=0;e<8;e+=1)for(let r=0;r<4;r+=1){let i=r*64+1.5,a=e*32+1.5,o=.82+n()*.3,s=t.createLinearGradient(i,a,i,a+32);s.addColorStop(0,Nh(3107408,o)),s.addColorStop(.4,Nh(2051128,o)),s.addColorStop(1,Nh(1390118,o)),t.fillStyle=s,t.fillRect(i,a,61,29),t.fillStyle=`rgba(255,255,255,0.22)`,t.fillRect(i+2,a+1.5,56,1.5)}return e})}function Uh(e){let t=jh(512),n=t.getContext(`2d`),r=Mh(29);n.fillStyle=e?`#c8c8c8`:Nh(5196871),n.fillRect(0,0,512,512),e||Lh(n,512,r,5e3,10130570,.18,2.2),e||Lh(n,512,r,3e3,1710102,.25,2);let i=Mh(31);for(let t=0;t<9;t+=1){let t=i()*512,r=i()*512,a=30+i()*90,o=n.createRadialGradient(t,r,a*.2,t,r,a);o.addColorStop(0,e?`rgba(20,20,20,0.95)`:`rgba(18,16,14,0.45)`),o.addColorStop(1,e?`rgba(20,20,20,0)`:`rgba(18,16,14,0)`),n.fillStyle=o,n.beginPath(),n.ellipse(t,r,a,a*(.5+i()*.5),i()*Math.PI,0,Math.PI*2),n.fill()}if(n.fillStyle=e?`rgba(255,255,255,0.6)`:`rgba(10,9,8,0.7)`,n.fillRect(0,255,512,2),n.fillRect(255,0,2,512),n.fillRect(0,0,512,2),n.fillRect(0,0,2,512),!e){n.strokeStyle=`rgba(12,10,9,0.55)`;for(let e=0;e<5;e+=1){n.lineWidth=.8,n.beginPath();let e=r()*512,t=r()*512;n.moveTo(e,t);for(let i=0;i<8;i+=1)e+=(r()-.5)*40,t+=(r()-.5)*40,n.lineTo(e,t);n.stroke()}}return t}function Wh(){return Ph(`concrete`,()=>Uh(!1))}function Gh(){return Ph(`concrete-rough`,()=>Uh(!0))}function Kh(){return Ph(`crate`,()=>{let e=jh(256),t=e.getContext(`2d`),n=Mh(17);for(let e=0;e<4;e+=1){t.fillStyle=Nh(8018486,.85+n()*.25),t.fillRect(0,e*64,256,62);for(let r=0;r<18;r+=1)t.fillStyle=Nh(4074006,1,.25),t.fillRect(0,e*64+n()*62,256,1)}return t.fillStyle=Nh(2759696),t.fillRect(0,0,256,10),t.fillRect(0,246,256,10),t.fillRect(0,0,10,256),t.fillRect(246,0,10,256),t.save(),t.translate(128,128),t.fillStyle=`rgba(28,20,12,0.75)`,t.font=`bold 30px serif`,t.textAlign=`center`,t.textBaseline=`middle`,t.fillText(`CHRONO`,0,-36),t.fillText(`EXPRESS`,0,-4),t.font=`bold 18px serif`,t.fillText(`FRAGILE · ↑ ↑`,0,34),t.lineWidth=3,t.strokeStyle=`rgba(28,20,12,0.7)`,t.beginPath(),t.arc(0,-20,64,0,Math.PI*2),t.stroke(),t.restore(),e})}var qh=[{title:`CHRONO EXPRESS`,line:`PARIS · VIENNE · ISTANBUL`,sky:[1911378,14714714],ground:1709076,accent:15777888},{title:`RIVIERA`,line:`LE TRAIN BLEU`,sky:[2779802,16044698],ground:2047578,accent:16777215},{title:`ALPENBLICK`,line:`SCHNELLZUG · 1934`,sky:[3229534,14279916],ground:2767662,accent:15259816}],Jh=qh.length;function Yh(e){return Ph(`poster:${e}`,()=>{let t=qh[e%qh.length],n=jh(256,384),r=n.getContext(`2d`),i=r.createLinearGradient(0,0,0,384*.7);i.addColorStop(0,Nh(t.sky[0])),i.addColorStop(1,Nh(t.sky[1])),r.fillStyle=i,r.fillRect(0,0,256,384),r.fillStyle=Nh(t.accent,1,.85),r.beginPath(),r.arc(184.32,84.48,26,0,Math.PI*2),r.fill(),r.fillStyle=Nh(t.ground,1.3),r.beginPath(),r.moveTo(0,384*.62),r.lineTo(76.8,161.28),r.lineTo(133.12,384*.56),r.lineTo(199.68,384*.38),r.lineTo(256,384*.58),r.lineTo(256,384),r.lineTo(0,384),r.fill(),r.fillStyle=Nh(t.ground,.6),r.fillRect(0,261.12,256,384),r.fillStyle=`#0c0b0c`,r.fillRect(35.84,384*.6,128,23.04),r.fillRect(122.88,384*.55,35.84,23.04),r.fillRect(51.2,218.88,12.8,15.36);for(let e=0;e<4;e+=1)r.beginPath(),r.arc(56.32-e*18,384*.62-6,7,0,Math.PI*2),r.fill();r.fillStyle=`rgba(230,230,230,0.5)`;for(let e=0;e<5;e+=1)r.beginPath(),r.arc(56.32+e*22,207.36-e*9,10+e*4,0,Math.PI*2),r.fill();return r.fillStyle=Nh(t.ground,.35),r.fillRect(0,384*.74,256,99.84),r.fillStyle=Nh(t.accent),r.textAlign=`center`,r.font=`bold 34px serif`,r.fillText(t.title,128,330.24,232),r.font=`15px serif`,r.fillText(t.line,128,357.12,232),r.strokeStyle=Nh(t.accent,1,.8),r.lineWidth=4,r.strokeRect(8,8,240,368),n})}function Xh(){return Ph(`clock-face`,()=>{let e=jh(256),t=e.getContext(`2d`);t.fillStyle=`#efe6cf`,t.fillRect(0,0,256,256),t.strokeStyle=`#1b1a18`,t.fillStyle=`#1b1a18`;for(let e=0;e<60;e+=1){let n=e/60*Math.PI*2,r=e%5==0;t.lineWidth=r?5:2,t.beginPath(),t.moveTo(128+Math.sin(n)*118,128-Math.cos(n)*118),t.lineTo(128+Math.sin(n)*(128-(r?30:18)),128-Math.cos(n)*(128-(r?30:18))),t.stroke()}t.font=`bold 26px serif`,t.textAlign=`center`,t.textBaseline=`middle`;for(let e=1;e<=12;e+=1){let n=e/12*Math.PI*2;t.fillText(String(e),128+Math.sin(n)*78,128-Math.cos(n)*78)}let n=(e,n,r)=>{t.lineWidth=r,t.lineCap=`round`,t.beginPath(),t.moveTo(128,128),t.lineTo(128+Math.sin(e)*n,128-Math.cos(e)*n),t.stroke()};return n(11.66/12*Math.PI*2,64,8),n(40/60*Math.PI*2,99.84,5),t.beginPath(),t.arc(128,128,7,0,Math.PI*2),t.fill(),e})}function Zh(){return Ph(`departures`,()=>{let e=jh(512,256),t=e.getContext(`2d`);return t.fillStyle=`#0b0c0e`,t.fillRect(0,0,512,256),t.fillStyle=`#e8b44a`,t.font=`bold 30px monospace`,t.fillText(`DEPARTURES`,18,38),t.font=`22px monospace`,[[`23:40`,`CHRONO EXPRESS`,`1`],[`23:55`,`VIENNE`,`3`],[`00:10`,`MARSEILLE`,`2`],[`00:25`,`BRUXELLES`,`4`],[`00:40`,`MILANO`,`5`]].forEach((e,n)=>{let r=82+n*36;t.fillStyle=n===0?`#ffd27a`:`#c99a3e`,t.fillText(e[0],18,r),t.fillText(e[1],120,r),t.fillText(e[2],472,r),t.fillStyle=`rgba(255,255,255,0.05)`,t.fillRect(10,r+8,492,1)}),e})}function Qh(){return Ph(`steel-door`,()=>{let e=jh(512),t=e.getContext(`2d`),n=Mh(61);t.fillStyle=Nh(3817277),t.fillRect(0,0,512,512),Lh(t,512,n,4e3,5922908,.15,2);for(let[e,n,r,i]of[[40,40,432,190],[40,282,432,190]])t.fillStyle=Nh(3159354),t.fillRect(e,n,r,i),t.fillStyle=`rgba(0,0,0,0.55)`,t.fillRect(e,n,r,6),t.fillRect(e,n,6,i),t.fillStyle=`rgba(255,255,255,0.12)`,t.fillRect(e,n+i-4,r,4),t.fillRect(e+r-4,n,4,i);for(let e of[18,256,494])for(let n=22;n<512;n+=32){let r=t.createRadialGradient(n-2,e-2,1,n,e,7);r.addColorStop(0,`#9aa09c`),r.addColorStop(1,`#1c1f1e`),t.fillStyle=r,t.beginPath(),t.arc(n,e,6,0,Math.PI*2),t.fill()}for(let e of[18,494])for(let n=50;n<482;n+=32){let r=t.createRadialGradient(e-2,n-2,1,e,n,7);r.addColorStop(0,`#9aa09c`),r.addColorStop(1,`#1c1f1e`),t.fillStyle=r,t.beginPath(),t.arc(e,n,6,0,Math.PI*2),t.fill()}t.strokeStyle=`rgba(170,175,170,0.35)`;for(let e=0;e<60;e+=1){t.lineWidth=.5+n(),t.beginPath();let e=n()*512,r=n()*512;t.moveTo(e,r),t.lineTo(e+(n()-.5)*60,r+(n()-.5)*18),t.stroke()}t.fillStyle=`rgba(110,84,60,0.25)`;for(let e=0;e<30;e+=1)t.beginPath(),t.arc(n()*512,512-n()*60,2+n()*8,0,Math.PI*2),t.fill();return e})}function $h(){return Ph(`hazard`,()=>{let e=jh(256,32),t=e.getContext(`2d`);t.fillStyle=`#d99a1c`,t.fillRect(0,0,256,32),t.fillStyle=`#121212`;for(let e=-32;e<288;e+=32)t.beginPath(),t.moveTo(e,32),t.lineTo(e+16,32),t.lineTo(e+16+32,0),t.lineTo(e+32,0),t.fill();t.fillStyle=`rgba(0,0,0,0.25)`;let n=Mh(5);for(let e=0;e<80;e+=1)t.fillRect(n()*256,n()*32,2+n()*4,1);return e})}function eg(e,{width:t=512,height:n=64,color:r=`#e7dcc0`}={}){return Ph(`stencil:${e}:${r}`,()=>{let i=jh(t,n),a=i.getContext(`2d`);a.clearRect(0,0,t,n),a.fillStyle=r,a.font=`bold ${Math.floor(n*.62)}px monospace`,a.textAlign=`center`,a.textBaseline=`middle`,a.fillText(e,t/2,n/2,t-16),a.globalCompositeOperation=`destination-out`;for(let e=6;e<t;e+=23)a.fillRect(e,n*.47,2,n*.08);return i})}function tg(){return Ph(`night-platform`,()=>{let e=jh(512,256),t=e.getContext(`2d`),n=t.createLinearGradient(0,0,0,256);n.addColorStop(0,`#0b1430`),n.addColorStop(.6,`#1d2a52`),n.addColorStop(1,`#2a2440`),t.fillStyle=n,t.fillRect(0,0,512,256);let r=Mh(3);for(let e=0;e<70;e+=1)t.fillStyle=`rgba(255,255,255,${.3+r()*.6})`,t.fillRect(r()*512,r()*256*.5,1,1);let i=t.createRadialGradient(399.36,51.2,4,399.36,51.2,40);i.addColorStop(0,`rgba(255,250,230,1)`),i.addColorStop(.35,`rgba(255,250,230,0.9)`),i.addColorStop(.4,`rgba(200,210,255,0.25)`),i.addColorStop(1,`rgba(200,210,255,0)`),t.fillStyle=i,t.fillRect(307.2,0,204.8,128),t.fillStyle=`#0a0c14`,t.fillRect(0,107.52,153.6,51.2),t.beginPath(),t.moveTo(0,107.52),t.lineTo(76.8,76.8),t.lineTo(153.6,107.52),t.fill(),t.fillStyle=`#12261c`,t.fillRect(0,140.8,512,64),t.fillStyle=`#0c1912`,t.fillRect(0,133.12,512,10.24);for(let e=12;e<512;e+=46)t.fillStyle=`#ffcf86`,t.fillRect(e,153.6,30,25.6),t.fillStyle=`rgba(150,20,20,0.85)`,t.fillRect(e,153.6,7,25.6),t.fillRect(e+23,153.6,7,25.6);t.fillStyle=`#c9a44a`,t.fillRect(0,189.44,512,2),t.fillStyle=`#16151a`,t.fillRect(0,204.8,512,51.2);for(let e of[92.16,281.6,460.8]){t.fillStyle=`#0a0a0c`,t.fillRect(e-1.5,102.4,3,115.2);let n=t.createRadialGradient(e,102.4,1,e,102.4,18);n.addColorStop(0,`rgba(255,220,150,1)`),n.addColorStop(1,`rgba(255,200,120,0)`),t.fillStyle=n,t.fillRect(e-18,84.4,36,36)}return e})}function ng(){return Ph(`carriage-window`,()=>{let e=jh(256,212),t=e.getContext(`2d`),n=t.createRadialGradient(128,212*.3,8,128,95.4,158.72);n.addColorStop(0,`#ffe6b0`),n.addColorStop(.45,`#f0a85a`),n.addColorStop(1,`#6e3416`),t.fillStyle=n,t.fillRect(0,0,256,212),t.strokeStyle=`rgba(90,40,14,0.35)`,t.lineWidth=2;for(let e=40;e<256;e+=58)t.strokeRect(e,212*.2,44,76.32);let r=t.createRadialGradient(128,36.04,1,128,36.04,36);r.addColorStop(0,`rgba(255,250,225,1)`),r.addColorStop(1,`rgba(255,220,160,0)`),t.fillStyle=r,t.fillRect(92,36.04-36,72,72);for(let e of[30.72,158.72])t.fillStyle=`#4a1812`,t.beginPath(),t.roundRect(e,212*.6,66.56,212*.4,14),t.fill(),t.fillStyle=`rgba(255,190,120,0.18)`,t.fillRect(e+6,131.44,54.56,4);t.fillStyle=`#efe4cc`,t.fillRect(97.28,156.88,61.44,212*.26),t.fillStyle=`#b08d3f`,t.fillRect(126.72,212*.6,3,212*.14),t.fillStyle=`#ff9a6a`,t.beginPath(),t.moveTo(117.76,212*.6),t.lineTo(138.24,212*.6),t.lineTo(134.4,112.36),t.lineTo(121.6,112.36),t.fill();for(let e of[-1,1]){let n=e<0?0:256,r=t.createLinearGradient(n,0,n-e*256*.24,0);r.addColorStop(0,`#5a0a10`),r.addColorStop(.5,`#a8182a`),r.addColorStop(1,`#6e0c14`),t.fillStyle=r,t.beginPath(),t.moveTo(n,0),t.lineTo(n-e*256*.26,0),t.quadraticCurveTo(n-e*256*.1,212*.4,n-e*256*.07,122.96),t.quadraticCurveTo(n-e*256*.16,212*.8,n-e*256*.2,212),t.lineTo(n,212),t.fill(),t.strokeStyle=`rgba(40,0,4,0.45)`,t.lineWidth=2;for(let r=1;r<4;r+=1)t.beginPath(),t.moveTo(n-e*256*.06*r,0),t.quadraticCurveTo(n-e*256*.025*r,95.4,n-e*256*.02*r,122.96),t.stroke();t.fillStyle=`#c9a44a`,t.fillRect(n-e*256*.11-6,212*.56,12,6)}t.fillStyle=`#7e0e18`,t.fillRect(0,0,256,212*.1),t.fillStyle=`#d6b05a`;for(let e=0;e<256;e+=6)t.fillRect(e,212*.1,3,6);let i=t.createRadialGradient(128,106,76.8,128,106,184.32);return i.addColorStop(0,`rgba(0,0,0,0)`),i.addColorStop(1,`rgba(20,6,0,0.55)`),t.fillStyle=i,t.fillRect(0,0,256,212),e})}function rg(){return Ph(`valance`,()=>{let e=jh(128,256),t=e.getContext(`2d`);t.clearRect(0,0,128,256);let n=Mh(9);for(let e=0;e<2;e+=1){let r=e*64+2,i=r+60,a=t.createLinearGradient(r,0,i,0);a.addColorStop(0,`#b8ad8e`),a.addColorStop(.5,`#ddd2b4`),a.addColorStop(1,`#a89e80`),t.fillStyle=a,t.beginPath(),t.moveTo(r,0),t.lineTo(i,0),t.lineTo(i,204.8),t.lineTo((r+i)/2,256),t.lineTo(r,204.8),t.fill();for(let e=0;e<14;e+=1)t.fillStyle=`rgba(70,55,35,${.05+n()*.08})`,t.fillRect(r+n()*60,0,1,256*(.5+n()*.3));t.fillStyle=`rgba(40,30,18,0.35)`,t.fillRect(r,30.72,60,3),t.beginPath(),t.arc((r+i)/2,140.8,7,0,Math.PI*2),t.fill()}return e})}function ig(e,{width:t=1024,height:n=96}={}){return Ph(`lettering:${e}`,()=>{let r=jh(t,n),i=r.getContext(`2d`);i.clearRect(0,0,t,n),i.font=`bold ${Math.floor(n*.66)}px Georgia, "Times New Roman", serif`,i.textAlign=`center`,i.textBaseline=`middle`;let a=e.split(``).join(` `);i.fillStyle=`rgba(30,14,4,0.85)`,i.fillText(a,t/2+3,n/2+3,t-24);let o=i.createLinearGradient(0,n*.2,0,n*.8);return o.addColorStop(0,`#fbe7a6`),o.addColorStop(.5,`#d4a443`),o.addColorStop(1,`#8a6224`),i.fillStyle=o,i.fillText(a,t/2,n/2,t-24),r})}function ag(){return Ph(`frond`,()=>{let e=jh(128,256),t=e.getContext(`2d`);t.clearRect(0,0,128,256),t.strokeStyle=`#3d5a24`,t.lineWidth=3,t.beginPath(),t.moveTo(64,256),t.quadraticCurveTo(70,128,64,4),t.stroke();for(let e=0;e<22;e+=1){let n=e/22,r=256-n*244,i=50*Math.sin(Math.PI*(.15+n*.85));for(let n of[-1,1])t.fillStyle=e%2?`#3f6e2c`:`#355f26`,t.beginPath(),t.moveTo(64,r),t.quadraticCurveTo(64+n*i*.6,r-10,64+n*i,r-22),t.quadraticCurveTo(64+n*i*.5,r-4,64,r+3),t.fill()}return e})}var og=null;function sg(e){return new x(e)}function cg(e,t,n={}){return sg({color:1708554,emissive:e,emissiveIntensity:t,roughness:.3,...n})}function lg(e,t,n,r={},i=0){let a=sg({map:Ih(t,e,{repeat:n}),...r});return i&&(a.normalMap=Ih(t,e,{repeat:n,normal:i})),a}function ug(e,t,n={}){return sg({map:Ih(t,e),transparent:!0,alphaTest:.3,depthWrite:!1,polygonOffset:!0,polygonOffsetFactor:-2,polygonOffsetUnits:-2,roughness:.8,...n})}function dg(){let e=Ih(`concrete-rough`,Gh,{repeat:[1,1],srgb:!1});e.colorSpace=``;let t=[];for(let e=0;e<Jh;e+=1)t.push(lg(()=>Yh(e),`poster:${e}`,[1,1],{roughness:.55,emissive:16777215,emissiveIntensity:.04})),t[e].emissiveMap=t[e].map;let n=lg(Xh,`clock-face`,[1,1],{roughness:.4,emissive:16773844,emissiveIntensity:.35});n.emissiveMap=n.map;let r=lg(Zh,`departures`,[1,1],{roughness:.4,emissive:16777215,emissiveIntensity:1.1});r.emissiveMap=r.map;let i=lg(tg,`night-platform`,[1,1],{roughness:.2,emissive:16777215,emissiveIntensity:.85});i.emissiveMap=i.map;let a=lg(ng,`carriage-window`,[1,1],{roughness:.12,metalness:.1,emissive:16777215,emissiveIntensity:1.25});a.emissiveMap=a.map;let o=new Map,s=Array.from({length:3},(e,t)=>{let n=lg(()=>zh(t),`station-window:${t}`,[1,1],{roughness:.3,emissive:16766106,emissiveIntensity:.9});return n.emissiveMap=n.map,n});return{plaster:Ch({repeat:[1,1],seed:72,base:14075554,roughness:.86}),ceiling:Ch({repeat:[1,1],seed:73,base:7300694,roughness:.92}),wainscot:_h({repeat:[1,1],seed:14,light:5912352,dark:2758412,roughness:.48}),checker:lg(Bh,`checker`,[1,1],{roughness:.32,metalness:.02},1.2),runner:yh({repeat:[1,1],seed:38,base:6953506,accent:10517050}),brick:lg(Vh,`glazed-brick`,[1,1],{roughness:.38,metalness:.02},2.2),tile:lg(Hh,`green-tile`,[1,1],{roughness:.22,metalness:.04},2.6),concrete:lg(Wh,`concrete`,[1,1],{roughness:1,roughnessMap:e,metalness:.05},1.4),green:sg({color:1915434,roughness:.45,metalness:.15}),greenDark:sg({color:1188890,roughness:.5,metalness:.2}),brass:sg({color:11570495,roughness:.3,metalness:.9}),iron:sg({color:1842975,roughness:.45,metalness:.75}),pipe:sg({color:3881524,roughness:.42,metalness:.7}),copper:sg({color:9065010,roughness:.35,metalness:.85}),wood:_h({repeat:[1,1],seed:15,light:8014890,dark:3875602,roughness:.5}),crate:lg(Kh,`crate`,[1,1],{roughness:.85},1.6),leather:sg({color:4860440,roughness:.62,metalness:.05}),cushion:sg({color:6034720,roughness:.9}),steel:lg(Qh,`steel-door`,[1,1],{roughness:.55,metalness:.65},2.4),steelFrame:sg({color:2830128,roughness:.4,metalness:.85}),hazard:lg($h,`hazard`,[1,1],{roughness:.6,metalness:.2}),stencil:ug(()=>eg(`AUTHORISED PERSONNEL ONLY`),`stencil:auth`),security:ug(()=>eg(`SECURITY`,{width:256}),`stencil:security`),bulb:cg(16767392,4.2),lantern:cg(16761466,3.2,{side:2}),lampShade:cg(16769976,.9,{color:15260864,side:2}),bulkhead:cg(16769456,2.8,{transparent:!1}),bankerGlass:cg(3115602,1.6,{color:1923638,roughness:.15}),transom:cg(16764810,2.2),redLens:cg(16722458,3.5),posters:t,poster:e=>t[e%t.length],clock:n,departures:r,nightView:i,ticketSign:Th({text:`TICKETS · BILLETS`,background:1315085,foreground:14726236,width:512,height:96,emissiveIntensity:.8}),sign:(e,t={})=>{let n=`${e}:${JSON.stringify(t)}`;return o.has(n)||o.set(n,Th({text:e,background:1315085,foreground:14726236,width:512,height:112,emissiveIntensity:.7,...t})),o.get(n)},paper:sg({color:14866623,roughness:.92}),newsprint:sg({color:12169890,roughness:.95}),cork:sg({color:9069632,roughness:.96}),coat:sg({color:2369326,roughness:.92}),coatTan:sg({color:7232062,roughness:.9}),bakelite:sg({color:920844,roughness:.28,metalness:.1}),locker:sg({color:3428415,roughness:.5,metalness:.45}),glass:sg({color:1712680,roughness:.08,metalness:.6,transparent:!0,opacity:.45}),frond:sg({map:Ih(`frond`,ag),alphaTest:.45,side:2,roughness:.7}),pot:sg({color:6961698,roughness:.7}),soil:sg({color:1708556,roughness:1}),carriageGreen:new ue({color:994844,roughness:.34,metalness:.2,clearcoat:.7,clearcoatRoughness:.22}),carriageRoof:sg({color:2303271,roughness:.72,metalness:.25}),carriageWindow:a,carriageLettering:ug(()=>ig(`CHRONO EXPRESS`),`lettering:chrono`,{roughness:.35,metalness:.6,alphaTest:.4}),bellows:sg({color:1381135,roughness:.95}),tyre:sg({color:7170918,roughness:.35,metalness:.9}),stationWindows:s,platformStone:lg(Oh,`platform-stone`,[1,1],{roughness:.86},.6),platformPaving:lg(kh,`platform-paving`,[1,1],{roughness:.23,roughnessMap:e,metalness:.12},.18),chronoPoster:lg(Ah,`platform-chrono-poster`,[1,1],{roughness:.58,emissive:16764817,emissiveIntensity:.18}),conifer:sg({color:1520937,roughness:.95}),stationStone:Ch({repeat:[1,1],seed:81,base:11707274,roughness:.87}),bucketRed:sg({color:7611678,roughness:.65,metalness:.18}),sack:sg({color:8878435,roughness:.98}),valance:sg({map:Ih(`valance`,rg),alphaTest:.5,side:2,roughness:.75}),signalRed:cg(16718346,9),signalGreen:sg({color:532495,roughness:.2,metalness:.1})}}function fg(){og=null}function pg(){return og||=dg(),og}new h;var mg=new n,hg=new R(1,1,1),gg=new R,_g=new R(0,1,0);function Z(e,t,n,r=0,i=1){return gg.set(e,t,n),mg.setFromAxisAngle(_g,r),hg.setScalar(i),new h().compose(gg,mg,hg)}function Q(e,t,n,r=0,i=0,a=0,o=0){let s=new K(e,t,n);if(o>0){let r=s.attributes.uv,i=[[n,t],[n,t],[e,n],[e,n],[e,t],[e,t]];for(let e=0;e<6;e+=1)for(let t=0;t<4;t+=1){let n=e*4+t;r.setXY(n,r.getX(n)*i[e][0]/o,r.getY(n)*i[e][1]/o)}}return s.translate(r,i,a),s}function vg(e,t){let n=e.parameters,r=e.attributes.uv;if(e.type===`PlaneGeometry`)for(let e=0;e<r.count;e+=1)r.setXY(e,r.getX(e)*n.width/t,r.getY(e)*n.height/t);else if(e.type===`BoxGeometry`){let i=[[n.depth,n.height],[n.depth,n.height],[n.width,n.depth],[n.width,n.depth],[n.width,n.height],[n.width,n.height]],a=0;for(let n of e.groups){let e=i[n.materialIndex],o=n.count/6*4;for(let n=0;n<o;n+=1,a+=1)r.setXY(a,r.getX(a)*e[0]/t,r.getY(a)*e[1]/t)}}return r.needsUpdate=!0,e}function yg(e,t){let n=new Set;e.traverse(e=>{if(!e.isMesh)return;let r=t.find(([t])=>t===e.material);r&&(e.material=r[1],!n.has(e.geometry)&&(n.add(e.geometry),vg(e.geometry,r[2])))})}function bg(e,t,n,r=12,i=0,a=0,o=0){let s=new p(e,t,n,r);return s.translate(i,a,o),s}function xg(e,t,n,r=8){let i=new R().subVectors(t,e),a=i.length(),o=new p(n,n,a,r);return mg.setFromUnitVectors(_g,i.normalize()),o.applyQuaternion(mg),o.translate((e.x+t.x)/2,(e.y+t.y)/2,(e.z+t.z)/2),o}function Sg(e){for(let t of Object.keys(e.attributes))t!==`position`&&t!==`normal`&&t!==`uv`&&e.deleteAttribute(t);return e.attributes.uv||e.setAttribute(`uv`,new Rt(new Float32Array(e.attributes.position.count*2),2)),e.index?e.toNonIndexed():e}function Cg(e){if(!e.length)return null;let t=e.map(e=>{let t=Sg(e);return t!==e&&e.dispose(),t}),n=ao(t,!1);for(let e of t)e.dispose();return n}function wg(){let e=new Map,t=new Map;function n(t,n,r,i=!1){if(!n)return;r&&n.applyMatrix4(r);let a=+!!i;e.has(t)||e.set(t,[[],[]]),e.get(t)[a].push(n)}function r(e,n,r,i){t.has(e)||t.set(e,{geometry:n(),material:r,matrices:[]}),t.get(e).matrices.push(i.clone())}function i(n,r=`kit`,{decor:i=!1}={}){let a=[],o=0;for(let[t,[i,s]]of e)for(let[e,c]of[[i,!1],[s,!0]]){let i=Cg(e);if(!i)continue;let s=new z(i,t);s.name=`${r}-${o++}`,s.castShadow=c,s.receiveShadow=!t.transparent,n.add(s),a.push(s)}for(let[e,i]of t){let t=new Lt(i.geometry,i.material,i.matrices.length);i.matrices.forEach((e,n)=>t.setMatrixAt(n,e)),t.instanceMatrix.needsUpdate=!0,t.name=`${r}-${e}`,t.receiveShadow=!0,t.computeBoundingSphere(),n.add(t),a.push(t)}if(i)for(let e of a)e.userData.decor=!0,e.userData.noInteractionBlocker=!0,e.userData.noCameraCollision=!0;return e.clear(),t.clear(),a}return{add:n,instance:r,build:i}}function Tg(e,t,n,r,i=0){return e?new h().multiplyMatrices(e,Z(t,n,r,i)):Z(t,n,r,i)}function Eg(e,t,n,r=1.4){e.add(t.brass,bg(.12,.12,.05,14,0,-.025,0),n),e.add(t.brass,bg(.018,.018,r-.2,6,0,-(r-.2)/2,0),n),e.add(t.brass,bg(.05,.07,.12,10,0,-r+.22,0),n);let i=[new m(.06,.18),new m(.1,.16),new m(.2,.06),new m(.34,-.06),new m(.4,-.13),new m(.41,-.16)],a=new Ue(i,18);a.translate(0,-r+.02,0),e.add(t.brass,a,n);let o=new Ue(i.map(e=>new m(e.x*.94,e.y-.01)),18);o.translate(0,-r+.02,0),e.add(t.lampShade,o,n);let s=new He(.09,12,8);s.translate(0,-r-.03,0),e.add(t.bulb,s,n)}function Dg(e,t,n){e.add(t.iron,bg(.17,.17,.05,16,0,.025,0),n);let r=new He(.12,14,8,0,Math.PI*2,0,Math.PI/2);r.scale(1,.9,1),r.translate(0,.05,0),e.add(t.bulkhead,r,n);let i=new Tt(.135,.012,6,18);i.rotateX(Math.PI/2),i.translate(0,.09,0),e.add(t.iron,i,n);for(let r=0;r<3;r+=1){let i=new Tt(.135,.01,4,10,Math.PI);i.rotateY(r/3*Math.PI),i.translate(0,.05,0),e.add(t.iron,i,n)}}function Og(e,t,n){e.add(t.brass,bg(.08,.09,.03,14,0,.015,0),n),e.add(t.brass,bg(.012,.012,.3,6,0,.18,0),n);let r=new p(.06,.11,.09,16,1,!0,0,Math.PI);r.rotateZ(Math.PI/2),r.rotateY(Math.PI/2),r.scale(1.6,1,1),r.translate(0,.34,.02),e.add(t.bankerGlass,r,n)}function kg(e,t,n,r,i=.06,a=null,o=new R(0,1,0)){let s=a??t.pipe;e.add(s,xg(n,r,i,10));let c=new R().subVectors(r,n),l=c.length();c.normalize();for(let a of[n,r])e.add(t.iron,xg(a.clone().addScaledVector(c,-.03),a.clone().addScaledVector(c,.03),i*1.6,10));let u=Math.max(1,Math.floor(l/1.6));for(let r=1;r<=u;r+=1){let a=n.clone().addScaledVector(c,r/(u+1)*l);e.add(t.iron,xg(a.clone().addScaledVector(c,-.025),a.clone().addScaledVector(c,.025),i*1.35,8)),e.add(t.iron,xg(a,a.clone().addScaledVector(o,i+.08),.012,4))}}function Ag(e,t,n,r=!1){let i=r?3.4:2.9,a=r?1.35:1.6;e.add(t.wood,Q(a+.22,i+.24,.1,0,i/2,.03),n);let o=new Ot(a,i);o.translate(0,i/2,.09),e.add(t.stationWindows[0],o,n);for(let r of[-a/2,0,a/2])e.add(t.wood,Q(.07,i,.12,r,i/2,.13),n);for(let r of[0,i*.68,i])e.add(t.wood,Q(a+.1,.08,.13,0,r,.13),n);e.add(t.stationStone,Q(a+.35,.12,.3,0,0,.1),n),r&&e.add(t.brass,Q(.06,.2,.06,a*.32,1.2,.23),n)}function jg(e,t,n){e.add(t.iron,Q(.16,.9,.09,0,0,0),n),e.add(t.brass,Q(.32,.75,.22,0,0,.22),n),e.add(t.lantern,Q(.24,.64,.24,0,0,.24),n);for(let r of[-.15,.15])for(let i of[.09,.39])e.add(t.iron,Q(.028,.82,.028,r,0,i),n);for(let r of[-.42,.42])e.add(t.brass,Q(.4,.07,.4,0,r,.24),n)}function Mg(e,t,n){e.add(t.wood,Q(.9,.72,.9,0,.36,0),n);for(let r of[.08,.68])e.add(t.brass,Q(.93,.04,.93,0,r,0),n);for(let r=0;r<4;r++){let i=new qt(.57-r*.1,.92,8);i.translate(0,1.02+r*.38,0),e.add(t.conifer,i,n)}}function Ng(e,t,n){for(let r of[-.92,.92])e.add(t.iron,Q(.62,.06,.06,.06,.42,r),n),e.add(t.iron,Q(.06,.42,.06,.32,.21,r),n),e.add(t.iron,Q(.06,.42,.06,-.2,.21,r),n),e.add(t.iron,Q(.06,.62,.06,-.38,.73,r),n),e.add(t.iron,Q(.62,.05,.08,.06,.66,r),n);e.add(t.wood,Q(.86,.06,2,0,.45,0),n,!0),e.add(t.cushion,Q(.62,.08,1.8,.06,.52,0),n),e.add(t.wood,Q(.1,.56,1.84,-.38,.86,0),n),e.add(t.cushion,Q(.06,.4,1.7,-.31,.86,0),n),e.add(t.brass,Q(.04,.03,1.84,-.38,1.15,0),n)}function Pg(e,t,n,r=.8,i=.7,a=.8){e.add(t.crate,Q(r,i,a,0,i/2,0),n,!0),Fg(e,t,n,r,i,a)}function Fg(e,t,n,r,i,a){let o=.05;for(let s of[-1,1])for(let c of[-1,1])e.add(t.wood,Q(o,i+.01,o,s*(r/2-o/2+.01),i/2,c*(a/2-o/2+.01)),n);for(let s of[.04,i-.04])e.add(t.wood,Q(r+.02,.06,o,0,s,a/2+.005),n),e.add(t.wood,Q(r+.02,.06,o,0,s,-a/2-.005),n),e.add(t.wood,Q(o,.06,a+.02,r/2+.005,s,0),n),e.add(t.wood,Q(o,.06,a+.02,-r/2-.005,s,0),n)}function Ig(e,t,n,r=.9,i=.45,a=.55){e.add(t.leather,Q(r,i,a,0,i/2,0),n,!0),e.add(t.wood,Q(r+.01,.03,a+.01,0,i*.68,0),n);let o=.07;for(let s of[-1,1])for(let c of[0,1])for(let l of[-1,1])e.add(t.brass,Q(o,o,o,s*(r/2-o/2+.004),c?i-o/2+.004:o/2-.004,l*(a/2-o/2+.004)),n);for(let o of[-r*.28,r*.28])e.add(t.greenDark,Q(.06,i+.012,a+.012,o,i/2,0),n),e.add(t.brass,Q(.08,.06,.02,o,i*.62,a/2+.01),n)}function Lg(e,t,n){e.add(t.wood,Q(1.1,.08,1.8,0,.32,0),n,!0);for(let r of[-.5,.5])e.add(t.iron,Q(.05,.08,1.8,r,.25,0),n);for(let r of[-.6,.6]){for(let i of[-.5,.5]){let a=new p(.16,.16,.08,14);a.rotateZ(Math.PI/2),a.translate(i,.16,r),e.add(t.iron,a,n)}e.add(t.iron,xg(new R(-.58,.16,r),new R(.58,.16,r),.025,6),n)}e.add(t.brass,xg(new R(-.45,.36,-.87),new R(-.45,1.15,-.87),.022),n),e.add(t.brass,xg(new R(.45,.36,-.87),new R(.45,1.15,-.87),.022),n),e.add(t.brass,xg(new R(-.45,1.15,-.87),new R(.45,1.15,-.87),.025),n),Ig(e,t,Tg(n,0,.36,.2),.8,.42,1.2),Ig(e,t,Tg(n,.02,.78,.28,.08),.7,.36,.95),Pg(e,t,Tg(n,-.05,1.14,.25,-.2),.42,.34,.42)}function Rg(e,t,n,r,i=.8,a=1.2){e.add(t.wood,Q(i+.12,a+.12,.04,0,0,.02),n),e.add(t.brass,Q(i+.02,a+.02,.045,0,0,.022),n);let o=new Ot(i,a);o.translate(0,0,.046),e.add(t.poster(r),o,n)}function zg(e,t,n,r=.42){let i=new p(r+.05,r+.05,.08,28);i.rotateX(Math.PI/2),i.translate(0,0,.04),e.add(t.wood,i,n);let a=new Tt(r+.02,.03,8,32);a.translate(0,0,.085),e.add(t.brass,a,n);let o=new G(r,32);o.translate(0,0,.082),e.add(t.clock,o,n)}function Bg(e,t,n,r=4){e.add(t.wood,Q(r,1.05,.34,0,.525,.38/2-.02),n,!0);let i=Math.max(2,Math.round(r/.9)),a=(r-.2)/i;for(let o=0;o<i;o+=1){let i=-r/2+.1+a*(o+.5);e.add(t.wainscot,Q(a-.12,.66,.03,i,.52,.35),n),e.add(t.brass,Q(a-.08,.02,.035,i,.87,.35),n)}e.add(t.wood,Q(r+.12,.06,.48,0,1.08,.22),n),e.add(t.brass,Q(r+.14,.025,.03,0,1.1,.46),n);for(let i of[-r/2+.08,r/2-.08,0])e.add(t.wood,Q(.16,1.4499999999999997,.14,i,3.65/2,.08),n);e.add(t.wood,Q(r,.4,.18,0,2.75,.09),n);let o=new Ot(r-.2,1.4);o.translate(0,3.6999999999999997/2,.012),e.add(t.lampShade,o,n);for(let i=-r/2+.2;i<=r/2-.2;i+=.12)Math.abs(i)<.09||e.add(t.brass,bg(.008,.008,1.4299999999999997,5,i,3.67/2,.1),n);for(let i of[1.16,1.8,2.5])e.add(t.brass,Q(r-.1,.025,.03,0,i,.1),n);for(let i of[-r/4,r/4])e.add(t.brass,Q(.5,.04,.12,i,1.13,.12),n);let s=new Ot(Math.min(r-.3,2.6),.32);s.translate(0,2.75,.185),e.add(t.ticketSign,s,n),Og(e,t,Tg(n,r*.3,1.11,.33)),e.add(t.leather,Q(.32,.03,.22,-r*.25,1.125,.36,0),n)}function Vg(e,t,n,r=3,i=3){let a=.5,o=r/i;e.add(t.wood,Q(r,1.05,a,0,.525,a/2),n,!0);let s=i*2,c=(r-.16)/s;for(let i=0;i<s;i+=1){let a=-r/2+.08+c*(i+.5);e.add(t.wainscot,Q(c-.1,.62,.025,a,.56,.512),n),e.add(t.brass,Q(c-.06,.02,.03,a,.9,.515),n)}e.add(t.greenDark,Q(r+.04,.14,.04,0,.07,.52),n),e.add(t.wood,Q(r+.14,.06,.62,0,1.08,.31),n),e.add(t.brass,Q(r+.16,.025,.03,0,1.1,.62),n);for(let a=0;a<=i;a+=1){let i=B.clamp(-r/2+a*o,-r/2+.06,r/2-.06);e.add(t.wood,Q(.12,1.39,.14,i,3.6100000000000003/2,.1),n)}let l=new Ot(r-.1,1.38);l.translate(0,3.62/2,.015),e.add(t.lampShade,l,n),e.add(t.wood,Q(r+.1,.46,.22,0,2.73,.11),n),e.add(t.brass,Q(r+.12,.03,.04,0,2.51,.21),n);let u=new Ot(Math.min(r-.3,2.8),.3);u.translate(0,2.74,.222),e.add(t.ticketSign,u,n);for(let a=0;a<i;a+=1){let i=-r/2+(a+.5)*o,s=o/2-.08,c=2.42-s*.55;e.add(t.brass,Q(s*2,.03,.03,i,1.42,.14),n),e.add(t.brass,Q(s*2,.03,.03,i,2.45,.14),n);let l=new Tt(s,.014,5,18,Math.PI);l.scale(1,.55,1),l.translate(i,c,.14),e.add(t.brass,l,n);for(let r=-s+.07;r<s-.04;r+=.075){let a=c+.55*Math.sqrt(Math.max(0,s*s-r*r));e.add(t.brass,bg(.006,.006,a-1.42,5,i+r,(a+1.42)/2,.14),n)}e.add(t.brass,Q(.42,.012,.26,i,1.116,.26),n),Og(e,t,Tg(n,i+o*.3,1.11,.44)),e.add(t.leather,Q(.3,.035,.22,0,0,0),Tg(n,i-o*.28,1.128,.42,.12*(a-1))),e.add(t.paper,Q(.21,.006,.29,0,0,0),Tg(n,i-o*.05,1.114,.5,-.2+.15*a)),e.add(t.paper,Q(.21,.006,.29,0,0,0),Tg(n,i-o*.07,1.12,.48,.1));let u=new G(.07,16);u.translate(i,2.3,.16),e.add(t.brass,u,n)}let d=-r/2+(Math.floor(i/2)+.5)*o+.18;e.add(t.iron,bg(.055,.06,.018,14,d,1.12,.52),n);let f=new He(.045,14,6,0,Math.PI*2,0,Math.PI/2);f.translate(d,1.128,.52),e.add(t.brass,f,n),e.add(t.brass,bg(.008,.008,.03,6,d,1.185,.52),n)}function Hg(e,t,n,r=.6,i=.42,a=.18,{material:o=null,lying:s=!1}={}){e.add(o??t.leather,Q(r,i,a,0,i/2,0),n,!0),s?e.add(t.wood,Q(r+.008,.02,a+.008,0,i*.5,0),n):e.add(t.wood,Q(r+.008,i+.008,.02,0,i/2,0),n);let c=.04;for(let o of[-1,1])for(let s of[0,1])for(let l of[-1,1])e.add(t.brass,Q(c,c,c,o*(r/2-c/2+.003),s?i-c/2+.003:c/2-.003,l*(a/2-c/2+.003)),n);let l=new Tt(.065,.012,5,10,Math.PI);if(s){l.rotateX(Math.PI/2),l.translate(0,i/2,a/2);for(let o of[-r*.3,r*.3])e.add(t.brass,Q(.05,.035,.012,o,i-.04,a/2+.006),n)}else{l.translate(0,i,0);for(let a of[-r*.3,r*.3])e.add(t.brass,Q(.05,.012,.035,a,i+.006,0),n)}e.add(t.leather,l,n)}function Ug(e,t,n){for(let r of[-.33,.33])e.add(t.green,Q(.04,1.62,.04,r,.81,.04),n),e.add(t.green,Q(.04,.95,.04,r,.475,.42),n),e.add(t.green,Q(.04,.04,.42,r,.3,.23),n);e.add(t.green,Q(.7,.03,.42,0,.3,.23),n);for(let[r,i]of[[.72,.3],[1.08,.18]]){let a=Q(.66,.02,.3,0,0,0);a.rotateX(.55),a.translate(0,r,i),e.add(t.green,a,n);for(let a of[-.16,.16]){let o=Q(.28,.025,.24,0,0,0);o.rotateX(.55),o.translate(a,r+.025,i+.012),e.add(t.newsprint,o,n);let s=new Ot(.24,.035);s.rotateX(-Math.PI/2+.55),s.translate(a,r+.08,i-.07),e.add(t.iron,s,n)}}for(let r of[-.17,.17])e.add(t.newsprint,Q(.3,.16,.24,r,.395,.24),n),e.add(t.wood,Q(.02,.165,.245,r,.395,.24),n);e.add(t.green,Q(.72,.2,.04,0,1.52,.04),n);let r=new Ot(.66,.15);r.translate(0,1.52,.062),e.add(t.sign(`NEWSPAPERS`,{height:96}),r,n)}function Wg(e,t,n){e.add(t.iron,bg(.18,.16,.72,16,0,.36,0),n,!0),e.add(t.green,bg(.186,.182,.14,16,0,.5,0),n);let r=new Tt(.18,.014,5,20);r.rotateX(Math.PI/2),r.translate(0,.72,0),e.add(t.brass,r,n),e.add(t.soil,bg(.168,.168,.01,16,0,.705,0),n),e.add(t.iron,bg(.17,.17,.03,16,0,.015,0),n)}function Gg(e,t,n,r,i=1.6,a=.34){e.add(t.greenDark,Q(i+.08,a+.08,.04,0,0,.02),n),e.add(t.brass,Q(i+.02,a+.02,.045,0,0,.022),n);let o=new Ot(i,a);o.translate(0,0,.046),e.add(r,o,n)}function Kg(e,t,n){e.add(t.wood,Q(1.24,.045,.64,0,.76,.32),n,!0);for(let r of[-.42,.42]){e.add(t.wood,Q(.38,.72,.58,r,.37,.31),n,!0);for(let i of[.18,.42,.64])e.add(t.wainscot,Q(.32,.18,.02,r,i,.61),n),e.add(t.brass,Q(.08,.02,.025,r,i+.02,.625),n)}e.add(t.wainscot,Q(.46,.5,.02,0,.47,.05),n),e.add(t.greenDark,Q(.56,.006,.38,-.05,.786,.36),n),e.add(t.paper,Q(.21,.004,.29,0,0,0),Tg(n,-.08,.792,.38,.18)),e.add(t.paper,Q(.21,.004,.29,0,0,0),Tg(n,.06,.79,.34,-.1)),e.add(t.leather,Q(.26,.04,.2,0,0,0),Tg(n,-.42,.803,.42,.1));let r=.38;e.add(t.bakelite,bg(.06,.07,.025,14,r,.795,.34),n),e.add(t.bakelite,bg(.016,.02,.26,8,r,.94,.34),n),e.add(t.bakelite,bg(.035,.022,.06,10,r,1.09,.36),n),e.add(t.brass,bg(.04,.04,.008,14,r,.81,.34),n),e.add(t.bakelite,xg(new R(.41000000000000003,1.02,.32),new R(.41000000000000003,.9,.32),.016,6),n),e.add(t.bakelite,Q(.16,.1,.05,.3,1.25,.03),n);for(let r of[.26,.34]){let i=new He(.028,10,6,0,Math.PI*2,0,Math.PI/2);i.translate(r,1.3,.06),e.add(t.brass,i,n)}Og(e,t,Tg(n,-.32,.785,.22))}function qg(e,t,n){e.add(t.wood,Q(.44,.04,.42,0,.46,0),n,!0);for(let r of[-.19,.19]){for(let i of[-.18,.18])e.add(t.wood,Q(.035,.46,.035,r,.23,i),n);e.add(t.wood,Q(.035,.5,.035,r,.72,-.19),n)}e.add(t.wood,Q(.42,.1,.03,0,.92,-.19),n);for(let r of[-.1,0,.1])e.add(t.wood,Q(.035,.34,.02,r,.68,-.19),n);e.add(t.cushion,Q(.38,.03,.36,0,.495,.01),n)}function Jg(e,t,n,r=3){let i=.42,a=1.85;e.add(t.locker,Q(i*r,a,.44,0,a/2,.22),n,!0),e.add(t.greenDark,Q(i*r+.02,.08,.46,0,.04,.23),n);for(let o=0;o<r;o+=1){let s=-((r-1)*i)/2+o*i;e.add(t.locker,Q(.39,1.71,.02,s,.9550000000000001,.45),n);for(let r of[1.6300000000000001,1.55,1.4700000000000002,.32,.24])e.add(t.iron,Q(.26,.025,.004,s,r,.462),n);e.add(t.brass,Q(.025,.12,.03,s+i*.32,a*.52,.47),n),e.add(t.brass,Q(.1,.05,.006,s,1.35,.462),n)}}function Yg(e,t,n,r=.9){e.add(t.wood,Q(r,.09,.03,0,0,.015),n);let i=Math.max(2,Math.round(r/.22));for(let a=0;a<i;a+=1){let o=-r/2+.1+a*(r-.2)/(i-1);e.add(t.brass,xg(new R(o,0,.03),new R(o,.05,.1),.008,5),n)}let a=[[-r/2+.12,t.coat,.92],[.04,t.coatTan,.84]];for(let[t,r,i]of a){let a=new p(.17,.24,i,4,1);a.rotateY(Math.PI/4),a.scale(1,1,.42),a.translate(t,-i/2-.02,.12),e.add(r,a,n);let o=new He(.14,8,4,0,Math.PI*2,0,Math.PI/2);o.scale(1.3,.45,.6),o.translate(t,-.04,.12),e.add(r,o,n)}let o=r/2-.12;e.add(t.coat,bg(.09,.1,.11,14,o,.02,.12),n),e.add(t.coat,bg(.15,.15,.012,16,o,-.035,.12),n),e.add(t.cushion,bg(.102,.102,.025,14,o,-.015,.12),n)}function Xg(e,t,n){e.add(t.locker,Q(.47,1.32,.6,0,.66,.3),n,!0);for(let r=0;r<4;r+=1){let i=.18+r*.31;e.add(t.locker,Q(.43,.28,.02,0,i,.605),n),e.add(t.brass,Q(.14,.025,.03,0,i-.03,.62),n),e.add(t.paper,Q(.08,.035,.004,0,i+.06,.616),n)}}function Zg(e,t,n,r=1.1,i=.8){e.add(t.wood,Q(r+.1,i+.1,.035,0,0,.018),n);let a=new Ot(r,i);a.translate(0,0,.037),e.add(t.cork,a,n);for(let[a,o,s,c,l]of[[-.32,.14,.24,.32,.06],[-.02,.18,.2,.26,-.08],[.3,.1,.26,.34,.04],[-.24,-.2,.3,.2,-.05],[.12,-.18,.22,.28,.1]]){if(Math.abs(a)+s/2>r/2-.02||Math.abs(o)+c/2>i/2-.02)continue;let u=new Ot(s,c);u.rotateZ(l),u.translate(a,o,.039),e.add(t.paper,u,n);let d=new He(.012,6,4);d.translate(a,o+c/2-.03,.045),e.add(t.redLens,d,n)}}function Qg(e,t,n,r=2.4,i=1.2,a=1.4){e.add(t.iron,Q(r+.16,i+.16,.12,0,0,-.02),n);let o=new Ot(r,i);o.translate(0,0,.045),e.add(t.departures,o,n);for(let o of[-r*.4,r*.4])e.add(t.brass,bg(.015,.015,a,6,o,i/2+a/2,0),n);e.add(t.brass,Q(r+.2,.05,.14,0,i/2+.1,-.02),n)}function $g(e,t,n,r=1.2,i=2.3){e.add(t.greenDark,Q(r+.24,i+.7,.08,0,(i+.7)/2,.04),n),e.add(t.green,Q(r,i,.06,0,i/2,.1),n);for(let a of[i*.28,i*.72])e.add(t.greenDark,Q(r*.7,i*.32,.02,0,a,.135),n),e.add(t.green,Q(r*.62,i*.26,.02,0,a,.145),n);e.add(t.brass,Q(.04,.16,.04,r*.36,i*.48,.15),n),e.add(t.brass,xg(new R(r*.36,i*.48,.15),new R(r*.36,i*.48,.2),.035,10),n),e.add(t.brass,Q(r*.4,.05,.02,0,i*.06,.14),n);let a=new Ot(r-.1,.42);a.translate(0,i+.3,.09),e.add(t.transom,a,n);for(let a of[-r/6,r/6])e.add(t.greenDark,Q(.03,.42,.03,a,i+.3,.1),n);e.add(t.greenDark,Q(r,.06,.05,0,i+.05,.1),n)}function e_(e,t,n,r=3,i=1.6){e.add(t.greenDark,Q(r+.24,i+.24,.1,0,0,0),n);let a=new Ot(r,i);a.translate(0,0,.06),e.add(t.nightView,a,n);let o=new Ot(r,i);o.translate(0,0,.09),e.add(t.glass,o,n);let s=Math.round(r/.5);for(let a=1;a<s;a+=1)e.add(t.greenDark,Q(.035,i,.04,-r/2+a*r/s,0,.1),n);for(let a of[-i/6,i/6])e.add(t.greenDark,Q(r,.035,.04,0,a,.1),n);e.add(t.tile,Q(r+.4,.06,.24,0,-i/2-.15,.1),n)}function t_(e,t,n,r=1){let i=new h().makeScale(r,r,r);n&&i.premultiply(n);let a=[new m(.17,0),new m(.22,.05),new m(.27,.45),new m(.3,.5),new m(.29,.55)];e.add(t.pot,new Ue(a,16),i),e.add(t.soil,bg(.26,.26,.02,14,0,.5,0),i),e.add(t.wood,bg(.04,.06,.6,7,0,.8,0),i);for(let n=0;n<9;n+=1){let r=new Ot(.42,1.05,1,3),a=r.attributes.position;for(let e=0;e<a.count;e+=1){let t=(a.getY(e)+.525)/1.05;a.setZ(e,-t*t*.45)}r.translate(0,.525,0),r.rotateX(-.75-n%3*.2),r.rotateY(n/9*Math.PI*2+n%2*.2),r.translate(0,1.05+n%3*.06,0),e.add(t.frond,r,i)}}function n_(e,t,n,r=.45,i=1){let a=(e,t,n)=>new R(e,t,n);zg(e,t,n,r),zg(e,t,Tg(n,0,0,0,Math.PI),r);let o=new p(r+.06,r+.06,.2,28,1,!0);o.rotateX(Math.PI/2),e.add(t.brass,o,n);let s=r+.1;e.add(t.iron,Q(.5,.05,.08,0,s,0),n);let c=new He(.06,10,8);c.translate(0,s+.08,0),e.add(t.brass,c,n);for(let r of[-.2,.2]){e.add(t.iron,xg(a(r,s,0),a(r,s+i,0),.015,5),n);let o=new Tt(.08,.012,4,12);o.translate(r*.6,s+.12,0),e.add(t.iron,o,n)}}function r_(e,t,n,r=5.6){let i=(e,t,n)=>new R(e,t,n);e.add(t.concrete,Q(.9,1.35,.9,0,-.5,0),n);let a=e=>.26+-.12*(e-.18)/(r-.18),o=[[1,1],[1,-1],[-1,-1],[-1,1]],s=(e,t)=>{let[n,r]=o[e%4];return i(n*a(t),t,r*a(t))};for(let i=0;i<4;i+=1)e.add(t.iron,xg(s(i,.18),s(i,r),.025,4),n);for(let i=.18,a=0;i+.8<=r;i+=.8,a+=1)for(let r=0;r<4;r+=1){let o=(a+r)%2;e.add(t.iron,xg(s(r+o,i),s(r+1-o,i+.8),.012,4),n)}e.add(t.iron,Q(.36,.06,.36,0,r+.03,0),n);let c=new qt(.06,.25,6);c.translate(0,r+.18,0),e.add(t.iron,c,n);let l=r-.7,u=new p(.42,.42,.04,24);u.rotateX(Math.PI/2),u.translate(0,l,-.26),e.add(t.iron,u,n),e.add(t.iron,Q(.36,.8,.24,0,l,-.13),n);let d=[[.17,t.signalRed],[-.17,t.signalGreen]];for(let[r,i]of d){let a=new p(.11,.11,.03,16);a.rotateX(Math.PI/2),a.translate(0,l+r,-.29000000000000004),e.add(i,a,n);let o=new p(.14,.14,.2,14,1,!0,-Math.PI/2,Math.PI);o.rotateX(-Math.PI/2),o.translate(0,l+r,-.38),e.add(t.iron,o,n)}for(let r of[-.18,.18])e.add(t.iron,xg(i(.38,.18,r),i(.38,l-.5,r),.015,4),n);for(let r=.45;r<l-.5;r+=.32)e.add(t.iron,xg(i(.38,r,-.18),i(.38,r,.18),.012,4),n);e.add(t.iron,Q(.8,.04,.7,.12,l-.5,-.05),n);for(let r of[-.26,.5])e.add(t.iron,xg(i(r,l-.5,.28),i(r,l+.3,.28),.012,4),n);return e.add(t.iron,xg(i(-.26,l+.3,.28),i(.5,l+.3,.28),.012,4),n),i(0,l+.17,-.31)}function i_(e,t,n){e.add(t.steelFrame,Q(.16,.2,.14,0,0,0),n),e.add(t.iron,Q(.22,.26,.03,0,0,-.07),n);let r=new p(.035,.035,.03,12);r.rotateX(Math.PI/2),r.translate(0,.02,.08),e.add(t.redLens,r,n)}var a_=`
  attribute vec4 aSeed;

  uniform float uTime;
  uniform float uPeriod;
  uniform float uHeight;
  uniform float uSpread;
  uniform float uSize;
  uniform float uScale;
  uniform vec3 uWind;

  varying float vAlpha;

  #include <fog_pars_vertex>

  void main() {
    float life = fract(uTime / uPeriod + aSeed.x);
    float ease = 1.0 - (1.0 - life) * (1.0 - life);
    vec2 side = (aSeed.yz * 2.0 - 1.0) * uSpread * (0.25 + life);
    vec3 offset = vec3(side.x, uHeight * ease, side.y) + uWind * life;
    vec4 mvPosition = modelViewMatrix * vec4(position + offset, 1.0);
    gl_Position = projectionMatrix * mvPosition;

    float size = uSize * (0.45 + life * 1.6) * (0.75 + 0.5 * aSeed.w);
    gl_PointSize = size * uScale / max(0.1, -mvPosition.z);
    vAlpha = smoothstep(0.0, 0.12, life) * (1.0 - smoothstep(0.55, 1.0, life));

    #include <fog_vertex>
  }
`,o_=`
  uniform vec3 uColor;
  uniform float uOpacity;

  varying float vAlpha;

  #include <fog_pars_fragment>

  void main() {
    vec2 p = gl_PointCoord * 2.0 - 1.0;
    float r2 = dot(p, p);
    if (r2 > 1.0) discard;
    float soft = (1.0 - r2) * (1.0 - r2) * exp(-1.6 * r2);
    float alpha = soft * vAlpha * uOpacity;
    if (alpha < 0.004) discard;
    gl_FragColor = vec4(uColor, alpha);
    #include <tonemapping_fragment>
    #include <colorspace_fragment>
    #include <fog_fragment>
  }
`;function s_(e){let t=e>>>0;return()=>(t=t*1664525+1013904223>>>0,t/4294967296)}function c_({count:e=40,height:t=10.5,spread:n=1.6,period:r=9,size:i=2.2,color:a=10133931,opacity:o=.34,wind:s=new R(-1.6,0,1.1),seed:c=23}={}){let l=s_(c),u=new Float32Array(e*3),d=new Float32Array(e*4);for(let t=0;t<e;t+=1)u[t*3]=(l()-.5)*.6,u[t*3+2]=(l()-.5)*.6,d[t*4]=(t+l()*.6)/e,d[t*4+1]=l(),d[t*4+2]=l(),d[t*4+3]=l();let f=new We;f.setAttribute(`position`,new Rt(u,3)),f.setAttribute(`aSeed`,new Rt(d,4));let p=new Je({uniforms:Ht.merge([J.fog,{uTime:{value:0},uPeriod:{value:r},uHeight:{value:t},uSpread:{value:n},uSize:{value:i},uScale:{value:400},uWind:{value:s.clone()},uColor:{value:new q(a)},uOpacity:{value:o}}]),vertexShader:a_,fragmentShader:o_,transparent:!0,depthWrite:!1,fog:!0}),h=new je(f,p);h.name=`landing-steam`,h.frustumCulled=!1,h.castShadow=!1,h.receiveShadow=!1,h.raycast=()=>{};let g=new m;h.onBeforeRender=(e,t,n)=>{let r=e.getRenderTarget(),i=r?r.height:e.getDrawingBufferSize(g).y;p.uniforms.uScale.value=i*.5*n.projectionMatrix.elements[5]};function _(e){p.uniforms.uTime.value+=e}return{points:h,update:_}}var l_=new n,u_=new R(0,1,0),d_=new R(1,1,1),f_=new R,p_=[[`d`,`h`],[`d`,`h`],[`w`,`d`],[`w`,`d`],[`w`,`h`],[`w`,`h`]];function m_(e,t,n,r,i){let a=e.attributes.uv,o={w:t,h:n,d:r};for(let e=0;e<6;e+=1){let t=o[p_[e][0]]/i,n=o[p_[e][1]]/i;for(let r=0;r<4;r+=1){let i=e*4+r;a.setXY(i,a.getX(i)*t,a.getY(i)*n)}}a.needsUpdate=!0}function $(e,t,n,r,i,a,o=0){let s=new K(e,t,n);return o>0&&m_(s,e,t,n,o),s.translate(r,i,a),s}function h_(e,t,n,r=0,i=1){return f_.set(e,t,n),l_.setFromAxisAngle(u_,r),d_.setScalar(i),new h().compose(f_,l_,d_)}function g_(e){if(!e.length)return null;let t=ao(e,!1);for(let t of e)t.dispose();return t}function __(e,t,n,{castShadow:r=!1,receiveShadow:i=!1,name:a}={},o){if(!t)return null;let s=new z(t,n);return s.castShadow=r,s.receiveShadow=i,a&&(s.name=a),e.add(s),o&&y_(s,o),s}function v_(e,t,n,r,{castShadow:i=!1,receiveShadow:a=!1,name:o}={},s){if(!t||!r.length)return t?.dispose(),null;let c=new Lt(t,n,r.length);for(let e=0;e<r.length;e+=1)c.setMatrixAt(e,r[e]);return c.instanceMatrix.needsUpdate=!0,c.castShadow=i,c.receiveShadow=a,o&&(c.name=o),e.add(c),s&&y_(c,s),c}function y_(e,t){t.draws+=1;let n=e.geometry;if(!n?.attributes?.position)return;let r=n.index?n.index.count/3:n.attributes.position.count/3,i=e.isInstancedMesh?e.count:1;e.isPoints||(t.triangles+=r*i)}function b_(){return{draws:0,triangles:0}}var x_=`
  varying vec2 vLocal;
  varying vec2 vWorld;
  varying vec3 vTint;

  void main() {
    vLocal = position.xz;
    vec4 world = modelMatrix * instanceMatrix * vec4(position, 1.0);
    vWorld = world.xz;
    #ifdef USE_INSTANCING_COLOR
      vTint = instanceColor;
    #else
      vTint = vec3(1.0);
    #endif
    gl_Position = projectionMatrix * viewMatrix * world;
  }
`,S_=`
  uniform sampler2D uMap;
  uniform vec2 uOrigin;
  uniform vec3 uColor;
  uniform float uMinX;
  uniform vec2 uOpening;

  varying vec2 vLocal;
  varying vec2 vWorld;
  varying vec3 vTint;

  void main() {
    // West of the quay there is only ground inside the street opening.
    if (vWorld.x < uMinX && (vWorld.y < uOpening.x || vWorld.y > uOpening.y)) discard;
    float r = length(vLocal);
    if (r >= 1.0) discard;
    float fall = 1.0 - smoothstep(0.0, 1.0, r);
    fall = fall * fall * (0.55 + 0.45 * (1.0 - smoothstep(0.0, 0.35, r)));
    vec3 albedo = texture2D(uMap, vec2(vWorld.x - uOrigin.x, uOrigin.y - vWorld.y)).rgb;
    vec3 light = uColor * vTint * fall;
    gl_FragColor = vec4(light * (albedo * 1.7 + 0.035), 1.0);
    #include <tonemapping_fragment>
    #include <colorspace_fragment>
  }
`;function C_(e){return new Je({uniforms:{uMap:{value:e},uOrigin:{value:new m(pm.minX,pm.maxZ)},uColor:{value:new q(1,.6,.3)},uMinX:{value:pm.minX-.05},uOpening:{value:new m(1,0)}},vertexShader:x_,fragmentShader:S_,transparent:!0,depthWrite:!1,blending:2,polygonOffset:!0,polygonOffsetFactor:-2,polygonOffsetUnits:-2,fog:!1})}function w_(e,t,n,r){let i=new G(1,40);i.rotateX(-Math.PI/2);let a=C_(n),o=new Lt(i,a,t.length),s=new h,c=new q;t.forEach((e,t)=>{s.makeScale(e.radius,1,e.radius),s.setPosition(e.x,pm.y+.012,e.z),o.setMatrixAt(t,s),o.setColorAt(t,c.setScalar(e.strength))}),o.instanceMatrix.needsUpdate=!0,o.instanceColor.needsUpdate=!0,o.name=`landing-light-pools`,o.castShadow=!1,o.receiveShadow=!1,o.renderOrder=2,o.frustumCulled=!1,e.add(o),r&&(r.draws+=1,r.triangles+=40*t.length);function l(e,t){o.setColorAt(e,c.setScalar(t)),o.instanceColor.needsUpdate=!0}function u(e,t){a.uniforms.uOpening.value.set(e,t)}return{mesh:o,setStrength:l,setOpening:u}}var T_=`
  attribute float strength;
  varying vec2 vDisc;
  varying float vStrength;

  void main() {
    vDisc = uv * 2.0 - 1.0;
    vStrength = strength;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  }
`,E_=`
  uniform vec3 uColor;
  varying vec2 vDisc;
  varying float vStrength;

  void main() {
    float r = length(vDisc);
    if (r >= 1.0) discard;
    float fall = 1.0 - smoothstep(0.0, 1.0, r);
    fall *= fall;
    gl_FragColor = vec4(uColor * vStrength * fall, 1.0);
    #include <tonemapping_fragment>
    #include <colorspace_fragment>
  }
`;function D_(e,t,n,r=16752210,i=`landing-wall-glow`){if(!t.length)return null;let a=[];for(let e of t){let t=new Ot(e.width,e.height);t.rotateY(Math.PI/2+(e.yaw||0)),t.translate(e.x,e.y,e.z);let n=new Float32Array(t.attributes.position.count).fill(e.strength);t.setAttribute(`strength`,new Rt(n,1)),a.push(t)}return k_(e,a,r,i,n,2*t.length)}function O_(e,t,n,r=16752210,i=`floor-glow`){if(!t.length)return null;let a=[];for(let e of t){let t=new Ot(e.radius*2,e.radius*2);t.rotateX(-Math.PI/2),t.translate(e.x,e.y+.015,e.z);let n=new Float32Array(t.attributes.position.count).fill(e.strength);t.setAttribute(`strength`,new Rt(n,1)),a.push(t)}return k_(e,a,r,i,n,2*t.length)}function k_(e,t,n,r,i,a){let o=g_(t),s=new Je({uniforms:{uColor:{value:new q().setHex(n,Fe)}},vertexShader:T_,fragmentShader:E_,transparent:!0,depthWrite:!1,blending:2,polygonOffset:!0,polygonOffsetFactor:-2,polygonOffsetUnits:-2,fog:!1}),c=new z(o,s);return c.name=r,c.renderOrder=2,e.add(c),i&&(i.draws+=1,i.triangles+=a),c}var A_=.75,j_=20,M_=1.2,N_=4,P_=j_/2,F_=1.45,I_=1.25,L_=3.75,R_=.07,z_=2.25,B_=3.2,V_=1.15,H_=[-6.6,-4.95,-3.3,-1.65,0,1.65,3.3,4.95,6.6],U_=8.9,W_=.86,G_=3.5,K_=.5,q_=2.6,J_=1.52,Y_=Math.asin(J_/q_),X_=q_*(1-Math.cos(Y_)),Z_=7,Q_=1.25,$_=.46,ev=.65,tv=83.6,nv=0,rv=44.3-tv/2;function iv(e){return tv/2-P_-e*21.2}function av(e,t,n){return new h().makeTranslation(e,t,n)}function ov(e,t,n){let r=[],i=e;for(let[e,t]of[...n].sort((e,t)=>e[0]-t[0]))e>i&&r.push([i,e]),i=Math.max(i,t);return i<t&&r.push([i,t]),r}function sv(e,t,n,r,i,a,o,s,c,l,u=!1){let d=r*(F_+i-a/2);e.add(t,Q(a,s-o,l-c,d,(o+s)/2,(c+l)/2),n,u)}function cv(e,t,n,r,i,a,o,s,c,l,u=!0){u&&sv(e,t,n,r,l,.02,o-c,o,i-c,a+c),sv(e,t,n,r,l,.02,s,s+c,i-c,a+c),sv(e,t,n,r,l,.02,o,s,i-c,i),sv(e,t,n,r,l,.02,o,s,a,a+c)}function lv(e,t,n,r,i,a,o,s,c){let l=new Ot(i,a);l.rotateY(r*Math.PI/2),l.translate(r*(F_-c),o,s),e.add(t,l,n)}function uv(e,t,n,r,i,a){sv(e,t.carriageGreen,n,r,.016,.02,1.47,2.03,i-a,i+a),cv(e,t.brass,n,r,i-a+.06,i+a-.06,1.53,1.97,.016,.03)}function dv(e,t,n,r,i){let a=H_.map(e=>[e-V_/2,e+V_/2]),o=[-8.9,U_].filter(e=>e!==i),s=o.map(e=>[e-K_/2,e+K_/2]),c=i==null?[]:[[i-W_/2,i+W_/2]],l=[-8.9,U_].map(e=>[e-W_/2-.04,e+W_/2+.04]),u=(i,a,o)=>{for(let[s,c]of ov(-10,P_,o))sv(e,t.carriageGreen,n,r,0,R_,i,a,s,c,!0)};u(I_,z_,c),u(z_,B_,[...a,...s,...c]),u(B_,G_,c),u(G_,L_,[]);let d=.9500000000000002,f=5.45/2;for(let i of H_)lv(e,t.carriageWindow,n,r,V_,d,f,i,.060000000000000005),cv(e,t.brass,n,r,i-V_/2,i+V_/2,z_,B_,.035,.012),uv(e,t,n,r,i,.62);for(let i of[1.36,2.13,3.27])for(let[a,o]of ov(-9.88,9.88,l))sv(e,t.brass,n,r,.008,.012,i-.011,i+.011,a,o);sv(e,t.carriageRoof,n,r,.03,.05,3.69,3.76,-10,P_);for(let i of o){cv(e,t.bellows,n,r,i-W_/2,i+W_/2,1.28,G_,.012,.004),cv(e,t.brass,n,r,i-W_/2+.07,i+W_/2-.07,1.37,3.43,.016,.012),lv(e,t.carriageWindow,n,r,K_,d,f,i,.060000000000000005),cv(e,t.brass,n,r,i-K_/2,i+K_/2,z_,B_,.03,.012),uv(e,t,n,r,i,.3),sv(e,t.brass,n,r,.05,.04,2.13,2.18,i-.36,i-.22);for(let a of[-1,1]){let o=i+a*.53,s=r*1.51;e.add(t.brass,xg(new R(s,1.75,o),new R(s,3.05,o),.016,6),n);for(let i of[1.8,3])e.add(t.brass,xg(new R(r*F_,i,o),new R(s,i,o),.012,4),n)}e.add(t.iron,Q(.3,.05,1.16,r*1.5999999999999999,.98,i),n);for(let a of[-1,1])e.add(t.iron,Q(.04,.27,.05,r*1.5,1.12,i+a*.48),n)}i!=null&&cv(e,t.brass,n,r,i-W_/2,i+W_/2,I_,G_,.03,.012,!1),lv(e,t.carriageLettering,n,r,4.4,.41,3.51,0,-.004)}function fv(e,t,n,r,i){let a=new p(q_,q_,19.98,26,1,!0,Math.PI-Y_,Y_*2);a.rotateX(Math.PI/2),a.translate(0,L_-q_*Math.cos(Y_),0),e.add(t.carriageRoof,a,n,!0);for(let r of[-1,1]){e.add(t.iron,xg(new R(r*J_,L_,-9.95),new R(r*J_,L_,9.95),.03,6),n);let i=Y_*.6,a=r*q_*Math.sin(i),o=L_-q_*Math.cos(Y_)+q_*Math.cos(i);e.add(t.iron,xg(new R(a,o+.01,-9.7),new R(a,o+.01,9.7),.018,4),n)}for(let r=-7.5;r<=7.5;r+=2.5){let i=new He(.1,10,6);i.scale(1,.8,2.2),i.translate(0,L_+X_+.05,r),e.add(t.iron,i,n)}let o=new It;o.moveTo(-1.45,I_),o.lineTo(F_,I_),o.lineTo(F_,L_);let s=L_-q_*Math.cos(Y_);for(let e=0;e<=12;e+=1){let t=Math.PI-Y_+e/12*Y_*2;o.lineTo(q_*Math.sin(t),s-q_*Math.cos(t))}o.lineTo(-1.45,L_);for(let a of[-1,1]){let s=new Ce(o,{depth:.08,bevelEnabled:!1,curveSegments:1});s.translate(0,0,a>0?9.92:-10),e.add(t.carriageGreen,s,n,!0),(a>0?!r:!i)?e.add(t.bellows,Q(1,2.05,M_/2-.02,0,2.5700000000000003,a*(10.3-.01)),n):e.add(t.bellows,Q(.8,1.95,.02,0,2.5300000000000002,a*10.005),n)}}function pv(e,t,n){for(let r of[-1,1]){e.add(t.iron,Q(.12,.26,19.7,r*1.22,1.12,0),n,!0);let i=r*1.12,a=(e,t)=>new R(i,e,t);e.add(t.iron,xg(a(1,-8.2),a(.66,-3),.025,5),n),e.add(t.iron,xg(a(.66,-3),a(.66,3),.025,5),n),e.add(t.iron,xg(a(.66,3),a(1,8.2),.025,5),n);for(let r of[-3,3])e.add(t.iron,xg(a(.66,r),a(1.12,r),.03,5),n);e.add(t.iron,Q(.95,.45,1.3,r*.6,.85,r*1.6),n)}let r=new p(.28,.28,.85,16);r.rotateZ(Math.PI/2),r.translate(0,.86,4.6),e.add(t.iron,r,n);for(let r of[-1,1]){e.add(t.iron,Q(2.7,.3,.14,0,1.1,r*9.93),n),e.add(t.iron,Q(.12,.1,.3,0,1.1,r*10.12),n);for(let i of[-.88,.88]){let a=new p(.08,.1,.5,10);a.rotateX(Math.PI/2),a.translate(i,1.1,r*10.25),e.add(t.iron,a,n);let o=new p(.19,.19,.05,16);o.rotateX(Math.PI/2),o.translate(i,1.1,r*10.555),e.add(t.tyre,o,n)}}}function mv(e,t,n){for(let r of[-1,1]){e.add(t.iron,Q(.12,.3,3.2,r*.98,.6,0),n);for(let i of[-1,1]){let a=i*Q_;e.add(t.iron,Q(.2,.28,.3,r*1,$_,a),n);for(let i=0;i<3;i+=1)e.add(t.pipe,Q(.12,.04,1.1-i*.25,r*.98,.79+i*.04,a),n);let o=new p($_,$_,.12,18);o.rotateZ(Math.PI/2),o.translate(r*A_,$_,a),e.add(t.iron,o,n);let s=new p(.5,.5,.025,18);s.rotateZ(Math.PI/2),s.translate(r*.6799999999999999,$_,a),e.add(t.iron,s,n);let c=new Tt(.44,.025,4,16);c.rotateY(Math.PI/2),c.translate(r*.815,$_,a),e.add(t.tyre,c,n);let l=new p(.12,.12,.14,10);l.rotateZ(Math.PI/2),l.translate(r*.83,$_,a),e.add(t.tyre,l,n),e.add(t.iron,Q(.1,.32,.1,r*A_,.5,i*(.79-.08)),n)}for(let i of[-.3,.3]){let a=new p(.09,.09,.22,10);a.translate(r*.98,.88,i),e.add(t.pipe,a,n)}}for(let r of[-1,1])e.add(t.iron,xg(new R(-.75,$_,r*Q_),new R(A_,$_,r*Q_),.07,8),n),e.add(t.iron,Q(1.86,.16,.16,0,.62,r*.45),n);e.add(t.iron,Q(2.1,.16,.42,0,.98,0),n)}function hv(e){let t=new Map,n=e=>(t.has(e)||t.set(e,e.clone()),t.get(e)),r=e.wainscot.clone();r.emissive.set(5909522),r.emissiveMap=r.map,r.emissiveIntensity=.75;let i=new U;i.name=`boarding-door`,i.position.set(-1.5,2,0);let a=new U;a.position.set(1.5,-2,0),i.add(a);let o=wg(),s=W_,c=(e,t,n)=>new R(e,t,n);o.add(n(e.iron),Q(.5,.04,.8,-1.7,1.22,0)),o.add(n(e.brass),Q(.03,.045,.8,-1.935,1.222,0));for(let t of[-.39,.39])o.add(n(e.iron),xg(c(-1.93,1.2,t),c(-1.43,1.52,t),.02,5)),o.add(n(e.iron),Q(.5,.06,.02,-1.7,1.17,t));o.add(n(e.brass),Q(.14,.03,s,-1.4,1.235,0)),o.add(n(e.iron),Q(.04,.3,s,-1.31,1.4,0));for(let t of[-.37,s/2-.06])o.add(n(e.brass),xg(c(-1.45+.1,1.65,t),c(-1.45+.1,3.2,t),.018,6));let l=1.38;o.add(n(e.runner),Q(l*2,.05,1.95,0,1.5250000000000001,.07)),o.add(r,Q(l*2,2.15,.06,0,2.625,-.95)),o.add(r,Q(.04,2.15,1.95,1.3599999999999999,2.625,.07)),o.add(r,Q(l*2,2.15,.04,0,2.625,1.03)),o.add(n(e.bellows),Q(.8,1.9,.01,0,2.5,1.005));let u=new Ot(.7,1.15);u.translate(.25,2.8,-.915),o.add(n(e.carriageWindow),u),o.add(n(e.brass),Q(.78,.04,.02,.25,3.4,-.915)),o.add(n(e.brass),Q(.78,.04,.02,.25,2.2,-.915)),o.add(n(e.lampShade),Q(l*2,.04,1.95,0,3.65,.07));let d=new He(.08,10,6);d.translate(0,3.55,.05),o.add(n(e.bulb),d),o.add(n(e.wood),Q(.5,.07,.62,-2.25,1.22,0));for(let t of[-2.43,-2.07])for(let r of[-.23,.23])o.add(n(e.wood),Q(.06,.19,.06,t,1.095,r));o.build(a,`boarding-door`);let f=O_(a,[{x:-2.5,y:1,z:0,radius:1.2,strength:.24}],null,16760181,`boarding-door-spill`);f.userData.decor=!0,f.userData.noInteractionBlocker=!0,f.userData.noCameraCollision=!0;let p=new U;p.name=`boarding-door-leaf`,p.position.set(-1.45,0,s/2),p.rotation.y=ev,a.add(p);let m=4.75/2;o.add(n(e.carriageGreen),Q(.06,2.23,.84,.03,m,-.86/2),null,!0);let h=(t,r,i,a,s)=>{o.add(n(e.brass),Q(.012,s,r-t+s*2,-.006,i-s/2,(t+r)/2)),o.add(n(e.brass),Q(.012,s,r-t+s*2,-.006,a+s/2,(t+r)/2)),o.add(n(e.brass),Q(.012,a-i,s,-.006,(i+a)/2,t-s/2)),o.add(n(e.brass),Q(.012,a-i,s,-.006,(i+a)/2,r+s/2))};h(-.78,-.08,1.37,3.42,.016);let g=new Ot(.5,.72);g.rotateY(-Math.PI/2),g.translate(-.004,2.78,-.86/2),o.add(n(e.carriageWindow),g),h(-.86/2-.25,-.18,2.42,3.14,.03),o.add(n(e.carriageGreen),Q(.016,.55,.6,-.008,1.75,-.86/2)),h(-.86/2-.24,-.19,1.53,1.97,.014),o.add(n(e.brass),Q(.05,.05,.14,-.03,2.15,-.72));let _=new Ot(.78,2.13);return _.rotateY(Math.PI/2),_.translate(.061,m,-.86/2),o.add(r,_),o.build(p,`boarding-door-leaf`),{door:i,hinge:p}}function gv(e){let t=[],n=(n,r,i,a)=>{let o=c_(a);o.points.position.set(n,r,i),o.points.name=`train-steam`,e.add(o.points),t.push(o)};for(let e=0;e<N_;e+=1)n(.3,.35,iv(e)+4,{count:22,height:1.4,spread:1.3,period:8,size:2.6,color:10988981,opacity:.2,wind:new R(-1.8,0,-3),seed:31+e});let r=[{z:62.5,color:9278363,opacity:.4,seed:51},{z:51.5,color:6975609,opacity:.46,seed:52},{z:57.5,color:3948616,opacity:.55,seed:53}];n(0,4.7,54,{count:34,height:7,spread:2,period:9,size:4.5,color:10332597,opacity:.36,wind:new R(-.8,0,-2),seed:63}),n(-7,.9,60.5,{count:28,height:3.5,spread:5.5,period:13,size:5,color:6716561,opacity:.28,wind:new R(-.1,0,-.8),seed:64});for(let e of r)n(.4,2.6,e.z,{count:46,height:6.5,spread:2.4,period:11,size:5.5,color:e.color,opacity:e.opacity,wind:new R(-1.2,0,-2.4),seed:e.seed});return n(-.6,.8,58,{count:30,height:2.2,spread:1.8,period:9,size:3.4,color:10133931,opacity:.28,wind:new R(-1.4,0,-3.2),seed:57}),t}function _v(e){let t=0,n=0;return e.traverse(e=>{if(!e.isMesh||!e.visible)return;t+=1;let r=e.geometry;n+=(r.index?r.index.count:r.attributes.position.count)/3}),{drawCalls:t,triangles:Math.round(n)}}function vv(e){let t=new U;t.name=`boarding-objective-marker`;let n={value:0},r=(e,r,i,a,o)=>{let s=new Je({uniforms:{uTime:n,uFloor:{value:a},uOpacity:{value:o},uGold:{value:new q(16764277)}},vertexShader:`
    varying vec2 vUv;
    void main() {
      vUv = uv;
      gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }
  `,fragmentShader:`
    uniform float uTime;
    uniform float uFloor;
    uniform float uOpacity;
    uniform vec3 uGold;
    varying vec2 vUv;
    void main() {
      vec2 p = vUv * 2.0 - 1.0;
      vec2 q = abs(p) - vec2(0.72, 0.80);
      float d = length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - 0.12;
      float halo = exp(-pow(d / 0.09, 2.0));
      float fill = 1.0 - smoothstep(-0.12, 0.08, d);
      float ring = halo * 0.8 + fill * 0.12;
      float edges = smoothstep(0.0, 0.18, vUv.x) * smoothstep(0.0, 0.18, 1.0-vUv.x)
        * smoothstep(0.0, 0.12, vUv.y) * smoothstep(0.0, 0.12, 1.0-vUv.y);
      float shimmer = edges * (0.88 + 0.12 * sin(vUv.y * 18.0 - uTime * 1.5));
      float pulse = 0.8 + 0.2 * cos(uTime * 6.28318530718 / 1.6);
      float alpha = mix(shimmer, ring, uFloor) * uOpacity * pulse;
      gl_FragColor = vec4(uGold * 1.8, alpha);
      #include <tonemapping_fragment>
      #include <colorspace_fragment>
    }
  `,transparent:!0,blending:2,depthWrite:!1,depthTest:!0,side:2,fog:!1}),c=new z(new Ot(r,i),s);return c.name=e,c.userData.decor=!0,c.userData.noInteractionBlocker=!0,c.userData.noCameraCollision=!0,c.raycast=()=>{},t.add(c),c},i=r(`boarding-objective-floor`,.9,1.6,1,.42);i.rotation.x=-Math.PI/2,i.position.set(-2.55,1.025,e);let a=r(`boarding-objective-doorway`,.8,2.25,0,.18);return a.rotation.y=-Math.PI/2,a.position.set(-1.53,4.75/2,e),{group:t,update:e=>{n.value+=e}}}function yv(){let e=pg(),t=new U;t.name=`train`;let n=wg(),r=new U;r.name=`chrono-express-visual`;let i=iv(nv)+U_;for(let t=0;t<N_;t+=1){let i=av(0,0,iv(t));dv(n,e,i,-1,t===nv?U_:null),dv(n,e,i,1,null),fv(n,e,i,t===0,t===3),pv(n,e,i);for(let r of[-7,Z_])mv(n,e,av(0,0,iv(t)+r));n.build(r,`carriage-${t}`),n=wg()}t.add(r);let a=new U;a.name=`locomotive-and-tender`;let o=wg(),s=(e,t,n,r,i,a,s)=>o.add(e,Q(t,n,r,i,a,s-rv));s(e.iron,2.5,.35,14,0,1.05,52.3),s(e.carriageGreen,2.6,1.7,3.4,0,2.1,46.8),s(e.iron,2.2,.2,3.1,0,3,46.8),s(e.carriageGreen,2.6,2.6,2.1,0,2.65,50),s(e.carriageRoof,2.95,.16,2.5,0,4.02,50);for(let t of[-1,1])s(e.lampShade,.025,.8,.8,t*1.31,3.1,50),s(e.brass,.03,.035,12.8,t*1.26,1.4,52.3);let c=new p(1.02,1.02,6.4,16);c.rotateX(Math.PI/2),c.translate(0,2.55,51.7),o.add(e.iron,c);for(let t of[52,54,56.4]){let n=new Tt(1.03,.025,4,16);n.translate(0,2.55,t-rv),o.add(e.brass,n)}for(let[t,n,r]of[[56.5,.25,1.05],[53,.34,.5]]){let i=new p(n*1.2,n,r,12);i.translate(0,3.4+r/2,t-rv),o.add(e.iron,i)}for(let t of[46,48,51.6,53.4,55.2,57.3])for(let n of[-1,1]){let r=t>50&&t<57?.69:.43,i=new p(r,r,.16,16);i.rotateZ(Math.PI/2),i.translate(n*.88,r,t-rv),o.add(e.iron,i);let a=new Tt(r-.04,.04,4,16);a.rotateY(Math.PI/2),a.translate(n*.98,r,t-rv),o.add(e.brass,a)}for(let t of[-1,1])s(e.brass,.07,.08,4.2,t*1.01,.72,53.4);s(e.iron,2.7,.3,.25,0,1.2,58.8),s(e.lampShade,.35,.35,.1,0,2.8,57.46),o.build(a,`locomotive`),t.add(a);let{door:l,hinge:u}=hv(e);l.position.z=i,t.add(l);let d=vv(i);t.add(d.group);let f=new dt;for(let e=0;e<N_;e+=1){let n=new z(new K(F_*2,2.5,j_),f);n.name=`carriage-${e}-collider`,n.position.set(0,5/2,iv(e)),n.visible=!1,n.userData.interactionCollider=!0,t.add(n)}let m=gv(t);t.traverse(e=>{e.isMesh&&!e.userData.interactionCollider&&(e.userData.noInteractionBlocker=!0)}),t.position.set(7,-1,rv),t.updateMatrixWorld(!0);let h=_v(t);t.userData.drawCalls=h.drawCalls,t.userData.triangles=h.triangles;let g=ev;function _(){d.group.visible=!1,g=0}function v(e){d.update(e);for(let t of m)t.update(e);u.rotation.y>g&&(u.rotation.y=Math.max(g,u.rotation.y-e*3.4))}return{train:t,boardingDoor:l,closeDoor:_,update:v}}function bv({start:e,end:t,width:n=3.2,steps:r=14,wallHeight:i=4.6,stepMaterial:a,wallMaterial:o,ceilingMaterial:s,addCeiling:c=!0}={}){if(!e||!t)throw Error(`stairs: start and end are required`);let l=new U;l.name=`staircase`;let u=t.x-e.x,d=t.z-e.z,f=Math.hypot(u,d);if(f<.01)throw Error(`stairs: start and end must differ in X/Z`);let p=u/f,m=d/f,h=m,g=-p,_=Math.atan2(p,m),v=f/r,y=Math.min(e.y,t.y)-.25,b=a??new x({color:4933200,roughness:.78,metalness:.08}),S=o??new x({color:6708565,roughness:.9,metalness:.02}),C=s??S;for(let a=0;a<r;a++){let o=a/r,s=(a+1)/r,f=(o+s)/2,p=B.lerp(e.y,t.y,s),m=Math.max(.18,p-y),x=e.x+u*f,w=e.z+d*f,T=new z(new K(n,m,v*1.04),b);T.position.set(x,y+m/2,w),T.rotation.y=_,T.receiveShadow=!0,l.add(T);for(let e of[-1,1]){let t=new z(new K(.18,i,v*1.08),S);t.position.set(x+h*e*(n/2+.09),p+i/2,w+g*e*(n/2+.09)),t.rotation.y=_,t.receiveShadow=!0,l.add(t)}if(c){let e=new z(new K(n+.36,.18,v*1.08),C);e.position.set(x,p+i,w),e.rotation.y=_,e.receiveShadow=!0,l.add(e)}}let w=new dt,T=Math.min(e.y,t.y),E=Math.max(e.y,t.y),D=(e.x+t.x)/2,O=(e.z+t.z)/2;function k(e,t,n,r,i,a){let o=new z(new K(e,t,n),w);o.name=`stair-shadow-volume`,o.position.set(r,i,a),o.rotation.y=_,o.castShadow=!0,o.layers.set(1),l.add(o)}k(n,E-y,f,D,(y+E)/2,O);let A=E-T+i;for(let e of[-1,1])k(.22,A,f+v,D+h*e*(n/2+.09),T+A/2,O+g*e*(n/2+.09));if(c){let e=T+i,t=E+i+.18;k(n+.36,t-e,f+v,D,(e+t)/2,O)}function j(r,i){let a=r-e.x,o=i-e.z,s=a*p+o*m,c=Math.abs(a*h+o*g);if(s<-.15||s>f+.15||c>n/2-.08)return null;let l=B.clamp(s/f,0,1);return B.lerp(e.y,t.y,l)}return{group:l,getFloorHeight:j,start:e.clone(),end:t.clone(),width:n,runLength:f}}function xv(){return g_([$(.08,.1,.22,0,.28,0),$(.06,.34,.06,0,.08,-.1),$(.06,.34,.06,0,.08,.1),$(.06,.06,.26,0,.24,0),$(.06,.05,.26,0,-.08,0),$(.28,.06,.08,-.12,.3,0),$(.16,.08,.08,-.22,.22,0)])}function Sv(){return $(.1,.22,.14,0,.08,0)}function Cv(e,t,n,r){let i=[],a=[];for(let n of t){let t=h_(n.x,n.y,n.z,n.yaw||0);if(i.push(t),a.push(t.clone()),!n.light)continue;let r=new j(n.color??16756839,n.intensity??12,n.distance??12,2);r.name=`landing-lantern`,r.castShadow=!1,r.position.set(n.x,n.y+.08,n.z),e.add(r)}v_(e,xv(),n.iron,i,{name:`landing-lantern-cages`},r),v_(e,Sv(),n.lantern,a,{name:`landing-lantern-glow`},r)}var wv=new h().makeRotationX(Math.PI);function Tv(e,t,n,r=0){let i=e===`x`?n>0?0:Math.PI:n>0?Math.PI/2:-Math.PI/2,a=(r,i)=>{let a=t+n*i;return e===`x`?{x:r,z:a}:{x:a,z:r}};return{axis:e,face:t,out:n,floorY:r,point:a,lanternYaw:e===`x`?-n*Math.PI/2:n>0?0:Math.PI,M(e,t=0,n=0){let o=a(e,n);return Z(o.x,r+t,o.z,i)},rect(r,i,a,o){let s=Math.min(t+n*a,t+n*o),c=Math.max(t+n*a,t+n*o);return e===`x`?{minX:r,maxX:i,minZ:s,maxZ:c}:{minX:s,maxX:c,minZ:r,maxZ:i}},vec(e,t,n){let i=a(e,n);return new R(i.x,r+t,i.z)},inward:e===`x`?new R(0,0,-n):new R(-n,0,0)}}var Ev=(e,t,n,r,i=0)=>new h().multiplyMatrices(e,Z(t,n,r,i));function Dv(e,t,n){let r=pg(),i=wg(),a=wg(),o=[],s=[],c={},l=`room`,u=(e,t=1)=>{c[l]??={},c[l][e]=(c[l][e]??0)+t},d=e=>t.push(e);return{k:r,kit:i,decor:a,tally:u,room(e){l=e},lantern(e,t,n=2.6){let r=e.point(t,.3);o.push({x:r.x,y:e.floorY+n,z:r.z,yaw:e.lanternYaw});let i=e.point(t,.02);s.push({x:i.x,y:e.floorY+n+.15,z:i.z,yaw:e.lanternYaw,width:1.9,height:2.3,strength:.24}),u(`wall lantern`)},poster(e,t,n,i,o=.62,s=.9){Rg(a,r,e.M(t,n,.005),i,o,s),u(`framed poster`)},notice(e,t,n,i=1.1,o=.8){Zg(a,r,e.M(t,n,.005),i,o),u(`notice board`)},sign(e,t,n,i,o=1.6){Gg(a,r,e.M(t,n,.005),r.sign(i),o,.32),u(`sign`)},pipes(e,t,n,i){for(let[o,s,c,l]of i)kg(a,r,e.vec(t,o,s),e.vec(n,o,s),c,l??r.pipe,e.inward);u(`ceiling pipe run`,i.length)},bulkhead(e,t,n){Dg(a,r,Z(e,t,n).multiply(wv)),u(`caged bulkhead lamp`)},window(e,t,n,i=2.4,o=1.4){e_(a,r,e.M(t,n,0),i,o),u(`window to the platform`)},cluster(e,t,n){let a=e.M(t);n===`crates`?(Pg(i,r,Ev(a,-.3,0,.42),.9,.8,.8),Pg(i,r,Ev(a,-.28,.8,.44,.18),.55,.45,.55),Ig(i,r,Ev(a,.45,0,.3,.06),.55,.42,.5),d(e.rect(t-.76,t+.76,0,.86)),u(`crate`,2),u(`trunk`)):n===`trunks`?(Ig(i,r,Ev(a,0,0,.3),.9,.45,.55),Ig(i,r,Ev(a,.03,.45,.3,-.08),.72,.38,.48),Hg(i,r,Ev(a,0,.83,.3,.1),.5,.36,.16),d(e.rect(t-.5,t+.5,0,.6)),u(`trunk`,2),u(`suitcase`)):n===`cases`?(Hg(i,r,Ev(a,-.08,0,.26),.66,.18,.44,{lying:!0}),Hg(i,r,Ev(a,-.06,.18,.25,.12),.56,.16,.38,{lying:!0,material:r.coatTan}),Hg(i,r,Ev(a,.42,0,.12,-.08),.4,.34,.15),d(e.rect(t-.43,t+.64,0,.5)),u(`suitcase`,3)):n===`trolley`&&(Lg(i,r,Ev(a,0,0,.6,Math.PI/2)),d(e.rect(t-.9,t+.9,0,1.18)),u(`luggage trolley (loaded)`))},bin(e,t){let n=e.point(t,.25);Wg(i,r,Z(n.x,e.floorY,n.z)),d(e.rect(t-.19,t+.19,.06,.44)),u(`waste bin`)},desk(e,t){Kg(i,r,e.M(t)),qg(i,r,Ev(e.M(t),.05,0,.9,Math.PI)),d(e.rect(t-.62,t+.62,0,.66)),d(e.rect(t-.18,t+.28,.66,1.14)),u(`guard desk`),u(`telephone`),u(`desk lamp`),u(`chair`)},lockers(e,t,n=3){Jg(i,r,e.M(t),n),d(e.rect(t-n*.21,t+n*.21,0,.47)),u(`locker`,n)},coats(e,t,n=.9){Yg(i,r,e.M(t,1.75),n),d(e.rect(t-n/2,t+n/2,0,.34)),u(`coat hook rail`),u(`coat`,2),u(`hat`)},filing(e,t){Xg(i,r,e.M(t)),d(e.rect(t-.25,t+.25,0,.63)),u(`filing cabinet`)},build(){if(i.build(e,`${n}-props`),a.build(e,`${n}-decor`,{decor:!0}),o.length){let t=new U;t.name=`${n}-lanterns`,Cv(t,o,{iron:r.iron,lantern:r.lantern}),D_(t,s,null,16752210,`${n}-lantern-glow`),t.traverse(e=>{e.userData.decor=!0,e.userData.noInteractionBlocker=!0,e.userData.noCameraCollision=!0}),e.add(t)}e.userData.propCounts={...e.userData.propCounts??{},...c}}}}function Ov(e,t){let n=Dv(e,t,`tutorial`),r=Tv(`x`,-27.38,1),i=Tv(`x`,-21.62,-1);n.room(`Passageway 1 gallery`),n.notice(r,-143.6,2.2),n.poster(r,-137.9,2.4,2),n.poster(i,-147.7,2.4,5),n.poster(i,-141.6,2.4,0),n.sign(r,-147.5,3.3,`PLATFORMS  →`,1.4),n.sign(i,-133.6,3.4,`←  LOWER CONCOURSE`,1.7),n.cluster(r,-138.6,`crates`),n.cluster(i,-137.3,`trunks`),n.room(`Passageway 1 turn room (security office)`);let a=Tv(`x`,-21.625,-1),o=Tv(`z`,-126.125,-1);n.desk(a,-130.4),n.filing(a,-129.2),n.notice(a,-129.8,2.15,1,.7),n.lockers(o,-25,3),n.coats(o,-26.6,.8),n.lantern(o,-23.5,2.4),n.room(`Passageway 1 lower landing`);let s=Tv(`z`,-131.875,1,-4),c=Tv(`x`,-39.875,1,-4);n.cluster(s,-39,`crates`),n.poster(c,-129.6,2.4,4),n.sign(c,-129.6,3.6,`PASSAGEWAY 2  →`,1.6),n.lantern(c,-127.4),n.pipes(c,-131.6,-126.2,[[4.75,.16,.06]]),n.build()}function kv(e,t){let n=Dv(e,t,`guards`),{k:r}=n,i=Tv(`x`,-41.78,1,-4),a=Tv(`x`,-34.82,-1,-4),o=Tv(`x`,-39.88,1,-4),s=Tv(`x`,-36.72,-1,-4);n.room(`Passageway 2 entry corridor`),n.lantern(o,-124),n.poster(s,-124,2.4,6),n.pipes(s,-125.8,-122.2,[[4.6,.15,.06]]),n.room(`Passageway 2 guard hall`),n.pipes(i,-121.6,-84.2,[[4.6,.16,.07],[4.35,.13,.045,r.copper]]),n.pipes(a,-121.6,-102.2,[[4.72,.16,.06]]),n.pipes(a,-99.2,-84.2,[[4.72,.16,.06]]);for(let e of[-116,-108,-100,-92,-86])n.lantern(i,e);for(let e of[-120,-112,-104,-96,-84.6])n.lantern(a,e);n.poster(a,-117.5,2.4,1),n.poster(a,-109,2.4,3),n.poster(a,-98.4,2.4,5),n.poster(a,-92.2,2.5,7),n.notice(i,-113.6,2.2),n.poster(i,-105,2.4,2),n.poster(i,-96.2,2.4,4),n.notice(i,-88.6,2.3),n.sign(i,-110.5,3.4,`PLATFORMS  →`,1.5),n.sign(a,-114,3.4,`←  PLATFORMS`,1.5),n.cluster(a,-121.2,`cases`),n.cluster(i,-121.1,`trunks`),n.cluster(a,-91.2,`crates`),n.cluster(i,-91.4,`cases`),n.cluster(a,-85.2,`trunks`),n.cluster(i,-85,`crates`),n.room(`Passageway 2 exit bay (guard post)`);let c=Tv(`x`,-40.88,1,-4),l=Tv(`x`,-35.72,-1,-4);n.desk(c,-82.5),n.filing(c,-80.75),n.notice(c,-82.5,2.1,.9,.6),n.lockers(l,-82.27,3),n.coats(l,-81,.8),n.build()}function Av(e,t){let n=Dv(e,t,`bridge`),{k:r}=n;n.room(`Passageway 3 entry room`);let i=Tv(`z`,-69.82,-1,-4),a=Tv(`x`,-36.02,-1,-4);n.cluster(i,-36.7,`trunks`),n.lantern(a,-72.1),n.poster(i,-39.2,2.4,0),n.pipes(a,-74.2,-70,[[4.6,.15,.06]]),n.room(`Passageway 3 south hall`);let o=Tv(`z`,-74.38,1,-4),s=Tv(`z`,-69.82,-1,-4);n.lantern(o,-43.5),n.lantern(s,-45.6),n.poster(s,-42.8,2.4,6),n.notice(o,-41.4,2.25,.9,.6),n.pipes(s,-40.9,-46.4,[[4.6,.15,.06]]),n.room(`Passageway 3 south room`);let c=Tv(`z`,-74.38,1,-4),l=Tv(`x`,-51.28,1,-4);n.cluster(l,-73.6,`trunks`),n.cluster(c,-49.6,`crates`),n.lantern(l,-71.4),n.sign(l,-71.4,3.7,`PLATFORMS  →`,1.4),n.room(`Passageway 3 laser passage`);let u=Tv(`x`,-51.28,1,-4),d=Tv(`x`,-46.72,-1,-4);for(let e of[-68.2,-63.6])n.bulkhead(e,.9,-49);n.pipes(d,-69.6,-61.5,[[4.62,.16,.07],[4.38,.13,.045,r.copper]]),n.pipes(u,-69.6,-61.5,[[4.7,.16,.055]]),n.window(u,-65.5,2.6,2.4,1.4),n.lantern(d,-67.6),n.lantern(d,-63.4),n.room(`Passageway 3 laser room`);let f=Tv(`x`,-51.28,1,-4),p=Tv(`z`,-56.72,-1,-4);n.cluster(f,-59.8,`trolley`),n.lantern(p,-49),n.poster(p,-50.4,2.4,3),n.pipes(p,-51.1,-46.8,[[4.6,.15,.06]]),n.room(`Passageway 3 security hall`);let m=Tv(`z`,-61.28,1,-4),h=Tv(`z`,-56.72,-1,-4);n.lantern(m,-44.15),n.poster(h,-44.15,2.4,1),n.room(`Passageway 3 relay chamber (security office)`);let g=Tv(`x`,-43.58,1,-4),_=Tv(`z`,-64.13,1,-4);n.desk(g,-62.9),n.notice(g,-62.9,2.15,.9,.6),n.lockers(g,-55.27,3),n.filing(g,-54.33),n.coats(_,-43.15,.6),n.room(`Passageway 3 stair landings`);let v=Tv(`z`,-61.28,1,-4),y=Tv(`z`,-56.72,-1,-4),b=Tv(`x`,-22.22,-1,-2);n.lantern(v,-34),n.poster(y,-34,2.4,2),n.cluster(b,-60.6,`trunks`),n.poster(b,-58.2,2.3,5),n.build()}function jv(e,t){let n=Dv(e,t,`hall`),r=Tv(`x`,-27.1,1),i=Tv(`x`,-21.9,-1),a=Tv(`x`,-26.99,1),o=Tv(`x`,-22.01,-1);n.room(`Approach hall`),n.notice(r,-10,2.3),n.notice(i,-25.5,2.4),n.sign(r,-49.8,3.2,`PLATFORMS  →`,1.5),n.sign(r,-16,3.6,`PLATFORM 1  →`,1.5),n.sign(i,-38.6,3.7,`←  PLATFORMS`,1.5),n.cluster(o,-49,`trunks`),n.cluster(o,-15.6,`cases`),n.cluster(o,-1,`crates`),n.cluster(a,-2,`trunks`),n.bin(a,-6.6),n.build()}var Mv=28,Nv=6,Pv=-24.5,Fv=5.5,Iv=[-40,-29,-18],Lv={x:1.6,z:-25},Rv=3.8,zv=4.45,Bv=Pv-Fv/2,Vv=-21.75,Hv=2.6,Uv=[-20,-12,-4,6,14,22,30,38,46,54].map((e,t)=>({id:`cover-${t+1}`,z:e,x:(t%2?1:-1)*3.05,pocketX:(t%2?1:-1)*4.1,width:1.3,length:t===2||t===3?8:6,height:t===0||t===6?1.8:1.35,type:[`trunks`,`trolley`,`trunks`,`trunks`,`crates`][t%5]})),Wv={minX:-51.3,maxX:4.3,minZ:-27.2,maxZ:61.2};function Gv(){let e=new U;e.name=`platform-track`;let t=Math.max(160,106,tv+48),n=Ch({repeat:[3,7],base:3881008,roughness:1}),r=_h({repeat:[2,1],light:4864038,dark:2365969,roughness:.95}),i=bh({repeat:[1,8],base:9276035,roughness:.78,metalness:.45});for(let a=0;a<8;a++){let o=t/8,s=rv-t/2+o*(a+.5),c=new z(new K(4.4,.4,o),n);c.position.set(7,-1.5,s),c.receiveShadow=!0,e.add(c);let l=Math.floor(o/.8),u=new Lt(new K(2.8,.14,.28),r,l),d=new Ee;for(let e=0;e<l;e++)d.position.set(7,-1.25,s-o/2+e*.8+.4),d.updateMatrix(),u.setMatrixAt(e,d.matrix);u.instanceMatrix.needsUpdate=!0,u.computeBoundingSphere(),u.receiveShadow=!0,e.add(u);for(let t of[-A_,A_]){let n=new z(new K(.12,.18,o),i);n.position.set(7+t,-1.09,s),e.add(n)}}return e}function Kv(){let e=new U,t=[],n=_h({repeat:[1,16],light:8147760,dark:4007445}),r=Ch({repeat:[2,14],base:9339250}),i=new x({color:11109167,roughness:.35,metalness:.85});function a(a,o){let s=o-a;if(s<=.05)return;let c=(a+o)/2,l=new z(new K(.4,1.5,s),n);l.position.set(-5.2,.75,c),l.receiveShadow=!0,e.add(l);let u=new z(new K(.4,5.1,s),r);u.position.set(-5.2,4.05,c),u.receiveShadow=!0,e.add(u);let d=new z(new K(.5,.12,s),i);d.position.set(-5.16,1.55,c),e.add(d),t.push({minX:-5.45,maxX:-4.85,minZ:a,maxZ:o})}a(-28,Bv),a(Vv,Mv);let o=new z(new K(.45,3.4,Fv),r);o.position.set(-5.18,4.3,Pv),o.castShadow=!0,e.add(o);let s=new K(.5,Hv,.12);for(let t of[Bv,Vv]){let n=new z(s,i);n.position.set(-5.12,Hv/2,t),e.add(n)}let c=new z(new K(.5,.12,5.74),i);return c.position.set(-5.12,Hv,Pv),e.add(c),{group:e,colliders:t}}function qv(){let e=new U;e.name=`west-infiltration-wing`;let t=[],n=Lv.x,r=n- -52,i=(-52+n)/2,a=pg(),o=wg(),s=a.checker,c=a.plaster,l=a.wainscot,u=a.brass,d=a.green,f=new z(vg(new Ot(r,Fv),2.4),s);f.rotation.x=-Math.PI/2,f.position.set(i,.01,Pv),f.receiveShadow=!0,e.add(f);for(let a of[Bv,Vv]){let o=new z(vg(new K(r,Nv,.3),3),c);o.position.set(i,Nv/2,a),o.castShadow=!0,o.receiveShadow=!0,e.add(o);let s=new z(vg(new K(Math.max(.1,r-.18),1.45,.08),1.4),l);s.position.set(i,.73,a+(a===-27.25?.17:-.17)),e.add(s);let d=new z(new K(Math.max(.1,r-.18),.1,.1),u);d.position.set(i,1.52,a+(a===-27.25?.2:-.2)),e.add(d),t.push({minX:-52,maxX:n,minZ:a-.22,maxZ:a+.22})}let p=Pv-Rv/2,m=-22.6;for(let[n,r]of[[Bv,p],[m,Vv]]){let i=r-n;if(i<=.05)continue;let a=new z(vg(new K(.3,Nv,i),3),c);a.position.set(-52,Nv/2,(n+r)/2),a.castShadow=!0,a.receiveShadow=!0,e.add(a),t.push({minX:-52.2,maxX:-51.8,minZ:n,maxZ:r})}let g=new z(vg(new K(.3,1.5499999999999998,Rv),3),c);g.position.set(-52,5.225,Pv),g.castShadow=!0,e.add(g);let _=new K(.34,zv,.14);for(let t of[p,m]){let n=new z(_,d);n.position.set(-52,zv/2,t),e.add(n)}let v=new z(new K(.34,.12,4.04),d);v.position.set(-52,zv,Pv),e.add(v);let y=new z(vg(new K(r,.22,6),3),a.ceiling);y.position.set(i,Nv,Pv),e.add(y);let b=new z(new K(r-2,.06,1.1),new x({color:11058392,emissive:9678548,emissiveIntensity:1,roughness:.25}));b.position.set(i,5.87,Pv),e.add(b);let S=[{x:Iv[0],doorMin:-26.95,doorMax:-24.65},{x:Iv[1],doorMin:-24.15,doorMax:-21.9},{x:Iv[2],doorMin:-26.9,doorMax:-24.55}];function C({x:n,doorMin:r,doorMax:i}){let a=r-Bv,s=Vv-i;if(a>.05){let i=new z(vg(new K(.3,Nv,a),3),c);i.position.set(n,Nv/2,Bv+a/2),i.castShadow=!0,e.add(i),t.push({minX:n-.2,maxX:n+.2,minZ:Bv,maxZ:r})}if(s>.05){let r=new z(vg(new K(.3,Nv,s),3),c);r.position.set(n,Nv/2,i+s/2),r.castShadow=!0,e.add(r),t.push({minX:n-.2,maxX:n+.2,minZ:i,maxZ:Vv})}let l=new z(vg(new K(.3,3.4,i-r),3),c);l.position.set(n,4.3,(r+i)/2),l.castShadow=!0,e.add(l);let f=new K(.34,Hv,.12);for(let t of[r,i]){let r=new z(f,d);r.position.set(n,Hv/2,t),e.add(r)}let p=new z(new K(.34,.12,i-r+.24),d);p.position.set(n,Hv,(r+i)/2),e.add(p),o.add(d,Q(.42,.16,i-r+.5,n,2.74,(r+i)/2)),o.add(u,Q(.44,.03,i-r+.52,n,2.83,(r+i)/2))}S.forEach(C);for(let t=-48;t<=-8;t+=8){Eg(o,a,Z(t,5.89,Pv),1.45);let n=new j(16763274,18,11,2);n.position.set(t,4.3,Pv),e.add(n)}function w(e,n,r=0,i=!1){let s=Z(e,0,n,r);i?(Pg(o,a,new h().multiplyMatrices(s,Z(0,0,-.45,.04)),.95,.85,.9),Pg(o,a,new h().multiplyMatrices(s,Z(.05,.85,-.42,-.18)),.55,.42,.55),Ig(o,a,new h().multiplyMatrices(s,Z(0,0,.52,Math.PI/2)),.9,.5,.62),Ig(o,a,new h().multiplyMatrices(s,Z(0,.5,.5,Math.PI/2+.1)),.72,.4,.5)):Lg(o,a,s);let c=Math.abs(Math.sin(r))>.5,l=c?1:.7,u=c?.7:1;t.push({minX:e-l,maxX:e+l,minZ:n-u,maxZ:n+u})}function T(e,n,r=0){Ng(o,a,Z(e,0,n,r));let i=Math.abs(Math.sin(r))>.5,s=i?1.1:.45,c=i?.45:1.1;t.push({minX:e-s,maxX:e+s,minZ:n-c,maxZ:n+c})}T(-45,-22.65,Math.PI/2),w(-35,-25.85,Math.PI/2),T(-24,-22.65,Math.PI/2),w(-21,-26.05,0,!0),T(-12,-26.25,Math.PI/2),w(-8.5,-22.95,Math.PI/2);let E=[{face:-27.04,out:1},{face:-21.96,out:-1}],D=(e,t)=>Iv.some(n=>Math.abs(n-e)<t),O=()=>new K(.08,1.24,.03);for(let{face:e,out:t}of E){let s=r-.4;o.add(d,Q(s,.2,.05,i,.1,e+t*.02)),o.add(a.wood,Q(s,.06,.07,i,1.42,e+t*.02)),o.add(d,Q(s,.16,.12,i,5.81,e)),o.add(u,Q(s,.025,.13,i,5.72,e));for(let r=-51.2;r<n-.4;r+=1.15)D(r,.35)||o.instance(`stile`,O,a.wood,Z(r,.83,e+t*.015))}for(let e=-50;e<n-1;e+=4)D(e,.7)||o.add(a.wood,Q(.26,.3,5.2,e,5.74,Pv),null,!0);let k=[-51.6,...Iv.flatMap(e=>[e-.35,e+.35]),n-.3];for(let e=0;e<k.length;e+=2){let t=k[e],n=k[e+1],r=vg(new Ot(n-t,1.5),1.5);r.rotateX(-Math.PI/2),r.translate((t+n)/2,.022,Pv),o.add(a.runner,r);for(let e of[-1,1])o.add(u,Q(n-t,.012,.04,(t+n)/2,.022,Pv+e*.77))}Bg(o,a,Z(-44.6,0,-27.040000000000003,0),3.8),[-43,-35,-21,-13,-3].forEach((e,t)=>Rg(o,a,Z(e,2.55,-21.9,Math.PI),t)),[-37,-24,-14,-5].forEach((e,t)=>Rg(o,a,Z(e,2.55,-27.1,0),t+1)),zg(o,a,Z(Iv[0]-.16,3.7,-25.8,-Math.PI/2),.42),zg(o,a,Z(Iv[2]-.16,3.7,-25.72,-Math.PI/2),.42),D_(e,[...[-43,-35,-21,-13,-3].map(e=>({x:e,y:3.4,z:-21.919999999999998,yaw:Math.PI/2,width:2.6,height:2.6,strength:.16})),...[-37,-24,-14,-5].map(e=>({x:e,y:3.4,z:-27.080000000000002,yaw:-Math.PI/2,width:2.6,height:2.6,strength:.16}))],null,16752210,`hall-wall-glow`);let A=new U;A.name=`hall-dressing`;let ee=wg();for(let[e,t]of[[-47,-26.75],[-42.2,-26.75],[-51.5,-26.78],[-51.5,-22.22],[Iv[1]-.5,-26.75],[Iv[2]-.5,-22.25]])t_(ee,a,Z(e,0,t,e*1.7),.9);Qg(ee,a,Z(-47.6,4.35,Pv,-Math.PI/2),2.6,1.05,1.4),ee.build(A,`hall-dressing`),o.build(e,`hall-kit`);let M=new K(.16,Hv,.16);for(let t of[-27.13,-21.87]){let n=new z(M,u);n.position.set(Lv.x,Hv/2,t),e.add(n)}let N=new z(new K(.16,.14,Fv),u);return N.position.set(Lv.x,Hv,Pv),e.add(N),jv(e,t),{group:e,colliders:t,dressing:A}}function Jv(e){e&&(e.userData.decor=!0,e.userData.noInteractionBlocker=!0,e.userData.noCameraCollision=!0)}function Yv(){let{group:e}=ul(cl);return e.name=`guard-placeholder`,e.position.set(1.8,0,9),e.rotation.y=Math.PI*.85,e}function Xv(e){let t=new U;t.name=`camera-placeholder`;let n=new x({color:2764083,roughness:.55,metalness:.6}),r=new z(new K(.5,.08,.08),n);r.position.x=.25,t.add(r);let i=new z(new He(.22,14,10),n);i.position.x=.55,t.add(i);let a=new z(new p(.1,.12,.24,12),new x({color:658190,roughness:.15,metalness:.3}));a.rotation.z=Math.PI/2,a.rotation.y=.5,a.position.set(.72,-.04,.1),t.add(a);let o=new z(new He(.035,8,6),new x({color:16726832,emissive:16722464,emissiveIntensity:4}));return o.position.set(.66,.14,.14),t.add(o),t.position.set(-4.7,4.6,e),t}function Zv(){let e=new U,t=pg(),n=[],r={...t,greenDark:t.iron,stationStone:t.platformStone,concrete:t.platformStone};e.name=`open-platform`,e.userData.platformRegion=!0;let i=Array.from({length:5},(e,t)=>{let n=wg();return{start:-28+t*20,end:Math.min(62,-8+t*20),builder:n,b:{add:(e,t,r)=>n.add(e,t,r)}}}),a=e=>i[Math.min(4,Math.max(0,Math.floor((e+28)/20)))],o=(e,t,n,r,i,a,o,s,c=1)=>e.add(t,Q(n,r,i,a,o,s,c)),s=[-26,-18,-10,-2,4,12,20,28,36,45,52,61];for(let{start:e,end:t,b:a}of i){let i=t-e,s=(e+t)/2,c=vg(new Ot(10,i),4);c.rotateX(-Math.PI/2),c.translate(0,0,s),a.add(r.platformPaving,c),o(a,r.stationStone,.4,.1,i,4.8,-.04,s),o(a,r.paper,.12,.012,i,4.28,.012,s),o(a,r.iron,.2,1.4,i,5,-.7,s),o(a,r.wood,11.8,.22,i,-.3,6,s,2);for(let e of[-4.7,-1.5,1.7,4.6])o(a,r.wood,.16,.22,i,e,5.78,s);let l=Math.max(e,Vv);t>l&&(o(a,r.platformStone,.16,6,t-l,-4.92,3,(l+t)/2,2),n.push({minX:-5.1,maxX:-4.84,minZ:l,maxZ:t}));for(let n=e+1;n<t;n+=2)o(a,r.wood,11.6,.2,.12,-.3,5.82,n)}for(let e of s){let t=a(e).b;o(t,r.iron,.64,.28,.64,4.6,.14,e);let i=new p(.16,.23,5.35,10);i.translate(4.6,2.94,e),t.add(r.iron,i);for(let n of[.42,5.55])o(t,r.brass,.42,.1,.42,4.6,n,e);o(t,r.wood,10,.3,.23,-.2,5.58,e);let s=new ve(new R(4.6,4.4,e),new R(3.4,4.45,e),new R(3.3,5.6,e),new R(4.3,5.6,e));t.add(r.iron,new nt(s,10,.045,4,!1)),n.push({minX:4.28,maxX:4.92,minZ:e-.32,maxZ:e+.32,kind:`wall`})}let c=[];for(let e=-24;e<=60;e+=6)Eg(a(e).b,r,Z(.4,5.85,e),1.25),c.push(e);for(let t of[-12,16,44]){let n=new j(16760962,34,19,2);n.position.set(.4,4.4,t),e.add(n)}for(let e=-18;e<=58;e+=8){let t=a(e).b;Ag(t,r,Z(-4.81,1.05,e,Math.PI/2),e===6||e===38),jg(t,r,Z(-4.78,3.45,e+3,Math.PI/2))}for(let[e,t]of[[-20.5,0],[17.5,1],[41.5,2]]){let n=a(e).b;Rg(n,e<0?{...r,poster:()=>r.chronoPoster}:r,Z(-4.79,3,e,Math.PI/2),t,e<0?1.35:.85,e<0?2.05:1.3)}let l=a(10).b;o(l,r.iron,1.3,.1,.1,-4.2,4.95,10),o(l,r.iron,.08,.5,.08,-3.6,4.7,10),n_(l,r,Z(-3.6,4.25,10),.48,.45);let u=new Map;for(let t of Uv){let{id:i,x:s,z:c,width:l,height:d,length:f,type:m}=t,h=wg();h.add(m===`crates`?r.crate:r.leather,Q(l,d,f,s,d/2,c));let g=new U,[_]=h.build(g,i);_.userData.coverId=i,u.set(i,_),e.add(g),n.push({minX:s-l/2,maxX:s+l/2,minZ:c-f/2,maxZ:c+f/2,kind:m===`crates`?`crate`:`trunk`});let v=a(c).b;for(let e of[-2.8,-1.4,0,1.4,2.8]){o(v,r.brass,l+.012,.035,.06,s,d+.01,c+e);for(let t of[-1,1])o(v,r.brass,.025,d,.06,s+t*(l/2+.01),d/2,c+e)}for(let e of[-1.8,0,1.8])Ig(v,r,Z(s,d,c+e),1.1,.32,1.2);if(m===`trolley`)for(let e of[-2.4,2.4])for(let t of[-1,1]){let n=new p(.15,.15,.06,10);n.rotateZ(Math.PI/2),n.translate(s+t*.58,.15,c+e),v.add(r.iron,n)}}for(let e of[-13.7,3,20,36,52,59])Ng(a(e).b,r,Z(-4.25,0,e)),n.push({minX:-4.68,maxX:-3.82,minZ:e-1,maxZ:e+1,kind:`seat`});for(let e of[-10.8,7.5,23.8,39.5,55.5])Mg(a(e).b,r,Z(-4.3,0,e)),n.push({minX:-4.75,maxX:-3.85,minZ:e-.45,maxZ:e+.45,kind:`crate`});for(let e of[-28,62]){let t=a(e).b,i=e<0;o(t,i?r.platformStone:r.iron,10,i?6:1.2,.2,0,i?3:.6,e,2),n.push({minX:-5,maxX:5,minZ:e-.1,maxZ:e+.1})}let d=a(62).b;r_(d,r,Z(10.6,-1,70),5.6);for(let{start:t,builder:n}of i){let r=new U;r.name=`platform-section-${t}`,n.build(r,`platform-detail`,{decor:!0}),e.add(r)}Jv(O_(e,c.map(e=>({x:.4,y:0,z:e,radius:2.5,strength:.2})),null,16758374,`platform-warm-pools`));let f=wg();for(let e of c)for(let t of[-.3,0,.3])o(f,r.lampShade,.045,.002,1.8,.4+t,.006,e);return f.build(e,`wet-light-streaks`,{decor:!0}),{group:e,colliders:n,cores:u}}function Qv({includePlaceholders:e=!1}={}){let t=new U;t.name=`station`;let n=Gv();t.add(n);let r=Kv();t.add(r.group);let i=qv();t.add(i.group);let a=Zv();return t.add(a.group),e&&(t.add(Yv()),t.add(Xv(-8)),t.add(Xv(12))),{group:t,bounds:Wv,platform:a.group,track:n,coverCores:a.cores,hallDressing:i.dressing,wallColliders:[...r.colliders,...i.colliders,...a.colliders]}}var $v=30*Math.PI/180,ey=new R(16,0,3).normalize(),ty=16,ny=36,ry=new R(ey.x*Math.cos($v),Math.sin($v),ey.z*Math.cos($v)),iy=new R(.85,.25,.46).normalize(),ay=new R(0,1,0),oy=new R,sy=new R,cy=new R,ly=new R,uy=new R;function dy(e,t,n=ry){if(!e||!t)return;let r=e.target;r.position.copy(t),e.position.copy(t).addScaledVector(n,ny);let i=e.shadow.camera;i.position.copy(e.position),i.up.copy(ay),i.lookAt(r.position),i.updateMatrixWorld(),oy.setFromMatrixColumn(i.matrixWorld,0),sy.setFromMatrixColumn(i.matrixWorld,1),cy.setFromMatrixColumn(i.matrixWorld,2);let a=Math.max(1,e.shadow.mapSize.x),o=(i.right-i.left)/a,s=Math.round(r.position.dot(oy)/o)*o,c=Math.round(r.position.dot(sy)/o)*o,l=r.position.dot(cy);ly.set(0,0,0).addScaledVector(oy,s).addScaledVector(sy,c).addScaledVector(cy,l),uy.copy(ly).sub(r.position),r.position.add(uy),e.position.add(uy)}function fy(){let e=new ce(13163254,1.95);e.name=`station-sun`,e.position.copy(ry).multiplyScalar(ny),e.castShadow=!0;let t=wa(Y.get(`shadowQuality`))||2048;e.shadow.mapSize.set(t,t),e.shadow.camera.left=-16,e.shadow.camera.right=ty,e.shadow.camera.top=ty,e.shadow.camera.bottom=-16,e.shadow.camera.near=1,e.shadow.camera.far=68,e.shadow.camera.updateProjectionMatrix(),e.shadow.camera.layers.enable(1),e.shadow.bias=-2e-4,e.shadow.normalBias=.045,e.target.position.set(0,0,0);let n=new W(2769e3,657678,.48);n.name=`station-sky`;let r=new _t(1053468,.06);r.name=`station-fill`;let i=[],a=[],o=new ft(16758892,6,145,Math.PI/2.8,.75,1.5);o.position.set(-5,6.2,-12);let s=new Ee;s.position.set(-65,18,-25),o.target=s,i.push(o),a.push(s);let c=new ft(16761984,8,165,Math.PI/2.6,.8,1.4);c.position.set(-5,6.4,0);let l=new Ee;l.position.set(-75,24,0),c.target=l,c.castShadow=!1,i.push(c),a.push(l);let u=new ft(16758892,6,145,Math.PI/2.8,.75,1.5);u.position.set(-5,6.2,12);let d=new Ee;d.position.set(-65,18,25),u.target=d,i.push(u),a.push(d);let f=[e,e.target,n,r,...i,...a];return f.spotLights=i,f}function py(e,t,n){let i=new Uint8Array([e,t,n,255]),a=new r(i,1,1);return a.wrapS=Oe,a.wrapT=Oe,a.colorSpace=``,a.needsUpdate=!0,a}function my(e={}){let t=[new R,new R,new R],n=[new R(0,-1,0),new R(0,-1,0),new R(0,-1,0)],r=[new q(0),new q(0),new q(0)],i=[new ut,new ut,new ut],a={uTime:{value:0},uSunDirection:{value:e.sunDirection||new R(1,1,-.5).normalize()},uSunColor:{value:new q(e.sunColor||16757107)},uSkyColor:{value:new q(e.skyColor||6188950)},uGroundColor:{value:new q(e.groundColor||2761243)},uGrassColor:{value:new q(e.grassColor||2832420)},uRockColor:{value:new q(e.rockColor||4867906)},uGravelColor:{value:new q(e.gravelColor||4012080)},uFogColor:{value:new q(e.fogColor||2366756)},uFogNear:{value:e.fogNear??30},uFogFar:{value:e.fogFar??250},uFogMax:{value:e.fogMax??1},uAmbient:{value:e.ambient??.7},uMist:{value:e.mist??0},uPaths:{value:e.paths??0},uPhoto:{value:e.photo??0},uGroundMap:{value:e.groundMap||py(80,90,60)},uGroundNormal:{value:e.groundNormal||py(128,128,255)},uRockMap:{value:e.rockMap||py(90,86,80)},uRockNormal:{value:e.rockNormal||py(128,128,255)},uStationSpotLightCount:{value:0},uStationSpotLightPos:{value:t},uStationSpotLightDir:{value:n},uStationSpotLightColor:{value:r},uStationSpotLightParams:{value:i}},o=new Je({uniforms:a,vertexShader:`
    varying vec3 vWorldPosition;
    varying vec3 vNormal;
    varying vec2 vUv;
    varying float vViewDistance;

    void main() {
      vUv = uv;
      vNormal = normalize(mat3(modelMatrix) * normal);
      vec4 worldPosition = modelMatrix * vec4(position, 1.0);
      vWorldPosition = worldPosition.xyz;

      vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
      vViewDistance = -mvPosition.z;

      gl_Position = projectionMatrix * mvPosition;
    }
  `,fragmentShader:`
    varying vec3 vWorldPosition;
    varying vec3 vNormal;
    varying vec2 vUv;
    varying float vViewDistance;

    uniform vec3 uSunDirection;
    uniform vec3 uSunColor;
    uniform vec3 uSkyColor;
    uniform vec3 uGroundColor;
    uniform vec3 uGrassColor;
    uniform vec3 uRockColor;
    uniform vec3 uGravelColor;
    uniform vec3 uFogColor;
    uniform float uFogNear;
    uniform float uFogFar;
    uniform float uFogMax;
    uniform float uAmbient;
    uniform float uMist;
    uniform float uPaths;
    uniform float uPhoto;
    uniform sampler2D uGroundMap;
    uniform sampler2D uGroundNormal;
    uniform sampler2D uRockMap;
    uniform sampler2D uRockNormal;
    uniform float uTime;

    uniform int uStationSpotLightCount;
    uniform vec3 uStationSpotLightPos[3];
    uniform vec3 uStationSpotLightDir[3];
    uniform vec3 uStationSpotLightColor[3];
    uniform vec4 uStationSpotLightParams[3]; // x: intensity, y: cutoffCos, z: penumbraCos, w: distance

    float hash(vec2 p) {
      return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453);
    }

    float segDist(vec2 p, vec2 a, vec2 b) {
      vec2 pa = p - a;
      vec2 ba = b - a;
      float h = clamp(dot(pa, ba) / dot(ba, ba), 0.0, 1.0);
      return length(pa - ba * h);
    }

    float noise(vec2 p) {
      vec2 i = floor(p);
      vec2 f = fract(p);
      f = f * f * (3.0 - 2.0 * f);
      return mix(
        mix(hash(i), hash(i + vec2(1.0, 0.0)), f.x),
        mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), f.x),
        f.y
      );
    }

    void main() {
      vec3 normal = normalize(vNormal);

      // Slope factor: 1.0 for flat ground, 0.0 for vertical cliff face
      float slope = clamp(normal.y, 0.0, 1.0);
      float cliffFactor = smoothstep(0.7, 0.45, slope);

      // Height factor: height above track level
      float height = vWorldPosition.y;

      // Distance from track center line (X = 7.0)
      float distFromTrack = abs(vWorldPosition.x - 7.0);
      float trackGravelFactor = smoothstep(12.0, 3.5, distFromTrack) * smoothstep(8.0, -2.0, height);

      // Detail noise texture modulation
      float detailNoise = noise(vWorldPosition.xz * 0.15);
      float microNoise = noise(vWorldPosition.xz * 0.8);

      vec3 grassCol = uGrassColor * (0.85 + detailNoise * 0.35 + microNoise * 0.15);
      vec3 rockCol = uRockColor * (0.8 + detailNoise * 0.4);
      vec3 gravelCol = uGravelColor * (0.9 + microNoise * 0.2);

      // Blend layers
      vec3 baseColor = mix(grassCol, rockCol, cliffFactor);
      baseColor = mix(baseColor, gravelCol, trackGravelFactor * (1.0 - cliffFactor * 0.5));

      // Mountain peak snow/grey rock highlight for tall hills
      // Worn earth. Two segments leave the station area and head up the
      // valley. uPaths is 0 on the moving levels, so this stays off there.
      float pathA = segDist(vWorldPosition.xz, vec2(-168.0, -18.0), vec2(-30.0, 28.0));
      float pathB = segDist(vWorldPosition.xz, vec2(-30.0, 28.0), vec2(55.0, 78.0));
      float worn = 1.0 - smoothstep(1.1, 3.4, min(pathA, pathB));
      baseColor = mix(baseColor, uGravelColor * 0.72 + vec3(0.06, 0.04, 0.02), worn * uPaths);

      float peakFactor = smoothstep(25.0, 60.0, height);
      baseColor = mix(baseColor, uRockColor * 1.3 + vec3(0.1, 0.1, 0.12), peakFactor * (1.0 - slope * 0.4));

      // Photo ground near the walkable run. The maps are sRGB stored as
      // raw texels, so they are converted before the moonlight multiply.
      // uPhoto is 0 on the moving levels and this block stays off.
      vec2 playMin = vec2(-189.0, -52.0);
      vec2 playMax = vec2(4.3, 27.0);
      vec2 clampedXZ = clamp(vWorldPosition.xz, playMin, playMax);
      float playGap = length(vWorldPosition.xz - clampedXZ);
      float nearPlay = (1.0 - smoothstep(6.0, 40.0, playGap)) * uPhoto;
      if (nearPlay > 0.001) {
        vec2 groundUv = vWorldPosition.xz * 0.11;
        vec2 rockUv = vWorldPosition.xz * 0.07;
        // Two scales of the same photo. The broad sample breaks the
        // repeat that shows in the gaps between grass blades.
        vec3 groundFine = pow(texture2D(uGroundMap, groundUv).rgb, vec3(2.2));
        vec3 groundBroad = pow(texture2D(uGroundMap, vWorldPosition.xz * 0.027).rgb, vec3(2.2));
        float tileMix = 0.38 + 0.28 * noise(vWorldPosition.xz * 0.041);
        vec3 groundTex = mix(groundFine, groundBroad, tileMix);
        // Patches many metres across, so the soil is not one flat tint.
        float patch = noise(vWorldPosition.xz * 0.011);
        // Stay in the green. The old high end (1.08, 1.00, 0.88) lifted the
        // red leaf-litter in the photo, and the blue night multiply turned
        // those patches magenta.
        groundTex *= mix(vec3(0.66, 0.86, 0.60), vec3(0.80, 1.06, 0.68), patch);
        vec3 rockTex = pow(texture2D(uRockMap, rockUv).rgb, vec3(2.2));
        vec3 photo = mix(groundTex, rockTex, cliffFactor);
        // Daylight photos are too green and too saturated for moonlight.
        // Pull them toward a cool grey so the grain stays and the hue does not.
        float photoLuma = dot(photo, vec3(0.299, 0.587, 0.114));
        photo = mix(photo, vec3(photoLuma), 0.32);
        photo.r = min(photo.r, max(photo.g, 0.02) * 0.88);
        photo.b = min(photo.b, photo.g * 1.02);
        photo *= vec3(0.76, 0.98, 0.78);
        // Meadow bed under the spawn grass. Gaps were reading as bright
        // dirt. This pulls that band toward a dark cool green-brown
        // while the patch variation above still shows through.
        float bedSpawn = length(vWorldPosition.xz - vec2(-182.1, -24.5));
        float bedDoor = length(vWorldPosition.xz - vec2(-166.0, -24.5));
        float bedDist = min(bedSpawn, bedDoor);
        float grassBed = (1.0 - smoothstep(5.0, 40.0, bedDist)) * (1.0 - cliffFactor);
        vec3 bedSoil = vec3(0.030, 0.042, 0.024);
        photo = mix(photo, photo * vec3(0.48, 0.58, 0.46) + bedSoil, grassBed * 0.85);
        baseColor = mix(baseColor, photo * (0.9 + detailNoise * 0.16), nearPlay);
        vec3 groundN = texture2D(uGroundNormal, groundUv).xyz * 2.0 - 1.0;
        vec3 rockN = texture2D(uRockNormal, rockUv).xyz * 2.0 - 1.0;
        vec3 photoN = mix(groundN, rockN, cliffFactor);
        normal = normalize(normal + vec3(photoN.x, photoN.z, photoN.y) * nearPlay * 0.5);
      }

      // Hemisphere & Directional Lighting
      float NdotL = max(0.0, dot(normal, uSunDirection));
      float skyDiff = clamp(0.5 + 0.5 * normal.y, 0.0, 1.0);

      vec3 diffuse = NdotL * uSunColor * 1.2;
      vec3 ambient = mix(uGroundColor, uSkyColor, skyDiff) * uAmbient;

      // Textured Boarding ground uses the same diffuse model as a standard
      // material: station moonlight (0xc8daf6 at 1.95), the hemisphere
      // (0x2a4068 over 0x0a090e at 0.48), and a dim cool fill for the
      // environment map at intensity 0.4. Diffuse is divided by PI.
      // nearPlay is 0 on the moving levels, so they keep the line above.
      vec3 moonIrradiance = vec3(0.784, 0.855, 0.965) * 1.95 * NdotL;
      vec3 hemiIrradiance = mix(vec3(0.039, 0.035, 0.055), vec3(0.165, 0.251, 0.408), skyDiff) * 0.48;
      vec3 envIrradiance = vec3(0.10, 0.12, 0.18) * 0.4;
      vec3 standardLit = baseColor * (moonIrradiance + hemiIrradiance + envIrradiance) * 0.3183;
      vec3 legacyLit = baseColor * (diffuse + ambient);

      // Station Exterior Spotlight Illumination
      vec3 stationLightContrib = vec3(0.0);
      for (int i = 0; i < 3; i++) {
        if (i >= uStationSpotLightCount) break;
        vec3 pos = uStationSpotLightPos[i];
        vec3 dir = normalize(uStationSpotLightDir[i]);
        vec3 col = uStationSpotLightColor[i];
        float intensity = uStationSpotLightParams[i].x;
        float cutoffCos = uStationSpotLightParams[i].y;
        float penumbraCos = uStationSpotLightParams[i].z;
        float maxDist = uStationSpotLightParams[i].w;

        vec3 toLight = vWorldPosition - pos;
        float dist = length(toLight);
        if (dist > maxDist || maxDist <= 0.0) continue;

        vec3 lDir = -normalize(toLight);
        float cosAngle = dot(lDir, -dir);

        if (cosAngle > cutoffCos) {
          float spotFactor = smoothstep(cutoffCos, penumbraCos, cosAngle);
          float distRatio = dist / maxDist;
          float distFactor = clamp(1.0 - distRatio * distRatio, 0.0, 1.0);
          distFactor = distFactor * distFactor;

          float spotNdotL = max(0.0, dot(normal, lDir));
          stationLightContrib += col * (intensity * spotNdotL * spotFactor * distFactor);
        }
      }

      vec3 litColor = mix(legacyLit, standardLit, nearPlay) + baseColor * stationLightContrib;

      // Distance fog calculation
      float fogFactor = min(smoothstep(uFogNear, uFogFar, vViewDistance), uFogMax);
      vec3 finalColor = mix(litColor, uFogColor, fogFactor);

      // Low mist. Stronger in the valley floor, drifting slowly with uTime.
      // uMist is 0 on the moving levels.
      float drift = noise(vWorldPosition.xz * 0.02 + vec2(uTime * 0.012, 0.0));
      float mist = smoothstep(9.0, 0.4, vWorldPosition.y);
      mist *= smoothstep(30.0, 110.0, vViewDistance);
      mist *= (0.55 + 0.45 * drift) * uMist;
      finalColor = mix(finalColor, uFogColor * 0.72 + vec3(0.025, 0.03, 0.045), mist);

      gl_FragColor = vec4(finalColor, 1.0);
      // Same ACES curve and sRGB output as the standard materials. Without
      // this, a shadowed slope's linear colour is stored as if it were already
      // display-ready and reads as black.
      #include <tonemapping_fragment>
      #include <colorspace_fragment>
    }
  `,side:2});return o.customUniforms=a,o}function hy(e={}){let t=[new R,new R,new R],n=[new R(0,-1,0),new R(0,-1,0),new R(0,-1,0)],r=[new q(0),new q(0),new q(0)],i=[new ut,new ut,new ut],a={uTime:{value:0},uWindSpeed:{value:e.windSpeed??1.8},uWindStrength:{value:e.windStrength??.15},uSwayHeight:{value:e.swayHeight??7.5},uSunDirection:{value:e.sunDirection||new R(1,1,-.5).normalize()},uSunColor:{value:new q(e.sunColor||16757107)},uSkyColor:{value:new q(e.skyColor||6188950)},uFoliageColor:{value:new q(e.foliageColor||2242077)},uHighlightColor:{value:new q(e.highlightColor||4877106)},uFogColor:{value:new q(e.fogColor||2366756)},uFogNear:{value:e.fogNear??30},uFogFar:{value:e.fogFar??250},uFogMax:{value:e.fogMax??1},uAmbient:{value:e.ambient??.6},uMist:{value:e.mist??0},uStationSpotLightCount:{value:0},uStationSpotLightPos:{value:t},uStationSpotLightDir:{value:n},uStationSpotLightColor:{value:r},uStationSpotLightParams:{value:i}},o=new Je({uniforms:a,vertexShader:`
    uniform float uTime;
    uniform float uWindSpeed;
    uniform float uWindStrength;
    uniform float uSwayHeight;

    varying vec3 vWorldPosition;
    varying vec3 vNormal;
    varying vec2 vUv;
    varying float vViewDistance;
    varying float vHeight;
    varying vec3 vTint;

    void main() {
      vUv = uv;
      vNormal = normalize(mat3(modelMatrix * instanceMatrix) * normal);
      vTint = instanceColor;

      vec3 pos = position;

      // Sway grows toward the crown. The phase is the tree's own position,
      // so neighbours do not rock in lockstep. Trunks (low y) stay still.
      float heightFactor = smoothstep(0.05, uSwayHeight, pos.y);
      heightFactor *= heightFactor;
      vec4 instanceWorldPos = modelMatrix * instanceMatrix * vec4(0.0, 0.0, 0.0, 1.0);
      float phase = instanceWorldPos.x * 0.37 + instanceWorldPos.z * 0.23;

      float windWave = sin(uTime * uWindSpeed + phase);
      float gustWave = cos(uTime * uWindSpeed * 0.62 + phase * 1.7);

      vec3 windOffset = vec3(
        (windWave + gustWave * 0.45) * uWindStrength * heightFactor,
        sin(uTime * uWindSpeed * 1.3 + phase) * 0.05 * heightFactor,
        (cos(windWave) * 0.55) * uWindStrength * heightFactor
      );

      pos += windOffset;
      vHeight = max(0.0, pos.y);

      vec4 worldPosition = modelMatrix * instanceMatrix * vec4(pos, 1.0);
      vWorldPosition = worldPosition.xyz;

      vec4 mvPosition = viewMatrix * worldPosition;
      vViewDistance = -mvPosition.z;

      gl_Position = projectionMatrix * mvPosition;
    }
  `,fragmentShader:`
    varying vec3 vWorldPosition;
    varying vec3 vNormal;
    varying vec2 vUv;
    varying float vViewDistance;
    varying float vHeight;
    varying vec3 vTint;

    uniform vec3 uSunDirection;
    uniform vec3 uSunColor;
    uniform vec3 uSkyColor;
    uniform vec3 uFoliageColor;
    uniform vec3 uHighlightColor;
    uniform vec3 uFogColor;
    uniform float uFogNear;
    uniform float uFogFar;
    uniform float uFogMax;
    uniform float uAmbient;
    uniform float uMist;
    uniform float uTime;

    uniform int uStationSpotLightCount;
    uniform vec3 uStationSpotLightPos[3];
    uniform vec3 uStationSpotLightDir[3];
    uniform vec3 uStationSpotLightColor[3];
    uniform vec4 uStationSpotLightParams[3]; // x: intensity, y: cutoffCos, z: penumbraCos, w: distance

    void main() {
      vec3 normal = normalize(vNormal);

      // Base color gradient from trunk/bottom to canopy top
      float topGradient = smoothstep(0.0, 4.0, vHeight);
      vec3 baseColor = mix(uFoliageColor, uHighlightColor, topGradient) * vTint;

      // Directional light & backlight translucency
      float NdotL = max(0.0, dot(normal, uSunDirection));
      float backLight = max(0.0, dot(-normal, uSunDirection)) * 0.45; // Subsurface translucent glow

      float skyDiff = clamp(0.5 + 0.5 * normal.y, 0.0, 1.0);

      vec3 diffuse = (NdotL + backLight) * uSunColor * 1.1;
      vec3 ambient = uSkyColor * skyDiff * uAmbient;

      // Station Exterior Spotlight Illumination
      vec3 stationLightContrib = vec3(0.0);
      for (int i = 0; i < 3; i++) {
        if (i >= uStationSpotLightCount) break;
        vec3 pos = uStationSpotLightPos[i];
        vec3 dir = normalize(uStationSpotLightDir[i]);
        vec3 col = uStationSpotLightColor[i];
        float intensity = uStationSpotLightParams[i].x;
        float cutoffCos = uStationSpotLightParams[i].y;
        float penumbraCos = uStationSpotLightParams[i].z;
        float maxDist = uStationSpotLightParams[i].w;

        vec3 toLight = vWorldPosition - pos;
        float dist = length(toLight);
        if (dist > maxDist || maxDist <= 0.0) continue;

        vec3 lDir = -normalize(toLight);
        float cosAngle = dot(lDir, -dir);

        if (cosAngle > cutoffCos) {
          float spotFactor = smoothstep(cutoffCos, penumbraCos, cosAngle);
          float distRatio = dist / maxDist;
          float distFactor = clamp(1.0 - distRatio * distRatio, 0.0, 1.0);
          distFactor = distFactor * distFactor;

          float spotNdotL = max(0.0, dot(normal, lDir));
          stationLightContrib += col * (intensity * spotNdotL * spotFactor * distFactor);
        }
      }

      vec3 litColor = baseColor * (diffuse + ambient + stationLightContrib);

      // Distance fog calculation
      float fogFactor = min(smoothstep(uFogNear, uFogFar, vViewDistance), uFogMax);
      vec3 finalColor = mix(litColor, uFogColor, fogFactor);
      float drift = 0.5 + 0.5 * sin(vWorldPosition.x * 0.03 + vWorldPosition.z * 0.021 + uTime * 0.08);
      float mist = smoothstep(8.0, 0.6, vWorldPosition.y) * smoothstep(18.0, 80.0, vViewDistance);
      mist *= (0.65 + 0.35 * drift) * uMist;
      finalColor = mix(finalColor, uFogColor * 0.7 + vec3(0.02, 0.025, 0.04), mist);

      gl_FragColor = vec4(finalColor, 1.0);
      #include <tonemapping_fragment>
      #include <colorspace_fragment>
    }
  `,side:2});return o.customUniforms=a,o}function gy(e){if(!Number.isInteger(e)||e<1)throw RangeError(`Invalid load concurrency`);let t=[],n=0;function r(){for(;n<e&&t.length;){let{task:e,resolve:i,reject:a}=t.shift();n++,Promise.resolve().then(e).then(e=>{n--,i(e),r()},e=>{n--,a(e),r()})}}return e=>new Promise((n,i)=>{t.push({task:e,resolve:n,reject:i}),r()})}var _y=Sh({repeat:[3,1.2],brick:7222316,mortar:6051918}),vy=Sh({repeat:[1.5,.4],seed:19,brick:7236194,mortar:4868164}),yy=new x({color:6972508,roughness:.94,metalness:.02}),by=bh({repeat:[6,2],seed:61,base:3817544,roughness:.55,metalness:.72}),xy=bh({repeat:[2,1],seed:44,base:1843752,roughness:.42,metalness:.8});bh({repeat:[2,1],seed:48,base:4081748,roughness:.55,metalness:.35});var Sy=new x({color:16769712,emissive:16757082,emissiveIntensity:1.6,roughness:.25}),Cy=new x({color:1316894,emissive:659480,emissiveIntensity:.15,roughness:.15}),wy=_h({repeat:[1,1],seed:12,light:6965808,dark:3810324});function Ty(e,t,n,r,i,a,o){let s=new K(t,n,r);s.translate(i,a,o),e.push(s)}function Ey(e,t=.42){if(!e.length)return null;let n=e.map(e=>e.index?e.toNonIndexed():e);for(let t of e)t.index&&t.dispose();e=n;let r=0;for(let t of e)r+=t.attributes.position.count;let i=new Float32Array(r*3),a=new Float32Array(r*3),o=new Float32Array(r*2),s=0;for(let n of e){n.attributes.normal||n.computeVertexNormals();let e=n.attributes.position,r=n.attributes.normal;for(let n=0;n<e.count;n+=1){let c=e.getX(n),l=e.getY(n),u=e.getZ(n),d=Math.abs(r.getX(n)),f=Math.abs(r.getY(n)),p=Math.abs(r.getZ(n)),m,h;f>=d&&f>=p?(m=c,h=u):d>=p?(m=u,h=l):(m=c,h=l);let g=s+n;i[g*3]=c,i[g*3+1]=l,i[g*3+2]=u,a[g*3]=r.getX(n),a[g*3+1]=r.getY(n),a[g*3+2]=r.getZ(n),o[g*2]=m*t,o[g*2+1]=h*t}s+=e.count,n.dispose()}let c=new We;return c.setAttribute(`position`,new Rt(i,3)),c.setAttribute(`normal`,new Rt(a,3)),c.setAttribute(`uv`,new Rt(o,2)),c}function Dy({brickMap:e,brickNormal:t,roofMap:n,roofNormal:r,pillarMap:i,pillarNormal:a}){_y.color.set(16777215),_y.map=e,_y.normalMap=t,_y.roughness=.84,_y.metalness=.02,_y.needsUpdate=!0,by.color.set(16777215),by.map=n,by.normalMap=r,by.roughness=.58,by.metalness=.55,by.needsUpdate=!0,i&&a&&(yy.map=i,yy.normalMap=a,yy.color.set(6972508),yy.needsUpdate=!0)}function Oy(e,t,n,r,i){let a=Ey(t,i);if(!a)return;let o=new z(a,n);o.name=r,o.castShadow=!1,o.receiveShadow=!1,e.add(o)}function ky(e,{name:t=`passage-shell`,minX:n,maxX:r,minZ:i,maxZ:a,floorY:o=0,wallHeight:s=5.2,skipWest:c=!1,skipEast:l=!1,gaps:u=[],signs:d=!1}={}){let f=new U;f.name=t;let m=r-n,h=a-i,g=(n+r)/2,_=(i+a)/2,v=o,y=o+s,b=.16,x=[],S=[],C=[];for(let[e,t]of[[`maxZ`,a+b*.5],[`minZ`,i-b*.5]]){let i=u.filter(t=>t.side===e).map(e=>[Math.max(n-.1,e.from),Math.min(r+.1,e.to)]).sort((e,t)=>e[0]-t[0]),a=n-.1;for(let[e,o]of[...i,[r+.1,r+.1]]){let i=e-a;if(i>.02){let o=(a+e)/2,c=Math.max(a,n),l=Math.min(e,r);l-c>.02&&Ty(x,l-c,s-.7,b,(c+l)/2,v+(s-.7)/2+.7,t),Ty(S,i,.7,.22,o,v+.35,t)}a=Math.max(a,o)}}if(!c){let e=2.85,t=(h-3)/2,r=v+.7+(s-.7)/2;Ty(x,b,s-.7,t,n-b*.5,r,_-(3+t)/2),Ty(x,b,s-.7,t,n-b*.5,r,_+(3+t)/2),Ty(x,b,s-e,3,n-b*.5,v+e+(s-e)/2,_),Ty(S,.22,.7,t,n-b*.5,v+.35,_-(3+t)/2),Ty(S,.22,.7,t,n-b*.5,v+.35,_+(3+t)/2)}l||(Ty(x,b,s-.7,h,r+b*.5,v+(s-.7)/2+.7,_),Ty(S,.22,.7,h+.12,r+b*.5,v+.35,_));for(let[e,t]of[[n,i],[n,a],[r,i],[r,a]])Ty(C,.42,s,.42,e,v+s/2,t);let w=[],T=1.05,E=Math.hypot(h*.5+.55,T),D=Math.atan2(T,h*.5+.55);for(let e of[-1,1]){let t=new K(m+.9,.07,E);t.rotateX(e*D),t.translate(g,y+T*.55,_+h*.22*e),w.push(t)}let O=[];Ty(O,m+.7,.08,.1,g,y+.08,a+.45),Ty(O,m+.7,.08,.1,g,y+.08,i-.45),Ty(O,.08,y-v-.2,.08,n+.4,v+(y-v)*.45,a+.5),Ty(O,.08,y-v-.2,.08,r-.8,v+(y-v)*.45,i-.5);let k=[],A=[],j=[],ee=Math.max(2,Math.floor(m/4.5));for(let e=0;e<ee;e+=1){let t=n+(e+.5)*(m/ee);Ty(e%2==0?k:A,.9,1.15,.04,t,v+2.5,a+b+.02),Ty(j,1.08,1.32,.05,t,v+2.5,a+b)}if(Oy(f,x,_y,`${t}-brick`,1/1.7),Oy(f,S,vy,`${t}-plinth`),Oy(f,C,yy,`${t}-quoins`),Oy(f,w,by,`${t}-roof`),Oy(f,O,xy,`${t}-gutter`),Oy(f,j,xy,`${t}-frames`),Oy(f,k,Sy,`${t}-warm-glass`),Oy(f,A,Cy,`${t}-dark-glass`),d){let e=new z(new Ot(2.4,.42),Th({text:`CHRONO RAIL CO. - SECURITY`,width:1024,height:180,background:1709068,foreground:14860922}));e.position.set(n-b-.02,v+3.15,_+1.7),e.rotation.y=-Math.PI/2;let i=new z(new Ot(1.35,.28),Th({text:`AUTHORISED PERSONNEL ONLY`,width:768,height:160,background:2757134,foreground:15787732,emissiveIntensity:1.05}));i.position.set(n-b-.02,v+2.55,_-1.55),i.rotation.y=-Math.PI/2;let o=new z(new K(.55,.16,.28),xy);o.position.set(n-.28,v+3.55,_);let s=new z(new K(.38,.06,.16),Sy);s.position.set(n-.42,v+3.44,_);let c=new z(new p(.06,.06,2.2,6),xy);c.position.set(r-.3,v+3.2,a+.35);let l=new z(new K(.45,.6,.22),xy);l.position.set(n+1.4,v+1.5,a+.28);let u=[];Ty(u,.7,.55,.55,n+.9,v+.28,a+.7),Ty(u,.5,.4,.5,n+1.5,v+.2,a+.85);let d=new p(.28,.32,.7,8);d.translate(n+2.2,v+.35,a+.75),u.push(d);for(let t of[e,i,o,s,c,l])t.castShadow=!1,t.receiveShadow=!1,f.add(t);Oy(f,u,wy,`${t}-crates`)}return e.add(f),f}var Ay=``+new URL(`pine-sapling-small-BNsWIyqb.glb`,import.meta.url).href,jy=``+new URL(`fir-sapling-Diah_fNu.glb`,import.meta.url).href,My=``+new URL(`pine-sapling-medium-D5dbSMk8.glb`,import.meta.url).href,Ny=``+new URL(`fir-sapling-medium-CGXwGTiw.glb`,import.meta.url).href,Py=``+new URL(`fern-DGpxLAP6.glb`,import.meta.url).href,Fy=``+new URL(`fern-b-Dj9WvISI.glb`,import.meta.url).href,Iy=``+new URL(`rock-moss-a-DFwOZ3uA.glb`,import.meta.url).href,Ly=``+new URL(`rock-moss-b-CTP1DpAp.glb`,import.meta.url).href,Ry=``+new URL(`rock-moss-c-ufeYTSk7.glb`,import.meta.url).href,zy=``+new URL(`dead-tree-trunk-xG0DrWkn.glb`,import.meta.url).href,By=``+new URL(`tree-stump-C7WMXUYL.glb`,import.meta.url).href,Vy=``+new URL(`castle-brick-diff-CHJbUQJ6.jpg`,import.meta.url).href,Hy=``+new URL(`castle-brick-nor-DwW8cv7g.jpg`,import.meta.url).href,Uy=``+new URL(`corrugated-iron-diff-BNlE6WvN.jpg`,import.meta.url).href,Wy=``+new URL(`corrugated-iron-nor-DgpCfsis.jpg`,import.meta.url).href,Gy=``+new URL(`forest-ground-diff-GKztnheg.jpg`,import.meta.url).href,Ky=``+new URL(`forest-ground-nor-ClZQj4hi.jpg`,import.meta.url).href,qy=``+new URL(`rock-face-diff-Sw-kDxoL.jpg`,import.meta.url).href,Jy=``+new URL(`rock-face-nor-tWkHH0Pd.jpg`,import.meta.url).href,Yy=[{key:`pine-sapling-small`,url:Ay,kind:`tree`,swayHeight:1.3,windStrength:.035,scale:[7.2,10.2],capacity:20},{key:`fir-sapling`,url:jy,kind:`tree`,swayHeight:1.29,windStrength:.04,scale:[9.5,13],capacity:20},{key:`pine-sapling-medium`,url:My,kind:`tree`,swayHeight:6.78,windStrength:.14,scale:[1.15,1.85],capacity:20},{key:`fir-sapling-medium`,url:Ny,kind:`tree`,swayHeight:8.61,windStrength:.16,scale:[1.25,1.9],capacity:20},{key:`fern`,url:Py,kind:`fern`,swayHeight:.43,windStrength:.05,scale:[.75,1.45],capacity:100},{key:`fern-b`,url:Fy,kind:`fern`,swayHeight:.35,windStrength:.045,scale:[.85,1.6],capacity:100},{key:`rock-moss-a`,url:Iy,kind:`rock`,scale:[.55,1.35],capacity:16},{key:`rock-moss-b`,url:Ly,kind:`rock`,scale:[.45,1.15],capacity:16},{key:`rock-moss-c`,url:Ry,kind:`rock`,scale:[.6,1.55],capacity:16},{key:`dead-tree-trunk`,url:zy,kind:`log`,scale:[.7,1.25],capacity:16},{key:`tree-stump`,url:By,kind:`stump`,scale:[.65,1.35],capacity:12}],Xy=new uo,Zy=new Ge,Qy=gy(4),$y=null,eb=null;function tb(e){return Qy(()=>new Promise((t,n)=>{Xy.load(e,t,void 0,n)}))}function nb(e){return Qy(()=>new Promise((t,n)=>{Zy.load(e,t,void 0,n)}))}function rb(e,t){return e.wrapS=Oe,e.wrapT=Oe,e.colorSpace=t?Me:``,e.anisotropy=4,e.userData.sharedTexture=!0,e}function ib(e){let t=null;return e.traverse(e=>{!t&&e.isMesh&&(t=e)}),t}function ab(e,{swayHeight:t,windStrength:n,timeUniform:r}){return!r||e.userData.wind?e:(e.userData.wind=!0,e.onBeforeCompile=e=>{e.uniforms.uTime=r,e.uniforms.uWindStrength={value:n},e.uniforms.uSwayHeight={value:t},e.vertexShader=e.vertexShader.replace(`#include <common>`,`#include <common>
uniform float uTime;
uniform float uWindStrength;
uniform float uSwayHeight;`).replace(`#include <begin_vertex>`,`#include <begin_vertex>
float windHeight = smoothstep(0.05, uSwayHeight, transformed.y);
windHeight *= windHeight;
#ifdef USE_INSTANCING
vec4 windOrigin = modelMatrix * instanceMatrix * vec4(0.0, 0.0, 0.0, 1.0);
#else
vec4 windOrigin = modelMatrix * vec4(0.0, 0.0, 0.0, 1.0);
#endif
float windPhase = windOrigin.x * 0.37 + windOrigin.z * 0.23;
float windWave = sin(uTime * 1.8 + windPhase);
float gustWave = cos(uTime * 1.12 + windPhase * 1.7);
transformed.x += (windWave + gustWave * 0.45) * uWindStrength * windHeight;
transformed.z += cos(windWave) * 0.55 * uWindStrength * windHeight;`),e.fragmentShader=e.fragmentShader.replace(`#include <opaque_fragment>`,`#if NUM_DIR_LIGHTS > 0
  float leafFront = gl_FrontFacing ? 1.0 : 0.0;
  vec3 leafLight = directionalLights[0].color;
  float throughLeaf = clamp(dot(-normal, directionalLights[0].direction), 0.0, 1.0);
  float wrapLeaf = clamp(dot(normal, directionalLights[0].direction) + 0.55, 0.0, 1.0) / 1.55;
  outgoingLight += diffuseColor.rgb * leafLight * (throughLeaf * (1.0 - leafFront) * 0.62 + wrapLeaf * 0.16);
#endif
#include <opaque_fragment>`)},e.side=2,e.customProgramCacheKey=()=>`nature-wind-leaf-${t}`,e)}async function ob(){return(await Promise.all(Yy.map(async e=>{try{let t=ib((await tb(e.url)).scene);if(!t)throw Error(`no mesh`);let n=t.material;return n.map&&rb(n.map,!0),n.normalMap&&rb(n.normalMap,!1),(e.kind===`tree`||e.kind===`fern`)&&(n.alphaTest=.5,n.side=2),{...e,geometry:t.geometry,material:n}}catch(t){return console.warn(`[nature] skipped ${e.key}`,t),null}}))).filter(Boolean)}async function sb(e,t){try{return rb(await nb(e),t)}catch(t){return console.warn(`[nature] texture failed`,e,t),null}}function cb(){return eb}function lb(){return $y||=(async()=>{let[e,t,n,r,i,a,o,s,c]=await Promise.all([ob(),sb(Vy,!0),sb(Hy,!1),sb(Uy,!0),sb(Wy,!1),sb(Gy,!1),sb(Ky,!1),sb(qy,!1),sb(Jy,!1)]);return t&&n&&r&&i&&Dy({brickMap:t,brickNormal:n,roofMap:r,roofNormal:i,pillarMap:s?rb(s.clone(),!0):null,pillarNormal:c?rb(c.clone(),!1):null}),eb={props:e,groundMap:a,groundNormal:o,rockMap:s,rockNormal:c},eb})(),$y}function ub({baseColor:e=1712668,forestColor:t=1318934,snowColor:n=12963032,hazeColor:r=3807304,haze:i=.4,forest:a=0,mist:o=.3,afterglowDir:s,moonDir:c}={}){let l={uBaseColor:{value:new q(e)},uForestColor:{value:new q(t)},uSnowColor:{value:new q(n)},uHazeColor:{value:new q(r)},uGlowColor:{value:new q(12875864)},uMoonColor:{value:new q(10137552)},uHaze:{value:i},uForest:{value:a},uMist:{value:o},uAfterglowDir:{value:(s||new R(16,.25,-10)).clone().normalize()},uMoonDir:{value:(c||new R(.85,.5,.16)).clone().normalize()}},u=new Je({uniforms:l,vertexShader:`
    varying float vAlong;
    varying vec3 vNormal;
    varying vec3 vWorld;

    void main() {
      // uv.y is 0 on the buried base and 1 on the crest.
      vAlong = uv.y;
      vec4 worldPosition = modelMatrix * vec4(position, 1.0);
      vWorld = worldPosition.xyz;
      vNormal = normalize(mat3(modelMatrix) * normal);
      gl_Position = projectionMatrix * viewMatrix * worldPosition;
    }
  `,fragmentShader:`
    uniform vec3 uBaseColor;
    uniform vec3 uForestColor;
    uniform vec3 uSnowColor;
    uniform vec3 uHazeColor;
    uniform vec3 uGlowColor;
    uniform vec3 uMoonColor;
    uniform float uHaze;
    uniform float uForest;
    uniform float uMist;
    uniform vec3 uAfterglowDir;
    uniform vec3 uMoonDir;

    varying float vAlong;
    varying vec3 vNormal;
    varying vec3 vWorld;

    float hash(vec2 p) {
      return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
    }

    float noise(vec2 p) {
      vec2 i = floor(p);
      vec2 f = fract(p);
      f = f * f * (3.0 - 2.0 * f);
      return mix(
        mix(hash(i), hash(i + vec2(1.0, 0.0)), f.x),
        mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), f.x),
        f.y
      );
    }

    void main() {
      vec3 normal = normalize(vNormal);
      vec3 viewDir = normalize(cameraPosition - vWorld);
      // The ring is double-sided. Flip so the face we see is the lit one.
      if (dot(normal, viewDir) < 0.0) normal = -normal;

      float forest = smoothstep(0.42, 0.06, vAlong) * uForest;
      // Snow only on the upper slope. Noise shifts the line so it is a
      // broken contour, not a soft band around the whole ring.
      float line = 0.84 + (noise(vWorld.xz * 0.006) - 0.5) * 0.1;
      float snow = smoothstep(line, line + 0.045, vAlong);
      snow = max(snow, smoothstep(0.96, 0.995, vAlong));

      vec3 rock = uBaseColor * 0.42;
      vec3 albedo = mix(rock, uForestColor * 0.75, forest);
      albedo = mix(albedo, uSnowColor, snow);

      // A short ramp so a ridge facing the moon is bright and the
      // opposite face falls off into dark rock.
      float moonL = smoothstep(0.12, 0.62, max(dot(normal, normalize(uMoonDir)), 0.0));
      float glowL = smoothstep(0.25, 0.8, max(dot(normal, normalize(uAfterglowDir)), 0.0));
      vec3 fill = vec3(0.07, 0.08, 0.11);
      // 3× the previous moon term so a ridge facing the moon has a readable face.
      vec3 lit = albedo * (fill + uMoonColor * moonL * 3.75);
      // Afterglow stays a faint tint on sunset-facing slopes only.
      lit += uGlowColor * glowL * 0.16;

      vec3 color = mix(lit, uHazeColor, clamp(uHaze, 0.0, 1.0));

      // Foot mist only. vAlong keeps it off the faces, so it cannot
      // draw a band across the ridge.
      float mist = smoothstep(12.0, 3.0, vWorld.y) * smoothstep(0.16, 0.0, vAlong);
      mist *= uMist * 0.12;
      color = mix(color, uHazeColor * 0.45 + vec3(0.02, 0.022, 0.03), mist);

      gl_FragColor = vec4(color, 1.0);
      #include <tonemapping_fragment>
      #include <colorspace_fragment>
    }
  `,side:2,fog:!1,toneMapped:!0});return u.customUniforms=l,u}function db(e){let t={uTime:e||{value:0}},n=new Je({uniforms:t,vertexShader:`
    uniform float uTime;
    attribute vec3 aColor;
    attribute float aSeed;
    attribute float aSize;
    varying vec3 vColor;
    varying float vTwinkle;

    void main() {
      vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
      gl_Position = projectionMatrix * mvPosition;

      // Gentle twinkle. aSeed is 0..1, so each lamp has its own phase.
      vTwinkle = 0.72 + 0.28 * sin(uTime * 1.6 + aSeed * 6.28318);
      float dist = max(1.0, -mvPosition.z);
      gl_PointSize = clamp(aSize * vTwinkle * (150.0 / dist), 1.5, 18.0);
      vColor = aColor;
    }
  `,fragmentShader:`
    varying vec3 vColor;
    varying float vTwinkle;

    void main() {
      // Round the point. The corners are discarded so a light is a dot,
      // not a square. Additive blending then fades the edge to nothing.
      vec2 p = gl_PointCoord - vec2(0.5);
      float d = length(p);
      if (d > 0.5) discard;
      float glow = smoothstep(0.5, 0.08, d);
      // Bright enough that ACES still leaves a warm speck at this distance.
      vec3 color = vColor * glow * vTwinkle * 3.2;
      gl_FragColor = vec4(color, 1.0);
      #include <tonemapping_fragment>
      #include <colorspace_fragment>
    }
  `,transparent:!0,blending:2,depthWrite:!1,fog:!1,toneMapped:!0});return n.customUniforms=t,n}function fb(e={}){let t={uSunDirection:{value:(e.sunDirection||new R(.5,.5,.2)).clone().normalize()},uSunColor:{value:new q(e.sunColor||10137552)},uSkyColor:{value:new q(e.skyColor||1714244)},uRockColor:{value:new q(e.rockColor||5920334)},uAmbient:{value:e.ambient??.55}},n=new Je({uniforms:t,vertexShader:`
    varying vec3 vWorldPosition;
    varying vec3 vNormal;

    void main() {
      vec4 worldPosition = modelMatrix * instanceMatrix * vec4(position, 1.0);
      vWorldPosition = worldPosition.xyz;
      vNormal = normalize(mat3(modelMatrix * instanceMatrix) * normal);
      gl_Position = projectionMatrix * viewMatrix * worldPosition;
    }
  `,fragmentShader:`
    varying vec3 vWorldPosition;
    varying vec3 vNormal;

    uniform vec3 uSunDirection;
    uniform vec3 uSunColor;
    uniform vec3 uSkyColor;
    uniform vec3 uRockColor;
    uniform float uAmbient;

    float hash(vec2 p) {
      p = fract(p * vec2(123.34, 456.21));
      p += dot(p, p + 45.32);
      return fract(p.x * p.y);
    }

    float noise(vec2 p) {
      vec2 i = floor(p);
      vec2 f = fract(p);
      f = f * f * (3.0 - 2.0 * f);
      return mix(
        mix(hash(i), hash(i + vec2(1.0, 0.0)), f.x),
        mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), f.x),
        f.y
      );
    }

    void main() {
      vec3 normal = normalize(vNormal);
      float grit = noise(vWorldPosition.xz * 0.65 + vWorldPosition.y * 0.4);
      // Warm grey stone, darker in the cracks of the noise.
      vec3 albedo = uRockColor * (0.62 + grit * 0.55);
      float ndotl = max(dot(normal, normalize(uSunDirection)), 0.0);
      float sky = clamp(0.35 + 0.65 * normal.y, 0.0, 1.0);
      vec3 lit = albedo * (uSunColor * ndotl * 1.15 + uSkyColor * sky * uAmbient);
      gl_FragColor = vec4(lit, 1.0);
      #include <tonemapping_fragment>
      #include <colorspace_fragment>
    }
  `});return n.customUniforms=t,n}var pb=`
  // Unbound consumers (the legacy lake) default to zero: retain the old size.
  uniform float uMoonSize;
  uniform float uMoonSoftGlow;
  float hash(vec2 p) {
    p = fract(p * vec2(123.34, 456.21));
    p += dot(p, p + 45.32);
    return fract(p.x * p.y);
  }

  float hash3(vec3 p) {
    p = fract(p * vec3(123.34, 456.21, 789.16));
    p += dot(p, p.yzx + 45.32);
    return fract(p.x * p.y * p.z);
  }

  float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = hash(i);
    float b = hash(i + vec2(1.0, 0.0));
    float c = hash(i + vec2(0.0, 1.0));
    float d = hash(i + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
  }

  // Value noise on a 3D point. Continuous across the whole sphere.
  float noise3(vec3 p) {
    vec3 i = floor(p);
    vec3 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float n000 = hash3(i);
    float n100 = hash3(i + vec3(1.0, 0.0, 0.0));
    float n010 = hash3(i + vec3(0.0, 1.0, 0.0));
    float n110 = hash3(i + vec3(1.0, 1.0, 0.0));
    float n001 = hash3(i + vec3(0.0, 0.0, 1.0));
    float n101 = hash3(i + vec3(1.0, 0.0, 1.0));
    float n011 = hash3(i + vec3(0.0, 1.0, 1.0));
    float n111 = hash3(i + vec3(1.0, 1.0, 1.0));
    float x00 = mix(n000, n100, f.x);
    float x10 = mix(n010, n110, f.x);
    float x01 = mix(n001, n101, f.x);
    float x11 = mix(n011, n111, f.x);
    return mix(mix(x00, x10, f.y), mix(x01, x11, f.y), f.z);
  }

  const float pi = 3.141592653589793238462643383279502884197169;
  const float rayleighZenithLength = 8.4E3;
  const float mieZenithLength = 1.25E3;
  const float sunAngularDiameterCos = 0.999956676946448443553574619906976478926848692873900859324;
  const float THREE_OVER_SIXTEENPI = 0.05968310365946075;
  const float ONE_OVER_FOURPI = 0.07957747154594767;

  float rayleighPhase(float cosTheta) {
    return THREE_OVER_SIXTEENPI * (1.0 + pow(cosTheta, 2.0));
  }

  float hgPhase(float cosTheta, float g) {
    float g2 = pow(g, 2.0);
    float inverse = 1.0 / pow(1.0 - 2.0 * g * cosTheta + g2, 1.5);
    return ONE_OVER_FOURPI * ((1.0 - g2) * inverse);
  }

  // Preetham sky plus night lift, sparse cloud streaks, moon and stars.
  // direction is a unit view direction. y = 1 is straight up.
  vec3 evaluateSky(vec3 direction) {
    vec3 up = vec3(0.0, 1.0, 0.0);
    float zenithAngle = acos(max(0.0, dot(up, direction)));
    float inverse = 1.0 / (cos(zenithAngle) + 0.15 * pow(93.885 - ((zenithAngle * 180.0) / pi), -1.253));
    float sR = rayleighZenithLength * inverse;
    float sM = mieZenithLength * inverse;

    vec3 Fex = exp(-(vBetaR * sR + vBetaM * sM));

    float cosTheta = dot(direction, vSunDirection);
    float rPhase = rayleighPhase(cosTheta * 0.5 + 0.5);
    vec3 betaRTheta = vBetaR * rPhase;
    float mPhase = hgPhase(cosTheta, uMieDirectionalG);
    vec3 betaMTheta = vBetaM * mPhase;

    vec3 Lin = pow(vSunE * ((betaRTheta + betaMTheta) / (vBetaR + vBetaM)) * (1.0 - Fex), vec3(1.5));
    Lin *= mix(
      vec3(1.0),
      pow(vSunE * ((betaRTheta + betaMTheta) / (vBetaR + vBetaM)) * Fex, vec3(1.0 / 2.0)),
      clamp(pow(1.0 - dot(up, vSunDirection), 5.0), 0.0, 1.0)
    );

    vec3 L0 = vec3(0.1) * Fex;
    float sundisc = smoothstep(sunAngularDiameterCos, sunAngularDiameterCos + 0.00002, cosTheta);
    L0 += (vSunE * 19000.0 * Fex) * sundisc * uShowSunDisc;

    vec3 skyColor = (Lin + L0) * uSkyGain + vec3(0.0, 0.0003, 0.00075);
    float skyLuma = max(dot(skyColor, vec3(0.2126, 0.7152, 0.0722)), 0.0001);
    skyColor *= (skyLuma / (1.0 + skyLuma * uHighlightCompress)) / skyLuma;
    float gradedLuma = dot(skyColor, vec3(0.2126, 0.7152, 0.0722));
    skyColor = max(mix(vec3(gradedLuma), skyColor, uSaturation), vec3(0.0));

    float sunDown = smoothstep(0.12, -0.15, vSunDirection.y);
    float liftHeight = clamp(direction.y * 0.85 + 0.05, 0.0, 1.0);
    vec3 airglow = mix(uHorizonColor, uZenithColor, liftHeight);
    skyColor += airglow * uNightLift * sunDown;

    // Thin streaks, not a glowing band. Stretched in elevation so each
    // wisp is a filament. The threshold is high on purpose: empty sky
    // is better than a smear. 3D noise, so there is no azimuth seam.
    vec3 cloudP = direction * vec3(1.7, 7.5, 1.7);
    cloudP += vec3(uTime * uCloudSpeed, 0.0, uTime * uCloudSpeed * 0.41);
    float warp = noise3(cloudP * 1.3);
    vec3 streakP = cloudP * vec3(1.1, 5.5, 1.1) + vec3(warp * 0.35, 0.2, 0.0);
    float filament = noise3(streakP);
    float grain = noise3(streakP * 2.7 + 4.0);
    float streak = smoothstep(0.74, 0.9, filament) * smoothstep(0.42, 0.78, grain);
    streak *= smoothstep(0.02, 0.16, direction.y);
    streak *= 1.0 - smoothstep(0.38, 0.7, direction.y);

    vec3 sunDir = normalize(vSunDirection);
    vec3 moonDir = normalize(uMoonDirection);
    // Afterglow lights the underside of a streak that faces the sunset.
    float sunsetSide = smoothstep(-0.02, 0.55, dot(direction, sunDir));
    float underside = 1.0 - smoothstep(0.04, 0.32, direction.y);
    float moonSide = clamp(dot(direction, moonDir), 0.0, 1.0);
    vec3 warm = vec3(0.55, 0.22, 0.12) * sunsetSide * underside;
    vec3 cool = vec3(0.32, 0.38, 0.52) * (0.2 + 0.8 * moonSide) * (1.0 - sunsetSide * 0.85);
    skyColor += (warm + cool) * streak * uCloudAmount;

    float moonFacing = dot(direction, moonDir);
    if (uMoonSize > 1.0) {
      moonFacing = 1.0 - (1.0 - moonFacing) / (uMoonSize * uMoonSize);
    }
    // Disc is about 1.5° across. The halo is a thin ring just outside it.
    // The disc used to be written at 5× linear, which bloom turned into a
    // blob. It now sits just above the bloom threshold, so the disc stays
    // white and only a small halo blooms.
    float moonDisc = smoothstep(0.9998, 0.99992, moonFacing);
    float moonHalo = smoothstep(0.99955, 0.9998, moonFacing) * (1.0 - moonDisc);
    if (uMoonSoftGlow > 0.5) {
      vec3 moonRight = normalize(cross(vec3(0.0, 1.0, 0.0), moonDir));
      vec3 moonUp = cross(moonDir, moonRight);
      vec2 discLocal = vec2(dot(direction, moonRight), dot(direction, moonUp))
        / (0.02 * max(uMoonSize, 1.0));
      float patches = 0.65 * noise(discLocal * 2.4 + vec2(3.7, 8.1))
        + 0.35 * noise(discLocal * 4.1 + vec2(11.3, 2.6));
      float glow = 0.14 * exp(-2.5 * dot(discLocal, discLocal));
      // The tangent projection also reaches zero opposite the moon: mask that
      // hemisphere smoothly where the exponential is already negligible.
      glow *= smoothstep(0.0, 0.5, dot(direction, moonDir));
      skyColor += vec3(1.0, 0.97, 0.90)
        * (moonDisc * 1.28 * (1.0 - patches * 0.12) + glow) * uMoonStrength;
    } else {
      skyColor += vec3(0.96, 0.97, 1.0) * (moonDisc * 1.28 + moonHalo * 0.2) * uMoonStrength;
    }

    // Stars on a 3D grid of the view direction. The old atan2 cell
    // wrapped at one meridian and drew a vertical line of mismatched stars.
    vec3 starP = direction * 24.0;
    vec3 starCell = floor(starP);
    vec3 starLocal = fract(starP) - 0.5;
    float starHash = hash3(starCell);
    float present = step(1.0 - uStarDensity, starHash);
    vec3 jitter = (vec3(
      hash3(starCell + 1.7),
      hash3(starCell + 8.3),
      hash3(starCell + 2.2)
    ) - 0.5) * 0.55;
    float dist = length(starLocal - jitter);
    float px = clamp(length(vec2(fwidth(starP.x), fwidth(starP.y))), 0.002, 0.14);
    float star = smoothstep(px * 1.25, px * 0.18, dist) * present;
    float phase = hash3(starCell + 4.2) * 6.28318;
    float twinkle = 0.6 + 0.4 * sin(uTime * 1.7 + phase);
    float brightness = 0.45 + 0.55 * hash3(starCell + 3.1);
    float luma = dot(skyColor, vec3(0.2126, 0.7152, 0.0722));
    float inDarkSky = 1.0 - smoothstep(0.06, 0.32, luma);
    float aboveHorizon = smoothstep(0.04, 0.18, direction.y);
    skyColor += vec3(star * twinkle * brightness * inDarkSky * aboveHorizon * uStarBrightness);

    float gradeHeight = smoothstep(-0.2, 0.85, direction.y);
    vec3 gradeColor = mix(uHorizonColor, uZenithColor, gradeHeight);
    skyColor = mix(skyColor, gradeColor, clamp(uGrade, 0.0, 1.0));
    return skyColor;
  }
`;function mb(e){let t={uTime:e.uTime,uSkyGain:e.uSkyGain,uHighlightCompress:e.uHighlightCompress,uSaturation:e.uSaturation,uMieDirectionalG:e.uMieDirectionalG,uShowSunDisc:e.uShowSunDisc,uMoonDirection:e.uMoonDirection,uMoonStrength:e.uMoonStrength,uNightLift:e.uNightLift,uStarDensity:e.uStarDensity,uStarBrightness:e.uStarBrightness,uCloudAmount:e.uCloudAmount,uCloudSpeed:e.uCloudSpeed,uGlitch:e.uGlitch,uGrade:e.uGrade,uHorizonColor:e.uHorizonColor,uZenithColor:e.uZenithColor,uSunDirection:e.uSunDirection,uRayleigh:e.uRayleigh,uTurbidity:e.uTurbidity,uMieCoefficient:e.uMieCoefficient,uDeepColor:{value:new q(462872)}},n=`
    varying vec3 vWorldPosition;
    varying vec3 vSunDirection;
    varying float vSunE;
    varying vec3 vBetaR;
    varying vec3 vBetaM;

    uniform float uTime;
    uniform float uSkyGain;
    uniform float uHighlightCompress;
    uniform float uSaturation;
    uniform float uMieDirectionalG;
    uniform float uShowSunDisc;
    uniform vec3 uMoonDirection;
    uniform float uMoonStrength;
    uniform float uNightLift;
    uniform float uStarDensity;
    uniform float uStarBrightness;
    uniform float uCloudAmount;
    uniform float uCloudSpeed;
    uniform float uGlitch;
    uniform float uGrade;
    uniform vec3 uHorizonColor;
    uniform vec3 uZenithColor;
    uniform vec3 uDeepColor;

    ${pb}

    void main() {
      // Two octaves of scrolling noise. The difference between a
      // neighbour sample and this one is the ripple slope.
      vec2 xz = vWorldPosition.xz;
      float t = uTime;
      float n = noise(xz * 0.17 + vec2(t * 0.035, t * 0.02));
      n += noise(xz * 0.41 - vec2(t * 0.02, t * 0.028)) * 0.45;
      float nx = noise((xz + vec2(0.6, 0.0)) * 0.17 + vec2(t * 0.035, t * 0.02));
      nx += noise((xz + vec2(0.6, 0.0)) * 0.41 - vec2(t * 0.02, t * 0.028)) * 0.45;
      float nz = noise((xz + vec2(0.0, 0.6)) * 0.17 + vec2(t * 0.035, t * 0.02));
      nz += noise((xz + vec2(0.0, 0.6)) * 0.41 - vec2(t * 0.02, t * 0.028)) * 0.45;
      vec3 normal = normalize(vec3((n - nx) * 0.55, 1.0, (n - nz) * 0.55));

      vec3 incident = normalize(vWorldPosition - cameraPosition);
      vec3 reflected = normalize(reflect(incident, normal));
      // Below the horizon the analytic sky is undefined. Clamp so a
      // steep ripple cannot sample under the ground.
      reflected.y = max(reflected.y, 0.02);
      reflected = normalize(reflected);
      vec3 reflection = evaluateSky(reflected);

      float ndotv = max(dot(normal, -incident), 0.0);
      float fresnel = pow(1.0 - ndotv, 3.0);
      vec3 water = mix(uDeepColor, reflection, 0.18 + fresnel * 0.82);

      float glint = pow(max(dot(reflected, normalize(uMoonDirection)), 0.0), 900.0);
      water += vec3(0.75, 0.82, 0.95) * glint * 6.0 * uMoonStrength;

      gl_FragColor = vec4(water, 1.0);
      #include <tonemapping_fragment>
      #include <colorspace_fragment>
    }
  `,r=new Je({uniforms:t,vertexShader:`
    uniform vec3 uSunDirection;
    uniform float uRayleigh;
    uniform float uTurbidity;
    uniform float uMieCoefficient;

    varying vec3 vWorldPosition;
    varying vec3 vSunDirection;
    varying float vSunE;
    varying vec3 vBetaR;
    varying vec3 vBetaM;

    // Same scattering coefficients as the sky dome's vertex shader, so
    // evaluateSky() sees the same air the dome does.
    const vec3 totalRayleigh = vec3(5.804542996261093E-6, 1.3562911419845635E-5, 3.0265902468824876E-5);
    const vec3 MieConst = vec3(1.8399918514433978E14, 2.7798023919660528E14, 4.0790479543861094E14);
    const float cutoffAngle = 1.6110731556870734;
    const float steepness = 1.5;
    const float EE = 1000.0;

    float sunIntensity(float zenithAngleCos) {
      zenithAngleCos = clamp(zenithAngleCos, -1.0, 1.0);
      return EE * max(0.0, 1.0 - exp(-((cutoffAngle - acos(zenithAngleCos)) / steepness)));
    }

    vec3 totalMie(float T) {
      float c = (0.2 * T) * 10E-18;
      return 0.434 * c * MieConst;
    }

    void main() {
      vec4 worldPosition = modelMatrix * vec4(position, 1.0);
      vWorldPosition = worldPosition.xyz;
      vSunDirection = normalize(uSunDirection);
      vSunE = sunIntensity(dot(vSunDirection, vec3(0.0, 1.0, 0.0)));
      vBetaR = totalRayleigh * uRayleigh;
      vBetaM = totalMie(uTurbidity) * uMieCoefficient;
      gl_Position = projectionMatrix * viewMatrix * worldPosition;
    }
  `,fragmentShader:n,fog:!1,toneMapped:!0});return r.customUniforms=t,r}function hb(e={}){let t={uTime:{value:0},uSunDirection:{value:e.sunDirection||new R(.5,.6,.2).normalize()},uFogColor:{value:new q(e.fogColor||1183778)},uFogNear:{value:e.fogNear??50},uFogFar:{value:e.fogFar??260},uFogMax:{value:e.fogMax??.88},uMist:{value:e.mist??.36}};e.skyTime&&(t.uTime=e.skyTime);let n=new Je({uniforms:t,vertexShader:`
    uniform float uTime;

    varying float vHeight;
    varying vec3 vTint;
    varying vec3 vNormal;
    varying vec3 vWorldPosition;
    varying float vViewDistance;

    float hash(vec2 p) {
      return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
    }

    // Value noise. One octave is enough for gusts; a second sample
    // below adds the smaller ripple on top.
    float noise(vec2 p) {
      vec2 i = floor(p);
      vec2 f = fract(p);
      f = f * f * (3.0 - 2.0 * f);
      return mix(
        mix(hash(i), hash(i + vec2(1.0, 0.0)), f.x),
        mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), f.x),
        f.y
      );
    }

    void main() {
      // The blade mesh is a unit card: y is 0 at the root and 1 at the
      // tip, x is -0.5..0.5 across the width, z is a small resting curl
      // stored as a fraction of height.
      vec3 origin = (modelMatrix * instanceMatrix * vec4(0.0, 0.0, 0.0, 1.0)).xyz;

      // --- Per-blade shape ---
      // Hashed from the blade's own position so neighbours do not match.
      float nH = hash(origin.xz);
      float nW = hash(origin.xz + vec2(19.1, 7.7));
      float nL = hash(origin.xz + vec2(3.3, 41.9));
      float nC = hash(origin.zx + vec2(8.2, 2.6));
      float bladeHeight = mix(0.32, 1.05, nH);
      float bladeWidth = mix(0.045, 0.13, nW);
      float lean = mix(0.04, 0.26, nL);

      float along = position.y;
      vec3 pos = vec3(
        position.x * bladeWidth,
        along * bladeHeight,
        position.z * bladeHeight + lean * along * along
      );

      // --- Wind ---
      // Gusts are spatial noise scrolled by uTime, so a Freeze holds the
      // field still and a Rewind runs the gusts backwards. The bend is
      // zero at the root (along^2) and strongest at the tip.
      vec2 windDir = vec2(0.72, 0.28);
      vec2 gustUv = origin.xz * 0.045 + windDir * uTime * 0.32;
      float gust = noise(gustUv);
      float ripple = noise(origin.xz * 0.28 + vec2(uTime * 0.85, nC));
      float tip = along * along;
      float amp = tip * mix(0.03, 0.48, smoothstep(0.2, 0.85, gust));
      vec3 worldPush = vec3(windDir.x, 0.0, windDir.y) * amp;
      worldPush.xz += vec2(-0.25, 0.65) * (ripple * 2.0 - 1.0) * tip * 0.07;
      // Inverse of the yaw. transpose() is not in the GLSL this project compiles.
      mat3 worldRot = mat3(modelMatrix * instanceMatrix);
      mat3 invRot = mat3(
        vec3(worldRot[0].x, worldRot[1].x, worldRot[2].x),
        vec3(worldRot[0].y, worldRot[1].y, worldRot[2].y),
        vec3(worldRot[0].z, worldRot[1].z, worldRot[2].z)
      );
      pos += invRot * worldPush;

      vec4 worldPosition = modelMatrix * instanceMatrix * vec4(pos, 1.0);
      vWorldPosition = worldPosition.xyz;
      vHeight = along;

      // Colour is chosen here and only painted in the fragment shader.
      // A cool, slightly yellow tip over a bluer root.
      vTint = mix(vec3(0.52, 0.84, 0.50), vec3(0.68, 1.06, 0.58), nC);

      vec3 n = normalize(vec3(0.0, lean * 0.35, 1.0));
      vNormal = normalize(worldRot * n);

      vec4 mvPosition = viewMatrix * worldPosition;
      vViewDistance = -mvPosition.z;
      gl_Position = projectionMatrix * mvPosition;
    }
  `,fragmentShader:`
    varying float vHeight;
    varying vec3 vTint;
    varying vec3 vNormal;
    varying vec3 vWorldPosition;
    varying float vViewDistance;

    uniform vec3 uSunDirection;
    uniform vec3 uFogColor;
    uniform float uFogNear;
    uniform float uFogFar;
    uniform float uFogMax;
    uniform float uMist;
    uniform float uTime;

    float hash(vec2 p) {
      return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
    }

    float noise(vec2 p) {
      vec2 i = floor(p);
      vec2 f = fract(p);
      f = f * f * (3.0 - 2.0 * f);
      return mix(
        mix(hash(i), hash(i + vec2(1.0, 0.0)), f.x),
        mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), f.x),
        f.y
      );
    }

    void main() {
      vec3 normal = normalize(vNormal);
      if (!gl_FrontFacing) normal = -normal;

      // --- Colour gradient ---
      // Dark cool green at the root, a lighter yellow-green at the tip.
      // vTint is the per-blade colour from the vertex shader.
      vec3 rootCol = vec3(0.020, 0.032, 0.018);
      vec3 tipCol = vec3(0.10, 0.15, 0.075);
      vec3 albedo = mix(rootCol, tipCol, smoothstep(0.08, 1.0, vHeight)) * vTint;

      // --- Moonlight ---
      // Same night model as the textured ground: moon 0xc8daf6 at 1.95,
      // hemisphere 0x2a4068 over 0x0a090e at 0.48, and a dim environment
      // fill at 0.4. Diffuse is divided by PI (0.3183).
      float skyDiff = clamp(0.5 + 0.5 * normal.y, 0.0, 1.0);
      float wrap = clamp((dot(normal, uSunDirection) + 0.5) / 1.5, 0.0, 1.0);
      // Translucency: the tip glows when the moon is behind the blade.
      float through = pow(max(dot(-normal, uSunDirection), 0.0), 1.3) * vHeight * vHeight;
      vec3 moon = vec3(0.784, 0.855, 0.965) * 1.95 * (wrap * 0.9 + through * 0.7);
      vec3 hemi = mix(vec3(0.039, 0.035, 0.055), vec3(0.165, 0.251, 0.408), skyDiff) * 0.48;
      vec3 env = vec3(0.10, 0.12, 0.18) * 0.4;
      vec3 litColor = albedo * (moon + hemi + env) * 0.3183;

      // --- Fog ---
      // Same curve as the terrain and the trees, then the same valley mist.
      float fogFactor = min(smoothstep(uFogNear, uFogFar, vViewDistance), uFogMax);
      vec3 finalColor = mix(litColor, uFogColor, fogFactor);
      float drift = noise(vWorldPosition.xz * 0.02 + vec2(uTime * 0.012, 0.0));
      float mist = smoothstep(9.0, 0.4, vWorldPosition.y);
      mist *= smoothstep(30.0, 110.0, vViewDistance);
      mist *= (0.55 + 0.45 * drift) * uMist;
      finalColor = mix(finalColor, uFogColor * 0.72 + vec3(0.025, 0.03, 0.045), mist);

      gl_FragColor = vec4(finalColor, 1.0);
      // ACES and sRGB, matching every other shader in the scene.
      #include <tonemapping_fragment>
      #include <colorspace_fragment>
    }
  `,side:2});return n.customUniforms=t,n}var gb={low:6e4,medium:8e4,high:1e5},_b=gb.high,vb=[{minX:-189.2,maxX:-168,minZ:-27.7,maxZ:-21.3},{minX:-177.2,maxX:-157.8,minZ:-28.2,maxZ:-20.8},{minX:-160,maxX:-142,minZ:-41,maxZ:-20.6}],yb={ax:-168,az:-18,bx:-30,bz:28};function bb(e,t,n){let r=e<n.minX?n.minX-e:e>n.maxX?e-n.maxX:0,i=t<n.minZ?n.minZ-t:t>n.maxZ?t-n.maxZ:0;return Math.hypot(r,i)}function xb(e,t){let n=1/0;for(let r of vb)n=Math.min(n,bb(e,t,r));return n}function Sb(e,t,n,r,i,a){let o=i-n,s=a-r,c=e-n,l=t-r,u=o*o+s*s,d=u>0?Math.max(0,Math.min(1,(c*o+l*s)/u)):0;return Math.hypot(e-(n+o*d),t-(r+s*d))}function Cb(e,t){return e<-168&&Math.abs(t+24.5)<3.1}function wb(e){let t=e%2147483647;return t<=0&&(t+=2147483646),()=>(t=t*16807%2147483647,(t-1)/2147483646)}function Tb(){let e=[{y:0,half:.5,curl:0},{y:.5,half:.26,curl:.06},{y:1,half:.015,curl:.18}],t=[],n=[];for(let r of e)t.push(-r.half,r.y,r.curl,r.half,r.y,r.curl),n.push(0,r.y,1,r.y);let r=new We;return r.setAttribute(`position`,new be(t,3)),r.setAttribute(`uv`,new be(n,2)),r.setIndex([0,2,1,1,2,3,2,4,3,3,4,5]),r.computeVertexNormals(),r}function Eb(e){let t=vb[Math.floor(e()*vb.length)],n=Math.floor(e()*4),r=t.maxX-t.minX,i=t.maxZ-t.minZ,a,o;n===0?(a=t.minX+e()*r,o=t.minZ):n===1?(a=t.minX+e()*r,o=t.maxZ):n===2?(a=t.minX,o=t.minZ+e()*i):(a=t.maxX,o=t.minZ+e()*i);let s=(t.minX+t.maxX)*.5,c=(t.minZ+t.maxZ)*.5,l=a-s,u=o-c,d=Math.hypot(l,u)||1;l/=d,u/=d;let f=(e()-.5)*1.7,p=Math.cos(f),m=Math.sin(f),h=l*p-u*m,g=l*m+u*p,_=.4+e()**1.45*39.6;return[a+h*_,o+g*_]}function Db({getTerrainHeight:e,gapOutsideFootprints:t,skyTime:n=null,sunDirection:r,fogColor:i,fogNear:a,fogFar:o,fogMax:s,mist:c=.36}){let l=hb({skyTime:n,sunDirection:r,fogColor:i,fogNear:a,fogFar:o,fogMax:s,mist:c}),u=new Lt(Tb(),l,_b);u.name=`boarding-grass`,u.castShadow=!1,u.receiveShadow=!1,u.frustumCulled=!0,u.raycast=Ee.prototype.raycast,u.userData.noCameraCollision=!0;let d=wb(6968801),f=new Ee,p=0;for(let n=0;n<52e4&&p<_b;n+=1){let[n,r]=Eb(d);if(xb(n,r)>40||Cb(n,r)||t(n,r)<.55||Sb(n,r,yb.ax,yb.az,yb.bx,yb.bz)<1.45)continue;let i=e(n,r);i<-.55||i>3.4||(f.position.set(n,i-.05,r),f.rotation.set(0,d()*Math.PI*2,0),f.scale.set(1,1,1),f.updateMatrix(),u.setMatrixAt(p,f.matrix),p+=1)}u.count=p,u.instanceMatrix.needsUpdate=!0,u.userData.placed=p,u.userData.bladeTriangles=4,p>0&&(u.computeBoundingSphere(),u.boundingSphere&&(u.boundingSphere.radius+=.8));function m(){let e=gb[Y.get(`grassDensity`)]??gb.medium;u.count=Math.min(e,p)}m();let h=Y.subscribe((e,t)=>{(t===`grassDensity`||t===`options`||t===`all`)&&m()});return{mesh:u,material:l,placed:p,dispose(){h()}}}var Ob=``+new URL(`pine-card-a-l8fq7E4x.png`,import.meta.url).href,kb=``+new URL(`pine-card-b-_BtlCKDE.png`,import.meta.url).href,Ab=``+new URL(`broadleaf-card-DSTApiiP.png`,import.meta.url).href,jb=8824992,Mb=-1,Nb=[[16,24,8],[28,36,11],[42,50,14],[58,70,17]],Pb=[[14,40,40]],Fb=[[40,66,40],[66,94,40],[94,120,40]],Ib=[[120,210,60]],Lb=930,Rb=new R(-.478,.292,.828).normalize();function zb(e,t,n){let r=an.lights_fragment_begin.replace(`#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )`,`#if 0`).replace(`#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )`,`#if 0`);e.onBeforeCompile=e=>{e.fragmentShader=e.fragmentShader.replace(`#include <lights_fragment_begin>`,r),e.uniforms.uSceneryViewerZ=t,e.vertexShader=`varying vec3 vSceneryWorld;
`+e.vertexShader,e.vertexShader=e.vertexShader.replace(`#include <project_vertex>`,`
      #include <project_vertex>
      vec4 sceneryPosition = vec4(transformed, 1.0);
      #ifdef USE_INSTANCING
        sceneryPosition = instanceMatrix * sceneryPosition;
      #endif
      vSceneryWorld = (modelMatrix * sceneryPosition).xyz;
    `),e.fragmentShader=`uniform float uSceneryViewerZ;
varying vec3 vSceneryWorld;
`+e.fragmentShader,e.fragmentShader=e.fragmentShader.replace(`#include <fog_fragment>`,`
      #include <fog_fragment>
      float sceneryFade = smoothstep(640.0, 780.0, distance(vSceneryWorld, vec3(0.0, 5.0, uSceneryViewerZ)));
      #ifdef USE_FOG
        gl_FragColor.rgb = mix(gl_FragColor.rgb, fogColor, sceneryFade);
      #endif
      float grain = fract(sin(dot(gl_FragCoord.xy, vec2(12.9898, 78.233))) * 43758.5453);
      if (sceneryFade > grain) discard;
    `)},e.customProgramCacheKey=()=>`moonlit-valley-${n}-no-local-lights-fade-v3`}function Bb(e,t,n,r){let i=r.valleySide,a=new Ge,o=[a.load(Ob),a.load(kb)],s=o.map((e,t)=>{e.colorSpace=Me;let r=new L({map:e,color:jb,alphaTest:.5,side:2,fog:!0});return zb(r,n,`pine-${t}`),r}),c=new We;c.setAttribute(`position`,new be([-.5,0,0,.5,0,0,.5,1,0,-.5,1,0,0,0,-.5,0,0,.5,0,1,.5,0,1,-.5],3)),c.setAttribute(`uv`,new be([0,0,1,0,1,1,0,1,0,0,1,0,1,1,0,1],2)),c.setIndex([0,1,2,0,2,3,4,5,6,4,6,7]),c.computeVertexNormals();let l=new Ee,u=new q,d=0,f=()=>(d=Math.imul(d,1664525)+1013904223>>>0,d/4294967296);for(let n of e){let e=s.map((e,t)=>{let r=new Lt(c,e,Lb/2);return r.name=`pine-forest-${t}`,r.instanceMatrix.setUsage(O),r.instanceColor=new Ye(new Float32Array(Lb/2*3),3),r.instanceColor.setUsage(O),r.boundingBox=new Ve,r.boundingSphere=new Pt,r.castShadow=!1,r.receiveShadow=!1,r.raycast=()=>{},r.userData.noCameraCollision=!0,n.group.add(r),r}),a=0,o=0,p=[0,0];function m(t,s,c,d=!1,m=!1){if(r.omitHillSide&&t<0)return;t*=i;let h=n.index*Vb+s,g=ix(n,t,h)-.3;if(d&&(c=Math.min(c,3.8-g)),m){let e=Math.tan(10*Math.PI/180);c=Math.min(c,(5-g+Math.abs(t)*e)/(1+e*.25))}let _=Math.abs(t)>300,v=!_||Math.floor(++o*.65)>Math.floor((o-1)*.65);_&&(c*=1.2);let y=c*.5;t=Math.sign(t)*Math.max(Math.abs(t),8+y*.5),l.position.set(t,ix(n,t,h)-.3,s),l.rotation.set(0,f()*Math.PI*2*i,0),l.scale.set(y,c,y);let b=.88+f()*.12,x=a++%2;if(!v)return;l.updateMatrix();let S=e[x],C=p[x]++;S.setMatrixAt(C,l.matrix),u.setRGB(b,b,b),S.setColorAt(C,u)}function h(e,t,n,r,i=!1,a=!1){for(let o of e)for(let e=0;e<o[2];e+=1){let s=n+f()*r;m(t*(o[0]+f()*(o[1]-o[0])),(e+.1+f()*.8)/o[2]*Vb,s,i,a)}}function g(e,t,r,a,o,s,c=!1){let l=e;for(;l>0;){let e=l<=14?l:Math.min(6+Math.floor(f()*9),l-6),u=r+f()*(a-r),d=12+f()*(Vb-24);if(c){let e=r+f()*(a-r),o=12+f()*(Vb-24),s=n.index*Vb,c=(e,n)=>Math.abs(tx((t*e+1)*i,s+n,i)-tx((t*e-1)*i,s+n,i));c(e,o)>c(u,d)&&(u=e,d=o)}let p=6+f()*6;for(let n=0;n<e;n+=1){let e=f()*Math.PI*2,n=p*Math.sqrt(f());m(t*B.clamp(u+Math.cos(e)*n,r,a),d+Math.sin(e)*n,o+f()*s)}l-=e}}let _=()=>{d=(Math.imul(n.index,374761393)^5074799)>>>0,a=0,o=0,p[0]=p[1]=0,h(Nb,-1,20,12),g(150,-1,80,300,16,10),h(Pb,1,10,8,!1,!0),h(Fb,1,16,10),h(Ib,1,16,8),g(450,1,220,750,14,10,!0);for(let e=0;e<60;e+=1)m(-(10+f()*70),f()*Vb,16+f()*10);for(let t of e)t.count=p[t===e[0]?0:1],t.instanceMatrix.needsUpdate=!0,t.instanceColor.needsUpdate=!0,t.computeBoundingBox(),t.computeBoundingSphere()};t(n,_),_()}return{textures:o,geometry:c,materials:s}}var Vb=160,Hb=11,Ub=5,Wb=450,Gb=900,Kb=160,qb=20,Jb=.25,Yb=5074799;function Xb(e){let t=Math.sin(Yb+e*127.1)*43758.5453;return(t-Math.floor(t))*Math.PI*2}var Zb=Xb(1),Qb=Xb(2),$b=Xb(3);function ex(e,t,n){let r=B.clamp((n-e)/(t-e),0,1);return r*r*(3-2*r)}function tx(e,t,n=Mb){if(e*=n,e>0){let n=-2.5-3.5*ex(10,40,e)-39*ex(40,120,e),r=.5*Math.sin(t/170+e/105+Zb)+.3*Math.cos(t/93-e/67+Qb)+.2*Math.sin(t/310+e/51+$b);return n+ex(210,430,e)*(145+40*r)-25*ex(750,900,e)}let r=Math.abs(e),i=ex(10,55,r),a=ex(55,180,r),o=ex(180,Wb,r),s=Math.sin(t*.009+Zb)*.55+Math.cos(t*.017+e*.006+Qb)*.3+Math.sin(t*.0037-e*.011+$b)*.15;return-2.5+i*(4+s*1.5)+a*(26+s*8)+o*(22+s*6)}function nx(e,t){let n=new U,r=t.omitHillSide?Kb/2:Kb,i=new Ot(Wb*2,Vb,r,qb);i.rotateX(-Math.PI/2),i.translate(0,0,Vb/2);let a=i.attributes.position;for(let e=0;e<a.count;e+=1){let n=a.getX(e)/Wb;if(t.omitHillSide){let r=t.valleySide>0?(n+1)/2:(1-n)/2;a.setX(e,t.valleySide*(6+r**1.6*894))}else a.setX(e,Math.sign(n)*Math.abs(n)**1.6*(n*t.valleySide>0?Gb:Wb))}i.setAttribute(`color`,new be(new Float32Array(a.count*3),3)),i.computeBoundingBox(),i.computeBoundingSphere();let o=new z(i,e);return o.name=`moonlit-valley-ground`,o.castShadow=!1,o.receiveShadow=!1,o.raycast=()=>{},o.userData.noCameraCollision=!0,n.add(o),{group:n,ground:o,geometry:i,options:t,xSegments:r,index:0,onRecycle:new Set}}function rx(e,t){e.index=t,e.group.name=`moonlit-valley-chunk-${t}`,e.group.userData.worldZ=t*Vb;let n=e.geometry.attributes.position,r=e.geometry.attributes.normal,i=e.geometry.attributes.color,a=e.geometry.attributes.uv,{valleySide:o,moonDirection:s}=e.options;for(let e=0;e<n.count;e+=1){let c=n.getX(e),l=t*Vb+n.getZ(e);n.setY(e,tx(c,l,o)),a.setXY(e,c/14,l/14);let u=(tx(c+Jb,l,o)-tx(c-Jb,l,o))/(2*Jb),d=(tx(c,l+Jb,o)-tx(c,l-Jb,o))/(2*Jb),f=Math.hypot(u,1,d);r.setXYZ(e,-u/f,1/f,-d/f);let p=c*o,m=Math.sin(p*.013+l*.008+Qb)*.08+Math.cos(p*.005-l*.014+$b)*.04,h=Math.max(0,(-u*s.x+s.y-d*s.z)/f),g=p<-10||p>210?.85:1,_=(B.clamp(.3+m*.4,.22,.38)+h*.06)*g,v=p>0?ex(100,120,p)*(1-ex(210,240,p)):0,y=1-ex(4,6,Math.abs(c)),b=_*(.65-v*.15),x=_*(.85-v*.25),S=_*(.62+v*.16);i.setXYZ(e,b*(1-y)+.21*y,x*(1-y)+.19*y,S*(1-y)+.17*y)}n.needsUpdate=!0,r.needsUpdate=!0,i.needsUpdate=!0,a.needsUpdate=!0,e.geometry.computeBoundingBox(),e.geometry.computeBoundingSphere();for(let t of e.onRecycle)t(e)}function ix(e,t,n){let r=e.geometry.attributes.position,i=B.clamp(n-e.index*Vb,0,Vb),a=Math.min(19,Math.floor(i/(Vb/qb))),{xSegments:o}=e,s=B.clamp(t,r.getX(0),r.getX(o)),c=0;for(;c<o-1&&r.getX(c+1)<s;)c+=1;let l=a*(o+1)+c,u=l+o+1,d=l+1,f=u+1,p=(s-r.getX(l))/(r.getX(d)-r.getX(l)),m=(i-r.getZ(l))/(Vb/qb);return p+m<=1?r.getY(l)*(1-p-m)+r.getY(d)*p+r.getY(u)*m:r.getY(f)*(p+m-1)+r.getY(d)*(1-m)+r.getY(u)*(1-p)}function ax(e,t,n=Rb){let r=new U;r.name=`moonlit-mountain-ring`;let i=new q(e??1321283),a=new q,o=new q(10466520),s=new R,c=Math.atan2(n.x,n.z),l=Math.asin(n.y),u=1024;[{inner:1050,outer:1300,height:210,amplitude:90,color:727583,topHaze:.15,baseHaze:.5,contrast:.8},{inner:1350,outer:1750,height:350,amplitude:100,color:1386044,topHaze:.35,baseHaze:.7,contrast:.88}].forEach((e,t)=>{let d=new q(e.color),f=new Float32Array(21525),p=new Float32Array(f.length),m=new Uint16Array(u*6*6);for(let n=0;n<=6;n+=1){let r=n/6,i=e.inner+(e.outer-e.inner)*r,a=Math.sin(Math.PI*r)**.85;for(let r=0;r<=u;r+=1){let o=r%u/u*Math.PI*2,s=.5*Math.sin(o*3+t*1.3)+.3*Math.sin(o*5+.7)+.2*Math.cos(o*9-t),d=-60+a*(e.height+e.amplitude*s+60);if(n===3){let n=Math.sin(r%u*127.1+t*311.7+19.3)*43758.5453;d+=4+8*(n-Math.floor(n)),d=Math.min(d,e.height+e.amplitude)}let p=ex(Math.cos(25*Math.PI/180),Math.cos(12*Math.PI/180),Math.cos(o-c)),h=5+i*Math.tan(l-3*Math.PI/180);d=Math.min(d,h+(1-p)*1e3);let g=(n*1025+r)*3;if(f[g]=i*Math.sin(o),f[g+1]=d,f[g+2]=i*Math.cos(o),n<6&&r<u){let e=n*1025+r,t=e+u+1;m.set([e,t,e+1,e+1,t,t+1],(n*u+r)*6)}}}let h=new We;h.setAttribute(`position`,new Rt(f,3)),h.setIndex(new Rt(m,1)),h.computeVertexNormals();let g=h.attributes.normal;for(let e=0;e<=6;e+=1){let t=e*1025,n=t+u;s.set(g.getX(t)+g.getX(n),g.getY(t)+g.getY(n),g.getZ(t)+g.getZ(n)).normalize(),g.setXYZ(t,s.x,s.y,s.z),g.setXYZ(n,s.x,s.y,s.z)}for(let r=0;r<=6;r+=1){let c=Math.sin(Math.PI*r/6)**.85,l=e.baseHaze+(e.topHaze-e.baseHaze)*c;for(let f=0;f<=u;f+=1){let m=r*1025+f;s.fromBufferAttribute(g,m);let h=Math.max(0,s.dot(n)),_=.85+.15*(.5+.5*Math.sin(f%u*127.1+r*311.7+t));a.copy(d).multiplyScalar((.3+.7*h)*_).lerp(i,l),a.lerp(o,h*c*.025),a.r=Math.min(a.r,i.r*e.contrast),a.g=Math.min(a.g,i.g*e.contrast),a.b=Math.min(a.b,i.b*e.contrast),p[m*3]=a.r,p[m*3+1]=a.g,p[m*3+2]=a.b}}h.setAttribute(`color`,new Rt(p,3)),h.computeBoundingBox(),h.computeBoundingSphere();let _=new dt({vertexColors:!0,fog:!1,depthWrite:!0}),v=new z(h,_);v.name=`mountain-ring-${t}`,v.renderOrder=-900,v.frustumCulled=!1,v.castShadow=!1,v.receiveShadow=!1,v.raycast=()=>{},v.userData.noCameraCollision=!0,r.add(v)});function d(){r.position.set(0,0,t())}return d(),{group:r,update:d}}function ox(e,t,n,r,i){let a=i.valleySide,o=new Ge().load(Ab);o.colorSpace=Me;let s=new L({map:o,color:new q(4874328).multiplyScalar(1.15),alphaTest:.5,side:2,fog:!0}),c=new x({color:2764337,flatShading:!0,roughness:1,fog:!0});zb(s,r,`bush`),zb(c,r,`rock`);let l=n.clone(),u=new y(1,0),d=new Ee,f=0,p=()=>(f=Math.imul(f,1664525)+1013904223>>>0,f/4294967296);for(let n of e){let e=new Lt(l,s,120),r=new Lt(u,c,60);e.name=`moonlit-valley-bushes`,r.name=`moonlit-valley-rocks`;for(let t of[e,r])t.instanceMatrix.setUsage(O),t.boundingBox=new Ve,t.boundingSphere=new Pt,t.castShadow=!1,t.receiveShadow=!1,t.raycast=()=>{},t.userData.noCameraCollision=!0,n.group.add(t);let o=()=>{f=(Math.imul(n.index,668265263)^1651864424)>>>0;let t=0,o=0;for(let r=0;r<120;r+=1){let o=1.2+p()*2.3,s=o*.5,c=a*(r%2?1:-1)*(r<48?4+s*.5+p()*(10-s*.5):r<72?14+p()*26:40+p()*80),l=p()*Vb;d.position.set(c,ix(n,c,n.index*Vb+l)-.1,l),d.rotation.set(0,p()*Math.PI*2*a,0),d.scale.set(s,o,s),!(i.omitHillSide&&c*a-s*.5<6)&&(d.updateMatrix(),e.setMatrixAt(t++,d.matrix))}for(let e=0;e<20;e+=1){let t=e%2?1:-1,s=t*(e<2?12+p()*5:25+p()*90),c=3+p()*154;for(let e=0;e<3;e+=1){let e=s+(p()-.5)*6,l=.4+p()*(Math.abs(e)<20?1.2:1.8),u=l*(.5+p()*.3),f=a*t*B.clamp(Math.abs(e),5+l,120-l),m=B.clamp(c+(p()-.5)*6,0,Vb);d.position.set(f,ix(n,f,n.index*Vb+m)+u*.5,m),d.rotation.set((p()-.5)*.1,p()*Math.PI*2*a,(p()-.5)*.1*a),d.scale.set(l,u,l),!(i.omitHillSide&&f*a-l<6)&&(d.updateMatrix(),r.setMatrixAt(o++,d.matrix))}}e.count=t,r.count=o,e.instanceMatrix.needsUpdate=!0,r.instanceMatrix.needsUpdate=!0,e.computeBoundingBox(),e.computeBoundingSphere(),r.computeBoundingBox(),r.computeBoundingSphere()};t(n,o),o()}return o}function sx(e){let t=new U;t.name=`moonlit-valley-rails`;let n=new K(.07,.15,2400),r=new x({color:2436146,metalness:.8,roughness:.35,fog:!0});for(let e of[-1,1]){let i=new z(n,r);i.position.set(e*(1.435+.07)/2,-2.25-.15/2,0),i.castShadow=!1,i.receiveShadow=!1,i.raycast=()=>{},i.userData.noCameraCollision=!0,t.add(i)}function i(){t.position.z=e()}return i(),{group:t,update:i}}function cx(e=Mb){let t=new U;t.name=`trackside-infrastructure`;let n=new x({color:4007703,roughness:.9}),r=new Ke({color:1118485}),i=new Lt(new p(.12,.16,6.5,8),n,24),a=new Lt(new K(1.8,.1,.12),n,24),o=new Ee,s=[[],[]],c=0;for(let t=-360;t<=360;t+=28)c<24&&(o.position.set(11.5*e,.75,t),o.updateMatrix(),i.setMatrixAt(c,o.matrix),o.position.set(11.5*e,3.55,t),o.updateMatrix(),a.setMatrixAt(c,o.matrix)),s[0].push(new R(10.75*e,3.6,t)),s[1].push(new R(12.25*e,3.6,t)),c+=1;i.instanceMatrix.needsUpdate=!0,a.instanceMatrix.needsUpdate=!0,t.add(i,a);for(let e of s){let n=[];for(let t=0;t<e.length-1;t+=1){let r=new R().lerpVectors(e[t],e[t+1],.5);r.y-=.85,n.push(e[t],r,e[t+1])}let i=new Qe(n);t.add(new Bt(new We().setFromPoints(i.getPoints(n.length*4)),r))}return t}function lx(){let e=document.createElement(`canvas`);e.width=e.height=256;let t=e.getContext(`2d`),n=t.createImageData(256,256),r=(e,t,n)=>{e=(e%n+n)%n,t=(t%n+n)%n;let r=Math.sin(e*127.1+t*311.7+Yb)*43758.5453;return r-Math.floor(r)},i=(e,t,n)=>{let i=Math.floor(e),a=Math.floor(t),o=ex(0,1,e-i),s=ex(0,1,t-a),c=B.lerp(r(i,a,n),r(i+1,a,n),o),l=B.lerp(r(i,a+1,n),r(i+1,a+1,n),o);return B.lerp(c,l,s)};for(let e=0;e<256;e+=1)for(let t=0;t<256;t+=1){let a=i(t/64,e/64,4)*.5+i(t/32,e/32,8)*.25+i(t/16,e/16,16)*.15+i(t/8,e/8,32)*.1,o=(r(t,e,256)-.5)*12,s=(e*256+t)*4;n.data[s]=72+a*38+o,n.data[s+1]=80+a*32+o,n.data[s+2]=55+a*27+o,n.data[s+3]=255}t.putImageData(n,0,0);let a=new mt(e);return a.colorSpace=Me,a.wrapS=a.wrapT=Oe,a.generateMipmaps=!0,a.minFilter=rt,a.magFilter=gt,a.anisotropy=4,a}function ux(e={}){let t={valleySide:e.valleySide??Mb,omitHillSide:e.omitHillSide??!1,moonDirection:e.moonDirection??Rb},n=e.chunkCount??Hb,r=e.chunkCount===void 0?Ub:Math.floor(n/2),i=new U;i.name=`outdoor-environment`,i.position.set(e.offsetX??0,e.offsetY??0,0);let a=lx(),o=new L({color:2374451,map:a,vertexColors:!0,fog:!0}),s=Array.from({length:n},()=>nx(o,t)),c=e.centerZ===void 0?e.getViewerZ||(()=>0):(()=>e.centerZ),l={value:c()};zb(o,l,`ground`);let u=0,d=Math.floor(c()/Vb)-r;s.forEach((e,t)=>{rx(e,d+t),e.group.position.z=e.index*Vb,i.add(e.group)});function f(e,t){return e.onRecycle.add(t),()=>e.onRecycle.delete(t)}let p=Bb(s,f,l,t),m=ox(s,f,p.geometry,l,t),h=ax(e.fogColor,c,t.moonDirection),g=e.rails===!1?null:sx(c);i.add(h.group),g&&i.add(g.group);let _=e.poles===!1?null:cx(t.valleySide);_&&i.add(_);let v=e.speed??35,y=!1,b={drawCalls:0,triangles:0};return i.traverse(e=>{!e.isMesh||e.isInstancedMesh&&e.count===0||(b.drawCalls+=1,b.triangles+=(e.geometry.index?.count??e.geometry.attributes.position.count)/3*(e.isInstancedMesh?e.count:1))}),i.userData.drawCalls=b.drawCalls,i.userData.triangles=b.triangles,{group:i,stats:b,chunks:s,heightAt:(e,n)=>tx(e,n,t.valleySide),surfaceHeightAt:ix,addToChunk(e,t,{x:n,worldZ:r,heightOffset:i=0}){return t.position.set(n,ix(e,n,r)+i,r-e.index*Vb),e.group.add(t),t},onChunkRecycle:f,update(t){if(y||e.static===!0||v===0)return;u+=t*v;let i=Math.floor((c()-u)/Vb)-r;i<d?(rx(s.find(e=>e.index===d+n-1),d-1),--d):i>d&&(rx(s.find(e=>e.index===d),d+n),d+=1);for(let e of s)e.group.position.z=e.index*Vb+u;_&&(_.position.z=(u%28+28)%28-14),l.value=c(),h.update(),g?.update()},dispose(){if(y)return;y=!0,p.geometry.dispose(),p.materials.forEach(e=>e.dispose()),p.textures.forEach(e=>e.dispose()),m.dispose(),a.dispose();let e=new Set,t=new Set;i.traverse(n=>{if(n.geometry===p.geometry){n.isInstancedMesh&&n.dispose();return}n.geometry&&e.add(n.geometry),n.material&&t.add(n.material),n.isInstancedMesh&&n.dispose()}),e.forEach(e=>e.dispose()),t.forEach(e=>e.dispose()),s.forEach(e=>e.onRecycle.clear())}}}var dx=1,fx=20,px=-190,mx=10,hx=-58,gx=-14,_x=-10,vx=-189,yx=4.3,bx=-52,xx=27,Sx=[{minX:-177.2,maxX:-157.8,minZ:-28.2,maxZ:-20.8},{minX:-160,maxX:-124.5,minZ:-41,maxZ:-20.6},{minX:-127,maxX:-79,minZ:-42.8,maxZ:-33.8},{minX:-81.2,maxX:-51,minZ:-52.2,maxZ:-21.2},{minX:-53.5,maxX:11,minZ:-30.5,maxZ:-13.5}];function Cx(e,t){return e>=px&&e<=mx&&t>=hx&&t<=gx}function wx(e,t,n,r,i,a){let o=e<n?n-e:e>r?e-r:0,s=t<i?i-t:t>a?t-a:0;return Math.hypot(o,s)}function Tx(e,t){let n=1/0;for(let r of Sx){let i=e<r.minX?r.minX-e:e>r.maxX?e-r.maxX:0,a=t<r.minZ?r.minZ-t:t>r.maxZ?t-r.maxZ:0;if(i===0&&a===0)return 0;n=Math.min(n,Math.hypot(i,a))}return n}var Ex=-95,Dx=42,Ox=62,kx=38;function Ax(e,t){let n=Math.hypot((e-Ex)/Ox,(t-Dx)/kx);return n>=1?0:(1-n)**1.35*5.4}function jx(e,t){let n=Math.sin(e*127.1+t*311.7)*43758.5453;return n-Math.floor(n)}function Mx(e,t){let n=Math.floor(e),r=Math.floor(t),i=e-n,a=t-r,o=i*i*(3-2*i),s=a*a*(3-2*a),c=jx(n,r),l=jx(n+1,r),u=jx(n,r+1),d=jx(n+1,r+1);return c+(l-c)*o+(u-c)*s+(c-l-u+d)*o*s}function Nx(e,t){return Mx(e*.008,t*.008)*.65+Mx(e*.019+4.2,t*.019-1.7)*.35}function Px(e){let t=e%2147483647;return t<=0&&(t+=2147483646),()=>(t=t*16807%2147483647,(t-1)/2147483646)}function Fx(e={}){if(e.mode===`moving`&&e.sceneryStyle===`moonlit-valley`)return ux(e);let t=e.mode||`station`,n=e.speed||35,r=e.stormy||!1,i=window.devicePixelRatio||1,a=window.innerWidth<768||i>2.5,o=e.quality||(a?`LOW`:`HIGH`),s=new U;s.name=`outdoor-environment`;let c=!1,l=null,u=e.sunPosition||new R(120,35,-90),d=e.sunColor?new q(e.sunColor):new q(r?9083828:16765332),f=e.fogColor?new q(e.fogColor):new q(r?1582128:15766634),m=e.skyColor?new q(e.skyColor):new q(6188950),h=e.groundColor?new q(e.groundColor):new q(2761243),g=e.fogNear??(r?15:35),_=e.fogFar??(r?120:260),v=e.fogMax??1,b=my({sunDirection:u.clone().normalize(),sunColor:d,skyColor:m,groundColor:h,grassColor:r?new q(1778710):new q(3030310),rockColor:r?new q(3353640):new q(5065028),gravelColor:new q(4012080),fogColor:f,fogNear:g,fogFar:_,fogMax:v,ambient:e.terrainAmbient??.7,mist:t===`station`?.42:0,paths:+(t===`station`),photo:t===`station`&&e.nature?.groundMap?1:0,groundMap:e.nature?.groundMap||null,groundNormal:e.nature?.groundNormal||null,rockMap:e.nature?.rockMap||null,rockNormal:e.nature?.rockNormal||null});function S(e,t){if(Cx(e,t))return _x;let n=Math.abs(e-dx),r=B.smoothstep(n,fx,62),i=Math.sin(e*.015+t*.012)*18,a=Math.cos(e*.035-t*.025)*8,o=Math.sin((e+100)*.008)*Math.cos(t*.008)*45,s=Math.max(0,(Math.abs(e)-80)/120)**1.8*65;return(i+a+o)*r+s-2.5}function C(e,t){let n=wx(e,t,vx,yx,bx,xx),r=B.smoothstep(n,6,100),i=Math.sin(e*.018+t*.014)*2.6+Math.cos(e*.031-t*.022)*1.4+Math.sin(e*.007+2.1)*Math.cos(t*.006)*1.6,a=B.lerp(1.6,9.5,r),o=(Math.max(0,n-100)/360)**1.35*28,s=a+i*(.45+.55*r)+o,c=Math.hypot(e,t),l=B.smoothstep(c,260,370);return s=B.lerp(s,10,l),Math.max(s,-1.2)}function w(e,t){if(Cx(e,t)){if(e<=-170){let e=Math.abs(t- -24.5),n=B.smoothstep(e,3.2,34);return B.lerp(-.4,1.8,n)}let n=Tx(e,t);if(n<=.4)return _x;let r=B.smoothstep(n,.4,8),i=Math.min(C(e,t),2.4);return B.lerp(-4.5,i,r)}let n=C(e,t),r=wx(e,t,px,mx,hx,gx);if(r<18){let e=B.smoothstep(r,0,18);n=B.lerp(Math.min(n,1.6),n,e)}let i=Math.abs(e-dx),a=B.smoothstep(i,fx,70),o=Ax(e,t);o>0&&(n-=o),n=B.lerp(-2.5,n,a);let s=e<sm.minX?sm.minX-e:e>sm.maxX?e-sm.maxX:0,c=t<sm.minZ?sm.minZ-t:t>sm.maxZ?t-sm.maxZ:0,l=Math.hypot(s,c);if(l<8){let e=1-B.smoothstep(l,0,8);n=B.lerp(n,sm.y,e)}return n}function T(e,n){return t===`station`?w(e,n):S(e,n)}let E=o===`HIGH`?96:o===`MEDIUM`?64:36,D=new Ot(750,750,E,E);D.rotateX(-Math.PI/2);let O=D.attributes.position;for(let e=0;e<O.count;e++){let t=T(O.getX(e),O.getZ(e));O.setY(e,t)}D.computeVertexNormals();let k=new z(D,b);k.receiveShadow=!0,s.add(k);let A=hy({windSpeed:1.8,windStrength:r?.35:.15,sunDirection:u.clone().normalize(),sunColor:d,skyColor:m,foliageColor:r?new q(1451028):new q(t===`station`?1055250:1979162),highlightColor:r?new q(3296553):new q(t===`station`?1715228:4285236),fogColor:f,fogNear:g,fogFar:_,fogMax:v,ambient:e.vegAmbient??.6,mist:t===`station`?.36:0});function j({tiers:e=7,trunkHeight:t=2.4,trunkRadius:n=.28,tierRadius:r=1.7,tierHeight:i=1.35,droop:a=.18,jitter:o=.16,lean:s=0}={}){let c=[],l=new p(n*.55,n,t,6);l.translate(0,t*.5,0),c.push(l);for(let n=0;n<e;n+=1){let s=e===1?0:n/(e-1),l=new qt(r*(1-s*.7),i*(.85+n%3*.08),6),u=t*.42+n*i*.46;l.translate(Math.sin(n*2.4)*o,u,Math.cos(n*1.7)*o),l.rotateZ(Math.sin(n*1.9)*a),l.rotateX(Math.cos(n*1.3)*a*.8),c.push(l)}let u=$x(c);return s&&u.rotateZ(s),c.forEach(e=>e.dispose()),u}function ee(){let e=[],t=new p(.12,.26,4.2,5);t.translate(0,2.1,0),t.rotateZ(.08),e.push(t);for(let[t,n,r,i]of[[.9,2.2,.5,.4],[1.5,2.8,-.35,-.2],[2.1,1.1,.15,.7],[2.7,.8,-.5,.15]]){let a=new p(.035,.06,n,4);a.translate(0,n*.5,0),a.rotateZ(i),a.rotateX(r),a.translate(0,t,0),e.push(a)}let n=$x(e);return e.forEach(e=>e.dispose()),n}function M(){let e=[],t=new p(.25,.45,2.2,6);t.translate(0,1.1,0),e.push(t);let n=new y(1.8,1);n.scale(1,.8,1),n.translate(0,2.8,0),e.push(n);let r=$x(e);return e.forEach(e=>e.dispose()),r}function N(){let e=new y(.9,1);return e.scale(1,.6,1.1),e.translate(0,.45,0),e}function P(e,t,n){let r=e.attributes.position;for(let e=0;e<r.count;e+=1){let i=r.getX(e),a=r.getY(e),o=r.getZ(e),s=Math.sin(i*4.1+n)*Math.cos(o*3.4+a*2.2+n);r.setXYZ(e,i*(1+s*t),a*(1+s*t*.45),o*(1+s*t))}return e.computeVertexNormals(),e}function te(e=[1.4,.68,1.08],t=.22,n=1){let r=new y(.95,0);r.scale(e[0],e[1],e[2]);let i=r.toNonIndexed();return r.dispose(),P(i,t,n)}let F=j({tiers:7,trunkHeight:2.6,tierRadius:1.85,tierHeight:1.45,droop:.22,jitter:.2}),ne=j({tiers:8,trunkHeight:3.4,trunkRadius:.18,tierRadius:.95,tierHeight:1.15,droop:.08,jitter:.06}),re=j({tiers:4,trunkHeight:1.1,trunkRadius:.12,tierRadius:.7,tierHeight:.7,droop:.16,jitter:.08}),I=ee(),L=M(),ie=N(),ae=te([1.4,.68,1.08],.22,1.2),oe=te([1.8,1.15,1.1],.35,4.4),se=te([2.1,.38,1.4],.16,8.1),ce=new p(.16,.2,2.4,6);ce.rotateZ(Math.PI/2),ce.translate(0,.18,0);let le=new p(.28,.34,.45,6);le.translate(0,.18,0);function ue(e,t){let n=[];for(let r=0;r<3;r+=1){let i=new Ot(e,t,1,2);i.translate(0,t*.5,0),i.rotateY(r*Math.PI/3),n.push(i)}let r=$x(n);return n.forEach(e=>e.dispose()),r}let de=ue(.28,.42),fe=ue(.55,.32),pe=o===`HIGH`?900:o===`MEDIUM`?500:250,me=o===`HIGH`?400:o===`MEDIUM`?200:100,he=o===`HIGH`?250:o===`MEDIUM`?120:60,ge=hy({windSpeed:1.1,windStrength:r?.22:.1,sunDirection:u.clone().normalize(),sunColor:d,skyColor:m,foliageColor:new q(3813928),highlightColor:new q(5917240),fogColor:f,fogNear:g,fogFar:_,fogMax:v,ambient:e.vegAmbient??.6,mist:t===`station`?.36:0}),_e=hy({windSpeed:2.2,windStrength:.55,swayHeight:.48,sunDirection:u.clone().normalize(),sunColor:d,skyColor:m,foliageColor:new q(1714710),highlightColor:new q(3820072),fogColor:f,fogNear:g,fogFar:_,fogMax:v,ambient:e.vegAmbient??.6,mist:t===`station`?.2:0});e.skyTime&&(A.customUniforms.uTime=e.skyTime,ge.customUniforms.uTime=e.skyTime,_e.customUniforms.uTime=e.skyTime);function ve(e,t){let n=new Float32Array(t*3);n.fill(1),e.instanceColor=new Ye(n,3)}let ye=new Lt(F,A,pe),be=new Lt(ne,A,pe),xe=new Lt(re,A,pe),V=new Lt(I,ge,Math.floor(pe*.12)),Se=new Lt(L,A,Math.floor(pe*.4)),Ce=new Lt(ie,A,me),we=t===`station`?420:1,Te=t===`station`?140:1,De=new Lt(de,_e,we),Oe=new Lt(fe,_e,Te);for(let e of[ye,be,xe,V,Se,Ce,De,Oe])ve(e,(e.instanceColor,e.count)),e.castShadow=!1,e.receiveShadow=!1;let H=fb({sunDirection:u.clone().normalize(),sunColor:d,skyColor:m,rockColor:new q(t===`station`?7235679:4867906),ambient:t===`station`?.72:.4}),ke=fb({sunDirection:u.clone().normalize(),sunColor:d,skyColor:m,rockColor:new q(4863012),ambient:t===`station`?.6:.35}),Ae=new Lt(ae,H,he),je=new Lt(oe,H,t===`station`?48:1),W=new Lt(se,H,t===`station`?28:1),Me=new Lt(ce,ke,t===`station`?36:1),Ne=new Lt(le,ke,t===`station`?24:1);for(let e of[Ae,je,W,Me,Ne])e.castShadow=!1,e.receiveShadow=!1;ye.castShadow=!1,Se.castShadow=!1;let G=new Ee;function Pe(e,n){return Cx(e,n)?!0:t===`station`?mm(e,n,3)?!0:e>=-200&&e<=20&&n>=-68&&n<=-4:!1}let Fe=0,Ie=0,Le=0,Re=0,ze=0,Be=0,Ve=0,He=0,Ue=0,Ge=0,qe=0,Je=Math.floor(pe*.5),Xe=Math.floor(pe*.28),Ze=Math.floor(pe*.16),$e=Math.min(V.count,Math.floor(pe*.06));function et(e,t,n,r,i,a,o,s){G.position.set(n,r-(.18+a*.28),i),G.rotation.set((o()-.5)*.22,o()*Math.PI*2,(o()-.5)*.22);let c=.86+o()*.28;G.scale.set(a*c,a,a*(1.72-c)),G.updateMatrix(),e.setMatrixAt(t,G.matrix),e.instanceColor.setXYZ(t,s,s*(.92+o()*.16),s*.82)}if(t===`station`){let t=Px(6221057);for(let n=0;n<pe*18&&(Fe<Je||Ie<Xe||Le<Ze||Re<$e);n++){let n=-360+t()*720,r=-360+t()*720;if(Pe(n,r)||Ax(n,r)>.35||e.nature&&wx(n,r,vx,yx,bx,xx)<=80)continue;let i=Nx(n,r);if(i<.46)continue;let a=T(n,r);if(a<.4||a>20)continue;let o=B.smoothstep(a,1.2,7);if(t()>i*(.5+o*.65))continue;let s=.78+t()*.36;i>.66&&Fe<Je?(et(ye,Fe,n,a,r,1.05+t()*.75,t,s),Fe+=1):i>.58&&Ie<Xe?(et(be,Ie,n,a,r,1.15+t()*.7,t,s*.9),Ie+=1):i<.58&&Le<Ze?(et(xe,Le,n,a,r,.4+t()*.35,t,s*1.05),Le+=1):Re<$e&&t()<.08&&(et(V,Re,n,a,r,.7+t()*.45,t,.85+t()*.2),Re+=1)}let n=Math.min(me,260);for(let e=0;e<n*8&&Be<n;e++){let e=-340+t()*680,n=-340+t()*680;if(Pe(e,n)||Ax(e,n)>.2)continue;let r=Nx(e,n);if(r<.36||r>.58)continue;let i=T(e,n);if(i<.2||i>14)continue;let a=.4+t()*.65;G.position.set(e,i-.12,n),G.rotation.y=t()*Math.PI*2,G.scale.set(a,a*.8,a),G.updateMatrix(),Ce.setMatrixAt(Be++,G.matrix)}let r=Math.min(he,70);for(let n=0;n<r*12&&Ve<r;n++){let n=-320+t()*640,r=-320+t()*640;if(Pe(n,r)||Ax(n,r)>.12||e.nature&&wx(n,r,vx,yx,bx,xx)<=55||Nx(n,r)>.4)continue;let i=T(n,r);if(i<0||i>16)continue;let a=.75+t()*1.5;G.position.set(n,i-a*.22,r),G.rotation.set(t()*.35,t()*Math.PI*2,t()*.25),G.scale.set(a*1.2,a*.55,a*.9),G.updateMatrix(),Ae.setMatrixAt(Ve++,G.matrix)}for(let n=0;n<500&&(He<je.count||Ge<Me.count);n+=1){let n=-300+t()*560,r=-300+t()*560;if(Pe(n,r)||Ax(n,r)>.15||e.nature&&wx(n,r,vx,yx,bx,xx)<=55)continue;let i=T(n,r),a=Math.abs(T(n+2,r)-i)+Math.abs(T(n,r+2)-i),o=Nx(n,r);if(a>1.1&&He<36&&i>2&&i<18){let e=He%3==0?W:je,a=e===W?Ue:He;if(e===W&&Ue>=W.count)continue;G.position.set(n,i-.3,r),G.rotation.set(t()*.2,t()*Math.PI*2,t()*.2);let o=.8+t()*1.4;G.scale.set(o,o*(.7+t()*.5),o),G.updateMatrix(),e.setMatrixAt(a,G.matrix),e===W?Ue+=1:He+=1,t()<.45&&He<36&&(G.position.set(n+(t()-.5)*2.2,i-.25,r+(t()-.5)*2.2),G.scale.set(o*.7,o*.55,o*.7),G.updateMatrix(),je.setMatrixAt(He,G.matrix),He+=1)}o>.5&&Ge<Me.count&&i>.3&&i<12?(G.position.set(n,i,r),G.rotation.set(0,t()*Math.PI,(t()-.5)*.2),G.scale.set(.8+t()*.6,.8+t()*.5,.8+t()*.6),G.updateMatrix(),Me.setMatrixAt(Ge,G.matrix),Ge+=1):o>.48&&qe<Ne.count&&i>.2&&i<10&&(G.position.set(n,i-.05,r),G.rotation.set(0,t()*Math.PI,0),G.scale.set(.7+t()*.6,.6+t()*.5,.7+t()*.6),G.updateMatrix(),Ne.setMatrixAt(qe,G.matrix),qe+=1)}De.count=0,Oe.count=0}else{for(let e=0;e<pe*2;e++){let t=(Math.random()-.5)*320*2;t+=t>0?25:-23;let n=(Math.random()-.5)*360*2;if(Pe(t,n))continue;let r=T(t,n);if(r<-2||r>45)continue;let i=.75+Math.random()*.65;G.position.set(t,r,n),G.rotation.y=Math.random()*Math.PI*2,G.rotation.x=(Math.random()-.5)*.1,G.scale.set(i,i*(.9+Math.random()*.2),i),G.updateMatrix(),e%3==0&&ze<Math.floor(pe*.4)?Se.setMatrixAt(ze++,G.matrix):Fe<pe&&ye.setMatrixAt(Fe++,G.matrix)}for(let e=0;e<me;e++){let e=(Math.random()-.5)*320*1.5;e+=e>0?25:-23;let t=(Math.random()-.5)*360*1.8;if(Pe(e,t))continue;let n=T(e,t),r=.6+Math.random()*.8;G.position.set(e,n,t),G.rotation.y=Math.random()*Math.PI*2,G.scale.set(r,r,r),G.updateMatrix(),Ce.setMatrixAt(Be++,G.matrix)}for(let e=0;e<he;e++){let e=(Math.random()-.5)*320*1.8;e+=e>0?25:-23;let t=(Math.random()-.5)*360*1.8;if(Pe(e,t))continue;let n=T(e,t),r=.8+Math.random()*1.4;G.position.set(e,n,t),G.rotation.set(Math.random()*Math.PI,Math.random()*Math.PI,0),G.scale.set(r*1.2,r*.6,r),G.updateMatrix(),Ae.setMatrixAt(Ve++,G.matrix)}}ye.count=Fe,be.count=Ie,xe.count=Le,V.count=Re,Se.count=ze,Ce.count=Be,Ae.count=Ve,je.count=He,W.count=Ue,Me.count=Ge,Ne.count=qe;for(let e of[ye,be,xe,V,Se,Ce,De,Oe,Ae])e.instanceMatrix.needsUpdate=!0,e.instanceColor&&(e.instanceColor.needsUpdate=!0);t!==`station`&&(De.count=0,Oe.count=0);function tt(t){let n={tree:[],fern:[],rock:[],log:[],stump:[]};for(let r of t){let t=r.material.clone();r.swayHeight&&ab(t,{swayHeight:r.swayHeight,windStrength:r.windStrength,timeUniform:e.skyTime});let i=new Lt(r.geometry.clone(),t,r.capacity);i.name=`nature-${r.key}`,i.castShadow=!1,i.receiveShadow=!1,i.raycast=Ee.prototype.raycast,i.userData.noCameraCollision=!0,i.count=0;let a=new Float32Array(r.capacity*3);a.fill(1),i.instanceColor=new Ye(a,3),s.add(i),n[r.kind].push({prop:r,mesh:i,index:0})}let r=Px(677351),i=(e,t)=>e<-168&&Math.abs(t+24.5)<3.1;function a(e,t,n,i,a,o,s,c,l,u){if(!e||e.index>=e.prop.capacity)return!1;G.position.set(t,n,i),G.rotation.set(a,o,s),G.scale.set(c,l,u),G.updateMatrix(),e.mesh.setMatrixAt(e.index,G.matrix);let d=.84+r()*.22;return e.mesh.instanceColor.setXYZ(e.index,d,d*(.94+r()*.1),d*.9),e.index+=1,!0}let o=n.tree,c=[];for(let e=0;e<8e3&&c.length<500&&o.length;e+=1){let e=-269+r()*353.3,t=-132+r()*239;if(wx(e,t,vx,yx,bx,xx)>80||Pe(e,t)||i(e,t)||Tx(e,t)<1.4||Ax(e,t)>.2||Nx(e,t)<.3&&r()>.4)continue;let n=T(e,t);if(n<.15||n>16)continue;let a=e<-188.1?30:0;c.push({rx:e,rz:t,groundY:n,score:Math.hypot(e- -182.1,t- -24.5)+a,yaw:r(),lean:r(),sink:r(),spread:r()})}c.sort((e,t)=>e.score-t.score);let l=Math.min(60,c.length);for(let e=0;e<l;e+=1){let t=c[e],n=o[e%o.length],[r,i]=n.prop.scale,s=r+(i-r)*t.spread;a(n,t.rx,t.groundY-(.16+t.sink*.22),t.rz,(t.lean-.5)*.08,t.yaw*Math.PI*2,(t.spread-.5)*.08,s,s*(.92+t.lean*.16),s)}let u=n.fern,d=0;for(let e=0;e<4e3&&d<16&&u.length;e+=1){let e=-224+r()*120,t=-72+r()*90,n=Tx(e,t);if(n<1.4||n>9||i(e,t)||Ax(e,t)>.15||xb(e,t)>24)continue;let o=T(e,t);if(o<-.45||o>3)continue;let s=u[d%u.length],[c,l]=s.prop.scale,f=c+r()*(l-c);a(s,e,o-.05,t,(r()-.5)*.22,r()*Math.PI*2,(r()-.5)*.18,f,.75+r()*.65,f)&&(d+=1)}function f(e,t,n,o){let s=0;for(let c=0;c<t*50&&s<t&&e.length;c+=1){let t=vx-n+r()*(193.3+n*2),c=bx-n+r()*(79+n*2);if(wx(t,c,vx,yx,bx,xx)>n||Pe(t,c)||i(t,c)||Tx(t,c)<.9||Ax(t,c)>.12)continue;let l=T(t,c);if(l<-.3||l>14)continue;let u=e[s%e.length],[d,f]=u.prop.scale,p=d+r()*(f-d),m=o?.08:.08+p*.12,h=o?.04:.4;a(u,t,l-m,c,(r()-.5)*h,r()*Math.PI*2,(r()-.5)*h,p*(.85+r()*.35),p*(o?.85+r()*.3:.75+r()*.45),p*(.85+r()*.35))&&(s+=1)}}f(n.rock,36,50,!1),f(n.log,14,45,!0),f(n.stump,10,45,!0);for(let e of Object.values(n))for(let t of e)t.mesh.count=t.index,t.mesh.instanceMatrix.needsUpdate=!0,t.mesh.instanceColor&&(t.mesh.instanceColor.needsUpdate=!0)}t===`station`&&e.nature?.props?.length&&tt(e.nature.props),t===`station`&&(l=Db({getTerrainHeight:T,gapOutsideFootprints:Tx,skyTime:e.skyTime||null,sunDirection:u.clone().normalize(),fogColor:f,fogNear:g,fogFar:_,fogMax:v,mist:.36}),s.add(l.mesh)),s.add(ye,be,xe,V,Se,Ce,De,Oe,Ae,je,W,Me,Ne);let nt=new U;nt.name=`trackside-infrastructure`;let rt=new x({color:4007703,roughness:.9});new x({color:2237994,metalness:.35,roughness:.78});let it=new Ke({color:1118485}),at=new Lt(new p(.12,.16,6.5,8),rt,24),ot=new Lt(new K(1.8,.1,.12),rt,24),st=0,ct=[[],[]];for(let e=-360;e<=360;e+=28){let n=11.5;if(t===`station`&&mm(n,e,1)){ct[0].push(null),ct[1].push(null);continue}let r=T(n,e)+3.25;G.position.set(n,r,e),G.rotation.set(0,0,0),G.scale.set(1,1,1),G.updateMatrix(),at.setMatrixAt(st,G.matrix),G.position.set(n,r+2.8,e),G.rotation.set(0,0,0),G.updateMatrix(),ot.setMatrixAt(st,G.matrix),ct[0].push(new R(10.75,r+2.85,e)),ct[1].push(new R(12.25,r+2.85,e)),st++}at.count=Math.min(st,24),ot.count=Math.min(st,24),at.instanceMatrix.needsUpdate=!0,ot.instanceMatrix.needsUpdate=!0,nt.add(at,ot);for(let e of ct){let t=[];function n(){if(t.length<2){t=[];return}let e=[];for(let n=0;n<t.length-1;n+=1){let r=t[n],i=t[n+1],a=new R().lerpVectors(r,i,.5);a.y-=.85,e.push(r,a,i)}let n=new Qe(e),r=new We().setFromPoints(n.getPoints(e.length*4));nt.add(new Bt(r,it)),t=[]}for(let r of e)r?t.push(r):n();n()}let lt=new K(.1,1.2,.1),dt=new K(.06,.08,3.8),ft=new Lt(lt,rt,160),pt=new Lt(dt,rt,160),mt=0,ht=0;for(let e of[2,12.5])for(let n=-140;n<=140&&!(mt>=160);n+=3.8){if(t===`station`&&e>8&&mm(e,n,2))continue;let r=T(e,n)+.6;G.position.set(e,r,n),G.rotation.set(0,0,(Math.random()-.5)*.08),G.scale.set(1,1,1),G.updateMatrix(),ft.setMatrixAt(mt++,G.matrix),G.position.set(e,r+.35,n+1.9),G.rotation.set(0,0,0),G.updateMatrix(),pt.setMatrixAt(ht++,G.matrix)}ft.count=mt,pt.count=ht,ft.instanceMatrix.needsUpdate=!0,pt.instanceMatrix.needsUpdate=!0,nt.add(ft,pt),s.add(nt);let gt=null;t===`station`&&(qx(s),gt=Qx(s,T,e.skyTime),e.skyUniforms&&(Jx(s,e.skyUniforms,T),Xx(s,e.skyUniforms,T)),Zx(s,T));let _t=0,vt=0,yt=e.stationSpotLights||[];function bt(e){if(yt=e||[],!yt.length)return;let t=Math.min(3,yt.length),n=[new R,new R,new R],r=[new R(0,-1,0),new R(0,-1,0),new R(0,-1,0)],i=[new q(0),new q(0),new q(0)],a=[new ut,new ut,new ut],o=new R;for(let e=0;e<t;e++){let t=yt[e];if(!t)continue;t.getWorldPosition(n[e]),t.target?(t.target.getWorldPosition(o),r[e].subVectors(o,n[e]).normalize()):r[e].set(0,-1,0).applyQuaternion(t.quaternion).normalize(),i[e].copy(t.color);let s=t.intensity,c=Math.cos(t.angle),l=Math.cos(t.angle*(1-t.penumbra)),u=t.distance||150;a[e].set(s,c,l,u)}[b,A].forEach(e=>{e&&e.customUniforms&&(e.customUniforms.uStationSpotLightCount.value=t,e.customUniforms.uStationSpotLightPos.value=n,e.customUniforms.uStationSpotLightDir.value=r,e.customUniforms.uStationSpotLightColor.value=i,e.customUniforms.uStationSpotLightParams.value=a)})}e.stationSpotLights&&bt(e.stationSpotLights);function xt(e,{color:t,near:n,far:r,max:i}){let a=e?.customUniforms;a&&(t!==void 0&&(t.isColor?a.uFogColor.value.copy(t):a.uFogColor.value.set(t)),n!==void 0&&(a.uFogNear.value=n),r!==void 0&&(a.uFogFar.value=r),i!==void 0&&(a.uFogMax.value=i))}function St(e){xt(b,e),xt(A,e),xt(ge,e),xt(_e,e),l&&xt(l.material,e)}function Ct(e){St({color:e})}return{group:s,terrainMesh:k,setStationSpotLights:bt,setFogColor:Ct,setFog:St,update(r){if(_t+=r,yt.length>0&&bt(yt),b.customUniforms&&(b.customUniforms.uTime.value=_t),A.customUniforms&&!e.skyTime&&(A.customUniforms.uTime.value=_t),ge.customUniforms&&!e.skyTime&&(ge.customUniforms.uTime.value=_t),_e.customUniforms&&!e.skyTime&&(_e.customUniforms.uTime.value=_t),l&&!e.skyTime&&(l.material.customUniforms.uTime.value=_t),gt&&!e.skyTime&&(gt.customUniforms.uTime.value=_t),t===`moving`){let e=r*n;vt+=e,nt.position.z=vt%28-14,k.position.z=vt%50-25,ye.position.z=vt%60-30,Se.position.z=vt%60-30,Ce.position.z=vt%40-20,Ae.position.z=vt%40-20}},dispose(){c||(c=!0,l&&l.dispose(),Jd(s))}}}var Ix=-187,Lx=-24.5,Rx=Math.atan2(-10,16),zx=Math.atan2(3,16),Bx=new R(16,.28,-10),Vx=[{inner:348,outer:500,base:6,freq:4.4,seed:2.2,scale:1,baseColor:1712668,forestColor:1318934,snowColor:13160668,hazeColor:1710128,haze:.22,forest:1,mist:.5},{inner:560,outer:760,base:8,freq:3.2,seed:9.4,scale:.82,baseColor:2238520,forestColor:1714224,snowColor:12109012,hazeColor:2365488,haze:.5,forest:.35,mist:.22},{inner:840,outer:1060,base:10,freq:2.1,seed:21.7,scale:.62,baseColor:2761788,forestColor:2761788,snowColor:11056328,hazeColor:3283e3,haze:.78,forest:0,mist:.08}];function Hx(e){return Math.atan2(Math.sin(e),Math.cos(e))}function Ux(e,t,n){let r=Math.max(0,Math.cos(e)),i=r*r,a=(6+t*3.2)*(1-i)+(14+t*6.5)*i,o=Math.exp(-((Hx(e-Rx)/.2)**2));a=a*(1-o)+4.8*o;let s=Math.exp(-((Hx(e-zx)/.16)**2));return a=Math.min(a,11+(1-s)*24),a*n}function Wx(e){let t=Math.sin(e*127.1+311.7)*43758.5453123;return t-Math.floor(t)}function Gx(e){let t=Math.floor(e),n=e-t,r=n*n*(3-2*n);return Wx(t)+(Wx(t+1)-Wx(t))*r}function Kx(e,t,n){let r=.5,i=1,a=0,o=0,s=e*t+n;for(let e=0;e<5;e+=1)a+=r*Gx(s*i),o+=r,r*=.5,i*=2.03;return a/o}function qx(e){for(let t=0;t<Vx.length;t+=1){let n=Vx[t],r=new Float32Array(966),i=new Float32Array(644),a=new Uint32Array(960);for(let e=0;e<=160;e+=1){let t=e/160*Math.PI*2,o=Math.cos(t),s=Math.sin(t),c=o*n.outer,l=s*n.outer,u=Math.atan2(l-Lx,c-Ix),d=Math.hypot(c-Ix,l-Lx),f=Ux(u,(1-Math.abs(Kx(u,n.freq,n.seed)*2-1))**.72,n.scale),p=2+d*Math.tan(f*Math.PI/180),m=e*2,h=m+1;if(r[m*3]=o*n.inner,r[m*3+1]=n.base,r[m*3+2]=s*n.inner,i[m*2+1]=0,r[h*3]=o*n.outer,r[h*3+1]=p,r[h*3+2]=s*n.outer,i[h*2+1]=1,e<160){let t=m,n=h,r=(e+1)*2,i=r+1,o=e*6;a[o]=t,a[o+1]=n,a[o+2]=r,a[o+3]=n,a[o+4]=i,a[o+5]=r}}let o=new We;o.setAttribute(`position`,new Rt(r,3)),o.setAttribute(`uv`,new Rt(i,2)),o.setIndex(new Rt(a,1)),o.computeVertexNormals();let s=new z(o,ub({baseColor:n.baseColor,forestColor:n.forestColor,snowColor:n.snowColor,hazeColor:n.hazeColor,haze:n.haze,forest:n.forest,mist:n.mist,afterglowDir:Bx,moonDir:ry}));s.name=`distant-range-${t}`,s.castShadow=!1,s.receiveShadow=!1,s.raycast=()=>{},e.add(s)}}function Jx(e,t,n){let r=n(-37.96,Dx)-.35,i=new G(1,48);i.rotateX(-Math.PI/2),i.scale(Ox,1,kx);let a=new z(i,mb(t));a.name=`valley-lake`,a.position.set(Ex,r,Dx),a.castShadow=!1,a.receiveShadow=!1,a.raycast=()=>{},e.add(a)}var Yx=[[70,108],[28,88],[-8,68],[-42,54],[-62,48]];function Xx(e,t,n){let r=1.7,i=[],a=[];for(let e=0;e<Yx.length;e+=1){let[t,o]=Yx[e],s=Yx[Math.max(0,e-1)],c=Yx[Math.min(Yx.length-1,e+1)],l=c[0]-s[0],u=c[1]-s[1],d=Math.hypot(l,u)||1;l/=d,u/=d;let f=n(t,o)-.45;if(i.push(t-u*r,f,o+l*r,t+u*r,f,o-l*r),e<Yx.length-1){let t=e*2;a.push(t,t+1,t+2,t+1,t+3,t+2)}}let o=new We;o.setAttribute(`position`,new be(i,3)),o.setIndex(a),o.computeVertexNormals();let s=new z(o,mb(t));s.name=`valley-creek`,s.castShadow=!1,s.receiveShadow=!1,s.raycast=()=>{},e.add(s);let c=new y(.35,0),l=c.toNonIndexed();l.computeVertexNormals(),c.dispose();let u=fb({sunDirection:ry,sunColor:new q(10137552).multiplyScalar(3),skyColor:new q(2373206),rockColor:new q(7235679),ambient:.7}),d=new Lt(l,u,Yx.length*4),f=new Ee,p=0;for(let e=0;e<Yx.length;e+=1){let[t,r]=Yx[e];for(let i of[-1,1])f.position.set(t+i*2.1,n(t+i*2.1,r)-.1,r+i*.4),f.rotation.set(0,e,0),f.scale.set(.8+e%3*.25,.45,.7),f.updateMatrix(),d.setMatrixAt(p,f.matrix),p+=1}d.count=p,d.castShadow=!1,d.receiveShadow=!1,d.instanceMatrix.needsUpdate=!0,e.add(d)}function Zx(e,t){let n=new x({color:4863012,roughness:.86}),r=new x({color:2764854,roughness:.55,metalness:.45}),i=new x({color:16769712,emissive:16757082,emissiveIntensity:1.5,roughness:.3}),a=new x({color:1711650,roughness:.4,metalness:.6}),o=[],s=[],c=[],l=[];function u(e,t,n,r,i,a,o){let s=new K(t,n,r);s.translate(i,a,o),e.push(s)}function d(e,n,r,i,a){let d=t(e,n);u(o,r,a,i,e,d+a/2,n),u(s,r+.45,.16,i+.45,e,d+a+.08,n),u(c,.7,.7,.06,e,d+a*.55,n+i/2+.02),u(c,.55,.55,.06,e+r/2+.02,d+a*.55,n),u(l,.28,.9,.28,e+r*.3,d+a+.7,n)}d(58,40,4.2,3.2,2.6),d(78,46,3.4,2.8,2.3);let f=t(46,-10);u(o,2.2,2.4,2.2,46,f+1.6,-10),u(c,.8,.6,.06,46,f+2,-10+1.12),u(s,2.6,.1,2.6,46,f+2.9,-10);let m=t(64,4),h=new p(1.3,1.3,1.5,8);h.translate(64,m+6.2,4),s.push(h),u(o,.18,5.2,.18,63.1,m+2.6,3.1),u(o,.18,5.2,.18,64.9,m+2.6,3.1),u(o,.18,5.2,.18,63.1,m+2.6,4.9),u(o,.18,5.2,.18,64.9,m+2.6,4.9);function g(t,n,r){let i=t.filter(Boolean);if(!i.length)return;let a=$x(i);i.forEach(e=>e.dispose());let o=new z(a,n);o.name=r,o.castShadow=!1,o.receiveShadow=!1,e.add(o)}g(o,n,`valley-walls`),g(s,r,`valley-roofs`),g(c,i,`valley-windows`),g(l,a,`valley-chimneys`);let _=[],v=[];function y(e,n,r,i){let a=Math.hypot(r-e,i-n),o=Math.max(1,Math.round(a/2.4));for(let a=0;a<=o;a+=1){let s=a/o,c=e+(r-e)*s,l=n+(i-n)*s,u=t(c,l);if(_.push([c,u,l]),a<o){let s=e+(r-e)*((a+1)/o),d=n+(i-n)*((a+1)/o);v.push([(c+s)/2,(u+t(s,d))/2,(l+d)/2,Math.atan2(s-c,d-l),Math.hypot(s-c,d-l)])}}}y(46,-28,78,-28),y(78,-28,78,-8),y(78,-8,46,-8),y(46,-8,46,-28);let b=new Lt(new K(.1,1.05,.1),n,_.length),S=new Lt(new K(.08,.08,1),n,v.length),C=new Ee;_.forEach(([e,t,n],r)=>{C.position.set(e,t+.5,n),C.rotation.set(0,0,0),C.scale.set(1,1,1),C.updateMatrix(),b.setMatrixAt(r,C.matrix)}),v.forEach(([e,t,n,r,i],a)=>{C.position.set(e,t+.85,n),C.rotation.set(0,r,0),C.scale.set(1,1,i),C.updateMatrix(),S.setMatrixAt(a,C.matrix)});for(let e of[b,S])e.castShadow=!1,e.receiveShadow=!1,e.instanceMatrix.needsUpdate=!0;e.add(b,S)}function Qx(e,t,n){let r=[],i=[],a=[],o=[],s=17,c=()=>(s=s*16807%2147483647,(s-1)/2147483646),l=[new q(16763274),new q(16769712),new q(16751178)];function u(e,t,n,s,l){r.push(e,t,n),i.push(s.r,s.g,s.b),a.push(c()),o.push(l)}for(let e of[{x:78,z:34,count:16},{x:150,z:-26,count:14},{x:214,z:46,count:18},{x:270,z:6,count:12}])for(let n=0;n<e.count;n+=1){let r=e.x+(c()-.5)*34,i=e.z+(c()-.5)*26;u(r,t(r,i)+.5+c()*3.4,i,l[n%l.length],5.2+c()*2.4)}let d=new q(16726586),f=new q(4063098),p=0;for(let e=48;e<=340;e+=26){for(let n of[-2.4,2.4]){let r=t(e,n)+5.4,i=(p+ +(n>0))%2==0?f:d;u(e,r,n,i,7.2)}p+=1}let m=new We;m.setAttribute(`position`,new be(r,3)),m.setAttribute(`aColor`,new be(i,3)),m.setAttribute(`aSeed`,new be(a,1)),m.setAttribute(`aSize`,new be(o,1));let h=db(n),g=new je(m,h);return g.name=`valley-lights`,g.castShadow=!1,g.receiveShadow=!1,g.raycast=()=>{},e.add(g),h}function $x(e){if(!e?.length)return new We;let t=e.some(e=>e.index!==null),n=0,r=0;e.forEach(e=>{n+=e.attributes.position.count,r+=e.index?e.index.count:e.attributes.position.count});let i=new Float32Array(n*3),a=new Float32Array(n*3),o=t?new(n>65535?Uint32Array:Uint16Array)(r):null,s=0,c=0;e.forEach(e=>{let n=e.attributes.position.array,r=e.attributes.normal?e.attributes.normal.array:null;if(i.set(n,s*3),r&&a.set(r,s*3),t){let t=e.index?e.index.count:e.attributes.position.count;for(let n=0;n<t;n+=1)o[c+n]=(e.index?e.index.getX(n):n)+s;c+=t}s+=e.attributes.position.count});let l=new We;return l.setAttribute(`position`,new Rt(i,3)),l.setAttribute(`normal`,new Rt(a,3)),o&&l.setIndex(new Rt(o,1)),l}var eS=480,tS=-1.6*Math.PI/180,nS=new R(16,0,-10).normalize(),rS={boarding:{turbidity:10,rayleigh:1.6,mieCoefficient:.004,mieDirectionalG:.84,skyGain:.0019,highlightCompress:.35,saturation:1.08,sunDirection:new R(nS.x*Math.cos(tS),Math.sin(tS),nS.z*Math.cos(tS)),showSunDisc:0,moonDirection:ry.clone(),moonStrength:1,nightLift:.8,starDensity:.026,starBrightness:3,cloudAmount:.09,cloudSpeed:.008,glitch:0,horizon:3807304,zenith:1713240},"moving-heist":{turbidity:2,rayleigh:1.2,mieCoefficient:.002,mieDirectionalG:.75,skyGain:.04,highlightCompress:.15,saturation:1,sunDirection:new R(.2,-.28,-.55).normalize(),showSunDisc:0,moonDirection:new R(-.478,.292,.828).normalize(),moonSize:2,moonSoftGlow:1,moonStrength:1,nightLift:.95,starDensity:.022,starBrightness:1.8,cloudAmount:.24,cloudSpeed:.003,glitch:0,horizon:2047331,zenith:727606},timewreck:{turbidity:16,rayleigh:1.5,mieCoefficient:.018,mieDirectionalG:.72,skyGain:.02,highlightCompress:.45,saturation:1.15,sunDirection:new R(.35,.07,-.55).normalize(),showSunDisc:1,moonDirection:new R(0,1,0),moonStrength:0,nightLift:.12,starDensity:.008,starBrightness:1.8,cloudAmount:.48,cloudSpeed:.04,glitch:.85,horizon:3820120,zenith:1714232}};rS[`boarding-platform`]={...rS[`moving-heist`],moonDirection:iy.clone()};function iS(e){let t=e?.getMode?.();return t===`SLOW`?.2:t===`FREEZE`?0:t===`REWIND`?-2.5:1}function aS(e){let t=rS[e];if(!t)throw Error(`sky-dome: unknown preset "${e}"`);let n={uTime:{value:0},uEnvCapture:{value:0},uSkyGain:{value:t.skyGain},uHighlightCompress:{value:t.highlightCompress},uSaturation:{value:t.saturation},uTurbidity:{value:t.turbidity},uRayleigh:{value:t.rayleigh},uMieCoefficient:{value:t.mieCoefficient},uMieDirectionalG:{value:t.mieDirectionalG},uSunDirection:{value:t.sunDirection.clone()},uShowSunDisc:{value:t.showSunDisc},uMoonDirection:{value:t.moonDirection.clone()},uMoonStrength:{value:t.moonStrength},uMoonSize:{value:t.moonSize??1},uMoonSoftGlow:{value:t.moonSoftGlow??0},uNightLift:{value:t.nightLift},uStarDensity:{value:t.starDensity},uStarBrightness:{value:t.starBrightness},uCloudAmount:{value:t.cloudAmount},uCloudSpeed:{value:t.cloudSpeed},uGlitch:{value:t.glitch},uGrade:{value:0},uHorizonColor:{value:new q(t.horizon)},uZenithColor:{value:new q(t.zenith)},uGroundBlack:{value:0}},r=`
    varying vec3 vWorldPosition;
    varying vec3 vSunDirection;
    varying float vSunE;
    varying vec3 vBetaR;
    varying vec3 vBetaM;

    uniform float uTime;
    uniform float uEnvCapture;
    uniform float uSkyGain;
    uniform float uHighlightCompress;
    uniform float uSaturation;
    uniform float uMieDirectionalG;
    uniform float uShowSunDisc;
    uniform vec3 uMoonDirection;
    uniform float uMoonStrength;
    uniform float uNightLift;
    uniform float uStarDensity;
    uniform float uStarBrightness;
    uniform float uCloudAmount;
    uniform float uCloudSpeed;
    uniform float uGlitch;
    uniform float uGrade;
    uniform vec3 uHorizonColor;
    uniform vec3 uZenithColor;
    uniform float uGroundBlack;

    ${pb}

    void main() {
      // View direction. Clouds and stars are sampled from this vector
      // inside evaluateSky(), not from an azimuth, so the sky has no seam.
      vec3 direction = normalize(vWorldPosition - cameraPosition);
      vec3 skyColor = evaluateSky(direction);
      float ground = 1.0 - smoothstep(-0.015, 0.05, direction.y);
      // The low sky goes nearly black too, so gaps between rooftops read as
      // night rather than glowing horizon. The moon (y ≈ 0.5) and the
      // stars above it are untouched.
      float lowSky = 1.0 - smoothstep(0.04, 0.4, direction.y);
      float dark = max(ground, lowSky * 0.94);

      gl_FragColor = vec4(skyColor * (1.0 - uGroundBlack * dark), 1.0);

      // Same ACES curve and output colour space as every other material.
      // Both chunks are what the three.js Sky example includes.
      #include <tonemapping_fragment>

      // 8. Timewreck tears, after tone mapping so the channel swap stays
      //    visible once ACES has compressed the sky. uGlitch is 0 elsewhere,
      //    and the finale sets it back to 0 when it recolours the sky.
      float slice = floor(direction.y * 22.0 + uTime * 1.6);
      float tear = step(0.62, hash(vec2(slice, floor(uTime * 4.0))));
      gl_FragColor.rgb = mix(gl_FragColor.rgb, gl_FragColor.gbr, uGlitch * tear);

      #include <colorspace_fragment>

      // The environment-map capture reads the linear sky, before ACES and
      // before the sRGB encode. Materials tone-map the map themselves.
      if (uEnvCapture > 0.5) {
        gl_FragColor = vec4(skyColor, 1.0);
      }
    }
  `,i=new Je({uniforms:n,vertexShader:`
    uniform vec3 uSunDirection;
    uniform float uRayleigh;
    uniform float uTurbidity;
    uniform float uMieCoefficient;

    // World position of this vertex. The fragment shader turns it into a
    // view direction. Doing that per pixel (not per vertex) keeps the
    // colour smooth across the dome's triangles.
    varying vec3 vWorldPosition;
    // Unit vector toward the sun. Same value everywhere; a varying only
    // because the scattering coefficients are computed here, once per vertex.
    varying vec3 vSunDirection;
    // Sun brightness after the horizon falloff. 0 once the sun has set.
    varying float vSunE;
    // How strongly air (Rayleigh) and haze (Mie) absorb each channel.
    // Blue is the largest Rayleigh component: blue light is scattered most.
    varying vec3 vBetaR;
    varying vec3 vBetaM;

    // Constants from the three.js Sky shader (Preetham).
    // Total Rayleigh scattering for Preetham's primaries (680, 550, 450 nm).
    // Replaces TotalRayleigh() in the example. Blue (z) is the largest.
    const vec3 totalRayleigh = vec3(5.804542996261093E-6, 1.3562911419845635E-5, 3.0265902468824876E-5);
    // MieConst = pi * pow((2 pi) / lambda, vec3(v - 2)) * K, with v = 4
    // and K the example's per-channel coefficients.
    const vec3 MieConst = vec3(1.8399918514433978E14, 2.7798023919660528E14, 4.0790479543861094E14);
    // Sun intensity drops to 0 as the sun crosses the horizon. cutoffAngle
    // is pi / 1.95, steepness shapes the falloff, EE is the base intensity.
    const float cutoffAngle = 1.6110731556870734;
    const float steepness = 1.5;
    const float EE = 1000.0;

    float sunIntensity(float zenithAngleCos) {
      zenithAngleCos = clamp(zenithAngleCos, -1.0, 1.0);
      return EE * max(0.0, 1.0 - exp(-((cutoffAngle - acos(zenithAngleCos)) / steepness)));
    }

    // Haze density from turbidity. The 10E-18 brings MieConst back to a
    // usable scale. This is totalMie() from the example.
    vec3 totalMie(float T) {
      float c = (0.2 * T) * 10E-18;
      return 0.434 * c * MieConst;
    }

    void main() {
      vec4 worldPosition = modelMatrix * vec4(position, 1.0);
      vWorldPosition = worldPosition.xyz;

      gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      // Push the dome to the far plane so it never wins a depth test.
      gl_Position.z = gl_Position.w;

      vSunDirection = normalize(uSunDirection);
      // World up. The dome is never tilted.
      vec3 up = vec3(0.0, 1.0, 0.0);
      vSunE = sunIntensity(dot(vSunDirection, up));

      // The example's sunfade term uses a sun position in huge world units
      // (y / 450000). We pass a unit direction, so that term stays at 1 and
      // the dusk comes from the sun's angle through the air, plus turbidity.
      float rayleighCoefficient = uRayleigh;

      vBetaR = totalRayleigh * rayleighCoefficient;
      vBetaM = totalMie(uTurbidity) * uMieCoefficient;
    }
  `,fragmentShader:r,side:1,depthWrite:!1,depthTest:!1,fog:!1,toneMapped:!0}),a=new z(new He(eS,64,48),i);a.name=`sky-dome`,a.frustumCulled=!1,a.castShadow=!1,a.receiveShadow=!1,a.renderOrder=-1e3,a.layers.set(0),a.raycast=()=>{},a.onBeforeRender=function(e,t,n){this.position.copy(n.position),this.updateMatrixWorld()};let o=new q(t.horizon),s=new q(t.zenith),c=new q(16769200),l=null;function u(e,t=0){let r=rS[e];if(!r)throw Error(`sky-dome: unknown preset "${e}"`);let i={uSkyGain:r.skyGain,uHighlightCompress:r.highlightCompress,uSaturation:r.saturation,uTurbidity:r.turbidity,uRayleigh:r.rayleigh,uMieCoefficient:r.mieCoefficient,uMieDirectionalG:r.mieDirectionalG,uShowSunDisc:r.showSunDisc,uMoonStrength:r.moonStrength,uMoonSize:r.moonSize??1,uMoonSoftGlow:r.moonSoftGlow??0,uNightLift:r.nightLift,uStarDensity:r.starDensity,uStarBrightness:r.starBrightness,uCloudAmount:r.cloudAmount,uCloudSpeed:r.cloudSpeed,uGlitch:r.glitch,uSunDirection:r.sunDirection,uMoonDirection:r.moonDirection,uHorizonColor:new q(r.horizon),uZenithColor:new q(r.zenith)};l={starts:Object.fromEntries(Object.keys(i).map(e=>{let t=n[e].value;return[e,t?.clone?t.clone():t]})),targets:i,seconds:t,elapsed:0},t<=0&&d(1)}function d(e){let{starts:t,targets:r}=l;for(let[i,a]of Object.entries(r)){let r=n[i];a?.isColor?r.value.copy(t[i]).lerp(a,e):a?.isVector3?r.value.copy(t[i]).lerp(a,e).normalize():r.value=B.lerp(t[i],a,e)}e>=1&&(o.copy(n.uHorizonColor.value),s.copy(n.uZenithColor.value),l=null)}function f({horizon:e,zenith:t,glow:r,glitch:i,starBrightness:a,grade:o}={}){e&&n.uHorizonColor.value.copy(e),t&&n.uZenithColor.value.copy(t),r&&c.copy(r),i!==void 0&&(n.uGlitch.value=i),a!==void 0&&(n.uStarBrightness.value=a),o!==void 0&&(n.uGrade.value=o)}function p(e,t){if(n.uTime.value+=e*iS(t),l){l.elapsed+=e;let t=Math.min(1,l.elapsed/l.seconds);d(t*t*(3-2*t))}}function m(){a.onBeforeRender=function(){},Jd(a)}return{mesh:a,horizonColor:n.uHorizonColor.value,timeUniform:n.uTime,uniforms:n,baseHorizon:o,baseZenith:s,baseGlow:c,baseGlitch:t.glitch,update:p,setLook:f,setPreset:u,dispose:m}}var oS=null,sS=new t;function cS(e,t){oS||=new En(e);let n=t.parent,r=t.material.uniforms.uEnvCapture,i=r.value;r.value=1,sS.add(t);try{return oS.fromScene(sS,0,.1,800)}finally{r.value=i,n?n.add(t):sS.remove(t)}}var lS=new Set;function uS(e){return typeof e==`function`?e():e}function dS(e,t,n){if(!e||!t||!n)return!1;let r=(n.x??0)/2,i=(n.y??1/0)/2,a=(n.z??0)/2;return Math.abs(e.x-t.x)<=r&&Math.abs(e.y-t.y)<=i&&Math.abs(e.z-t.z)<=a}function fS({player:e,hud:t}={}){let n=[],r=new Set,i=!1;function a(e={}){if(!e.id)throw Error(`tutorial-hints: every zone needs a unique id`);if(!e.center||!e.size)throw Error(`tutorial-hints: zone "${e.id}" needs center and size`);return n.push({...e}),()=>{let t=n.findIndex(t=>t.id===e.id);t>=0&&n.splice(t,1),r.delete(e.id)}}function o(e){let n=uS(e.text)??``;e.modal&&t?.showTutorial?t.showTutorial({eyebrow:uS(e.eyebrow)??`Field Guide`,title:uS(e.title)??`New Mechanic`,text:n,controls:uS(e.controls)??[],footer:uS(e.footer)}):t?.showToast?.(n,e.duration??3200)}function s(){if(i||t?.isTutorialOpen?.())return;let a=e?.mesh?.position??e?.position;if(a){for(let e of n)if(!r.has(e.id)){if(e.modal&&lS.has(e.id)){r.add(e.id);continue}if(!(e.condition&&!e.condition())&&dS(a,e.center,e.size)){r.add(e.id),e.modal&&lS.add(e.id),o(e);break}}}}function c(){r.clear()}function l(){i=!0,n.length=0,r.clear()}return{addZone:a,update:s,reset:c,dispose:l,hasSeen:e=>r.has(e)}}function pS(e={}){let t={uTime:{value:0},uState:{value:0},uBeamCount:{value:e.beamCount||4},uScanSpeed:{value:3.5},uBoost:{value:e.boost??3.2}},n=new Je({uniforms:t,vertexShader:`
    varying vec2 vUv;
    varying vec3 vViewPosition;
    varying vec3 vNormal;

    void main() {
      vUv = uv;
      vNormal = normalize(normalMatrix * normal);

      vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
      vViewPosition = -mvPosition.xyz;

      gl_Position = projectionMatrix * mvPosition;
    }
  `,fragmentShader:`
    uniform float uTime;
    uniform int uState;
    uniform float uBeamCount;
    uniform float uScanSpeed;
    uniform float uBoost;

    varying vec2 vUv;
    varying vec3 vViewPosition;
    varying vec3 vNormal;

    void main() {
      // Create multi-beam grid lines along UV Y-axis
      float beamPattern = sin(vUv.y * uBeamCount * 6.28318);
      float beamCore = pow(abs(beamPattern), 8.0); // Sharp plasma core beam

      // Moving scanline energy pulses along UV X-axis
      float effectiveSpeed = (uState == 2) ? uScanSpeed * 2.8 : ((uState == 1) ? 1.0 : uScanSpeed);
      float scanline = sin(vUv.x * 25.0 - uTime * effectiveSpeed);
      scanline = smoothstep(0.2, 0.95, scanline);

      // Edge fading for plasma beam volume
      vec3 viewDir = normalize(vViewPosition);
      vec3 normal = normalize(vNormal);
      float fresnel = pow(1.0 - max(0.0, dot(viewDir, normal)), 1.5);

      vec3 coreColor;
      vec3 glowColor;
      float baseOpacity;

      if (uState == 1) {
        // Disabled State: Soft translucent green/emerald pulse
        float pulse = 0.3 + 0.2 * sin(uTime * 2.0);
        coreColor = vec3(0.06, 0.72, 0.51); // Emerald #10b981
        glowColor = vec3(0.02, 0.4, 0.25);
        baseOpacity = pulse * 0.3;
      } else if (uState == 2) {
        // Alarm State: High-intensity flashing crimson & amber
        float flash = step(0.5, sin(uTime * 14.0));
        coreColor = mix(vec3(0.94, 0.27, 0.27), vec3(0.98, 0.6, 0.07), flash); // #ef4444 to #f59e0b
        glowColor = vec3(0.86, 0.15, 0.15);
        baseOpacity = 0.95 + 0.1 * sin(uTime * 20.0);
      } else {
        // Normal Active State: Vibrant security red beam (#ef4444)
        coreColor = vec3(0.94, 0.27, 0.27);
        glowColor = vec3(0.7, 0.08, 0.08);
        baseOpacity = 0.85;
      }

      vec3 finalColor = mix(glowColor, coreColor, beamCore) + coreColor * scanline * 0.4 + glowColor * fresnel;
      float alpha = clamp(beamCore * baseOpacity + fresnel * 0.4 + scanline * 0.15, 0.05, 1.0);

      if (uState == 1 && beamCore < 0.2) {
        alpha *= 0.2; // Fade background volume heavily when disabled
      }

      if (uState != 1) finalColor *= uBoost;
      gl_FragColor = vec4(finalColor, alpha);
    }
  `,transparent:!0,side:2,depthWrite:!1,blending:2});return n.customUniforms=t,n}function mS(e,t,n,r=.55){if(!n.length)return null;let i=new Float32Array(n.length*12),a=new Float32Array(n.length*8),o=[];n.forEach((e,t)=>{for(let n=0;n<4;n+=1)i.set([e.x,e.y,e.z],t*12+n*3);a.set([0,0,1,0,1,1,0,1],t*8),o.push(t*4,t*4+1,t*4+2,t*4,t*4+2,t*4+3)});let s=new We;s.setAttribute(`position`,new Rt(i,3)),s.setAttribute(`uv`,new Rt(a,2)),s.setIndex(o),s.boundingSphere=new Pt(new R,1e4);let c=t.customUniforms,l=new Je({uniforms:{uTime:c.uTime,uState:c.uState,uSize:{value:r}},vertexShader:`
      uniform float uSize;
      varying vec2 vCorner;
      void main() {
        vCorner = uv - 0.5;
        vec4 mv = modelViewMatrix * vec4(position, 1.0);
        mv.xy += vCorner * uSize;
        gl_Position = projectionMatrix * mv;
      }
    `,fragmentShader:`
      uniform float uTime;
      uniform int uState;
      varying vec2 vCorner;
      void main() {
        float r = length(vCorner) * 2.0;
        if (r >= 1.0) discard;
        float glow = pow(1.0 - r, 2.4);
        vec3 color = vec3(1.0, 0.16, 0.1) * 2.6;
        if (uState == 1) color = vec3(0.05, 0.5, 0.3) * 0.35;
        if (uState == 2) color *= 0.7 + 0.6 * step(0.5, sin(uTime * 14.0));
        gl_FragColor = vec4(color * glow, glow);
      }
    `,transparent:!0,depthWrite:!1,blending:2}),u=new z(s,l);return u.name=`laser-glow`,u.renderOrder=3,u.userData.decor=!0,u.userData.noInteractionBlocker=!0,u.userData.noCameraCollision=!0,e.add(u),u}var hS=null;function gS(e){if(hS&&hS.sampleRate===e.sampleRate)return hS;hS=e.createBuffer(1,e.sampleRate,e.sampleRate);let t=hS.getChannelData(0);for(let e=0;e<t.length;e+=1)t[e]=Math.random()*2-1;return hS}function _S(e,t,{at:n,duration:r,frequency:i,q:a=1,gain:o,type:s=`lowpass`}){let c=e.createBufferSource();c.buffer=gS(e);let l=e.createBiquadFilter();l.type=s,l.frequency.value=i,l.Q.value=a;let u=e.createGain();return u.gain.setValueAtTime(0,n),u.gain.linearRampToValueAtTime(o,n+.008),u.gain.exponentialRampToValueAtTime(1e-4,n+r),c.connect(l).connect(u).connect(t),c.start(n,Math.random()*.5),c.stop(n+r+.05),{filter:l,env:u}}function vS(e=.5){let t=Lc(),n=Rc();if(!t||!n||t.state!==`running`)return;let r=t.createGain();r.gain.value=e,r.connect(n);let i=t.currentTime+.02,a=t.createOscillator();a.type=`sine`,a.frequency.setValueAtTime(110,i),a.frequency.exponentialRampToValueAtTime(42,i+.18);let o=t.createGain();o.gain.setValueAtTime(.9,i),o.gain.exponentialRampToValueAtTime(1e-4,i+.22),a.connect(o).connect(r),a.start(i),a.stop(i+.25),_S(t,r,{at:i,duration:.09,frequency:900,gain:.6});for(let e=0;e<3;e+=1)_S(t,r,{at:i+.14+e*.07,duration:.03,frequency:2600,q:4,gain:.28,type:`bandpass`});let s=_S(t,r,{at:i+.3,duration:.6,frequency:380,q:3,gain:.32,type:`bandpass`});s.filter.frequency.setValueAtTime(320,i+.3),s.filter.frequency.linearRampToValueAtTime(720,i+.85),setTimeout(()=>r.disconnect(),1400)}function yS(e,t){let n=e.attributes.uv;for(let e=0;e<n.count;e+=1)n.setX(e,n.getX(e)*t);return e}var bS=null;function xS(){if(bS)return bS;let e=document.createElement(`canvas`);e.width=64,e.height=64;let t=e.getContext(`2d`),n=t.createRadialGradient(32,32,0,32,32,32);return n.addColorStop(0,`rgba(255,255,255,0.9)`),n.addColorStop(.5,`rgba(255,255,255,0.35)`),n.addColorStop(1,`rgba(255,255,255,0)`),t.fillStyle=n,t.fillRect(0,0,64,64),bS=new mt(e),bS}function SS(e,t,n){let r=new Float32Array(144),i=new Float32Array(144),a=new We;a.setAttribute(`position`,new Rt(r,3)),a.boundingSphere=new Pt(new R(0,.6,0),t+2);let o=new Ae({map:xS(),color:9208436,size:.32,transparent:!0,opacity:0,depthWrite:!1}),s=new je(a,o);s.name=`door-dust`,s.userData.decor=!0,s.userData.noInteractionBlocker=!0,s.userData.noCameraCollision=!0,e.add(s);let c=1.6,l=c;function u(){for(let e=0;e<48;e+=1){let a=(Math.random()-.5)*t,o=(Math.random()<.5?-1:1)*(.15+Math.random()*.2),s=(Math.random()-.5)*.4,c=Math.sign(o)*(.35+Math.random()*.6),l=.15+Math.random()*.45,[u,d,f,p]=n===`x`?[o,a,c,s]:[a,o,s,c];r.set([u,.05+Math.random()*.15,d],e*3),i.set([f,l,p],e*3)}a.attributes.position.needsUpdate=!0,l=0}function d(e){if(l>=c)return;l+=e;for(let t=0;t<48;t+=1)r[t*3]+=i[t*3]*e,r[t*3+1]+=i[t*3+1]*e,r[t*3+2]+=i[t*3+2]*e,i[t*3]*=1-1.6*e,i[t*3+1]*=1-1.2*e,i[t*3+2]*=1-1.6*e;a.attributes.position.needsUpdate=!0;let t=l/c;o.opacity=.55*Math.min(1,t*8)*(1-t),o.size=.32+t*.5}return{start:u,update:d}}function CS(e,t,n){let r=pg(),i=wg();for(let{x:e,y:t,z:a,yaw:o}of n)i_(i,r,Z(e,t,a,o));i.build(e,`laser-emitters`),mS(e,t,n.map(({x:e,y:t,z:n,yaw:r})=>new R(e+Math.sin(r)*.1,t+.02,n+Math.cos(r)*.1)))}function wS({start:e,end:t,width:n=6,height:r=5.2,wallThickness:i=.24,floorMaterial:a,wallMaterial:o,ceilingMaterial:s}={}){if(!e||!t)throw Error(`passage-components: corridor needs start/end`);let c=new U;c.name=`corridor-shell`;let l=[],u=t.x-e.x,d=t.z-e.z,f=Math.abs(u)>Math.abs(d),p=Math.abs(f?u:d),m=(e.x+t.x)/2,h=(e.z+t.z)/2,g=e.y??0,_=a??new x({color:6117729,roughness:.82}),v=o??new x({color:7300703,roughness:.9}),y=s??v,b=new z(new Ot(f?p:n,f?n:p),_);b.rotation.x=-Math.PI/2,b.position.set(m,g+.01,h),b.receiveShadow=!0,c.add(b);let S=new z(new K(f?p:n,.2,f?n:p),y);if(S.position.set(m,g+r,h),S.receiveShadow=!0,c.add(S),f)for(let a of[-1,1]){let o=h+a*n/2,s=new z(new K(p,r,i),v);s.position.set(m,g+r/2,o),s.castShadow=!0,s.receiveShadow=!0,c.add(s),l.push({minX:Math.min(e.x,t.x),maxX:Math.max(e.x,t.x),minZ:o-i/2-.05,maxZ:o+i/2+.05})}else for(let a of[-1,1]){let o=m+a*n/2,s=new z(new K(i,r,p),v);s.position.set(o,g+r/2,h),s.castShadow=!0,s.receiveShadow=!0,c.add(s),l.push({minX:o-i/2-.05,maxX:o+i/2+.05,minZ:Math.min(e.z,t.z),maxZ:Math.max(e.z,t.z)})}return{group:c,colliders:l}}function TS({center:e,sizeX:t=4.8,sizeZ:n=4.8,height:r=5,wallThickness:i=.24,openings:a={},floorMaterial:o,wallMaterial:s,ceilingMaterial:c}={}){if(!e)throw Error(`passage-components: room needs center`);if(t<=0||n<=0||r<=0)throw Error(`passage-components: room dimensions must be positive`);let l=new U;l.name=`room-shell`;let u=[],d=e.y??0,f=o??new x({color:6117729,roughness:.82}),p=s??new x({color:7300703,roughness:.9}),m=c??p,h=new z(new Ot(t,n),f);h.name=`room-floor`,h.rotation.x=-Math.PI/2,h.position.set(e.x,d+.01,e.z),h.receiveShadow=!0,l.add(h);let g=new z(new K(t,.2,n),m);g.name=`room-ceiling`,g.position.set(e.x,d+r,e.z),g.receiveShadow=!0,l.add(g);function _(e,t){let n=a[e];if(!n)return null;if(n===!0)return{width:t,height:r,offset:0};let i=B.clamp(n.width??t,0,t),o=B.clamp(n.height??r,0,r),s=Math.max(0,(t-i)/2);return{width:i,height:o,offset:B.clamp(n.offset??0,-s,s)}}function v(a,o,s){let c=s-o;if(c<=.01)return;let f,m;if(a===`minX`||a===`maxX`){let n=e.x+(a===`minX`?-t/2:t/2),l=e.z+(o+s)/2;f=new z(new K(i,r,c),p),f.position.set(n,d+r/2,l),m={minX:n-i/2-.05,maxX:n+i/2+.05,minZ:e.z+o,maxZ:e.z+s}}else{let t=e.z+(a===`minZ`?-n/2:n/2),l=e.x+(o+s)/2;f=new z(new K(c,r,i),p),f.position.set(l,d+r/2,t),m={minX:e.x+o,maxX:e.x+s,minZ:t-i/2-.05,maxZ:t+i/2+.05}}f.name=`room-wall-${a}`,f.castShadow=!0,f.receiveShadow=!0,l.add(f),u.push(m)}function y(a,o,s){if(!o||o.height>=r-.01||o.width<=.01)return;let c=r-o.height,u;if(a===`minX`||a===`maxX`){let n=e.x+(a===`minX`?-t/2:t/2);u=new z(new K(i,c,o.width),p),u.position.set(n,d+o.height+c/2,e.z+o.offset)}else{let t=e.z+(a===`minZ`?-n/2:n/2);u=new z(new K(o.width,c,i),p),u.position.set(e.x+o.offset,d+o.height+c/2,t)}u.name=`room-lintel-${a}`,u.castShadow=!0,u.receiveShadow=!0,l.add(u)}for(let e of[`minX`,`maxX`,`minZ`,`maxZ`]){let r=e===`minX`||e===`maxX`?n:t,i=_(e,r);if(!i){v(e,-r/2,r/2);continue}let a=i.offset-i.width/2,o=i.offset+i.width/2;v(e,-r/2,a),v(e,o,r/2),y(e,i,r)}return{group:l,colliders:u}}function ES({position:e,width:t=3.4,height:n=2.8,thickness:r=.28,axis:i=`x`}={}){let a=new U;a.name=`puzzle-door`,a.position.copy(e);let o=pg(),s=new x({color:2754054,emissive:16722458,emissiveIntensity:2.6,roughness:.25}),c=new U;i===`x`&&(c.rotation.y=Math.PI/2),a.add(c);let l=new z(new K(t,n,r),o.steel);l.position.y=n/2,l.castShadow=!0,l.receiveShadow=!0,c.add(l);let u=wg(),d=r/2;for(let e of[-1,1]){let r=e*(d+.012);for(let e of[-n/2+.03,n/2-.03])u.add(o.steelFrame,Q(t,.06,.03,0,e,r));for(let e of[-t/2+.03,t/2-.03])u.add(o.steelFrame,Q(.06,n,.03,e,0,r));u.add(o.brass,Q(t-.12,.03,.03,0,-n/2+.3,r));let i=Q(t-.12,.22,.02,0,-n/2+.17,e*(d+.006));yS(i,(t-.12)/1.76),u.add(o.hazard,i);let a=new Ot(Math.min(t*.7,2.2),Math.min(t*.7,2.2)/8);e<0&&a.rotateY(Math.PI),a.translate(0,.05,e*(d+.004)),u.add(o.stencil,a);let s=new Ot(.8,.2);e<0&&s.rotateY(Math.PI),s.translate(0,n/2-.42,e*(d+.004)),u.add(o.security,s);let c=()=>new He(.018,6,2,0,Math.PI*2,0,Math.PI/2).rotateX(Math.PI/2),l=e>0?0:Math.PI;for(let r=-t/2+.12;r<=t/2-.1;r+=.16)for(let t of[-n/2+.03,n/2-.03,-n/2+.3])u.instance(`rivet`,c,o.steelFrame,Z(r,t,e*(d+.028),l));for(let r=-n/2+.2;r<=n/2-.15;r+=.16)for(let n of[-t/2+.03,t/2-.03])u.instance(`rivet`,c,o.steelFrame,Z(n,r,e*(d+.028),l))}u.build(l,`door-slab`,{decor:!0});let f=new z(new K(t*.5,.04,r+.03),s);f.position.y=n-.12,c.add(f);let m=wg(),h=r+.3;for(let e of[-1,1])m.add(o.steelFrame,Q(.22,n+.5,h,e*(t/2+.11),(n+.5)/2,0),null,!0);m.add(o.steelFrame,Q(t+.44,.42,h,0,n+.21,0),null,!0),m.add(o.iron,Q(t,.025,r+.08,0,.012,0));for(let e of[-1,1]){for(let r of[-t/2-.11,t/2+.11])for(let t of[.22,n+.21]){let n=new p(.04,.04,.03,6).rotateX(Math.PI/2);n.translate(r,t,e*(h/2+.015)),m.add(o.brass,n)}let r=new He(.07,12,8,0,Math.PI*2,0,Math.PI/2).rotateX(e*Math.PI/2);r.translate(t/2+.11,n+.21,h/2*e),m.add(s,r);let i=new Tt(.075,.01,4,12);i.translate(t/2+.11,n+.21,e*(h/2+.03)),m.add(o.iron,i)}m.build(c,`door-housing`);let g=SS(a,t,i),_=i===`x`?{minX:e.x-r/2-.08,maxX:e.x+r/2+.08,minZ:e.z-t/2,maxZ:e.z+t/2,enabled:!0}:{minX:e.x-t/2,maxX:e.x+t/2,minZ:e.z-r/2-.08,maxZ:e.z+r/2+.08,enabled:!0},v=!1,y=0;function b(){v||(v=!0,_.enabled=!1,s.color.setHex(408100),s.emissive.setHex(2285706),vS(),g.start())}function S(e){if(g.update(e),!v||y>=1)return;y=Math.min(1,y+e*1.65);let t=1-(1-y)**3;l.position.y=n/2+t*(n+.35),f.position.y=n-.12+t*(n+.35)}return{group:a,collider:_,unlock:b,update:S,isUnlocked:()=>v}}function DS({position:e,beamLength:t=5.1,beamHeight:n=.58,travelAxis:r=`x`,travelDistance:i=1.5,speed:a=1.25,hitHalfThickness:o=.22,onHit:s}={}){let c=new U;c.name=`sweeping-laser`,c.position.copy(e);let l=pS({beamCount:1}),u=new z(new p(.018,.018,t,10),l);u.rotation.x=Math.PI/2,u.position.y=n,c.add(u),CS(c,l,[-1,1].map(e=>({x:0,y:n,z:e*t/2,yaw:e>0?Math.PI:0})));let d=0,f=0;function m(u,p){d+=u,f=Math.max(0,f-u),l.customUniforms&&(l.customUniforms.uTime.value+=u);let m=Math.sin(d*a)*i;if(r===`z`?c.position.z=e.z+m:c.position.x=e.x+m,!p||typeof s!=`function`)return;let h=Math.abs(p.z-c.position.z)<=t/2,g=Math.abs(p.x-c.position.x)<=o,_=c.position.y+n,v=p.y<=_+.12;h&&g&&v&&f<=0&&(f=.75,s())}return{group:c,update:m,material:l}}function OS(e,{activeDuration:t=2.4,inactiveDuration:n=1.35,startActive:r=!0}={}){let i=r,a=0;e.setActive(i);function o(r){a+=r,!(a<(i?t:n))&&(a=0,i=!i,e.setActive(i))}return{update:o,isActive:()=>i}}function kS({start:e,end:t,width:n=4.2,rowCount:r=5,floorY:i,hitHalfDepth:a=.2,clearanceHeight:o=.44,onHit:s}={}){if(!e||!t)throw Error(`passage-components: laser floor needs start/end`);let c=new U;c.name=`laser-floor-course`;let l=Number.isFinite(i)?i:e.y??0,u=t.x-e.x,d=t.z-e.z,f=Math.abs(u)>=Math.abs(d),m=Math.abs(f?u:d),h=Math.sign(f?u||1:d||1),g=pS({beamCount:1}),_=new x({color:2106924,roughness:.72,metalness:.42}),v=[],y=[],b=Math.min(1.05,m*.12),S=Math.max(.5,m-b*2),C=r>1?S/(r-1):0;for(let t=0;t<r;t++){let r=b+t*C,i=f?e.x+h*r:e.x,a=f?e.z:e.z+h*r;for(let e of[-.07,.07]){let t=new z(new p(.024,.024,n-.34,14),g);f?(t.rotation.x=Math.PI/2,t.position.set(i+e,l+.09,a)):(t.rotation.z=Math.PI/2,t.position.set(i,l+.09,a+e)),c.add(t)}for(let e of[-1,1])f?v.push({x:i,y:l+.09,z:a+e*(n/2-.08),yaw:e>0?Math.PI:0}):v.push({x:i+e*(n/2-.08),y:l+.09,z:a,yaw:e>0?-Math.PI/2:Math.PI/2});y.push({x:i,z:a})}CS(c,g,v);let w=r+1,T=m/w;for(let t=0;t<w;t++){let r=T*(t+.5),i=f?e.x+h*r:e.x,a=f?e.z:e.z+h*r,o=f?new K(Math.max(.55,T*.62),.035,n-.55):new K(n-.55,.035,Math.max(.55,T*.62)),s=new z(o,_);s.position.set(i,l+.025,a),s.receiveShadow=!0,c.add(s)}let E=!0,D=0;function O(t,r){D=Math.max(0,D-t),g.customUniforms&&(g.customUniforms.uTime.value+=t,g.customUniforms.uState.value=+!E),!(!E||!r||typeof s!=`function`||D>0)&&(Math.abs(f?r.z-e.z:r.x-e.x)>n/2||r.y>l+o||y.some(e=>f?Math.abs(r.x-e.x)<=a:Math.abs(r.z-e.z)<=a)&&(D=.9,s()))}function k(e){E=!!e}function A(){g.dispose(),_.dispose()}return{group:c,update:O,setActive:k,isActive:()=>E,dispose:A,rows:y}}var AS=-27.38,jS=-21.62,MS=-24.5,NS=5.1;function PS(e,t,n,r){return e.multiply(new h().makeScale(t,n,r))}function FS(e,t){let n=pg(),r=wg(),i=wg(),a=(e,n,r,i)=>t.push({minX:e,maxX:n,minZ:r,maxZ:i}),o=-26.98,s=(e,t)=>{t_(r,n,Z(e,0,t,e*1.7),.85),a(e-.24,e+.24,t-.24,t+.24)},c=(e,t,i,o)=>{Ng(r,n,PS(Z(e,0,t,i),1,1,o/2)),a(e-o/2,e+o/2,t-.42,t+.42)};s(-160.62,o),c(-159.6,-26.93,-Math.PI/2,1.4),Ig(r,n,Z(-158.45,0,o),.78,.4,.5),Hg(r,n,Z(-158.42,.4,-26.96,.06),.62,.17,.4,{lying:!0}),Hg(r,n,Z(-158.48,.57,o,-.14),.5,.15,.34,{lying:!0,material:n.coatTan}),a(-158.85,-158.05,AS,-26.7),c(-157.3,-26.93,-Math.PI/2,1.4),Ug(r,n,Z(-156.15,0,-27.36)),a(-156.51,-155.79,AS,-26.9),Ig(r,n,Z(-155.35,0,o,.04),.72,.44,.52),Hg(r,n,Z(-155.33,.44,-26.95,-.1),.56,.16,.38,{lying:!0,material:n.coatTan}),Hg(r,n,Z(-155.38,.6,-27,.12),.46,.34,.15),a(-155.72,-154.98,AS,-26.7),s(-154.68,o),Wg(r,n,Z(-154.1,0,-27.13)),a(-154.29,-153.91,AS,-26.939999999999998),Lg(r,n,Z(-159.95,0,-22.220000000000002,Math.PI/2)),a(-160.85,-159.05,-22.8,jS),Vg(r,n,Z(-157.5,0,jS,Math.PI),2.9,3),a(-159.02,-155.98,-22.26,jS),s(-155.62,-22.02),c(-154.45,-22.07,Math.PI/2,1.3),Rg(i,n,Z(-159.6,2.35,-27.375,0),0,.7,1),Rg(i,n,Z(-156.15,2.5,-27.375,0),2,.62,.9),Rg(i,n,Z(-159.95,2.4,-21.625,Math.PI),3,.7,1),Rg(i,n,Z(-154.2,2.4,-21.625,Math.PI),4,.62,.9),Rg(i,n,Z(-161.02,2,-26.9,Math.PI/2),5,.55,.8),Rg(i,n,Z(-161.02,2,-22.1,Math.PI/2),1,.55,.8),zg(i,n,Z(-157.3,3.2,AS,0),.55),Gg(i,n,Z(-159.6,3.45,AS,0),n.sign(`TO PLATFORMS  →`),1.7,.34);for(let e of[-160.4,-157.7,-155])Eg(i,n,Z(e,NS,MS),1.2);Qg(i,n,Z(-153.95,4.1,MS,-Math.PI/2),2.4,.9,.55),r.build(e,`arrival-hall-kit`),i.build(e,`arrival-hall-decor`,{decor:!0})}var IS=1.1,LS=.4,RS=new R(0,-1,0),zS=new R(0,1,0),BS=new Ve,VS=new R,HS=new n,US=new R,WS={tile:e=>({panel:e.tile,panelTile:.6,trim:e.greenDark,cornice:e.plaster}),wood:e=>({panel:e.wainscot,panelTile:1.4,trim:e.wood,cornice:e.plaster})};function GS(e){e.getWorldQuaternion(HS);let t=new R(1,0,0).applyQuaternion(HS);return new R(0,1,0).applyQuaternion(HS).y>.999&&(Math.abs(t.x)>.999||Math.abs(t.z)>.999)}function KS(e,{walls:t,finish:n=`tile`,name:r=`wall-dressing`,skip:i=()=>!1,clear:a=[]}={}){let o=(e,t)=>a.some(n=>e>=n.minX&&e<=n.maxX&&t>=n.minZ&&t<=n.maxZ),s=pg(),c=WS[n](s),l=wg(),u=new we;e.updateMatrixWorld(!0);let d=[],f=[];e.traverse(e=>{if(!e.isMesh||e.isInstancedMesh)return;for(let t=e;t;t=t.parent)if(!t.visible||t.userData.decor)return;if(d.push(e),!t.includes(e.material)||i(e))return;let n=e.geometry.type;(n===`BoxGeometry`||n===`PlaneGeometry`)&&GS(e)&&f.push(e)});function p(e,t,n,r){return u.set(e,t),u.far=n,u.intersectObjects(d,!1).some(e=>e.face&&r(e))}function m(e,t,n,r){let i=new R(e,n+1,t);return p(i,RS,1.3,e=>Math.abs(e.point.y-n)<.15&&US.copy(e.face.normal).transformDirection(e.object.matrixWorld).y>.6)?p(i,zS,r-n+.2,e=>e.point.y>r-.45&&US.copy(e.face.normal).transformDirection(e.object.matrixWorld).y<-.6):!1}let h=0;for(let e of f){BS.setFromObject(e).getSize(VS);let t=BS.min.y,n=BS.max.y;if(VS.y<2.4)continue;let r=VS.x>=VS.z,i=r?VS.x:VS.z,a=r?VS.z:VS.x;if(i<.6||a>.5)continue;let s=r?BS.min.x:BS.min.z,c=e.geometry.type===`PlaneGeometry`,l=[-1,1];c&&(e.getWorldQuaternion(HS),US.set(0,0,1).applyQuaternion(HS),l=[Math.sign(r?US.z:US.x)]);for(let e of l){let a=e>0?r?BS.max.z:BS.max.x:r?BS.min.z:BS.min.x,l=Math.max(1,Math.round(i/LS)),u=[];for(let c=0;c<l;c+=1){let d=s+(c+.5)*(i/l),f=a+e*.4;(r?o(d,a):o(a,d))?u.push(!1):u.push(r?m(d,f,t,n):m(f,d,t,n))}for(let o=0;o<l;){if(!u[o]){o+=1;continue}let d=o;for(;d+1<l&&u[d+1];)d+=1;_(s+o*i/l,s+(d+1)*i/l,a,e,t,n,r,c),h+=1,o=d+1}}}function g(e,t,n,r,i,a,o,s,c,u,d,f){let p=n-t,m=(t+n)/2;if(f){let t=vg(new Ot(p,s),d||1);t.rotateY(a?i>0?0:Math.PI:i>0?Math.PI/2:-Math.PI/2);let n=r+i*(u+c);t.translate(a?m:n,o,a?n:m),l.add(e,t);return}let h=r+i*(u+c/2);l.add(e,a?Q(p,s,c,m,o,h,d):Q(c,s,p,h,o,m,d))}function _(e,t,n,r,i,a,o,s){let l=a-.1;g(c.panel,e,t,n,r,o,i+IS/2,IS,.025,0,c.panelTile,s),g(c.trim,e,t,n,r,o,i+.08,.16,.045,0,.5,s),g(c.trim,e,t,n,r,o,i+IS+.02,.07,.055,0,.5,s),g(c.trim,e,t,n,r,o,i+IS-.03,.03,.035,0,.5,s),g(c.cornice,e,t,n,r,o,l-.09,.18,.05,0,1.5,s),g(c.cornice,e,t,n,r,o,l-.04,.08,.1,0,1.5,s),g(c.trim,e,t,n,r,o,l-.2,.04,.06,0,.5,s)}let v=l.build(e,r,{decor:!0});return{faces:h,meshes:v}}var qS=-66,JS=e=>e+qS,YS=new R(JS(-90.5),0,-24.5),XS={minX:JS(-93.2),maxX:JS(-59.2),minZ:-40.4,maxZ:-21.2},ZS=-24.5,QS=6,$S=0,eC=-4,tC=5.2,nC=JS(-93),rC=JS(-66),iC=JS(-60),aC=JS(-63),oC=-27.5,sC=-36.6,cC=-40,lC=-36.6;function uC(e,t,{size:n,position:r,material:i,collider:a=!0,colliderInset:o=0,name:s=``}){let c=new z(new K(n.x,n.y,n.z),i);if(c.position.copy(r),c.name=s,c.castShadow=!0,c.receiveShadow=!0,e.add(c),a){let e=Math.max(0,o);t.push({minX:r.x-n.x/2+e,maxX:r.x+n.x/2-e,minZ:r.z-n.z/2+e,maxZ:r.z+n.z/2-e})}return c}function dC(e,t,n,r,i,a=``){let o=n.clone().sub(t),s=o.length();if(s<.001)return null;let c=new z(new p(r,r,s,8),i);return c.name=a,c.position.copy(t).add(n).multiplyScalar(.5),c.quaternion.setFromUnitVectors(new R(0,1,0),o.normalize()),c.castShadow=!0,e.add(c),c}function fC(e,t,n,{railHeight:r=.95,inset:i=.16,postSpacing:a=1.15}={}){let o=t.end.x-t.start.x,s=t.end.z-t.start.z,c=Math.hypot(o,s);if(c<.001)return;let l=o/c,u=s/c,d=-l,f=Math.max(.2,t.width/2-i),p=Math.max(2,Math.ceil(t.runLength/a));for(let i of[-1,1]){let a=u*i*f,o=d*i*f;dC(e,t.start.clone().add(new R(a,r,o)),t.end.clone().add(new R(a,r,o)),.035,n,`tutorial-stair-rail-${i}`);for(let s=0;s<=p;s++){let c=s/p,l=new R(B.lerp(t.start.x,t.end.x,c)+a,B.lerp(t.start.y,t.end.y,c)+.04,B.lerp(t.start.z,t.end.z,c)+o),u=l.clone();u.y+=r-.04,dC(e,l,u,.025,n,`tutorial-stair-post-${i}-${s}`)}}}function pC(e,t){let n;return n=e===0?new G(.13,20):e===1?new Ot(.23,.23):new G(.15,3),new z(n,t)}function mC({group:e,interaction:t,hud:n,door:r}){let i=[],a=[`circle`,`square`,`triangle`],o=[2,0,1],s=[0,1,2],c=new U;c.name=`tutorial-symbol-puzzle`,c.position.set(JS(-69.3),1.45,-21.72),c.rotation.y=Math.PI,e.add(c);let l=new x({color:2239284,roughness:.42,metalness:.72}),u=new x({color:11570495,roughness:.3,metalness:.88}),d=[new x({color:3718648,emissive:805486,emissiveIntensity:1.6}),new x({color:16096779,emissive:7877903,emissiveIntensity:1.5}),new x({color:12616956,emissive:5774471,emissiveIntensity:1.5})],f=new z(new K(2.1,.85,.18),l);c.add(f);let p=new x({color:15680580,emissive:8330525,emissiveIntensity:2}),m=new z(new K(1.7,.07,.04),p);m.position.set(0,.33,.115),c.add(m);let h=[];for(let e=0;e<3;e++){let t=new U;t.name=`symbol-dial-${e+1}`,t.position.set(-.62+e*.62,-.05,.12);let n=new z(new Tt(.2,.035,8,20),u);t.add(n);let r=[];for(let n=0;n<3;n++){let i=pC(n,d[n]);i.position.z=.025,i.visible=n===s[e],t.add(i),r.push(i)}t.userData.variants=r,c.add(t),h.push(t)}let g=new U;g.name=`symbol-clue-plaque`,g.position.set(JS(-70.2),1.55,-27.42),e.add(g);let _=new z(new K(2.2,.8,.13),l);g.add(_);for(let e=0;e<3;e++){let t=pC(o[e],d[o[e]]);t.position.set(-.62+e*.62,0,.075),g.add(t)}let v=!1;function y(e){h[e].userData.variants.forEach((t,n)=>{t.visible=n===s[e]})}function b(){v||(v=s.every((e,t)=>e===o[t]),v&&(p.color.setHex(1096065),p.emissive.setHex(292951),r.unlock(),t?.flashPrompt?.(`Cipher accepted — door unlocked`),n?.showToast?.(`Cipher accepted. Turn left beyond the door and take the stairs down.`,3200)))}return h.forEach((e,n)=>{let r=t.register(e,{prompt:`Rotate cipher dial ${n+1}`,range:2.4,onInteract:()=>{v||(s[n]=(s[n]+1)%a.length,y(n),t?.flashPrompt?.(`Dial ${n+1}: ${a[s[n]]}`),b())}});i.push(r)}),{dispose(){i.forEach(e=>e())},isSolved:()=>v}}function hC({interaction:e,hud:t,player:n,respawn:r,connectedToPassage0:i=!1,connectedToPassage2:a=!1}={}){let o=new U;o.name=`passage-tutorial`;let s=[],c={camera:null,timedGrid:null,timedController:null},l=vh({repeat:[16,3],base:8748147,vein:5064515,grout:3354413}),u=Ch({repeat:[12,3],base:6643030,roughness:.9});ky(o,{name:`tutorial-exterior`,minX:nC,maxX:iC,minZ:ZS-QS/2,maxZ:-21.5,floorY:$S,wallHeight:tC,skipWest:!0,skipEast:!0,gaps:[{side:`minZ`,from:aC-1.6,to:aC+1.6}]});let d=Ch({repeat:[12,2],base:4012604,roughness:.96}),f=bh({repeat:[8,1],base:2897472,roughness:.48,metalness:.72});new x({color:11570495,roughness:.3,metalness:.9});let p=new x({color:11570495,emissive:3088648,emissiveIntensity:.35,roughness:.3,metalness:.9}),m=wS({start:new R(nC,$S,ZS),end:new R(rC,$S,ZS),width:QS,height:tC,floorMaterial:l,wallMaterial:u,ceilingMaterial:d});o.add(m.group),s.push(...m.colliders),i||uC(o,s,{size:new R(.25,tC,QS),position:new R(nC,tC/2,ZS),material:u});let g=pg(),_=wg(),v=wg(),y=new h().makeRotationX(Math.PI);for(let e of[-89,-84,-79,-74,-69].map(JS)){e!==JS(-89)&&Dg(v,g,Z(e,5.1000000000000005,ZS).multiply(y));let t=new j(16763274,15,9,2);t.position.set(e,4.55,ZS),o.add(t)}let b=DS({position:new R(JS(-86),0,ZS),beamLength:5.1,beamHeight:.56,travelAxis:`x`,travelDistance:1.25,speed:1.3,onHit:()=>{t?.showToast?.(`Low laser tripped — jump over the moving beam.`,1500),r?.fail?.(`laser`)}});o.add(b.group);for(let[e,t,n]of[[new R(1.25,1.35,.85),new R(JS(-81.3),.675,-26.25),`camera-cover-cabinet-a`],[new R(1.1,1.2,.85),new R(JS(-79.7),.6,-22.8),`camera-cover-cabinet-b`]])uC(o,s,{size:e,position:t,material:g.crate,colliderInset:.06,name:n}),Fg(_,g,Z(t.x,0,t.z),e.x,e.y,e.z);let S=3.4;for(let e of[-1,1]){let t=ZS+e*2.35;uC(o,s,{size:new R(.25,tC,1.3),position:new R(rC,tC/2,t),material:u})}uC(o,s,{size:new R(.25,2.4000000000000004,S),position:new R(rC,4,ZS),material:u,collider:!1});let C=ES({position:new R(rC,$S,ZS),width:S,height:2.8,axis:`x`});o.add(C.group),s.push(C.collider);let w=mC({group:o,interaction:e,hud:t,door:C}),T=(rC+iC)/2,E=ZS,D=iC-rC,O=QS,k=new z(new Ot(D,O),l);k.rotation.x=-Math.PI/2,k.position.set(T,.01,E),k.receiveShadow=!0,o.add(k);let A=new z(new K(D,.2,O),d);A.position.set(T,tC,E),o.add(A),uC(o,s,{size:new R(.25,tC,O),position:new R(iC,tC/2,E),material:u}),uC(o,s,{size:new R(D,tC,.25),position:new R(T,tC/2,-21.5),material:u});let ee=3.2,M=ZS-QS/2,N=(D-ee)/2;for(let e of[-1,1]){let t=aC+e*(ee/2+N/2);uC(o,s,{size:new R(N,tC,.25),position:new R(t,tC/2,M),material:u})}let P=new x({color:5460058,roughness:.82,metalness:.05}),te=bv({start:new R(aC,$S,oC),end:new R(aC,eC,sC),width:ee,steps:15,wallHeight:4.6,stepMaterial:P,wallMaterial:u,ceilingMaterial:d,addCeiling:!1});o.add(te.group);let F=new R(aC,4.6,-27.4),ne=new R(aC,.5999999999999996,-36.7),re=ne.clone().sub(F),I=new z(new K(3.62,.2,re.length()+.22),d);I.name=`tutorial-stair-continuous-roof`,I.position.copy(F).add(ne).multiplyScalar(.5),I.quaternion.setFromUnitVectors(new R(0,0,1),re.clone().normalize()),I.castShadow=!0,I.receiveShadow=!0,o.add(I);let L=new z(new K(3.24,.31666666666666665,.16),P);L.name=`tutorial-stair-upper-threshold-riser`,L.position.set(aC,$S-.26666666666666666/2,-27.555),L.castShadow=!0,L.receiveShadow=!0,o.add(L),uC(o,s,{size:new R(3.52,.6400000000000006,.28),position:new R(aC,4.88,-27.52),material:u,collider:!1,name:`tutorial-stair-upper-header`});for(let e of[-1,1]){let t=aC+e*1.6900000000000002;s.push({minX:t-.16,maxX:t+.16,minZ:sC,maxZ:oC})}fC(o,te,p);let ie=new x({color:2107696,roughness:.42,metalness:.82}),ae=new x({color:16768944,emissive:16754253,emissiveIntensity:1.2,roughness:.28,metalness:.12});function oe(e,t,n,r=5.1){let i=e.end.x-e.start.x,a=e.end.z-e.start.z,s=Math.hypot(i,a),c=i/s,l=a/s,u=l,d=-c,f=Math.atan2(c,l),p=B.lerp(e.start.y,e.end.y,t),m=B.lerp(e.start.x,e.end.x,t),h=B.lerp(e.start.z,e.end.z,t),g=e.width/2+.035,_=new U;_.position.set(m+u*n*g,p+1.62,h+d*n*g),_.rotation.y=f,o.add(_);let v=new z(new K(.13,.38,.46),ie);_.add(v);let y=new z(new K(.045,.23,.3),ae);y.position.x=-n*.085,_.add(y);let b=new j(16763014,r,5.8,2.25);b.position.set(m-u*n*.3,p+1.55,h-d*n*.3),o.add(b)}for(let[e,t]of[[.16,-1],[.48,1],[.8,-1]])oe(te,e,t,5.1);function se(e,t=5.4){let n=new z(new K(.85,.11,.34),ie);n.position.copy(e),o.add(n);let r=new z(new K(.61,.03,.2),ae);r.position.copy(e),r.position.y-=.07,o.add(r);let i=new j(16763014,t,6.2,2.25);i.position.copy(e),i.position.y-=.28,o.add(i)}se(new R(aC,4.72,-26.55),5.2),se(new R(aC,.7199999999999998,-37.5),5.4);let ce=-76.6/2,le=3.3999999999999986,ue=aC,de=new z(new Ot(6,le),l);de.rotation.x=-Math.PI/2,de.position.set(ue,-3.99,ce),de.receiveShadow=!0,o.add(de);let fe=new z(new K(6,.2,le),d);fe.position.set(ue,1.2000000000000002,ce),o.add(fe);for(let e of[-1,1]){let t=ue+e*2.3;uC(o,s,{size:new R(1.4,tC,.25),position:new R(t,-1.4,lC),material:u})}if(uC(o,s,{size:new R(.25,tC,le),position:new R(ue-3,-1.4,ce),material:u}),uC(o,s,{size:new R(6,tC,.25),position:new R(ue,-1.4,cC),material:u}),!a){let e=uC(o,s,{size:new R(.3,tC,le),position:new R(ue+3,-1.4,ce),material:f,name:`passage-2-stage-bulkhead`});e.userData.stageBoundary=!0}yg(o,[[l,g.concrete,3],[u,g.brick,.46],[d,g.ceiling,3]]),KS(o,{walls:[g.brick],finish:`tile`,name:`tutorial-wall-dressing`,clear:[{minX:JS(-83.5)-.7,maxX:JS(-83.5)+.7,minZ:-28,maxZ:-27}]}),FS(o,s),Ov(o,s);let pe=(e,t,n)=>new R(e,t,n),me=nC+.4,he=rC-.15;kg(v,g,pe(me,4.78,-27.22),pe(he,4.78,-27.22),.07,g.pipe,pe(0,0,-1)),kg(v,g,pe(me,4.5,-27.25),pe(he,4.5,-27.25),.045,g.copper,pe(0,0,-1)),kg(v,g,pe(me,4.9,-21.78),pe(he,4.9,-21.78),.055,g.pipe,pe(0,0,1));for(let[e,t,n,r]of[[4.78,-27.22,.07,g.pipe],[4.5,-27.25,.045,g.copper],[4.9,-21.78,.055,g.pipe]])v.add(r,xg(pe(me,e,t),pe(me,5.15,t),n,10));let ge=JS(-75),_e=-27.22;kg(v,g,pe(ge,4.78,_e),pe(ge,1.5,_e),.05,g.pipe,pe(0,0,-1)),v.add(g.iron,xg(pe(ge,1.95,_e),pe(ge,1.95,-27.06),.015,6));let ve=new Tt(.15,.018,6,20);ve.translate(ge,1.95,-27.06),v.add(g.green,ve),v.add(g.green,Q(.3,.025,.02,ge,1.95,-27.06)),v.add(g.green,Q(.025,.3,.02,ge,1.95,-27.06));let ye=[...[-155,-146,-139.5,-133.5].map(e=>({x:e,y:2.6,z:-27.08,yaw:-Math.PI/2})),...[-155,-149.5,-143.6,-137.6].map(e=>({x:e,y:2.6,z:-21.92,yaw:Math.PI/2}))],be=new U;be.name=`tutorial-lanterns`,Cv(be,ye,{iron:g.iron,lantern:g.lantern}),D_(be,ye.map(({x:e,z:t,yaw:n})=>({x:e,y:2.75,z:t<ZS?-27.36:-21.64,yaw:n,width:1.9,height:2.3,strength:.26})),null,16752210,`tutorial-wall-glow`),be.traverse(e=>{e.userData.decor=!0,e.userData.noInteractionBlocker=!0,e.userData.noCameraCollision=!0}),o.add(be),$g(v,g,Z(JS(-83.5),0,-27.3,0),1.2,2.3),e_(v,g,Z(JS(-73.6),2.75,-21.62,Math.PI),2.4,1.5),Lg(v,g,Z(iC-1.1,0,-22.25,Math.PI/2)),_.build(o,`tutorial-kit`),v.build(o,`tutorial-decor`,{decor:!0});let xe=fS({player:n,hud:t});xe.addZone({id:`tutorial-moving-laser`,center:{x:JS(-88),y:0,z:ZS},size:{x:3.4,y:4,z:5.4},modal:!0,eyebrow:`Passageway 1 · Security Training`,title:`Jump`,text:`The first security beam sweeps across the floor. Read its movement, then jump cleanly over the low beam instead of trying to run through it.`,controls:[{label:`Jump`,action:`jump`}]}),xe.addZone({id:`tutorial-camera`,center:{x:JS(-82.2),y:0,z:ZS},size:{x:3.5,y:4,z:5.4},modal:!0,eyebrow:`Passageway 1 · Security Training`,title:`Security Cameras`,text:`Blue vision cones show where a camera can see. Being watched raises suspicion, so wait for the sweep to move away or keep solid cover between you and the camera.`}),xe.addZone({id:`tutorial-timed-gate`,center:{x:JS(-78.4),y:0,z:ZS},size:{x:3.5,y:4,z:5.4},text:`LASER GATE — this one cycles off briefly. Read the timing and cross during the safe window.`,duration:3500}),xe.addZone({id:`tutorial-puzzle`,center:{x:JS(-72),y:0,z:ZS},size:{x:4.5,y:4,z:5.4},text:`LOCKED DOOR — inspect the opposite maintenance plaque, then rotate all three cipher dials to match it.`,duration:3900}),xe.addZone({id:`tutorial-stage-complete`,center:{x:aC,y:eC,z:-38.4},size:{x:5.2,y:3.5,z:2.2},condition:()=>w.isSolved(),text:a?`Passageway 1 complete. Continue east into the lower security passage.`:`Passageway 1 complete. The sealed bulkhead ahead is the connection point for Passageway 2.`,duration:4200});function V(e){e&&(c.camera=e.addCamera({position:new R(JS(-80.4),4.45,-21.78),baseAngle:Math.PI,sweepRange:Math.PI/5.2,sweepSpeed:.58,range:7.2}),c.timedGrid=e.addLaserGrid({position:new R(JS(-76.3),$S,ZS),width:5.25,height:2.2,beamCount:4,rotationY:Math.PI/2}),c.timedController=OS(c.timedGrid,{activeDuration:2.35,inactiveDuration:1.45,startActive:!0}))}function Se(e,t,n=0){return te.getFloorHeight(e,t)??(e>=ue-3&&e<=ue+3&&t>=cC&&t<=-36.4?eC:n)}function Ce(e){b.update(e,n?.mesh?.position),C.update(e),c.timedController?.update(e),xe.update()}function we(){w.dispose(),xe.dispose()}return{group:o,colliders:s,spawn:YS.clone(),bounds:{...XS},setupStealth:V,getGroundHeight:Se,update:Ce,dispose:we,isComplete:()=>w.isSolved()}}function gC({scene:e,player:t,camera:n,stealth:r,hud:i,groundHeightAt:a,isEnabled:o=()=>!0,hearingRadius:s=10,inventory:c={count:0,max:3}}={}){Number.isFinite(c.count)||(c.count=0),(!Number.isFinite(c.max)||c.max<1)&&(c.max=3);let l=new x({color:11570495,roughness:.28,metalness:.9,emissive:3810824,emissiveIntensity:.45}),u=new p(.08,.08,.22,10);u.rotateZ(Math.PI/2);let d=new dt({color:6809849,transparent:!0,opacity:.72,side:2,depthWrite:!1}),f=new M(.75,.9,40);f.rotateX(-Math.PI/2);let m=null,h=null,g=0,_=null,v=0,y=!0,b=null;function S(){m&&(e.remove(m),m=null,h=null)}function C(){_&&(e.remove(_),_=null,v=0)}function w(){if(!o())return!1;if(c.count<=0)return i?.showToast?.(`You have nothing to throw`,1700),!1;if(!t?.mesh||g>0||m||b)return!1;let e=t.playThrow?.();return e?(b={animation:e,yaw:n?.getYaw?.()??t.mesh.rotation.y??0},!0):!1}function T({animation:n,yaw:r}){let a=new R(Math.sin(r),0,Math.cos(r));m=new z(u,l),m.name=`thrown-distraction`;let o=!!t.isCrouching?.();m.position.copy(t.mesh.position),m.position.y+=o?.78:1.12,m.position.addScaledVector(a,.55),n.releasePosition&&m.position.copy(n.releasePosition),m.rotation.y=r,h=a.multiplyScalar(8.8),h.y=o?3.6:4.15,e.add(m),c.count=Math.max(0,c.count-1),g=.65,y?(y=!1,i?.showToast?.(`Distractor thrown — ${c.count}/${c.max} remaining. Guards who hear it will investigate.`,2400)):i?.showToast?.(`Distractors: ${c.count}/${c.max}`,1100)}function E(t){let n=t.clone();S(),C(),d.opacity=.72,_=new z(f,d),_.name=`distraction-noise-pulse`,_.position.copy(n),_.position.y+=.035,_.scale.setScalar(.35),e.add(_);let a=r?.investigate?.(n,{radius:s,duration:3.4})??0;a>0?i?.showToast?.(a===1?`A guard heard the noise and is investigating.`:`${a} guards heard the noise and are investigating.`,1700):i?.showToast?.(`The impact was too far away for a guard to hear.`,1400)}function D(e){if(g=Math.max(0,g-e),b&&(b.animation.cancelled?b=null:b.animation.released&&(T(b),b=null)),m&&h){h.y-=12.5*e,m.position.addScaledVector(h,e),m.rotation.x+=e*8,m.rotation.z+=e*4.5;let n=t?.mesh?.position?.y??-4,r=typeof a==`function`?a(m.position.x,m.position.z,n):n;m.position.y<=r+.08&&h.y<=0&&(m.position.y=r+.08,E(m.position))}if(_){v+=e;let t=Math.min(1,v/1.05);_.scale.setScalar(.35+t*3.7),_.material.opacity=.72*(1-t),t>=1&&C()}}function O(){b&&(b.animation.cancelled=!0),b=null,S(),C(),u.dispose(),l.dispose(),f.dispose(),d.dispose()}return{throw:w,update:D,dispose:O,isReady:()=>g<=0&&!m&&!b&&c.count>0,getCount:()=>c.count}}var _C=-66,vC=e=>e+_C,yC=new R(vC(-58.25),-4,-38.3),bC={minX:vC(-60.2),maxX:vC(-13.8),minZ:-42.15,maxZ:-34.45},xC=-38.3,SC=5,CC=vC(-60),wC=vC(-56),TC=vC(-17.8),EC=vC(-14.2),DC=new R(EC,-4,xC),OC=7.2,kC=3.4,AC=5.4;function jC(e,t,{size:n,position:r,material:i,collider:a=!0,colliderInset:o=0,name:s=``}){let c=new z(new K(n.x,n.y,n.z),i);if(c.position.copy(r),c.name=s,c.castShadow=!0,c.receiveShadow=!0,e.add(c),a){let e=Math.max(0,o);t.push({minX:r.x-n.x/2+e,maxX:r.x+n.x/2-e,minZ:r.z-n.z/2+e,maxZ:r.z+n.z/2-e})}return c}function MC(e){return e===0?new G(.18,22):e===1?new G(.2,3):e===2?new Ot(.3,.3):new M(.1,.19,20)}function NC({group:e,interaction:t,hud:n,player:r,door:i,floorY:a}){let o=[1,3,0,2],s=[],c=[new R(vC(-23.4),a+.055,-39.849999999999994),new R(vC(-20.7),a+.055,-39.849999999999994),new R(vC(-23.4),a+.055,-36.75),new R(vC(-20.7),a+.055,-36.75)],l=[3718648,16096779,12616956,3462041],u=l.map(e=>new x({color:2370097,roughness:.52,metalness:.62,emissive:e,emissiveIntensity:.35})),d=l.map(e=>new x({color:e,emissive:e,emissiveIntensity:1.2,roughness:.25,metalness:.25,side:2})),f=[];for(let t=0;t<c.length;t++){let n=new U;n.name=`routing-floor-plate-${t+1}`,n.position.copy(c[t]);let r=new z(new K(1.35,.09,1.35),u[t]);r.position.y=0,r.receiveShadow=!0,n.add(r);let i=new z(MC(t),d[t]);i.rotation.x=-Math.PI/2,i.position.y=.055,n.add(i),e.add(n),f.push({plate:n,slab:r,symbol:i})}let p=new U;p.name=`routing-sequence-relay`,p.position.set(vC(-22.05),a+1.55,-34.83),p.rotation.y=Math.PI,e.add(p);let m=new x({color:1910577,roughness:.4,metalness:.78}),h=new x({color:11570495,roughness:.3,metalness:.88}),g=new z(new K(3,1.05,.18),m);p.add(g);let _=new z(new K(2.55,.06,.05),h);_.position.set(0,.39,.115),p.add(_);let v=[];for(let e=0;e<4;e++){let t=d[e].clone();t.emissiveIntensity=.18;let n=new z(MC(e),t);n.position.set(-.9+e*.6,-.05,.12),p.add(n),v.push(n)}let y=0,b=!1,S=-1,C=!0,w=0,T=0,E=!1,D=.35,O=.68,k=D+o.length*O+.9;function A(e=-1){v.forEach((t,n)=>{t.material.emissiveIntensity=n===e?3.2:.18,t.scale.setScalar(n===e?1.22:1)})}function j({resetInput:e=!1}={}){b||T>0||(e&&M(!1),E=!1,C=!0,w=0,T=.35,A(-1))}let ee=t.register(p,{prompt:`Replay routing sequence`,range:2.7,onInteract:()=>{j({resetInput:!0}),t?.flashPrompt?.(`Sequence replaying`)}});s.push(ee);function M(e=!0){y=0,f.forEach(({slab:e},t)=>{e.material.emissive.setHex(l[t]),e.material.emissiveIntensity=.35}),e&&n?.showToast?.(`Wrong pressure plate — routing sequence reset. Replay the wall relay and try again.`,2100)}function N(e){if(!b){if(e!==o[y]){M(!0),j();return}E||(E=!0,C=!1,A(-1)),y+=1,!(y<o.length)&&(b=!0,C=!1,A(-1),f.forEach(({slab:e})=>{e.material.emissive.setHex(1096065),e.material.emissiveIntensity=2.5}),v.forEach(e=>{e.material.emissive.setHex(1096065),e.material.emissiveIntensity=2.2}),i.unlock(),n?.showToast?.(`Routing sequence accepted — Passageway 3 access unlocked.`,3e3),t?.flashPrompt?.(`Access granted`))}}function P(e){if(T=Math.max(0,T-e),C&&!b){w+=e;let t=w%k;if(t<D)A(-1);else{let e=t-D,n=Math.floor(e/O);n>=0&&n<o.length?A(e-n*O<.52?o[n]:-1):A(-1)}E&&(C=!1,A(-1))}if(b||!r?.mesh)return;let t=r.mesh.position,n=-1,i=1/0;for(let e=0;e<c.length;e++){let r=t.x-c[e].x,a=t.z-c[e].z,o=r*r+a*a;o<.56*.56&&o<i&&(n=e,i=o)}n!==-1&&S!==n&&N(n),S=n}function te(){s.forEach(e=>e())}return{update:P,dispose:te,replay:j,isSolved:()=>b}}function PC({scene:e,interaction:t,hud:n,player:r,respawn:i,camera:a,distractionInventory:o,connectedToPassage3:s=!1}={}){let c=new U;c.name=`passage-guards`;let l=[],u=vh({repeat:[20,4],base:6907498,vein:4012608,grout:2565418}),d=Ch({repeat:[18,3],base:5067093,roughness:.92});ky(c,{name:`guards-exterior`,minX:CC,maxX:EC,minZ:xC-OC/2,maxZ:-34.699999999999996,floorY:-4,wallHeight:SC,skipWest:!0,skipEast:!0});let f=Ch({repeat:[16,2],base:2698545,roughness:.98}),m=bh({repeat:[10,2],base:2700608,roughness:.5,metalness:.75}),h=_h({repeat:[6,2],light:6045740,dark:2825493}),g=[],_=o??{count:0,max:3};function v(e,r){let i=new U;i.name=r,i.position.copy(e);let a=new x({color:11570495,emissive:3810824,emissiveIntensity:.45,roughness:.28,metalness:.9}),o=new z(new p(.09,.09,.26,10),a);o.rotation.z=Math.PI/2,o.position.y=.16,i.add(o),c.add(i);let s=!1,l=null;l=t.register(i,{prompt:`Pick up loose metal distractor`,range:2.2,onInteract:()=>{if(!s){if(_.count>=_.max){n?.showToast?.(`Distractor pouch full — ${_.count}/${_.max}`,1300);return}s=!0,_.count+=1,i.visible=!1,l?.(),t?.flashPrompt?.(`Distractor collected — ${_.count}/${_.max}`)}}}),g.push(()=>l?.())}let y=wS({start:new R(CC,-4,xC),end:new R(wC,-4,xC),width:kC,height:SC,floorMaterial:u,wallMaterial:d,ceilingMaterial:f});c.add(y.group),l.push(...y.colliders);let b=wS({start:new R(wC,-4,xC),end:new R(TC,-4,xC),width:OC,height:SC,floorMaterial:u,wallMaterial:d,ceilingMaterial:f});c.add(b.group),l.push(...b.colliders);for(let e of[-1,1]){let t=xC+e*2.65;jC(c,l,{size:new R(.24,SC,1.9000000000000001),position:new R(wC,-1.5,t),material:d})}let S=new x({color:16769197,emissive:16755021,emissiveIntensity:3,roughness:.18});for(let e of[-57.5,-52,-46.5,-41,-35.5,-30,-24.5,-19.5].map(vC)){let t=new z(new p(.09,.09,.95,10),S);t.rotation.z=Math.PI/2,t.position.set(e,.34999999999999964,xC),c.add(t);let n=new j(16762239,11,8,2);n.position.copy(t.position),c.add(n)}jC(c,l,{size:new R(1.45,1.55,.9),position:new R(vC(-53),-3.225,-40.65),material:m,colliderInset:.06,name:`guard-passage-cover-a`}),jC(c,l,{size:new R(1.25,1.25,.85),position:new R(vC(-48.2),-3.375,-36.05),material:h,colliderInset:.06,name:`guard-passage-cover-b`});let C=new U;C.position.set(vC(-40.8),-4,-35.75);let w=new z(new K(1.5,.16,.72),m);w.position.y=.35,C.add(w);for(let e of[-1,1]){let t=new z(new K(.55,.75,.5),h);t.position.set(e*.38,.8,0),C.add(t)}c.add(C),v(new R(vC(-54.8),-3.98,-36.4),`distractor-pickup-p2-a`),v(new R(vC(-41.1),-3.98,-36.3),`distractor-pickup-p2-b`),v(new R(vC(-34.2),-3.98,-40.199999999999996),`distractor-pickup-p2-c`),jC(c,l,{size:new R(1.2,1.35,.82),position:new R(vC(-35),-3.325,-40.75),material:m,colliderInset:.06,name:`guard-passage-camera-cover`});let T=DS({position:new R(vC(-28.4),-4,xC),beamLength:6.15,beamHeight:.58,travelAxis:`x`,travelDistance:.85,speed:1.05,onHit:()=>{n?.showToast?.(`Moving laser tripped — use the jump timing learned upstairs.`,1500),i?.fail?.(`laser`)}});c.add(T.group);let E=3.6;for(let e of[-1,1]){let t=xC+e*2.7;jC(c,l,{size:new R(.24,SC,1.8),position:new R(TC,-1.5,t),material:d})}jC(c,l,{size:new R(.24,2.2,E),position:new R(TC,-.10000000000000009,xC),material:d,collider:!1});let D=ES({position:new R(TC,-4,xC),width:E,height:2.8,axis:`x`});c.add(D.group),l.push(D.collider);let O=wS({start:new R(TC,-4,xC),end:new R(EC,-4,xC),width:AC,height:SC,floorMaterial:u,wallMaterial:d,ceilingMaterial:f});if(c.add(O.group),l.push(...O.colliders),!s){let e=jC(c,l,{size:new R(.3,SC,AC),position:new R(EC,-1.5,xC),material:m,name:`passage-3-stage-bulkhead`});e.userData.stageBoundary=!0}let k=NC({group:c,interaction:t,hud:n,player:r,door:D,floorY:-4}),A=fS({player:r,hud:n});A.addZone({id:`guards-intro`,center:{x:vC(-57.7),y:-4,z:xC},size:{x:3.8,y:3.2,z:3},modal:!0,eyebrow:`Passageway 2 · Stealth`,title:`Guards & Crouching`,text:`Yellow vision cones show where guards can see. Watch their patrol before moving. Crouching is slower, but it makes you much harder to detect while crossing exposed ground.`,controls:[{label:`Crouch / Sneak`,action:`duck`}]}),A.addZone({id:`crouch-intro`,center:{x:vC(-53.4),y:-4,z:xC},size:{x:4,y:3.2,z:6.4},text:()=>`Stay low with ${ja(Y.getBinding(`duck`))} when you need to cross a guard's sightline.`,duration:3e3}),A.addZone({id:`distract-intro`,center:{x:vC(-45.5),y:-4,z:xC},size:{x:5,y:3.2,z:6.4},modal:!0,eyebrow:`Passageway 2 · Stealth`,title:`Distractions`,text:`Loose metal can pull guards away from your route. Collect a distractor when you find one, then throw it toward open space. Each throw consumes one pickup, so use them deliberately.`,controls:[{label:`Pick Up`,action:`interact`},{label:`Throw Distractor`,action:`distract`}]}),A.addZone({id:`combine-camera-laser`,center:{x:vC(-35.2),y:-4,z:xC},size:{x:4.8,y:3.2,z:6.5},text:`COMBINE MECHANICS — use the cabinet as camera cover, read the laser cycle, then cross during the safe window.`,duration:3900}),A.addZone({id:`moving-laser-recall`,center:{x:vC(-29.4),y:-4,z:xC},size:{x:4,y:3.2,z:6.5},text:`MOVING LASER — same principle as Passageway 1, but now after stealth pressure. Wait for a clean jump rather than rushing.`,duration:3500}),A.addZone({id:`signal-step-puzzle`,center:{x:vC(-24.2),y:-4,z:xC},size:{x:5,y:3.2,z:6.5},text:`ROUTING FLOOR — watch the wall relay flash four symbols, then step on the matching floor plates in that order. Interact with the relay to replay it.`,duration:4700}),A.addZone({id:`passage-2-complete`,center:{x:vC(-15.9),y:-4,z:xC},size:{x:2.8,y:3.2,z:4.8},condition:()=>k.isSolved(),text:s?`Passageway 2 complete. The maintenance vent ahead is the only route forward — crouch to fit through.`:`Passageway 2 complete. The bulkhead ahead is the Stage 3 connection point.`,duration:3600});let ee=null,M=null;function N(e=r?.mesh?.position){return e?e.x>=bC.minX&&e.x<=bC.maxX&&e.z>=bC.minZ&&e.z<=bC.maxZ&&e.y<-2.4:!1}function P(e,t,n=0){return e>=bC.minX&&e<=bC.maxX&&t>=bC.minZ&&t<=bC.maxZ?-4:n}function te(t){t&&(t.addGuard({waypoints:[new R(vC(-50.6),-4,-40.65),new R(vC(-50.6),-4,-36.05)],speed:1.08,waitTime:2.7,initialWaypoint:0}),t.addGuard({waypoints:[new R(vC(-44),-4,xC),new R(vC(-38.4),-4,xC)],speed:1.22,waitTime:2.25,initialWaypoint:1}),t.addCamera({position:new R(vC(-34.7),.4500000000000002,-34.81999999999999),baseAngle:Math.PI,sweepRange:Math.PI/4.7,sweepSpeed:.58,range:7.4}),ee=OS(t.addLaserGrid({position:new R(vC(-32.15),-4,xC),width:6.25,height:2.2,beamCount:4,rotationY:Math.PI/2}),{activeDuration:2.65,inactiveDuration:1.65,startActive:!0}),M=gC({scene:e,player:r,camera:a,stealth:t,hud:n,groundHeightAt:P,isEnabled:()=>N(),hearingRadius:10,inventory:_}))}function F(e){return e===`distract`?M?.throw?.()??!1:!1}function ne(e){T.update(e,r?.mesh?.position),ee?.update(e),M?.update(e),k.update(e),D.update(e),A.update()}let re=pg();yg(c,[[u,re.concrete,3],[d,re.brick,.46],[f,re.ceiling,3]]),KS(c,{walls:[re.brick],finish:`wood`,name:`guards-wall-dressing`}),kv(c,l);function I(){k.dispose(),g.forEach(e=>e()),M?.dispose(),M=null,A.dispose()}return{group:c,colliders:l,bounds:{...bC},entryCheckpoint:yC.clone(),setupStealth:te,handleAction:F,getGroundHeight:P,isInsidePassage:N,update:ne,dispose:I,isComplete:()=>k.isSolved()}}var FC=DC.clone(),IC={minX:-80.5,maxX:-51.7,minZ:-51.6,maxZ:-21.8},LC=5,RC=4.8,zC=1.65,BC=1.34,VC=-74.5,HC=-72.1,UC=FC.z,WC=HC,GC=-49,KC=-59,qC=GC,JC=KC,YC=-39.7,XC=10.5,ZC=8,QC=6.2,$C=-35.7,ew=JC,tw=3.4,nw=-32.300000000000004,rw=ew,iw=Pv,aw=4.8,ow=iw-aw/2,sw=-56.6,cw=-52,lw=Pv,uw=3.3;function dw(e,t,{size:n,position:r,material:i,collider:a=!0,colliderInset:o=0,name:s=``}){let c=new z(new K(n.x,n.y,n.z),i);if(c.position.copy(r),c.name=s,c.castShadow=!0,c.receiveShadow=!0,e.add(c),a){let e=Math.max(0,o);t.push({minX:r.x-n.x/2+e,maxX:r.x+n.x/2-e,minZ:r.z-n.z/2+e,maxZ:r.z+n.z/2-e})}return c}function fw(e,t,n=.16){let r=t.end.x-t.start.x,i=t.end.z-t.start.z,a=Math.hypot(r,i),o=r/a,s=i/a,c=-o;for(let r of[-1,1]){let i=t.start.x+s*r*(t.width/2+.09),a=t.start.z+c*r*(t.width/2+.09),o=t.end.x+s*r*(t.width/2+.09),l=t.end.z+c*r*(t.width/2+.09);e.push({minX:Math.min(i,o)-n,maxX:Math.max(i,o)+n,minZ:Math.min(a,l)-n,maxZ:Math.max(a,l)+n})}}function pw(e,t,n,r,i,a=``){let o=n.clone().sub(t),s=o.length();if(s<.001)return null;let c=new z(new p(r,r,s,10),i);return c.name=a,c.position.copy(t).add(n).multiplyScalar(.5),c.quaternion.setFromUnitVectors(new R(0,1,0),o.normalize()),c.castShadow=!0,e.add(c),c}function mw(e,t,n,{railHeight:r=.95,inset:i=.16,postSpacing:a=1.15}={}){let o=t.end.x-t.start.x,s=t.end.z-t.start.z,c=Math.hypot(o,s);if(c<.001)return;let l=o/c,u=s/c,d=-l,f=Math.max(.2,t.width/2-i),p=Math.max(2,Math.ceil(t.runLength/a));for(let i of[-1,1]){let a=u*i*f,o=d*i*f;pw(e,t.start.clone().add(new R(a,r,o)),t.end.clone().add(new R(a,r,o)),.035,n,`bridge-stair-rail-${i}`);for(let s=0;s<=p;s++){let c=s/p,l=new R(B.lerp(t.start.x,t.end.x,c)+a,B.lerp(t.start.y,t.end.y,c)+.04,B.lerp(t.start.z,t.end.z,c)+o),u=l.clone();u.y+=r-.04,pw(e,l,u,.025,n,`bridge-stair-post-${i}-${s}`)}}}function hw({group:e,colliders:t,floorMat:n,wallMat:r,ironMat:i,player:a,hud:o}){let s=FC.x,c=VC,l=FC.z,u=1.65,d=c-s,f=(s+c)/2,p=new z(new Ot(d,u),n);p.rotation.x=-Math.PI/2,p.position.set(f,-3.985,l),p.receiveShadow=!0,e.add(p);let m=new z(new K(d,.12,1.8299999999999998),i);m.position.set(f,-2.66,l),m.receiveShadow=!0,e.add(m);let h=new z(new K(d,.18,1.97),r);h.position.set(f,1,l),h.receiveShadow=!0,e.add(h);for(let n of[-1,1]){let i=l+n*u/2;dw(e,t,{size:new R(d,LC,.14),position:new R(f,-1.5,i),material:r})}for(let n of[-1,1]){let r=l+n*1.7625000000000002;dw(e,t,{size:new R(.28,LC,1.8750000000000002),position:new R(s,-1.5,r),material:i})}dw(e,t,{size:new R(.28,3.66,u),position:new R(s,-2.66+3.66/2,l),material:i,collider:!1});let g=[s+.18,f,-74.68],_=[];for(let n=0;n<g.length;n++){let r=g[n],a=new z(new K(.1,.1,u),i);a.position.set(r,-2.72,l),e.add(a);let o={minX:r-.12,maxX:r+.12,minZ:l-u/2+.06,maxZ:l+u/2-.06,enabled:!0,ventClearance:!0};t.push(o),_.push(o)}let v=!1;function y(){let e=!!a?.isCrouching?.();_.forEach(t=>{t.enabled=!e});let t=a?.mesh?.position;if(!t)return;let n=t.x>s-.4&&t.x<-74.3&&Math.abs(t.z-l)<1.025;a.mesh.userData.tightCrouchCamera=n,!(e||v)&&n&&(v=!0,o?.showToast?.(`Too low to stand — ${Ma()} to crouch through the vent.`,2500))}return{update:y,contains(e,t){return e>=s-.1&&e<=-74.4&&Math.abs(t-l)<=.9249999999999999},hasCleared(e){return!!(e&&e.x>-73.95&&e.z<l+2.2&&e.z>l-3.3)}}}function gw(e){let t=[];for(let n of[...e.group.children]){if(!n?.isMesh||!n.name?.startsWith(`room-wall-`))continue;let e=n.name.slice(10),r=n.geometry?.parameters??{},i=r.height??QC,a=e===`minX`||e===`maxX`?r.depth??ZC:r.width??XC,o=new z(new Ot(a,i),n.material);o.name=`${n.name}-camera-friendly`,o.position.copy(n.position),e===`minX`?o.rotation.y=Math.PI/2:e===`maxX`?o.rotation.y=-Math.PI/2:e===`maxZ`&&(o.rotation.y=Math.PI),o.castShadow=!0,o.receiveShadow=!0,t.push({wall:n,plane:o})}for(let{wall:n,plane:r}of t)e.group.remove(n),e.group.add(r),n.geometry?.dispose?.()}function _w({group:e,floorY:t,ironMat:n}){let r=new x({color:1383716,roughness:.66,metalness:.42}),i=new x({color:2108726,roughness:.58,metalness:.52,side:0}),a=new x({color:9400633,emissive:2168582,emissiveIntensity:.28,roughness:.34,metalness:.82}),o=new x({color:4438216,emissive:743782,emissiveIntensity:.8,roughness:.28,metalness:.45}),s=new x({color:16769720,emissive:16757853,emissiveIntensity:1.35,roughness:.32,metalness:.12}),c=new z(new K(6.15,.055,5.15),r);c.position.set(JC,t+.026,-39.650000000000006),c.receiveShadow=!0,e.add(c);let l=t+.065,u=-39.650000000000006;for(let t of[-3.02,3.02]){let n=new z(new K(.045,.035,5),o);n.position.set(JC+t,l,u),e.add(n)}for(let t of[-2.5,2.5]){let n=new z(new K(6,.035,.045),a);n.position.set(JC,l,u+t),e.add(n)}function d(t,n,r,o=0){let s=new z(new Ot(t,n),i);s.position.copy(r),s.rotation.y=o,s.receiveShadow=!0,e.add(s);for(let i of[-n/2+.08,n/2-.08]){let n=new z(new K(t,.055,.035),a);n.position.set(r.x,r.y+i,r.z),n.rotation.y=o,e.add(n)}}let f=t+1.45;for(let e of[-2.15,0,2.15])d(1.75,2.45,new R(-64.215,f,YC+e),Math.PI/2),d(1.75,2.45,new R(-53.785,f,YC+e),-Math.PI/2);let m=-35.735;d(2.7,2.45,new R(-62.55,f,m),Math.PI),d(2.7,2.45,new R(-55.45,f,m),Math.PI);for(let r of[-2.45,0,2.45]){let i=new z(new K(9.8,.18,.16),n);i.position.set(JC,t+QC-.3,YC+r),i.castShadow=!0,e.add(i)}for(let r of[-2.1,.25,2.35]){let i=new z(new K(1.35,.12,.38),n);i.position.set(JC,t+QC-.52,YC+r),e.add(i);let a=new z(new K(1.02,.035,.22),s);a.position.set(JC,t+QC-.59,YC+r),e.add(a);let o=new j(16763267,4.8,8,2.2);o.position.set(JC,t+QC-.82,YC+r),e.add(o)}let h=new x({color:5661804,roughness:.38,metalness:.82});for(let n of[-1,1])for(let r of[-2.8,2.8]){let i=new z(new p(.055,.055,2.5,10),h);i.position.set(JC+n*(XC/2-.13),t+1.35,YC+r),e.add(i)}let g=new z(new K(3.9,.16,.12),a);g.position.set(JC,t+3.12,-35.76),e.add(g);for(let n of[-1,1]){let r=new z(new K(.22,.12,.06),o);r.position.set(JC+n*1.55,t+3.12,-35.835),e.add(r)}}function vw({group:e,colliders:t,interaction:n,hud:r,door:i,floorY:a,ironMat:o}){let s=[],c=!1,l=[{dr:-1,dc:0},{dr:0,dc:1},{dr:1,dc:0},{dr:0,dc:-1}],u={straight:[1,3],corner:[0,1],tee:[0,1,3],cross:[0,1,2,3]},d=[[{type:`corner`,rotation:3},{type:`straight`,rotation:1},{type:`corner`,rotation:0}],[{type:`tee`,rotation:2},{type:`cross`,rotation:0,fixed:!0},{type:`tee`,rotation:1}],[{type:`corner`,rotation:2},{type:`tee`,rotation:3},{type:`corner`,rotation:1}]],f=new Set([`0,0`,`2,0`,`2,2`]),m={row:1,col:0,edge:3},h={row:1,col:2,edge:1},g=new U;g.name=`bridge-chrono-router`,g.position.set(JC,a,-39.550000000000004),e.add(g);let _=new x({color:1120288,roughness:.48,metalness:.76}),v=new x({color:10189375,emissive:2168582,emissiveIntensity:.28,roughness:.32,metalness:.88}),y=new x({color:2503227,roughness:.4,metalness:.72}),b=new z(new K(3.42,.66,3.36),_);b.position.y=.33,b.castShadow=!0,b.receiveShadow=!0,g.add(b);let S=new z(new K(3.62,.12,3.54),y);S.position.y=.72,S.castShadow=!0,S.receiveShadow=!0,g.add(S);for(let e of[-1.77,1.77]){let t=new z(new K(.045,.045,3.45),v);t.position.set(e,.8,0),g.add(t)}for(let e of[-1.73,1.73]){let t=new z(new K(3.54,.045,.045),v);t.position.set(0,.8,e),g.add(t)}t?.push?.({minX:-60.82,maxX:-57.18,minZ:-41.370000000000005,maxZ:-37.730000000000004});let C=new U;C.position.set(0,1.36,1.47),C.rotation.x=-.52,g.add(C);let w=new z(new K(3.18,.92,.12),o);w.castShadow=!0,C.add(w);let T=document.createElement(`canvas`);T.width=1024,T.height=256;let E=T.getContext(`2d`),D=new mt(T),O=new dt({map:D,toneMapped:!1,side:0}),k=new z(new Ot(2.96,.74),O);k.position.z=-.065,k.rotation.y=Math.PI,C.add(k);for(let e of[-1,1]){let t=new z(new K(.11,.62,.11),v);t.position.set(e*1.34,1.05,1.39),t.rotation.x=-.22,g.add(t)}let A=new x({color:1120295,roughness:.42,metalness:.62}),j=new x({color:2503233,emissive:728875,emissiveIntensity:.55,roughness:.38,metalness:.7}),ee=new P(new K(.88,.055,.88)),M=new Ke({color:16639626,transparent:!0,opacity:.95,toneMapped:!1}),N=[],te=.92;function F(e){return u[e.type].map(t=>(t+e.rotation)%4)}function ne(e,t){return F(e).includes(t)}function re(e,t){let n=e===1||e===3,r=new z(new K(n?.36:.095,.055,n?.095:.36),t),i=.19;return e===0&&(r.position.z=-.19),e===1&&(r.position.x=i),e===2&&(r.position.z=i),e===3&&(r.position.x=-.19),r.position.y=.075,r}for(let e=0;e<3;e++){N[e]=[];for(let t=0;t<3;t++){let r=d[e][t],i={row:e,col:t,type:r.type,rotation:r.rotation,fixed:!!r.fixed,group:new U,lineMaterial:new x({color:3003583,emissive:1013358,emissiveIntensity:.65,roughness:.22,metalness:.48}),fuseMaterial:null,focusFrame:null};i.group.name=`bridge-router-tile-${e}-${t}`,i.group.position.set((t-1)*te,.84,(e-1)*te);let a=new z(new K(.78,.075,.78),i.fixed?j:A);a.position.y=.015,i.group.add(a);for(let e of u[i.type])i.group.add(re(e,i.lineMaterial));let o=new z(new p(.105,.105,.045,16),i.lineMaterial);if(o.position.y=.085,i.group.add(o),i.fixed||(i.focusFrame=new Et(ee,M),i.focusFrame.position.y=.115,i.focusFrame.visible=!1,i.focusFrame.renderOrder=8,i.group.add(i.focusFrame)),f.has(`${e},${t}`)){i.fuseMaterial=new x({color:16096779,emissive:7877903,emissiveIntensity:1.2,roughness:.2,metalness:.35});let e=new z(new Tt(.18,.035,8,20),i.fuseMaterial);e.rotation.x=Math.PI/2,e.position.y=.115,i.group.add(e)}i.group.rotation.y=-i.rotation*Math.PI/2,g.add(i.group),N[e][t]=i,i.fixed||s.push(n.register(i.group,{prompt:`Rotate highlighted relay tile`,range:3.25,selectionMode:`aim`,aimMin:.78,onFocusChange:e=>{i.focusFrame.visible=e&&!c},onInteract:()=>{c||(i.rotation=(i.rotation+1)%4,i.group.rotation.y=-i.rotation*Math.PI/2,R())}}))}}let I=new x({color:3718648,emissive:165063,emissiveIntensity:2.6}),L=new x({color:15680580,emissive:10033947,emissiveIntensity:2.2}),ie=new z(new K(.28,.08,.34),I);ie.position.set(-1.54,.93,0),g.add(ie);let ae=new z(new K(.28,.08,.34),L);ae.position.set(1.54,.93,0),g.add(ae);function oe(){let e=new Set,t=N[m.row][m.col];if(!ne(t,m.edge))return e;let n=[[m.row,m.col]];for(e.add(`${m.row},${m.col}`);n.length;){let[t,r]=n.shift(),i=N[t][r];for(let a of F(i)){let i=l[a],o=t+i.dr,s=r+i.dc;if(o<0||o>=3||s<0||s>=3)continue;let c=N[o][s];if(!ne(c,(a+2)%4))continue;let u=`${o},${s}`;e.has(u)||(e.add(u),n.push([o,s]))}}return e}function se(e,t){if(!E)return;let n=E;n.fillStyle=`#071019`,n.fillRect(0,0,T.width,T.height),n.strokeStyle=`#b08d3f`,n.lineWidth=8,n.strokeRect(8,8,T.width-16,T.height-16),n.textAlign=`center`,n.fillStyle=`#f8fafc`,n.font=`700 54px sans-serif`,n.fillText(`CHRONO RELAY ROUTER`,512,64),n.fillStyle=`#67e8f9`,n.font=`700 34px sans-serif`,n.fillText(`ROTATE TILES: SOURCE → ALL 3 FUSES → DOOR`,512,126),n.fillStyle=e===3?`#34d399`:`#fbbf24`,n.font=`700 38px sans-serif`,n.fillText(`FUSES ${e}/3`,360,202),n.fillStyle=t?`#34d399`:`#f87171`,n.fillText(t?`DOOR LINKED`:`DOOR OFFLINE`,690,202),D.needsUpdate=!0}function R(){let e=oe(),t=0;for(let n of N)for(let r of n){let n=`${r.row},${r.col}`,i=e.has(n);r.lineMaterial.emissiveIntensity=i?2.35:.55,r.lineMaterial.color.setHex(i?6809849:3003583),r.fuseMaterial&&(r.fuseMaterial.color.setHex(i?3462041:16096779),r.fuseMaterial.emissive.setHex(i?366185:7877903),r.fuseMaterial.emissiveIntensity=i?2.5:1.05,i&&(t+=1))}let n=N[h.row][h.col],a=e.has(`${h.row},${h.col}`)&&ne(n,h.edge);L.color.setHex(a?3462041:15680580),L.emissive.setHex(a?366185:10033947),L.emissiveIntensity=a?3.1:2.2,se(t,a),!(c||t!==3||!a)&&(c=!0,i.unlock(),r?.showToast?.(`ROUTE COMPLETE — all three chrono fuses powered; stairwell unlocked.`,3300))}return R(),{isSolved:()=>c,dispose(){s.forEach(e=>e()),k.geometry.dispose(),O.dispose(),D.dispose(),_.dispose(),v.dispose(),y.dispose(),A.dispose(),j.dispose(),ee.dispose(),M.dispose(),I.dispose(),L.dispose();for(let e of N)for(let t of e)t.lineMaterial.dispose(),t.fuseMaterial?.dispose?.()}}}function yw({scene:e,interaction:t,hud:n,player:r,respawn:i,camera:a,distractionInventory:o}={}){let s=new U;s.name=`passage-bridge`;let c=[],l=vh({repeat:[16,4],base:5988452,vein:3422269,grout:2237994}),u=Ch({repeat:[14,3],base:4475728,roughness:.94}),d=Ch({repeat:[14,2],base:2435888,roughness:.98}),f=bh({repeat:[9,2],base:2503742,roughness:.48,metalness:.78}),m=_h({repeat:[5,2],light:5979947,dark:2956564}),h=new x({color:11570495,emissive:3088648,emissiveIntensity:.35,roughness:.3,metalness:.9}),g=[],_=o??{count:0,max:3};function v(e,r){let i=new U;i.name=r,i.position.copy(e);let a=new x({color:11570495,emissive:3810824,emissiveIntensity:.45,roughness:.28,metalness:.9}),o=new z(new p(.09,.09,.26,10),a);o.rotation.z=Math.PI/2,o.position.y=.16,o.castShadow=!0,i.add(o),s.add(i);let c=!1,l=null;l=t.register(i,{prompt:`Pick up loose metal distractor`,range:2.2,onInteract:()=>{if(!c){if(_.count>=_.max){n?.showToast?.(`Distractor pouch full — ${_.count}/${_.max}`,1300);return}c=!0,_.count+=1,i.visible=!1,l?.(),t?.flashPrompt?.(`Distractor collected — ${_.count}/${_.max}`)}}}),g.push(()=>l?.())}function y(e){return s.add(e.group),c.push(...e.colliders),e}let b=hw({group:s,colliders:c,floorMat:l,wallMat:u,ironMat:f,player:r,hud:n});y(TS({center:new R(HC,-4,UC),sizeX:RC,sizeZ:RC,height:LC,openings:{minX:{width:zC,height:BC},minZ:!0},floorMaterial:l,wallMaterial:u,ceilingMaterial:d}));let S=UC-RC/2,C=-46.6;y(wS({start:new R(WC,-4,S),end:new R(WC,-4,C),width:RC,height:LC,floorMaterial:l,wallMaterial:u,ceilingMaterial:d})),y(TS({center:new R(WC,-4,GC),sizeX:RC,sizeZ:RC,height:LC,openings:{maxZ:!0,maxX:!0},floorMaterial:l,wallMaterial:u,ceilingMaterial:d}));let w=KC-RC/2;y(wS({start:new R(-69.69999999999999,-4,qC),end:new R(w,-4,qC),width:RC,height:LC,floorMaterial:l,wallMaterial:u,ceilingMaterial:d})),y(TS({center:new R(KC,-4,qC),sizeX:RC,sizeZ:RC,height:LC,openings:{minX:!0,maxZ:!0},floorMaterial:l,wallMaterial:u,ceilingMaterial:d}));let T=YC-ZC/2;y(wS({start:new R(JC,-4,-46.6),end:new R(JC,-4,T),width:RC,height:LC,floorMaterial:l,wallMaterial:u,ceilingMaterial:d}));let E=3.4;gw(y(TS({center:new R(JC,-4,YC),sizeX:XC,sizeZ:ZC,height:QC,openings:{minZ:{width:RC,height:LC},maxZ:{width:E,height:2.8}},floorMaterial:l,wallMaterial:u,ceilingMaterial:d}))),_w({group:s,floorY:-4,ironMat:f});let D=ES({position:new R(JC,-4,$C),width:E,height:2.8,axis:`z`});s.add(D.group),c.push(D.collider);let O=vw({group:s,colliders:c,interaction:t,hud:n,door:D,floorY:-4,ironMat:f});y(TS({center:new R(ew,-4,-34),sizeX:RC,sizeZ:tw,height:LC,openings:{minZ:!0,maxZ:{width:uw,height:LC}},floorMaterial:l,wallMaterial:u,ceilingMaterial:d}));let k=bv({start:new R(ew,-4,nw),end:new R(ew,-2,ow),width:uw,steps:15,wallHeight:4.35,stepMaterial:f,wallMaterial:u,ceilingMaterial:d});s.add(k.group),fw(c,k),mw(s,k,h),y(TS({center:new R(rw,-2,iw),sizeX:aw,sizeZ:aw,height:4.35,openings:{minZ:{width:uw,height:4.35},maxX:{width:uw,height:4.35}},floorMaterial:l,wallMaterial:u,ceilingMaterial:d}));let A=bv({start:new R(sw,-2,lw),end:new R(cw,0,lw),width:uw,steps:12,wallHeight:4.35,stepMaterial:f,wallMaterial:u,ceilingMaterial:d});s.add(A.group),fw(c,A),mw(s,A,h),dw(s,c,{size:new R(1.1,1.45,.85),position:new R(-73.44999999999999,-3.275,-42.25),material:f,colliderInset:.06,name:`bridge-cover-a`}),dw(s,c,{size:new R(1.15,1.2,.8),position:new R(-70.8,-3.4,-44.7),material:m,colliderInset:.06,name:`bridge-cover-b`}),dw(s,c,{size:new R(1,1.4,.9),position:new R(-60.45,-3.3,-47.65),material:f,colliderInset:.06,name:`bridge-cover-c`}),v(new R(-71,-3.98,UC+1.2),`distractor-pickup-p3-a`),v(new R(-57.75,-3.98,-50.25),`distractor-pickup-p3-b`);let ee=new x({color:16766874,emissive:16752451,emissiveIntensity:3});[[HC,UC],[WC,-43.2],[WC,GC],[-66.2,qC],[KC,qC],[JC,-44.2]].forEach(([e,t])=>{let n=new z(new He(.095,10,8),ee);n.position.set(e,.04999999999999982,t),s.add(n);let r=new j(16760181,7.2,7,2.15);r.position.copy(n.position),s.add(r)});let M=new x({color:2107696,roughness:.42,metalness:.82}),N=new x({color:16768944,emissive:16754253,emissiveIntensity:1.2,roughness:.28,metalness:.12});function P(e,t,n,r=5.2){let i=e.end.x-e.start.x,a=e.end.z-e.start.z,o=Math.hypot(i,a),c=i/o,l=a/o,u=l,d=-c,f=Math.atan2(c,l),p=B.lerp(e.start.y,e.end.y,t),m=B.lerp(e.start.x,e.end.x,t),h=B.lerp(e.start.z,e.end.z,t),g=e.width/2+.035,_=new U;_.position.set(m+u*n*g,p+1.62,h+d*n*g),_.rotation.y=f,s.add(_);let v=new z(new K(.13,.38,.46),M);_.add(v);let y=new z(new K(.045,.23,.3),N);y.position.x=-n*.085,_.add(y);let b=new j(16763014,r,5.8,2.25);b.position.set(m-u*n*.3,p+1.55,h-d*n*.3),s.add(b)}for(let[e,t]of[[.16,-1],[.48,1],[.8,-1]])P(k,e,t,5.1);for(let[e,t]of[[.18,1],[.5,-1],[.82,1]])P(A,e,t,5.1);function te(e,t=5.5){let n=new z(new K(.85,.11,.34),M);n.position.copy(e),s.add(n);let r=new z(new K(.61,.03,.2),N);r.position.copy(e),r.position.y-=.07,s.add(r);let i=new j(16763014,t,6.2,2.25);i.position.copy(e),i.position.y-=.28,s.add(i)}te(new R(ew,-.25,-34),5.2),te(new R(rw,1.55,iw),5.4),te(new R(-51.45,3.55,Pv),5.8);let F=kS({start:new R(-68.99999999999999,-4,qC),end:new R(-62.1,-4,qC),width:4.25,rowCount:5,onHit:()=>{n?.showToast?.(`Laser floor tripped — jump cleanly over each glowing row.`,1500),i?.fail?.(`laser`)}});s.add(F.group);let ne=fS({player:r,hud:n});ne.addZone({id:`bridge-vent`,center:{x:FC.x+.7,y:-4,z:FC.z},size:{x:2.2,y:2.3,z:2.5},text:()=>`MAINTENANCE VENT — ${Ma()} to crouch and stay crouched until you clear all three low ribs.`,duration:4200}),ne.addZone({id:`bridge-mixed-intro`,center:{x:WC,y:-4,z:-42.1},size:{x:4.5,y:3.4,z:3},text:()=>`PASSAGEWAY 3 — read the guard and camera together. Use cover, or spend a collected distractor with ${ja(Y.getBinding(`distract`))} when you need space.`,duration:4400}),ne.addZone({id:`bridge-laser-floor`,center:{x:-131.1/2,y:-4,z:qC},size:{x:8.29999999999999,y:3.4,z:4.6},text:`LASER FLOOR — the dark slabs are landing zones. Jump each glowing row; do not sprint straight through them.`,duration:4300}),ne.addZone({id:`bridge-timed-recall`,center:{x:JC,y:-4,z:-90.30000000000001/2},size:{x:4.6,y:3.4,z:4.4},text:`SECURITY CHOKE — combine laser timing with camera/guard awareness. Wait for a clean opening.`,duration:3600}),ne.addZone({id:`bridge-power-puzzle`,center:{x:JC,y:-4,z:YC},size:{x:9.9,y:4.8,z:7.4},text:`CHRONO RELAY ROUTER — rotate the junction tiles to carry the cyan route from SOURCE through all three fuse rings and into the DOOR.`,duration:5200}),ne.addZone({id:`bridge-stairs`,center:{x:ew,y:-4,z:-34},size:{x:3.4,y:3,z:3},condition:()=>O.isSolved(),text:`BRIDGE COMPLETE — climb the first staircase, turn right inside the enclosed landing, then climb directly into the original passageway.`,duration:4700});let re=[];function I(e,t,n,r,i=-4){re.push({minX:e-n/2,maxX:e+n/2,minZ:t-r/2,maxZ:t+r/2,y:i})}I((FC.x+VC)/2,FC.z,VC-FC.x,zC),I(HC,UC,RC,RC),I(WC,(S+C)/2,RC,Math.abs(C-S)),I(WC,GC,RC,RC),I(-131.1/2,qC,8.29999999999999,RC),I(KC,qC,RC,RC),I(JC,-90.30000000000001/2,RC,2.8999999999999986),I(JC,YC,XC,ZC),I(ew,-34,RC,tw),I(rw,iw,aw,aw,-2);function L(e,t,n=0){let r=k.getFloorHeight(e,t);if(r!=null)return r;let i=A.getFloorHeight(e,t);if(i!=null)return i;for(let n of re)if(e>=n.minX&&e<=n.maxX&&t>=n.minZ&&t<=n.maxZ)return n.y;return n}function ie(e=r?.mesh?.position){if(!e||e.y>.55)return!1;let t=L(e.x,e.z,NaN);return Number.isFinite(t)}let ae=null,oe=null;function se(t){t&&(t.addGuard({waypoints:[new R(-71.19999999999999,-4,-42.2),new R(-72.85,-4,-45)],speed:1.15,waitTime:2.4,initialWaypoint:0}),t.addCamera({position:new R(-74.28,.34999999999999964,-45.4),baseAngle:Math.PI/2,sweepRange:Math.PI/5.4,sweepSpeed:.58,range:6.4}),ae=OS(t.addLaserGrid({position:new R(JC,-4,-90.30000000000001/2),width:4.25,height:2.15,beamCount:4,rotationY:0}),{activeDuration:2.3,inactiveDuration:1.6,startActive:!0}),t.addGuard({waypoints:[new R(-60,-4,-47.9),new R(-58,-4,-44.35)],speed:1.25,waitTime:2,initialWaypoint:0}),oe=gC({scene:e,player:r,camera:a,stealth:t,hud:n,groundHeightAt:L,isEnabled:()=>ie(),hearingRadius:9.5,inventory:_}))}function ce(e){return e===`distract`?oe?.throw?.()??!1:!1}let le=new R(HC,-4,UC),ue=new R(-51,0,Pv),de=!1;function fe(){let e=r?.mesh?.position;return!!(e&&O.isSolved()&&e.y>-.25&&e.x>=-51.45&&Math.abs(e.z- -24.5)<=uw/2)}function pe(e){b.update();let t=r?.mesh?.position;if(b.hasCleared(t)&&(de=!0),de&&t&&t.y<-1&&!ie(t)){i?.fail?.(`fell`);return}F.update(e,r?.mesh?.position),ae?.update(e),oe?.update(e),D.update(e),ne.update()}let me=pg();yg(s,[[l,me.concrete,3],[u,me.brick,.46],[d,me.ceiling,3]]),KS(s,{walls:[me.brick],finish:`tile`,name:`bridge-wall-dressing`,skip:e=>e.name.endsWith(`-camera-friendly`)}),Av(s,c);function he(){O.dispose(),g.forEach(e=>e()),oe?.dispose(),oe=null,F.dispose?.(),ne.dispose()}return{group:s,colliders:c,bounds:{...IC},setupStealth:se,handleAction:ce,getGroundHeight:L,isInsidePassage:ie,hasClearedVent:()=>b.hasCleared(r?.mesh?.position),hasReachedExit:fe,entryCheckpoint:le,exitCheckpoint:ue,update:pe,dispose:he,isComplete:()=>O.isSolved()}}var bw=.65,xw=2.4,Sw=.03,Cw=7.5,ww=8,Tw=.72,Ew=1.2,Dw=.72,Ow=1.55,kw=1.6,Aw=2.2,jw=Math.PI/3.4,Mw=1.6,Nw=B.degToRad(4),Pw=.35,Fw=1.6,Iw=2,Lw=9,Rw=1.5,zw={NORMAL:1,SLOW:.2,FREEZE:0,REWIND:0};function Bw({scene:e,player:t,respawn:n,hud:r,collidables:i=[],obstacles:a=[],timeSystem:o=null,assets:s=null}){let c=0,l=[],u=[],d=[],f=[],m=!1,g=new we,_=[],v=[],y=new WeakMap,b=new R;function S(e,t){_.length=0;for(let t of e){let e=t.geometry;if(t.isMesh&&!t.isSkinnedMesh&&!t.isInstancedMesh&&!t.isBatchedMesh&&t.children.length===0&&t.raycast===z.prototype.raycast&&!e.morphAttributes.position&&Number.isFinite(g.far)){e.boundingSphere===null&&e.computeBoundingSphere();let n=e.boundingSphere,r=y.get(t);r||(r={matrix:new h,local:new Pt,world:new Pt,localBox:new Ve,worldBox:new Ve,hasBox:!1,geometry:null},y.set(t,r));let i=e.boundingBox;(r.geometry!==e||!r.matrix.equals(t.matrixWorld)||!r.local.equals(n)||r.hasBox!==!!i||i&&!r.localBox.equals(i))&&(r.geometry=e,r.matrix.copy(t.matrixWorld),r.local.copy(n),r.world.copy(n).applyMatrix4(t.matrixWorld),r.world.radius+=1e-4,r.hasBox=!!i,i&&(r.localBox.copy(i),r.worldBox.copy(i).applyMatrix4(t.matrixWorld).expandByScalar(1e-4)));let a=r.world;if(!a.containsPoint(g.ray.origin)){let e=g.ray.intersectSphere(a,b);if(!e||e.distanceToSquared(g.ray.origin)>(g.far+1e-4)**2)continue}if(r.hasBox&&!r.worldBox.containsPoint(g.ray.origin)){let e=g.ray.intersectBox(r.worldBox,b);if(!e||e.distanceToSquared(g.ray.origin)>(g.far+1e-4)**2)continue}}_.push(t)}return v.length=0,g.intersectObjects(_,t,v)}s&&Mu(s);function C(e,t){return e.nearbyBlockers??=cd(),e.nearbyBlockers.get(i,t,Math.max(10,e.coneDistance))}function w(e=7.5,t=Math.PI/3.2){let n=Math.tan(t/2)*e,r=new qt(n,e,20,1,!0);r.rotateX(-Math.PI/2),r.translate(0,0,e/2);let i=new dt({color:16436245,transparent:!0,opacity:.22,side:2,depthWrite:!1}),a=new z(r,i);return a.name=`vision-cone`,{mesh:a,coneMat:i}}function T({waypoints:t,speed:n=1.6,waitTime:i=2.5,initialWaypoint:a=0,shielded:o=!1,distractible:u=!0}){let d=new U;d.name=o?`guard-shielded`:`guard`;let{mesh:p,coneMat:h}=w(Cw,Math.PI/3.2);p.position.set(0,Ow,0),d.add(p);let g=new z(new He(.06,8,8),new dt({color:16436245}));g.position.set(0,2.15,0),d.add(g);let _=null,v=null;if(o){v=new dt({color:16096779,transparent:!0,opacity:.55,side:2,depthWrite:!1});let e=new M(.44,.6,28);e.rotateX(-Math.PI/2),_=new z(e,v),_.position.y=.04,_.name=`chrono-shield`,d.add(_);let t=new z(new D(.09,0),new x({color:16639626,emissive:16096779,emissiveIntensity:3.5,roughness:.2}));t.position.set(0,1.42,.22),d.add(t)}let y=t[a]||t[0];d.position.copy(y);let b={shielded:o,distractible:u,shieldRing:_,shieldMat:v,shieldPulse:0,group:d,body:null,leftArm:null,rightArm:null,leftLeg:null,rightLeg:null,visual:null,primitiveRoot:null,coneMat:h,visionCone:p,coneDistance:Cw,statusBeacon:g,waypoints:t,targetIdx:(a+1)%t.length,speed:n,waitTime:i,waitTimer:0,state:`PATROL`,facing:0,scanBase:0,stridePhase:0,lookAroundTimer:0,investigateTarget:null,investigateBuffer:new R,investigateTimer:0,investigateGiveUpTimer:0,investigateArrived:!1};function S(){if(b.primitiveRoot||b.visual)return;let e=ul(cl);e.group.name=`guard-primitive`,d.add(e.group),b.primitiveRoot=e.group,b.body=e.body,b.leftArm=e.leftArm,b.rightArm=e.rightArm,b.leftLeg=e.leftLeg,b.rightLeg=e.rightLeg}function C(e){if(!e||b.visual)return;let t=Pu(e);t&&(b.primitiveRoot&&(d.remove(b.primitiveRoot),Jd(b.primitiveRoot),b.primitiveRoot=null,b.body=null,b.leftArm=null,b.rightArm=null,b.leftLeg=null,b.rightLeg=null),b.visual=t,d.add(t.root),d.updateMatrixWorld(!0),oe(b))}let T=Nu();return T?C(T):(S(),s&&Mu(s).then(e=>{l.includes(b)&&C(e)})),l.push(b),f.push({x:d.position.x,z:d.position.z,radius:Tw,onCollide(){b.state=`ALERT`,c=100,m=!0,r&&r.showToast(`Bumped into a guard!`,1200)}}),e.add(d),b}function E(e,{radius:t=9,duration:n=3.2}={}){if(!e)return 0;let r=0;return _e.position.copy(e),_e.timer=Math.max(_e.timer,n),l.forEach(i=>{if(i.state===`ALERT`)return;let a=e.x-i.group.position.x,o=e.z-i.group.position.z;Math.abs((e.y??i.group.position.y)-i.group.position.y)>2.25||a*a+o*o>t*t||(i.state=`INVESTIGATE`,i.investigateTarget=i.investigateBuffer.set(e.x,i.group.position.y,e.z),i.investigateTimer=n,i.investigateGiveUpTimer=Math.max(9,n+6),i.investigateArrived=!1,i.waitTimer=0,i.lookAroundTimer=0,r+=1)}),r}let O=new we,k=[new R(1,0,0),new R(-1,0,0),new R(0,0,1),new R(0,0,-1)];function A(e,t){let n=null,r=.9;for(let t of k){O.set(e.clone().addScaledVector(t,-.3),t),O.far=r+.3;let a=O.intersectObjects(i,!0)[0];a&&a.distance-.3<r&&(r=a.distance-.3,n=t)}return n?n.clone().negate():new R(Math.sin(t),0,Math.cos(t))}function j({position:t,baseAngle:n=0,sweepRange:r=Math.PI/3,sweepSpeed:i=.8,range:a=9,shielded:o=!1}){let s=new U;s.name=`security-camera`,s.position.copy(t);let c=new x({color:2303786,roughness:.45,metalness:.75}),l=new x({color:3029555,roughness:.4,metalness:.55}),d=new x({color:329224,roughness:.05,metalness:.9}),f=A(t,n),m=new U;m.rotation.y=Math.atan2(f.x,f.z),s.add(m);let h=new z(new K(.26,.34,.04),c);h.position.z=.02,m.add(h);for(let[e,t]of[[-.09,.13],[.09,.13],[-.09,-.13],[.09,-.13]]){let n=new z(new p(.016,.016,.02,6),c);n.rotation.x=Math.PI/2,n.position.set(e,t,.045),m.add(n)}let g=new z(new K(.06,.06,.3),c);g.position.set(0,.1,.19),m.add(g);let _=new z(new K(.04,.04,.3),c);_.position.set(0,-.02,.15),_.rotation.x=-.75,m.add(_);let v=new U;v.position.copy(f).multiplyScalar(.34),v.position.y=.1,s.add(v);let y=new z(new p(.05,.05,.1,10),c);y.position.y=0,v.add(y);let b=new U;b.position.y=-.1,b.rotation.x=.55,v.add(b);let S=new z(new K(.17,.17,.42),l);S.position.z=.08,b.add(S);let C=new z(new K(.23,.02,.5),c);C.position.set(0,.1,.12),b.add(C);let w=new z(new p(.06,.07,.08,14),c);w.rotation.x=Math.PI/2,w.position.z=.32,b.add(w);let T=new z(new G(.05,14),d);T.position.z=.361,b.add(T);let E=new z(new K(.03,.14,.06),c);E.position.set(0,.06,0),v.add(E);let D=new dt({color:3718648}),O=new z(new He(.022,8,6),D);O.position.set(.06,.05,.3),b.add(O);let k=Math.tan(Math.PI/6)*a,j=new qt(k,a,18,1,!0);j.rotateX(-Math.PI/2),j.translate(0,0,a/2);let ee=new dt({color:3718648,transparent:!0,opacity:.2,side:2,depthWrite:!1}),M=new z(j,ee);M.rotation.x=.55,M.position.y=-.1,v.add(M);let N={shielded:o,camGroup:s,pivot:v,ledMat:D,coneMat:ee,coneMesh:M,baseAngle:n,sweepRange:r,sweepSpeed:i,range:a,elapsed:Math.random()*10,clipAge:1/0,clipAngle:1/0,clipPosition:new R(1/0,1/0,1/0)};return u.push(N),e.add(s),N}function ee({position:t,width:n=2.4,height:r=2.2,beamCount:i=4,rotationY:a=0}){let o=new U;o.name=`laser-grid`,o.position.copy(t),o.rotation.y=a;let s=new x({color:988970,metalness:.9,roughness:.2}),c=new z(new K(.15,r,.15),s);c.position.set(-n/2,r/2,0);let l=new z(new K(.15,r,.15),s);l.position.set(n/2,r/2,0),o.add(c,l);let u=pS({beamCount:i}),f=[],m=r/(i+1),h=[],g=new x({color:1705221,emissive:16722458,emissiveIntensity:3.5,roughness:.3}),_=new K(.22,.08,.22),v=new p(.03,.03,.03,10);v.rotateZ(Math.PI/2);for(let e of[-1,1])for(let t of[.04,r]){let r=new z(_,s);r.position.set(e*n/2,t,0),o.add(r)}for(let e=1;e<=i;e++){let t=new z(new p(.014,.014,n,10),u);t.rotation.z=Math.PI/2,t.position.set(0,e*m,0),o.add(t),f.push(t);for(let t of[-1,1]){let r=new z(v,g);r.position.set(t*(n/2-.08),e*m,0),o.add(r),h.push(new R(t*(n/2-.1),e*m,0))}}mS(o,u,h,.45);let y={gridGroup:o,beams:f,laserMat:u,active:!0,bounds:Math.abs(Math.sin(a))>.5?{minX:t.x-.35,maxX:t.x+.35,minZ:t.z-n/2-.2,maxZ:t.z+n/2+.2,minY:t.y,maxY:t.y+r}:{minX:t.x-n/2-.2,maxX:t.x+n/2+.2,minZ:t.z-.35,maxZ:t.z+.35,minY:t.y,maxY:t.y+r},setActive(e){y.active=e,u.customUniforms&&(u.customUniforms.uState.value=+!e),g.emissive.setHex(e?16722458:1096065),g.emissiveIntensity=e?3.5:.8}};return d.push(y),e.add(o),y}let N=new R,P=new R,te=new R,F=new R,ne=new R;function re(){return t?.isCrouching?.()?Dw:Ew}let I=new R,L=new R,ie=new R;function ae(e,t){return e.visual?.getBeamWorldPosition?.(t)?t:t.set(e.group.position.x,e.group.position.y+Ow,e.group.position.z)}function oe(e){if(!e.visual?.getBeamWorldPosition?.(ie)){e.visionCone.position.set(0,Ow,0);return}e.group.worldToLocal(ie),e.visionCone.position.copy(ie)}function se(e,t){if(!t)return!1;ae(e,P),N.set(t.x,t.y+re(),t.z),te.subVectors(N,P);let n=te.length();if(n>(e.state===`ALERT`?10:Cw)||n<.1||(F.set(te.x,0,te.z),F.lengthSq()<1e-6)||(F.normalize(),ne.set(Math.sin(e.facing),0,Math.cos(e.facing)),ne.dot(F)<(e.state===`ALERT`?.3:.52)))return!1;te.normalize(),g.set(P,te),g.far=n;let r=S(C(e,P),!1);for(let e of r)if(e.distance<n-.3)return!1;return!0}let ce=new R,le=new R,ue=new R,de=new R;function fe(e,t){if(!t)return!1;let n=e.camGroup.position,r=t.x-n.x,a=t.z-n.z,o=Math.hypot(r,a);if(o>e.range||o<1)return!1;let s=e.baseAngle+Math.sin(e.elapsed*e.sweepSpeed)*e.sweepRange;if(ue.set(Math.sin(s),0,Math.cos(s)).normalize(),de.set(r,0,a).normalize(),ue.dot(de)<=.72)return!1;ce.copy(n),le.set(t.x,t.y+re(),t.z).sub(ce);let c=le.length();le.normalize(),g.set(ce,le),g.far=c;let l=S(i,!0);for(let e of l)if(e.distance<c-.3)return!1;return!0}function pe(e,t){if(!t||Math.hypot(t.x-e.group.position.x,t.z-e.group.position.z)>kw)return!1;ae(e,P),N.set(t.x,t.y+re(),t.z),te.subVectors(N,P);let n=te.length();if(n<.01)return!0;te.normalize(),g.set(P,te),g.far=n;let r=S(C(e,P),!1);for(let e of r)if(e.distance<n-.3)return!1;return!0}function me(){return t?t.isAirborne&&t.isAirborne()?Iw:t.isCrouching&&t.isCrouching()?Pw:t.isRunning&&t.isRunning()?Fw:1:1}function he(e){if(!e)return!1;for(let t of d){if(!t.active)continue;let n=t.bounds;if(e.x>=n.minX&&e.x<=n.maxX&&e.z>=n.minZ&&e.z<=n.maxZ&&e.y>=n.minY&&e.y<=n.maxY)return!0}return!1}let ge={"guard-bump":4,laser:4,camera:2,"guard-sight":1},_e={position:new R,timer:0};function ve(e,t=.4){if(!e){_e.timer=0;return}_e.position.copy(e),_e.timer=t}function ye(){let e=o?.getMode?.();return e?zw[e]??1:1}function be(e){m=!1;let o=t?.mesh?.position,s=!1,p=null,h=ye(),_=e*h,v=0;_e.timer>0&&(_e.timer=Math.max(0,_e.timer-e));function y(t,n=e){s=!0,v=Math.max(v,n),(!p||ge[t]>=ge[p])&&(p=t)}if(l.forEach(t=>{let n=t.shielded?e:_,r=t.stridePhase,i=se(t,o),s=pe(t,o);(i||s)&&y(`guard-sight`,n);let c=_e.timer>0&&t.distractible&&t.group.position.distanceTo(_e.position)<Lw;if(s){t.state=`ALERT`,t.lookAroundTimer=0;let e=o.x-t.group.position.x,r=o.z-t.group.position.z;t.facing+=(Math.atan2(e,r)-t.facing)*Math.min(1,n*6),t.group.rotation.y=t.facing}else t.state===`ALERT`?(t.lookAroundTimer+=n,t.facing+=Math.sin(t.lookAroundTimer*3)*.02,t.group.rotation.y=t.facing,t.lookAroundTimer>Aw&&(t.state=`PATROL`,t.lookAroundTimer=0)):c&&t.state!==`INVESTIGATE`&&(t.state=`INVESTIGATE`,t.investigateTarget=t.investigateBuffer.copy(_e.position),t.investigateTimer=3.2,t.investigateGiveUpTimer=9.2,t.investigateArrived=!1,t.waitTimer=0,t.lookAroundTimer=0);if(t.state===`ALERT`?(t.coneMat.color.setHex(15680580),t.statusBeacon.material.color.setHex(15680580)):t.state===`INVESTIGATE`?(t.coneMat.color.setHex(3003583),t.statusBeacon.material.color.setHex(3003583)):i?(t.coneMat.color.setHex(16347926),t.statusBeacon.material.color.setHex(16347926)):t.state===`INVESTIGATE`?(t.coneMat.color.setHex(2282478),t.statusBeacon.material.color.setHex(2282478)):(t.coneMat.color.setHex(16436245),t.statusBeacon.material.color.setHex(16436245)),t.state===`INVESTIGATE`&&t.investigateTarget){t.investigateGiveUpTimer-=e;let n=t.investigateTarget,r=n.x-t.group.position.x,i=n.z-t.group.position.z,o=Math.hypot(r,i);if(!t.investigateArrived&&o>Rw){let n=Math.atan2(r,i)-t.facing;for(;n>Math.PI;)n-=Math.PI*2;for(;n<-Math.PI;)n+=Math.PI*2;if(t.facing+=n*Math.min(1,e*ww),t.group.rotation.y=t.facing,Math.abs(n)<=Nw){let n=Math.min(t.speed*1.08*e,o);t.group.position.x+=r/o*n,t.group.position.z+=i/o*n,Ml(t.group.position,a),t.stridePhase+=n*xw}else t.stridePhase*=Math.max(0,1-e*10)}else t.investigateArrived||(t.investigateArrived=!0,t.scanBase=t.facing,t.lookAroundTimer=0),t.lookAroundTimer+=e,t.investigateTimer-=e,t.facing=t.scanBase+Math.sin(t.lookAroundTimer*2.5)*(Math.PI/2.8),t.group.rotation.y=t.facing,t.stridePhase*=Math.max(0,1-e*10);(t.investigateTimer<=0||t.investigateGiveUpTimer<=0)&&(t.state=`PATROL`,t.investigateTarget=null,t.investigateArrived=!1,t.lookAroundTimer=0,t.waitTimer=.5,t.scanBase=t.facing)}if(t.state===`PATROL`&&t.waypoints.length>1){if(t.waitTimer>0){t.waitTimer=Math.max(0,t.waitTimer-n);let e=t.waitTime-t.waitTimer;t.facing=t.scanBase+Math.sin(e*Mw)*jw,t.group.rotation.y=t.facing,t.stridePhase*=Math.max(0,1-n*10)}else{let e=t.waypoints[t.targetIdx],r=e.x-t.group.position.x,i=e.z-t.group.position.z,o=Math.hypot(r,i);if(o<.08)t.group.position.copy(e),t.targetIdx=(t.targetIdx+1)%t.waypoints.length,t.waitTimer=t.waitTime,t.scanBase=t.facing,t.stridePhase=0;else{let e=Math.atan2(r,i)-t.facing;for(;e>Math.PI;)e-=Math.PI*2;for(;e<-Math.PI;)e+=Math.PI*2;if(t.facing+=e*Math.min(1,n*ww),t.group.rotation.y=t.facing,Math.abs(e)<=Nw){let e=Math.min(t.speed*n,o);t.group.position.x+=r/o*e,t.group.position.z+=i/o*e,Ml(t.group.position,a),t.stridePhase+=e*xw}else t.stridePhase*=Math.max(0,1-n*10)}}}else t.stridePhase*=Math.max(0,1-n*10);if(t.visual)t.visual.setWalking(t.stridePhase>r+1e-6),t.visual.update(n),t.group.updateMatrixWorld(!0);else if(t.leftLeg&&t.rightLeg&&t.leftArm&&t.rightArm&&t.body){let e=Math.sin(t.stridePhase)*bw;t.leftLeg.rotation.x=e,t.rightLeg.rotation.x=-e,t.leftArm.rotation.x=-e*.8,t.rightArm.rotation.x=e*.8,t.body.position.y=Math.abs(Math.sin(t.stridePhase))*Sw}oe(t),I.set(Math.sin(t.facing),0,Math.cos(t.facing)),ae(t,L),g.set(L,I),g.far=t.coneDistance;let l=t.coneDistance;for(let e of S(C(t,L),!1))e.distance<l&&(l=e.distance);if(t.visionCone.scale.setScalar(B.clamp(l/t.coneDistance,.05,1)),t.shieldMat){t.shieldPulse+=e*(h<1?9:2.5);let n=h<1?.75:.45;t.shieldMat.opacity=n+Math.sin(t.shieldPulse)*.22}}),o){for(let e=0;e<l.length;e++)f[e].x=l[e].group.position.x,f[e].z=l[e].group.position.z;Nl(o,f),m&&y(`guard-bump`)}u.forEach(t=>{let n=t.shielded?e:_;t.elapsed+=n;let r=t.baseAngle+Math.sin(t.elapsed*t.sweepSpeed)*t.sweepRange;if(t.pivot.rotation.y=r,I.set(Math.sin(r),0,Math.cos(r)),L.copy(t.camGroup.position),g.set(L,I),g.far=t.range,t.clipAge+=e,t.clipAge>=.1||Math.abs(r-t.clipAngle)>=.06||t.clipPosition.distanceToSquared(t.camGroup.position)>=.01){let e=t.range;for(let t of S(i,!0))t.distance<e&&(e=t.distance);t.coneMesh.scale.setScalar(B.clamp(e/t.range,.05,1)),t.clipAge=0,t.clipAngle=r,t.clipPosition.copy(t.camGroup.position)}fe(t,o)?(y(`camera`,n),t.ledMat.color.setHex(15680580),t.coneMat.color.setHex(15680580)):(t.ledMat.color.setHex(3718648),t.coneMat.color.setHex(3718648))}),d.forEach(t=>{t.laserMat?.customUniforms&&(t.laserMat.customUniforms.uTime.value+=e,t.active?t.laserMat.customUniforms.uState.value=c>50?2:0:t.laserMat.customUniforms.uState.value=1)}),he(o)&&(c=100,y(`laser`),r&&r.showToast(`Laser grid tripped! Security alerted!`,1500)),s&&v>0?c=Math.min(100,c+45*v*me()):s||(c=Math.max(0,c-22*e)),c>=100&&(c=0,l.forEach(e=>{e.state=`PATROL`,e.waitTimer=1,e.investigateTarget=null,e.investigateTimer=0,e.investigateGiveUpTimer=0,e.investigateArrived=!1}),n&&n.fail(p??`caught`)),r&&r.setSuspicion&&r.setSuspicion(c)}function xe(){c=0,_e.timer=0,r&&r.setSuspicion&&r.setSuspicion(0)}function V(){xe(),l.forEach(e=>{e.state=`PATROL`,e.waitTimer=0,e.targetIdx=0,e.investigateTarget=null,e.investigateTimer=0,e.investigateGiveUpTimer=0,e.investigateArrived=!1,e.waypoints.length>0&&e.group.position.copy(e.waypoints[0])}),r&&r.setSuspicion&&r.setSuspicion(0)}function Se(){l.forEach(t=>{t.visual&&=(t.group.remove(t.visual.root),t.visual.dispose(),null),e.remove(t.group),Jd(t.group)}),u.forEach(t=>{e.remove(t.camGroup),Jd(t.camGroup)}),d.forEach(t=>{e.remove(t.gridGroup),Jd(t.gridGroup)}),l.length=0,u.length=0,d.length=0,r&&r.setSuspicion&&r.setSuspicion(0)}return{addGuard:T,addCamera:j,addLaserGrid:ee,setDistraction:ve,investigate:E,getSuspicion:()=>c,clearSuspicion:xe,getGuards:()=>l,update:be,reset:V,dispose:Se}}var Vw=.25,Hw=9,Uw=3;function Ww({root:e,roots:t,host:n,size:r=8,accept:i,name:a=`light-pool`,kind:o=`point`}){let s=t&&t.length?t:[e],c=n||e,l=i||(e=>e.isPointLight),u=[];for(let e of s)e&&e.traverse(e=>{!l(e)||e.userData.lightPoolSlot||(e.visible=!1,e.userData.lightPoolSource=!0,u.push({light:e,distance:1/0,wasOn:e.intensity>0}))});let d=o===`spot`,f=[];for(let e=0;e<r;e++){let t=d?new ft(16777215,0,1,Math.PI/4,0,2):new j(16777215,0,1,2);if(t.name=`${a}-${e}`,t.castShadow=!1,t.userData.lightPoolSlot=!0,d){let n=new Ee;n.name=`${a}-target-${e}`,c.add(n),t.target=n}c.add(t),f.push(t)}let p=Array(u.length),m=Array(r),h=new Float64Array(r),g=new R,_=new R,v=new R,y=0,b=!1;function x(e){for(let t=e.parent;t;t=t.parent)if(!t.visible)return!1;return!0}function S(e){return e.light.intensity>0&&!e.light.userData.lightPoolOff&&x(e.light)}function C(e,t){t.getWorldPosition(g),e.parent?(_.copy(g),e.parent.worldToLocal(_),e.position.copy(_)):e.position.copy(g)}function w(e){let t=0;for(let n=0;n<u.length;n++){let r=u[n],i=S(r);if(r.wasOn=i,!i)continue;r.light.getWorldPosition(g);let a=g.x-e.x,o=g.y-e.y,s=g.z-e.z;r.distance=Math.sqrt(a*a+o*o+s*s),p[t++]=r}for(let e=1;e<t;e++){let t=p[e],n=e-1;for(;n>=0&&p[n].distance>t.distance;)p[n+1]=p[n],n--;p[n+1]=t}let n=t>r?p[r].distance:1/0;for(let e=0;e<r;e++){let r=e<t?p[e]:null;m[e]=r,h[e]=!r||n===1/0?+!!r:B.clamp((n-r.distance)/Uw,0,1)}}function T(){for(let e=0;e<r;e++){let t=f[e],n=m[e];if(!n||!S(n)){t.intensity=0;continue}let r=n.light;C(t,r),t.color.copy(r.color),t.distance=r.distance,t.decay=r.decay,t.isSpotLight&&r.target&&(t.angle=r.angle,t.penumbra=r.penumbra,C(t.target,r.target)),t.intensity=r.intensity*h[e]}}function E(e,t=0){y+=t;let n=e.x-v.x,r=e.y-v.y,i=e.z-v.z,a=!b||y>=Vw||n*n+r*r+i*i>=Hw;if(!a){for(let e=0;e<u.length;e++)if(S(u[e])!==u[e].wasOn){a=!0;break}}a&&(w(e),y=0,v.copy(e),b=!0),T()}return{update:E,sourceCount:u.length,size:r}}var Gw=1.65,Kw=2.05;function qw(e,t=e){let n=document.createElement(`canvas`);return n.width=e,n.height=t,n}function Jw(e){let t=qw(e),n=t.getContext(`2d`);n.fillStyle=`#c4baab`,n.fillRect(0,0,e,e);let r=e/4,i=e/6;for(let e=0;e<6;e+=1){let t=e%2?r*.5:0;for(let a=-1;a<=4;a+=1){let o=.9+(e*3+a*5)%7*.018,s=Math.floor(214*o);n.fillStyle=`rgb(${s},${s-6},${s-16})`,n.fillRect(a*r+t+2,e*i+2,r-4,i-4)}}return t}function Yw(e,t){let n=e.width,r=e.getContext(`2d`).getImageData(0,0,n,n).data,i=(e,t)=>{let i=(e+n)%n,a=((t+n)%n*n+i)*4;return(r[a]*.299+r[a+1]*.587+r[a+2]*.114)/255},a=qw(n),o=a.getContext(`2d`),s=o.createImageData(n,n);for(let e=0;e<n;e+=1)for(let r=0;r<n;r+=1){let a=(i(r-1,e)-i(r+1,e))*t,o=(i(r,e-1)-i(r,e+1))*t,c=Math.hypot(a,o,1),l=(e*n+r)*4;s.data[l]=(a/c*.5+.5)*255,s.data[l+1]=(o/c*.5+.5)*255,s.data[l+2]=(1/c*.5+.5)*255,s.data[l+3]=255}return o.putImageData(s,0,0),a}function Xw(e,t,n){let r=new mt(e);return r.wrapS=Oe,r.wrapT=Oe,r.anisotropy=8,r.repeat.set(t[0],t[1]),n&&(r.colorSpace=Me),r}function Zw(){let e=qw(512),t=e.getContext(`2d`);t.fillStyle=`#1a120c`,t.fillRect(0,0,512,512),t.beginPath(),t.arc(256,256,230.4,0,Math.PI*2),t.fillStyle=`#f3e6c8`,t.fill(),t.lineWidth=10,t.strokeStyle=`#c4a56a`,t.stroke();let n=[`XII`,`I`,`II`,`III`,`IV`,`V`,`VI`,`VII`,`VIII`,`IX`,`X`,`XI`];t.fillStyle=`#2a2118`,t.textAlign=`center`,t.textBaseline=`middle`,t.font=`600 42px Georgia, "Times New Roman", serif`;for(let e=0;e<12;e+=1){let r=e/12*Math.PI*2-Math.PI/2,i=174.08;t.fillText(n[e],256+Math.cos(r)*i,256+Math.sin(r)*i)}for(let e=0;e<60;e+=1){let n=e/60*Math.PI*2-Math.PI/2,r=e%5==0?204.8:215.04;t.strokeStyle=`#3a2e22`,t.lineWidth=e%5==0?4:2,t.beginPath(),t.moveTo(256+Math.cos(n)*r,256+Math.sin(n)*r),t.lineTo(256+Math.cos(n)*256*.88,256+Math.sin(n)*256*.88),t.stroke()}return t.beginPath(),t.arc(256,256,8,0,Math.PI*2),t.fillStyle=`#2a2118`,t.fill(),e}function Qw(e,t){return new x({color:1314314,emissive:new q(e),emissiveIntensity:t,roughness:.16,metalness:.05,side:2})}function $w(){let e=Jw(256),t=Yw(e,2.2),n=Xw(e,[1,1],!0),r=Xw(t,[1,1],!1),i=new x({map:n,normalMap:r,roughness:.78,metalness:.04}),a=i.clone();a.roughness=.7;let o=Xw(Zw(),[1,1],!0);return{brickTile:Gw,stoneTile:Kw,brick:Sh({repeat:[1,1],seed:19,brick:9058352,mortar:14274754,roughness:.9}),stone:i,stoneTrim:a,iron:new x({color:1841430,roughness:.42,metalness:.78}),brass:new x({color:11570495,roughness:.32,metalness:.86}),wood:new x({color:2759700,roughness:.72,metalness:.08}),roof:new x({color:2373680,roughness:.48,metalness:.42}),soffit:new x({color:3811864,emissive:16757082,emissiveIntensity:.22,roughness:.6}),glass:[Qw(16756848,.72),Qw(11827272,.32),Qw(6042140,.08),Qw(1052172,0)],archGlass:Qw(12615752,.38),entranceGlass:Qw(16756848,.42),clock:new x({map:o,emissiveMap:o,emissive:16773844,emissiveIntensity:1.7,roughness:.4,metalness:.05,side:2}),cobble:(()=>{let e=eT(256);return new x({map:Xw(e.color,[1,1],!0),normalMap:Xw(e.normal,[1,1],!1),roughnessMap:Xw(e.rough,[1,1],!1),roughness:1,metalness:.14})})(),shrub:new x({color:2372392,roughness:.92}),crate:new x({color:6964784,roughness:.84}),sign:Th({text:`CHRONO EXPRESS`,background:1185296,foreground:15123818,width:1024,height:160,emissiveIntensity:.55}),lantern:Qw(16766882,2.6)}}function eT(e){let t=qw(e),n=qw(e),r=t.getContext(`2d`),i=n.getContext(`2d`),a=e/8,o=e/8;r.fillStyle=`#3a342c`,r.fillRect(0,0,e,e),i.fillStyle=`#c8c8c8`,i.fillRect(0,0,e,e);for(let e=0;e<8;e+=1){let t=e%2?a*.5:0;for(let n=-1;n<=8;n+=1){let s=Math.sin((e+1)*12.1+(n+3)*4.7)*43758.5453,c=s-Math.floor(s),l=Math.floor(78+c*58);r.fillStyle=`rgb(${l+18},${l+8},${l-6})`,r.fillRect(n*a+t+3,e*o+3,a-6,o-6);let u=Math.floor(28+c*36);i.fillStyle=`rgb(${u},${u},${u})`,i.fillRect(n*a+t+3,e*o+3,a-6,o-6)}}return{color:t,normal:Yw(t,3.4),rough:n}}function tT(e){let t=Math.sin(e*12.9898+4.2)*43758.5453,n=t-Math.floor(t);return n<.34?3:n<.58?2:+(n<.82)}var nT=1.18,rT=2.16;function iT(){let e=nT,t=rT,n=.055,r=.07,i=.02;return g_([$(r,t,n,i,0,-.5625),$(r,t,n,i,0,e/2-n/2),$(r,n,e,i,t/2-n/2,0),$(r,n,e-n*2,i,-1.0525,0),$(r*.65,t-n*2,n*.48,.008,0,0),$(r*.65,n*.48,e-n*2,.008,t*.14,0),$(r*.65,n*.48,e-n*2,.008,-2.16*.2,0)])}function aT(){let e=1.46,t=2.3800000000000003,n=.1,r=.12,i=1.35;return g_([$(r,t,n,-.02,.04,-.6799999999999999,i),$(r,t,n,-.02,.04,e/2-n/2,i),$(r,n,e,-.02,1.1800000000000002,0,i),$(.18,.08,1.54,-.01,-1.1700000000000002,0,i)])}function oT(){let e=new Ot(1.04,2.02);return e.rotateY(Math.PI/2),e.translate(.045,0,0),e}function sT(e,t,n,r){let i=[[],[],[],[]],a=[],o=[];t.forEach((e,t)=>{let n=h_(e.x,e.y,e.z,e.yaw||0,e.scale||1);a.push(n),o.push(n),i[e.shade??0].push(n.clone())}),v_(e,aT(),n.stoneTrim,a,{name:`landing-window-surrounds`,receiveShadow:!0},r),v_(e,iT(),n.iron,o,{name:`landing-window-frames`},r);let s=oT();i.forEach((t,i)=>{v_(e,s.clone(),n.glass[i],t,{name:`landing-window-glass-${i}`},r)}),s.dispose()}var cT=nm-rm,lT=nm+rm,uT=6.2,dT=4.7,fT=4.72;function pT(e,t,n){let r=Math.max(1,Math.round((t-e)/n)),i=(t-e)/r,a=[];for(let t=0;t<r;t+=1)a.push(e+i*(t+.5));return a}function mT(e){let t=Math.abs(e-nm);return t>=4.62?uT:uT+Math.sqrt(dT*dT-t*t)}function hT(e){if(e<=uT)return 4.58;let t=e-uT;return t>=4.62?0:Math.sqrt(Math.max(0,dT*dT-t*t))-.12}function gT(){let e=new It,t=4.42;e.moveTo(-4.42,fT),e.lineTo(-4.42,uT),e.absarc(0,uT,t,Math.PI,0,!0),e.lineTo(t,fT),e.closePath();let n=new yt(e,20);return n.rotateY(Math.PI/2),n.translate(X+.16,0,nm),n}function _T(){let e=new G(1.72,40);return e.rotateY(Math.PI/2),e.translate(X-.08,8.75,nm),e}function vT(){let e=new Tt(1.86,.07,8,36);return e.rotateY(Math.PI/2),e.translate(X-.1,8.75,nm),e}function yT(e,t,n){let r=[],i=[],a=[],o=[],s=[],c=[],l=[],u=t.brickTile,d=t.stoneTile,f=pT(em+1.15,cT-.7,2.35),m=pT(lT+.7,tm-1.15,2.35),h=[{y:2.48},{y:6.32},{y:9.92}];function g(e,t){let n=t-e,i=(e+t)/2;r.push($($p,im,n,X+$p/2+.15,im/2,i,u)),a.push($(.34,.62,n+.2,X-.02,.31,i,d));for(let e of[4.48,8.22,im+.02])a.push($(.46,.2,n+.3,X-.12,e,i,d));a.push($(.4,am-im,n,X+.02,(im+am)/2,i,d)),a.push($(.62,.16,n+.4,X-.08,am,i,d)),s.push($($p+.7,.16,n+.15,X+$p/2+.1,im+.08,i))}g(em,cT),g(lT,tm);function _(e,t,n=.42){i.push($(.38,t,n,X-.06,t/2,e,d)),a.push($(.46,.16,n+.12,X-.1,t-.02,e,d))}for(let e of[em+.28,cT-.28,lT+.28,tm-.28])_(e,am,.55);function v(e){let t=[];for(let n=0;n<e.length-1;n+=1)t.push((e[n]+e[n+1])/2);return t}for(let e of[...v(f),...v(m)])_(e,im-.15,.22);function y(e,t){let n=X+$p/2+.15;r.push($($p,im,.45,n,im/2,e,u)),a.push($($p+.3,.2,.4,n,im+.02,e,d));let i=[];for(let n of h)i.push({x:X+$p*.38,y:n.y,z:e+t*.24,yaw:t>0?Math.PI/2:-Math.PI/2,shade:tT(e*3+n.y)});return i}let b=[],x=0;for(let e of[...f,...m])for(let t of h)b.push({x:X-.02,y:t.y,z:e,yaw:0,shade:tT(x)}),x+=1;b.push(...y(em+.22,-1)),b.push(...y(tm-.22,1));let S=pT(em+3,tm-3,4.2);for(let e of S)for(let t of h.slice(0,2))b.push({x:X+$p+.28,y:t.y,z:e,yaw:Math.PI,shade:tT(e+t.y*2)});r.push($(.45,im,tm-em,X+$p+.15,im/2,nm,u));let C=(lT-cT-dT*2)/2;i.push($($p,om,C,X+$p/2,om/2,cT+C/2,d)),i.push($($p,om,C,X+$p/2,om/2,lT-C/2,d));let w=10.9;i.push($($p*.92,om-w,9.8,X+$p*.46,(om+w)/2,nm,d)),i.push($(.4,om,lT-cT,X+$p-.15,om/2,nm,d)),i.push($(.55,.7,9.6,X+.15,4.35,nm,d));for(let e of[{y:13.15,h:1.15,inset:.35},{y:14.45,h:1.2,inset:1.15},{y:15.75,h:1.05,inset:2.05},{y:16.85,h:.7,inset:2.9}])i.push($($p*.72,e.h,lT-cT-e.inset*2,X+$p*.36,e.y,nm,d));s.push($($p+.4,.14,lT-cT+.5,X+$p/2,om+.08,nm));for(let e of[-1,1]){let t=nm+e*5.25;for(let n=0;n<7;n+=1){let r=t+e*n*.22;a.push($(.1,10.4,.08,X-.1,10.2,r,d))}}let T=new Tt(dT,.22,8,28,Math.PI);T.rotateY(Math.PI/2),T.translate(X-.06,uT,nm),i.push(T);for(let e of[-1,1])i.push($(.42,5.8,.48,X-.08,3.3,nm+e*dT,d));a.push($(.5,.36,.7,X-.12,mT(nm)+.05,nm,d));for(let e=nm-dT+.55;e<=nm+dT-.5;e+=.72){let t=mT(e)-.2-fT;t<.4||o.push($(.06,t,.045,X-.02,fT+t/2,e))}for(let e of[6.15,7.85,9.45]){let t=hT(e);t<.3||o.push($(.06,.045,t*2,X-.02,e,nm))}for(let e of[em+2.4,cT-1.6,lT+1.6,tm-2.4])r.push($(.7,2.15,.7,X+3.2,im+1.2,e,u)),a.push($(.92,.16,.92,X+3.2,im+2.28,e,d));__(e,g_(r),t.brick,{castShadow:!0,receiveShadow:!0,name:`landing-brick`},n),__(e,g_(i),t.stone,{castShadow:!0,receiveShadow:!0,name:`landing-stone`},n),__(e,g_(a),t.stoneTrim,{receiveShadow:!0,name:`landing-stone-trim`},n),__(e,g_(o),t.iron,{name:`landing-mullions`},n),__(e,g_(s),t.roof,{castShadow:!0,name:`landing-roof`},n),__(e,gT(),t.archGlass,{name:`landing-arch-glass`},n),__(e,$(.2,8.4,dT*1.7,X+2.4,8.6,nm),t.archGlass,{name:`landing-hall-glow`},n),__(e,_T(),t.clock,{name:`landing-clock`},n),__(e,vT(),t.brass,{name:`landing-clock-rim`},n);let E=new U,D=t.iron,O=new z(new K(.045,1.05,.07),D);O.geometry.translate(0,.48,0),O.rotation.x=-55*Math.PI/180,O.castShadow=!1;let k=new z(new K(.035,1.45,.06),D);k.geometry.translate(0,.68,0),k.rotation.x=60*Math.PI/180;let A=new z(new p(.07,.07,.08,10),t.brass);A.rotation.z=Math.PI/2,E.add(O,k,A),E.position.set(X-.16,8.75,nm),e.add(E),n.draws+=3,n.triangles+=44,sT(e,b,t,n);let ee=1.38,M=[-1,0,1].map(e=>nm+e*1.7999999999999998);for(let e of M)c.push($(.12,3.15,.1,X-.02,2.15,e-ee/2)),c.push($(.12,3.15,.1,X-.02,2.15,e+ee/2)),c.push($(.12,.1,ee,X-.02,3.68,e)),c.push($(.08,1.35,1.2,X-.04,1.25,e)),c.push($(.06,3.05,.05,X-.05,2.1,e)),l.push($(.04,1.45,1.0999999999999999/2-.04,X-.06,2.75,e-ee*.22)),l.push($(.04,1.45,1.0999999999999999/2-.04,X-.06,2.75,e+ee*.22)),l.push($(.04,.42,1.22,X-.06,3.95,e));__(e,g_(c),t.wood,{name:`landing-doors`},n),__(e,g_(l),t.entranceGlass,{name:`landing-door-glass`},n);let N=nm,P=6.08,te=[];te.push($(3.7,.16,P,X-1.7,4.42,N)),te.push($(.12,.55,P,X-3.5,4.15,N)),__(e,g_(te),t.roof,{castShadow:!0,receiveShadow:!0,name:`landing-canopy`},n),__(e,$(3.3,.06,5.78,X-1.65,4.3,N),t.soffit,{name:`landing-soffit`},n);for(let r of[-1,1])__(e,$(.32,4.2,.32,X-3.15,2.1,N+r*(P/2-.2),d),t.stone,{castShadow:!0,name:`landing-canopy-pier`},n);let F=new z(new Ot(6.6,.78),t.sign);F.rotateY(-Math.PI/2),F.position.set(X-3.58,4.15,N),F.name=`landing-sign`,e.add(F),n.draws+=1,n.triangles+=2;let ne=[];for(let e=0;e<4;e+=1){let t=.72,n=X-.35-e*t;ne.push($(t,.16+e*.02,5.68+e*.35,n-t/2,.1+(3-e)*.14,N,d))}__(e,g_(ne),t.stone,{castShadow:!0,receiveShadow:!0,name:`landing-steps`},n);let re=[];for(let e of[-1,1]){let t=N+e*3.19;re.push($(2.6,.06,.06,X-1.7,1.05,t)),re.push($(.06,.85,.06,X-.5,.55,t)),re.push($(.06,.55,.06,X-2.9,.4,t))}__(e,g_(re),t.iron,{name:`landing-step-rails`},n);let I=[];for(let e of[-1,1])I.push({x:X-1.2,y:2.25,z:N+e*3.19,light:!0,color:16761994,intensity:12,distance:4.5});for(let e of[f[0],f[f.length-1],m[0],m[m.length-1]])I.push({x:X-.28,y:3.15,z:e,light:!1}),I.push({x:X-.28,y:7.15,z:e,light:!1});let L=new j(16758122,8,4.4,2);L.name=`landing-canopy-light`,L.castShadow=!1,L.position.set(X-1.8,3.6,N),e.add(L);let ie=new j(16756832,6,3.2,2);return ie.name=`landing-door-spill`,ie.castShadow=!1,ie.position.set(X-2.35,1.2,N),e.add(ie),Cv(e,I,t,n),bT(P)}function bT(e){let t=[{minX:X-.25,maxX:X+$p,minZ:em-.3,maxZ:tm+.3}],n=.72,r=1/0,i=-1/0,a=1/0,o=-1/0;for(let t=0;t<4;t+=1){let s=X-.35-t*n-n/2,c=e-.4+t*.35;r=Math.min(r,s-n/2),i=Math.max(i,s+n/2),a=Math.min(a,nm-c/2),o=Math.max(o,nm+c/2)}t.push({minX:r,maxX:i,minZ:a,maxZ:o});for(let n of[-1,1]){let r=nm+n*(e/2-.2);t.push({minX:X-3.35,maxX:X-2.95,minZ:r-.2,maxZ:r+.2})}return t}function xT(){let e=[];for(let t=0;t<4;t+=1)e.push($(.08,.045,1.45,-.12+t*.1,.48,0));for(let t=0;t<3;t+=1)e.push($(.045,.1,1.4,.22,.66+t*.14,0));return g_(e)}function ST(){let e=[];for(let t of[-.58,.58])e.push($(.06,.48,.06,-.16,.24,t)),e.push($(.06,.48,.06,.16,.24,t)),e.push($(.4,.04,.05,0,.46,t)),e.push($(.05,.42,.05,.2,.7,t));return e.push($(.05,.05,1.2,.2,.92,0)),g_(e)}function CT(e,t,n,r){let i=[],a=[];for(let e of t){let t=h_(e.x,e.y,e.z,e.yaw||0);i.push(t),a.push(t.clone())}v_(e,xT(),n.crate,i,{name:`landing-benches`},r),v_(e,ST(),n.iron,a,{name:`landing-bench-frames`},r)}var wT=4.95,TT=.62,ET=.82;function DT(e,t,n){let r=[],i=new p(.1,.15,3.7,12);i.translate(0,t+.95+1.85,0),r.push(i);for(let e of[{h:1.05,r:.22,t:.12},{h:1.32,r:.17,t:.06},{h:3.2,r:.14,t:.05},{h:4.62,r:.18,t:.08}]){let n=new p(e.r,e.r,e.t,12);n.translate(0,t+e.h,0),r.push(n)}let a=new qt(.09,.42,10);a.translate(0,t+5.42,0),r.push(a);let o=new He(.09,10,8);o.translate(0,t+5.15,0),r.push(o);for(let e=0;e<3;e+=1){let n=e/3*Math.PI*2+Math.PI/6,i=Math.cos(n),a=Math.sin(n),o=new K(TT,.05,.05);o.translate(TT/2,0,0),o.rotateY(-n),o.translate(0,t+4.66,0),r.push(o);let s=new Tt(.12,.02,6,14,Math.PI*1.5);s.rotateY(-n+Math.PI/2),s.translate(i*TT*.5,t+4.52,a*TT*.5),r.push(s);let c=i*TT,l=a*TT;for(let[e,n]of[[-.1,-.1],[.1,-.1],[-.1,.1],[.1,.1]])r.push($(.04,.32,.04,c+e,t+wT,l+n));r.push($(.26,.05,.26,c,t+wT+.18,l)),r.push($(.2,.04,.2,c,t+wT-.17,l));let u=new qt(.17,.16,4);u.rotateY(Math.PI/4),u.translate(c,t+wT+.28,l),r.push(u)}let s=g_(r);return s.translate(e,0,n),s}function OT(e,t,n){let r=[];for(let i=0;i<3;i+=1){let a=i/3*Math.PI*2+Math.PI/6;r.push($(.16,.28,.16,e+Math.cos(a)*TT,t+wT,n+Math.sin(a)*TT))}return g_(r)}function kT(e,t,n,r){let{x:i,y:a,z:o}=t,s=n.stoneTile;__(e,g_([$(1.64,.22,1.64,i,a+.11,o,s),$(1.24,.5,1.24,i,a+.47,o,s),$(1.36,.1,1.36,i,a+.77,o,s),$(.62,.16,.62,i,a+.9,o,s)]),n.stone,{castShadow:!0,receiveShadow:!0,name:`landing-centre-plinth`},r),__(e,DT(i,a,o),n.iron,{name:`landing-centre-lamp`},r);let c=n.lantern.clone();c.emissiveIntensity=5,__(e,OT(i,a,o),c,{name:`landing-centre-glow`},r);let l=new j(16757864,90,9,2);l.name=`landing-centre-light`,l.castShadow=!1,l.position.set(i,a+wT,o),e.add(l)}function AT(){let e=new p(.07,.1,3.55,8);return e.translate(0,1.95,0),g_([$(.42,.12,.42,0,.06,0),$(.28,.1,.28,0,.16,0),e,$(.22,.08,.22,0,3.78,0),$(.16,.34,.16,0,4.15,0),$(.2,.06,.2,0,4.34,0)])}function jT(){return g_([$(.05,.28,.05,-.1,4.12,-.1),$(.05,.28,.05,.1,4.12,-.1),$(.05,.28,.05,-.1,4.12,.1),$(.05,.28,.05,.1,4.12,.1),$(.24,.04,.24,0,4.28,0)])}function MT(){return $(.14,.2,.14,0,4.12,0)}function NT(e,t,n,r){let i=[],a=[],o=[],s=[];for(let e of t){let t=h_(e.x,e.y,e.z,e.yaw||0);i.push(t),a.push(t.clone()),e.flicker?s.push(t.clone()):o.push(t.clone())}let c=n.lantern.clone();if(c.emissiveIntensity=5,v_(e,AT(),n.iron,i,{name:`landing-lamp-posts`},r),v_(e,jT(),n.iron,a,{name:`landing-lamp-cages`},r),v_(e,MT(),c,o,{name:`landing-lamp-glow`},r),!s.length)return null;let l=c.clone();return v_(e,MT(),l,s,{name:`landing-lamp-flicker-glow`},r),l}function PT(){return g_([$(.85,.55,.85,0,.28,0,1.2),$(.98,.08,.98,0,.58,0,1.2),$(.7,.08,.7,0,.08,0,1.2)])}function FT(){let e=new He(.36,10,8);e.translate(0,.98,0);let t=new He(.22,8,6);return t.translate(.16,.82,.08),g_([e,t])}function IT(e,t,n,r){let i=[],a=[];for(let e of t){let t=h_(e.x,e.y,e.z,e.yaw||0);i.push(t),a.push(t.clone())}v_(e,PT(),n.stoneTrim,i,{receiveShadow:!0,name:`landing-planters`},r),v_(e,FT(),n.shrub,a,{name:`landing-shrubs`},r)}var LT=pm.minX,RT=pm.maxX,zT=pm.minZ,BT=pm.maxZ;function VT(e,t,n){let r=RT-LT,i=BT-zT,a=r/1,o=i/1;for(let e of[t.cobble.map,t.cobble.normalMap,t.cobble.roughnessMap])e.repeat.set(a,o),e.anisotropy=4;let s=new Ot(r,i);s.rotateX(-Math.PI/2),s.translate((LT+RT)/2,.045,(zT+BT)/2),__(e,s,t.cobble,{receiveShadow:!0,name:`landing-plaza`},n),__(e,$(.45,1.35,i,LT+.1,-.55,(zT+BT)/2,1.6),t.stone,{castShadow:!0,receiveShadow:!0,name:`landing-quay`},n)}function HT(e,t,n){let r=[],i=[];for(let e of XT)r.push($(e.w,e.h,e.d,e.x,e.y,e.z)),i.push($(e.w+.02,.04,.04,e.x,e.y,e.z+e.d/2)),i.push($(e.w+.02,.04,.04,e.x,e.y,e.z-e.d/2));let a=$(.85,.38,.48,20.8,.22,24.9),o=new p(.24,.24,.85,10,1,!1,0,Math.PI);o.rotateZ(Math.PI/2),o.translate(20.8,.41,24.9),r.push(a,o),i.push($(.9,.04,.04,20.8,.4,25.14)),__(e,g_(r),t.crate,{name:`landing-luggage`},n),__(e,g_(i),t.iron,{name:`landing-luggage-straps`},n)}function UT(e,t,n){let r=$(6.2,.14,12.5,13.4,5.15,33.2),i=ZT.map(e=>$(.16,5.1,.16,e.x,2.55,e.z));__(e,r,t.roof,{castShadow:!0,name:`landing-shelter`},n),__(e,g_(i),t.iron,{name:`landing-shelter-posts`},n)}var WT=[{x:9.55,y:.05,z:9.4,flicker:!0},{x:9.55,y:.05,z:17.8}],GT=[{x:16.2,y:.05,z:13.4},{x:16.2,y:.05,z:2*nm-13.4}],KT={centre:2.1,entrance:1.55,steps:.75},qT=[{x:GT[0].x,z:GT[0].z,radius:5.6,strength:KT.centre},{x:WT[0].x,z:WT[0].z,radius:4.3,strength:KT.entrance},{x:WT[1].x,z:WT[1].z,radius:4.3,strength:KT.entrance},{x:19.3,z:18.6,radius:3.4,strength:KT.steps},{x:GT[1].x,z:GT[1].z,radius:5.6,strength:KT.centre}],JT=[{x:18.4,y:.05,z:8.6},{x:18.4,y:.05,z:28.8},{x:16.2,y:.05,z:4.6,yaw:.4}],YT=[{x:20.2,y:.05,z:14.6},{x:20.2,y:.05,z:22.6},{x:19.4,y:.05,z:6.2},{x:19.4,y:.05,z:31.2},{x:17.2,y:.05,z:2.4}],XT=[{w:.7,h:.55,d:.55,x:21.6,y:.28,z:13.4},{w:.5,h:.4,d:.48,x:21.9,y:.75,z:13.15},{w:.62,h:.48,d:.5,x:21.5,y:.25,z:24.2},{w:.4,h:.32,d:.4,x:21.2,y:.64,z:24.45}],ZT=[{x:10.6,z:27.4},{x:16.1,z:27.4},{x:10.6,z:38.6},{x:16.1,z:38.6}];function QT(e,t,n,r,i=0,a=.12){let o=Math.abs(Math.cos(i)),s=Math.abs(Math.sin(i)),c=n*o+r*s+a,l=n*s+r*o+a;return{minX:e-c,maxX:e+c,minZ:t-l,maxZ:t+l}}function $T(){let e=[];for(let t of WT)e.push(QT(t.x,t.z,.24,.24));for(let t of GT)e.push(QT(t.x,t.z,ET,ET,0,.06));for(let t of JT)e.push(QT(t.x,t.z,.28,.78,t.yaw||0));for(let t of YT)e.push(QT(t.x,t.z,.52,.52));for(let t of XT)e.push({minX:t.x-t.w/2,maxX:t.x+t.w/2,minZ:t.z-t.d/2,maxZ:t.z+t.d/2});e.push({minX:20.35,maxX:21.3,minZ:24.6,maxZ:25.2});for(let t of ZT)e.push(QT(t.x,t.z,.16,.16,0,.06));return e.push({minX:pm.minX-.85,maxX:pm.minX+.05,minZ:pm.minZ+.2,maxZ:pm.maxZ-.2}),e}function eE(e,t,n){VT(e,t,n),HT(e,t,n),UT(e,t,n);let r=NT(e,WT,t,n);for(let r of GT)kT(e,r,t,n);let i=w_(e,qT,t.cobble.map,n);CT(e,JT,t,n),IT(e,YT,t,n);let a=c_({height:12,size:2.6});a.points.position.set(4.2,7,26.4),e.add(a.points),n.draws+=1;let o=0;function s(e){if(o+=e,a.update(e),r){let e=Math.sin(o*2.3),t=Math.sin(o*7.1+1.4),n=Math.sin(o*14.2+Math.sin(o*.6)*3),a=e*.45+t*.35+n*.3,s=.72+.28*(.5+.5*t);a>.62?s*=.08:a>.38&&(s*=.4),r.emissiveIntensity=5*Math.max(.12,s),i.setStrength(1,KT.entrance*s)}}return{update:s,pools:i,colliders:$T()}}var tE=.4,nE=.3,rE=null;function iE(){if(rE)return rE;let e=document.createElement(`canvas`);e.width=128,e.height=128;let t=e.getContext(`2d`);t.fillStyle=`#d8cfba`,t.fillRect(0,0,128,128),t.fillStyle=`#8a1a12`;for(let e of[-128,0,128])t.beginPath(),t.moveTo(e,128),t.lineTo(e+64,128),t.lineTo(e+128,0),t.lineTo(e+64,0),t.closePath(),t.fill();let n=new mt(e);return n.wrapS=Oe,n.wrapT=Oe,n.colorSpace=Me,rE=new x({map:n,roughness:.78}),rE}function aE(e){let t=[],n=e/2-.16;for(let e of[-n,n]){for(let n of[-1,1]){let r=new K(.06,1.12,.06);r.rotateX(-n*nE),r.translate(e,.53,n*.165),t.push(r)}t.push($(.08,.07,.22,e,1.06,0)),t.push($(.04,.04,.56,e,.32,0))}return t}function oE(e){return[$(e,.2,.03,0,.96,.06,tE),$(e,.18,.03,0,.6,.18,tE)]}function sE(e,t,n,r,i){let a=[],o=[],s=[],c=[],l=[],u=[],d=new Ve;for(let e of t){let t=aE(e.length),n=oE(e.length),r=[],i=[],f=[];if(e.sign){for(let e of[-.5,.5])t.push($(.04,.3,.03,e,1.18,.06));let e=new Ot(1.5,.42);e.translate(0,1.42,.08),r.push(e)}if(e.lantern){let t=e.length/2-.16;i.push($(.13,.03,.13,t,1.11,0),$(.14,.03,.14,t,1.28,0));for(let[e,n]of[[-1,-1],[1,-1],[-1,1],[1,1]])i.push($(.015,.15,.015,t+e*.055,1.195,n*.055));let n=new Tt(.045,.008,4,10,Math.PI);n.translate(t,1.3,0),i.push(n),f.push($(.085,.13,.085,t,1.195,0))}let p=h_(e.x,e.y,e.z,e.yaw||0);d.makeEmpty();for(let e of[...t,...n,...r,...i,...f])e.applyMatrix4(p),e.computeBoundingBox(),d.union(e.boundingBox);u.push({minX:d.min.x,maxX:d.max.x,minZ:d.min.z,maxZ:d.max.z}),a.push(...t),o.push(...n),s.push(...r),c.push(...i),l.push(...f)}if(__(e,g_(a),n.wood,{castShadow:!0,name:`landing-barricade-trestles`},r),__(e,g_(o),iE(),{castShadow:!0,receiveShadow:!0,name:`landing-barricade-boards`},r),s.length){let t=Th({text:i,background:14208954,foreground:2757132,width:1024,height:288,emissiveIntensity:.12});__(e,g_(s),t,{name:`landing-barricade-sign`},r)}if(c.length){__(e,g_(c),n.iron,{name:`landing-barricade-lantern`},r);let t=new x({color:1705476,emissive:16723992,emissiveIntensity:2.4,roughness:.2});__(e,g_(l),t,{name:`landing-barricade-lantern-glass`},r)}return u}var cE=[1714212,2891290,1448738];function lE(){return g_([$(1.48,.42,4.05,0,.62,0),$(1.32,.38,1.55,0,.95,1.05),$(1.38,.62,1.45,0,1.22,-.35),$(1.22,.1,1.15,0,1.56,-.32),$(1.28,.36,.72,0,.92,-1.55),$(1.5,.08,.9,0,.48,1.85),$(1.5,.08,.55,0,.46,-1.85)])}function uE(){let e=[];for(let t of[-.72,.72])for(let n of[1.25,-1.25]){let r=new p(.36,.36,.16,12);r.rotateZ(Math.PI/2),r.translate(t,.36,n),e.push(r);let i=new He(.42,8,6,0,Math.PI*2,0,Math.PI/2);i.scale(1,.7,1.15),i.translate(t,.5,n),e.push(i)}return e.push($(1.62,.06,2.3,0,.32,0)),e.push($(.9,.42,.06,0,.78,1.82)),e.push($(1.15,.38,.04,0,1.28,-.35)),e.push($(1.15,.32,.04,0,1.28,-1.05)),g_(e)}function dE(){let e=[];for(let t of[-.48,.48]){let n=new He(.1,8,6);n.translate(t,.72,2.02),e.push(n)}return g_(e)}function fE(){let e=[];for(let t of[-.72,.72])for(let n of[1.25,-1.25]){let r=new p(.12,.12,.18,8);r.rotateZ(Math.PI/2),r.translate(t,.36,n),e.push(r)}return e.push($(.55,.22,.04,0,.72,2.04)),g_(e)}function pE(e,t,r,i){let a=[],o=[],s=[],c=[],l=new Float32Array(t.length*3);t.forEach((e,t)=>{let r=new h().compose(new R(e.x,e.y,e.z),new n().setFromAxisAngle(new R(0,1,0),e.yaw||0),new R(1,1,1));a.push(r),o.push(r.clone()),s.push(r.clone()),c.push(r.clone());let i=new q(cE[t%cE.length]);l[t*3]=i.r,l[t*3+1]=i.g,l[t*3+2]=i.b});let u=r.roof.clone();u.color.set(16777215),u.roughness=.32,u.metalness=.55;let d=v_(e,lE(),u,a,{castShadow:!0,receiveShadow:!0,name:`landing-cars`},i);d&&(d.instanceColor=new Ye(l,3)),v_(e,uE(),r.iron,o,{name:`landing-car-dark`},i),v_(e,dE(),r.lantern,s,{name:`landing-car-lamps`},i),v_(e,fE(),r.brass,c,{name:`landing-car-chrome`},i)}var mE={minZ:10.1,maxZ:17.1,endX:-30},hE=3.9,gE=3.3,_E=.74,vE=new R(0,1,0),yE=36,bE=8.4,xE=new Set([5,23]);function SE(e){return hE+gE*(e-1)+.5}function CE(e,t,n){let r=new R(e[0],0,e[1]),i=new R().crossVectors(vE,r);return{matrix:new h().makeBasis(i,vE,r).setPosition(t,0,n),yaw:Math.atan2(r.z,-r.x)}}function wE(e,t,n){t.applyMatrix4(n.matrix),e.push(t)}function TE(){return{brick:[],trim:[],stone:[],wood:[],awning:[],glass:[[],[],[],[]],openings:[],signs:[]}}var EE=0;function DE(){let e=EE;return EE+=1,xE.has(e)?1:e*7%9==0?2:3}function OE(e,t,n,r,i){let a=Math.max(1,Math.floor(r/2.1)),o=r/a,s=new R;for(let r=1;r<i;r+=1){let i=hE+gE*(r-1)+1.72;for(let r=0;r<a;r+=1)s.set(n+o*(r+.5),i,.07).applyMatrix4(t.matrix),e.openings.push({x:s.x,y:s.y,z:s.z,yaw:t.yaw,scale:_E,shade:DE()})}}function kE(e,t,n,r,i,a){let o=n+r/2,s=r-.7;wE(e.wood,$(s,.58,.16,o,3.42,.08),t),wE(e.wood,$(s,.62,.1,o,.31,.05),t);let c=1.05,l=n+.35+c/2;wE(e.wood,$(c,2.55,.08,l,1.28,.02),t);let u=n+.35+c+.12,d=n+r-.35-u;if(d>.6){let n=Math.max(1,Math.round(d/1.25)),r=d/n,a=i.shopShade??3;for(let i=0;i<n;i+=1){let n=u+r*(i+.5);wE(e.glass[a],$(r-.08,2.35,.04,n,1.8,.04),t),wE(e.wood,$(.07,2.4,.08,u+r*i,1.8,.05),t)}wE(e.wood,$(d,.07,.08,u+d/2,2.62,.05),t)}for(let i of[n+.18,n+r-.18])wE(e.stone,$(.36,hE,.16,i,hE/2,.08,a.stone),t);if(i.awning){let n=new K(s-.3,.05,1.35);n.rotateX(.38),n.translate(o,3,.64),wE(e.awning,n,t),wE(e.awning,$(s-.3,.24,.03,o,2.66,1.26),t)}if(i.sign){let n=new Ot(Math.min(s-.4,3.6),.48);n.translate(o,3.42,.17),n.applyMatrix4(t.matrix),e.signs.push({geometry:n,text:i.sign})}}function AE(e,t,n,r,i){let a=0;for(let o of n){let n=o.width,s=SE(o.storeys),c=a+n/2;o.mass!==!1&&(wE(e.brick,$(n,s,r,c,s/2,-r/2,i.brick),t),Math.round(a*10)%3==0&&wE(e.brick,$(.6,1.6,.6,c+n*.2,s+.5,-r*.55,i.brick),t)),o.plain||(wE(e.trim,$(n+.04,.2,.14,c,hE,.07,i.stone),t),wE(e.trim,$(n+.12,.22,.34,c,s-.62,.15,i.stone),t),wE(e.trim,$(n+.04,.12,.4,c,s+.06,-.12,i.stone),t),OE(e,t,a,n,o.storeys),o.shop&&kE(e,t,a,n,o,i)),a+=n}}function jE(e,t,n,r,i){let a=mE.endX,o=pm.minX,s=o-a,c=mE.maxZ-mE.minZ,l=new Ot(s,c);l.rotateX(-Math.PI/2),l.translate((a+o)/2,.045,(mE.minZ+mE.maxZ)/2);let u=l.attributes.position,d=l.attributes.uv,f=pm.maxX-pm.minX,m=pm.maxZ-pm.minZ;for(let e=0;e<u.count;e+=1)d.setXY(e,(u.getX(e)-pm.minX)/f,(pm.maxZ-u.getZ(e))/m);__(e,l,n.cobble,{receiveShadow:!0,name:`landing-street`},r);for(let e of[mE.minZ+.75,mE.maxZ-.75])t.stone.push($(s-.2,.15,1.5,(a+o)/2-.1,.075,e,i.stone));let h=[];for(let e=mE.minZ+.6;e<=mE.maxZ-.5;e+=1.15)h.push(h_(pm.minX+.25,pm.y,e));let g=new p(.09,.12,.9,8);g.translate(0,.45,0),v_(e,g,n.iron,h,{name:`landing-bollards`},r);let _=new dt({color:0,transparent:!0,opacity:.4,depthWrite:!1,fog:!1}),v=[];for(let e of[-4,-10,-16,-22,-27]){let t=new Ot(c,13);t.rotateY(Math.PI/2),t.translate(e,6.5,(mE.minZ+mE.maxZ)/2),v.push(t)}__(e,g_(v),_,{name:`landing-street-veil`},r)}var ME=[{x:3.2,y:.05,z:12.35,yaw:Math.PI/2},{x:-2.4,y:.05,z:12.35,yaw:Math.PI/2},{x:-8.1,y:.05,z:12.35,yaw:Math.PI/2},{x:-13.8,y:.05,z:12.35,yaw:Math.PI/2},{x:-19.6,y:.05,z:12.35,yaw:Math.PI/2},{x:.2,y:.05,z:14.85,yaw:-Math.PI/2},{x:-5.6,y:.05,z:14.85,yaw:-Math.PI/2},{x:-11.3,y:.05,z:14.85,yaw:-Math.PI/2},{x:-20.4,y:.05,z:14.85,yaw:-Math.PI/2}],NE=`STATION CLOSED - BY ORDER OF CHRONO RAIL CO.`,PE=[{x:7.35,y:.045,z:12.65,yaw:Math.PI/2+.05,length:2,sign:!0},{x:7,y:.045,z:14.6,yaw:Math.PI/2-.08,length:2,lantern:!0},{x:7.7,y:.15,z:10.85,yaw:Math.PI/2,length:1.3},{x:7.7,y:.15,z:16.35,yaw:Math.PI/2,length:1.3}];function FE(){let e=pm.minZ,t=pm.maxZ;return[{minX:bE,maxX:yE,minZ:e-9.4,maxZ:e},{minX:pm.maxX-.05,maxX:yE,minZ:e,maxZ:-1.42},{minX:bE,maxX:yE,minZ:t,maxZ:t+9.4},{minX:pm.maxX-.05,maxX:yE,minZ:38.62,maxZ:t}]}function IE(e,t,n){EE=0;let r=new U;r.name=`landing-town`,e.add(r);let i={brick:t.brickTile,stone:t.stoneTile},a=TE(),o=t.brick.clone();o.color.multiplyScalar(.55);let s=new x({color:3806996,roughness:.88}),c=pm.minZ,l=pm.maxZ,u=pm.maxX+.1;AE(a,CE([0,1],2,c),[{width:6.4,storeys:3,plain:!0},{width:5,storeys:3,shop:!0},{width:5.2,storeys:2,shop:!0,awning:!0},{width:u-18.6,storeys:3,shop:!0,awning:!0,sign:`CAFE DE LA GARE`,shopShade:2},{width:yE-u,storeys:2,plain:!0}],9.4,i),AE(a,CE([0,1],u,-1.42),[{width:yE-u,storeys:2,plain:!0}],2.2,i),AE(a,CE([0,-1],u,l),[{width:u-18.4,storeys:3,shop:!0,sign:`HOTEL TERMINUS`},{width:5.6,storeys:2,shop:!0,awning:!0},{width:4.4,storeys:3,shop:!0},{width:6.4,storeys:3,plain:!0}],9.4,i),AE(a,CE([0,-1],yE,l),[{width:yE-u,storeys:2,plain:!0}],9.4,i),AE(a,CE([0,-1],yE,38.62),[{width:yE-u,storeys:2,plain:!0}],l-38.62,i);let d=mE.endX;AE(a,CE([0,1],d,mE.minZ),[{width:7,storeys:2},{width:6.5,storeys:3},{width:6.5,storeys:2,shop:!0},{width:6.5,storeys:3,shop:!0,awning:!0},{width:6.1,storeys:2,shop:!0},{width:5.800000000000001,storeys:3,shop:!0,sign:`TABAC`}],mE.minZ-1,i),AE(a,CE([0,-1],bE,mE.maxZ),[{width:5.6,storeys:3,shop:!0},{width:6.2,storeys:2,shop:!0,awning:!0},{width:6.6,storeys:3},{width:6.5,storeys:2},{width:6.5,storeys:3},{width:7,storeys:2}],6.4,i),AE(a,CE([1,0],d,23.5),[{width:22.5,storeys:3}],8,i),AE(a,CE([1,0],bE,mE.minZ),[{width:4.6,storeys:3,mass:!1,shop:!0,sign:`PHARMACY`,shopShade:2},{width:mE.minZ-1-4.6,storeys:3,mass:!1,shop:!0,awning:!0,sign:`BARBER`},{width:1-c,storeys:2,shop:!0,sign:`IRONMONGER`}],6.4,i),AE(a,CE([1,0],bE,l),[{width:5.6,storeys:2,shop:!0,awning:!0,sign:`CAFÉ`,shopShade:1},{width:6.1,storeys:3,shop:!0,sign:`POST OFFICE`},{width:l-mE.maxZ-5.6-6.1-6.4,storeys:2,shop:!0,awning:!0,sign:`BAKERY`},{width:6.4,storeys:3,mass:!1,shop:!0,sign:`TAILOR`}],6.4,i),jE(r,a,t,n,i);let f=__(r,g_(a.brick),o,{castShadow:!0,receiveShadow:!0,name:`landing-town-brick`},n);__(r,g_(a.trim),t.stoneTrim,{receiveShadow:!0,name:`landing-town-trim`},n),__(r,g_(a.stone),t.stone,{receiveShadow:!0,name:`landing-town-stone`},n),__(r,g_(a.wood),t.wood,{name:`landing-town-shopfronts`},n),__(r,g_(a.awning),s,{name:`landing-town-awnings`},n),a.glass.forEach((e,i)=>{e.length&&__(r,g_(e),t.glass[i],{name:`landing-town-shop-glass-${i}`},n)}),sT(r,a.openings,t,n);for(let e of a.signs){let t=Th({text:e.text,background:921612,foreground:14202982,width:1024,height:160,emissiveIntensity:.42});__(r,e.geometry,t,{name:`landing-town-sign`},n)}pE(r,ME,t,n);let p=sE(r,PE,t,n,NE);D_(r,[{x:8.43,y:4.7,z:8.85,width:2.3,height:3.4,strength:.32},{x:8.43,y:4.7,z:18.9,width:2.7,height:3.4,strength:.32}],n),r.traverse(e=>{e.userData.noCameraCollision=!0}),f.userData.noCameraCollision=!1;let m=f.raycast.bind(f);return f.raycast=(e,t)=>{r.visible&&m(e,t)},{group:r,colliders:[...FE(),...p]}}function LE(){let e=new U;e.name=`landing-station`;let t=$w(),n=b_(),r=yT(e,t,n),i=eE(e,t,n);e.traverse(e=>{e.userData.noCameraCollision=!0,e.isLight&&(e.castShadow=!1)});let a=IE(e,t,n);i.pools.setOpening(mE.minZ,mE.maxZ);let o=cm.clone();return{group:e,town:a.group,stats:n,shadowFocus:o,colliders:[...r,...i.colliders,...a.colliders],update(e){i.update(e)}}}var RE=Pv-Fv/2-.4,zE=Pv+Fv/2+.4,BE=-20,VE=[{name:`plaza`,region:`platform`,box:{minX:6,maxX:36,minZ:-10,maxZ:48},show:[`landing`]},{name:`p1`,region:`p1`,box:{...XS,minY:-6},show:[`p1`,`p2`]},{name:`p2`,region:`p2`,box:{...bC,maxY:-1.5},show:[`p1`,`p2`,`p3`]},{name:`p3`,region:`p3`,box:{...IC},show:[`p2`,`p3`,`p4`]},{name:`p4-west`,region:`p4`,box:{minX:-52,maxX:BE,minZ:RE,maxZ:zE,minY:-1},show:[`p3`,`p4`,`platform`,`train`,`landing`]},{name:`p4-east`,region:`p4`,outdoor:!0,box:{minX:BE,maxX:-4.6,minZ:RE,maxZ:zE,minY:-1},show:[`p4`,`platform`,`train`,`landing`,`outdoor`]}],HE={name:`platform`,region:`platform`,outdoor:!0,box:null,show:[`p4`,`platform`,`train`,`platform-backdrop`]},UE=.6;function WE(e,t,n=0){return!(!e||t.x<e.minX-n||t.x>e.maxX+n||t.z<e.minZ-n||t.z>e.maxZ+n||e.minY!==void 0&&t.y<e.minY-n||e.maxY!==void 0&&t.y>e.maxY+n)}function GE(e){for(let t of VE)if(WE(t.box,e))return t;return HE}function KE({dynamic:e=()=>[],onChange:t}={}){let n=new Map,r=null;function i(e,...t){n.has(e)||n.set(e,[]),n.get(e).push(...t.filter(Boolean))}function a(){let i=new Set(r.show);for(let[e,t]of n){let n=i.has(e);for(let e of t)e.visible=n}for(let t of e())t.visible=i.has(GE(t.position).region);t?.(r)}function o(e){if(!e||r&&r.box&&WE(r.box,e,UE))return;let t=GE(e);t!==r&&(r=t,a())}return{addRegion:i,update:o,refresh(){r&&a()},get zone(){return r}}}var qE=new R(0,-1,0),JE=new Ve,YE=new R;function XE(e){let{r:t,g:n,b:r}=e.color;return t>=r&&n>=t*.35&&r<=n}function ZE(e,t,n){let r=e.getWorldPosition(new R);n.set(r,qE),n.far=14;for(let e of n.intersectObject(t,!0))if(!(!e.object.isMesh||e.object.material?.transparent)&&!(!e.face||e.face.normal.clone().transformDirection(e.object.matrixWorld).y<.6)&&(JE.setFromObject(e.object).getSize(YE),!(Math.max(YE.x,YE.z)<3)))return{origin:r,y:e.point.y};return null}function QE(e,t){let n=new we,r=[];for(let{root:t,keep:i}of e){t.updateMatrixWorld(!0);let e=[],a=[];t.traverse(t=>{!t.isPointLight||t.userData.lightPoolSlot||(XE(t)?a:e).push(t)});let o=Math.max(0,i-e.length);if(a.length<=o)continue;let s=new Map(a.map(e=>[e,e.getWorldPosition(new R)])),c=a.map(e=>s.get(e).x),l=a.map(e=>s.get(e).z),u=Math.max(...c)-Math.min(...c)>=Math.max(...l)-Math.min(...l)?`x`:`z`;a.sort((e,t)=>s.get(e)[u]-s.get(t)[u]);let d=new Set;for(let e=0;e<o;e+=1)d.add(a[Math.floor((e+.5)*a.length/o)]);for(let e of a){if(d.has(e))continue;let i=ZE(e,t,n);if(i){let t=Math.max(.5,i.origin.y-i.y);r.push({x:i.origin.x,y:i.y,z:i.origin.z,radius:B.clamp(t*.9+e.distance*.12,1.4,3.8),strength:B.clamp(e.intensity/70,.08,.2)})}e.parent.remove(e)}}return O_(t,r,null,16752210,`lamp-floor-glow`)}function $E({scene:e,interaction:t,assets:n,hud:r,player:i,camera:a,respawn:o,timeSystem:s,advance:c,beginCinematic:l,renderer:u}){s?.setMode?.(`NORMAL`),s?.setAbilityAvailability?.({SLOW:!1,FREEZE:!1,REWIND:!1,GHOST:!1}),r?.setChronoVisible?.(!1),fg();let{group:d,wallColliders:f,hallDressing:m,platform:h,track:g,coverCores:_}=Qv({includePlaceholders:!1}),v=LE();v.town.visible=!1;let y=[];v.group.traverse(e=>{e.isPointLight&&y.push(e)});let b=y.length,C={count:0,max:3},w=hC({interaction:t,hud:r,player:i,respawn:o,connectedToPassage0:!1,connectedToPassage2:!0}),T=PC({scene:e,interaction:t,hud:r,player:i,respawn:o,camera:a,distractionInventory:C,connectedToPassage3:!0}),E=yw({scene:e,interaction:t,hud:r,player:i,respawn:o,camera:a,distractionInventory:C});d.add(w.group,T.group,E.group),f.push(...w.colliders,...T.colliders,...E.colliders);let D={minX:Math.min(Wv.minX,w.bounds.minX,T.bounds.minX,E.bounds.minX),maxX:Math.max(Wv.maxX,w.bounds.maxX,T.bounds.maxX,E.bounds.maxX),minZ:Math.min(Wv.minZ,w.bounds.minZ,T.bounds.minZ,E.bounds.minZ),maxZ:Math.max(Wv.maxZ,w.bounds.maxZ,T.bounds.maxZ,E.bounds.maxZ)},O=D.maxZ;D.maxX=Math.max(D.maxX,X-.2),D.maxZ=Math.max(D.maxZ,pm.maxZ-.1),f.push(...v.colliders,{minX:4.5,maxX:pm.minX+.2,minZ:-80,maxZ:80},{minX:-400,maxX:pm.minX+.05,minZ:O-.05,maxZ:90},{minX:pm.minX-.3,maxX:X+.4,minZ:-80,maxZ:pm.minZ+.05},{minX:pm.minX-.3,maxX:X+.4,minZ:pm.maxZ-.05,maxZ:90});let{train:k,boardingDoor:A,closeDoor:M,update:N}=yv(),P=fy(),te=P.find(e=>e.name===`station-sun`),F=P.find(e=>e.name===`station-sky`),ne=P.find(e=>e.name===`station-fill`),re={sky:.48,ambient:.06,environment:.4},I=new S(1183778,40,240),L=new ee(329228,.023),ie=new S(2047331,60,700),ae={color:1183778,near:50,far:260,max:.88},oe={color:329228,near:20,far:62,max:.98},se=new Set([`guard`,`guard-shielded`,`security-camera`,`laser-grid`]),ce=new Map,le=!1;function ue(){let e=[...P.spotLights];for(let t of gt.children){if(!t.isLight)continue;t.name.startsWith(`torch-pool-`)&&e.push(t);let n=t.name.match(/^light-pool-(\d+)$/);n&&Number(n[1])>=b&&e.push(t)}return e}function de(t){if(t!==le){if(le=t,t)for(let e of ue())ce.set(e,e.visible),e.visible=!1;else{for(let[e,t]of ce)e.visible=t;ce.clear()}v.town.visible=t,ge.uniforms.uGroundBlack.value=+!!t,e.environment=t?null:we?.texture??null}}let fe=P.spotLights.map(e=>e.intensity);function pe(e){let t=e.name===`platform`;ge.setPreset(t?`boarding-platform`:`boarding`,+!!t),P.spotLights.forEach((n,r)=>{n.intensity=e.outdoor&&!t?fe[r]:0}),ge.mesh.material.depthTest=!e.outdoor,ge.mesh.renderOrder=e.outdoor?-1e3:1e3;for(let t of y)t.userData.lightPoolOff=e.name!==`plaza`}let me=KE({dynamic:()=>e.children.filter(e=>se.has(e.name)),onChange:pe});function he(t){if(!t)return;let n=t.x>6&&t.x<36&&t.z>-10&&t.z<48;F&&(F.intensity=n?.1:re.sky),ne&&(ne.intensity=n?.01:re.ambient),e.environmentIntensity=n?.06:re.environment,e.fog=n?L:I,be.setFog(n?oe:ae),de(n),me.update(t),me.zone?.name===`platform`?(ie.color=ge.horizonColor,e.fog=ie,e.environment=Te?.texture??null):e.environment=n?null:we?.texture??null}let ge=aS(`boarding`),_e=0,ve=0,ye=0;function B(e,t=!0){t&&(_e+=e,be.group.visible&&(be.update(_e),_e=0)),ve+=e,v.group.visible&&(v.update(ve),ve=0),ye+=e,(k.visible||Ge)&&(N(ye),ye=0)}let be=Fx({mode:`station`,stationSpotLights:P.spotLights,fogColor:1183778,sunPosition:ry,sunColor:new q(10137552).multiplyScalar(3),skyColor:2373206,groundColor:789008,fogNear:50,fogFar:260,fogMax:.88,terrainAmbient:.88,vegAmbient:.64,skyTime:ge.timeUniform,skyUniforms:ge.uniforms,nature:cb()}),xe=ux({static:!0,speed:0,valleySide:1,offsetX:7,offsetY:.8,chunkCount:3,centerZ:0,omitHillSide:!0,rails:!1,poles:!1,fogColor:2047331,moonDirection:iy}),V=xe.group;V.visible=!1;let Se=new Je({uniforms:Ht.merge([J.fog,{uTime:ge.timeUniform,uColor:{value:new q(8560302)}}]),vertexShader:`
      varying vec2 vUv;
      #include <common>
      #include <fog_pars_vertex>
      void main() {
        vUv = uv;
        #include <begin_vertex>
        #include <project_vertex>
        #include <fog_vertex>
      }
    `,fragmentShader:`
      uniform float uTime;
      uniform vec3 uColor;
      varying vec2 vUv;
      #include <common>
      #include <fog_pars_fragment>
      float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
      float noise(vec2 p) {
        vec2 i = floor(p), f = fract(p);
        vec2 s = f * f * (3.0 - 2.0 * f);
        return mix(mix(hash(i), hash(i + vec2(1, 0)), s.x),
          mix(hash(i + vec2(0, 1)), hash(i + vec2(1, 1)), s.x), s.y);
      }
      void main() {
        vec2 edge = smoothstep(vec2(0.0), vec2(0.18), vUv)
          * smoothstep(vec2(0.0), vec2(0.18), vec2(1.0) - vUv);
        vec2 p = vUv * vec2(7.0, 3.0) + vec2(uTime * 0.016, uTime * 0.006);
        float density = smoothstep(0.28, 0.8, noise(p) * 0.7 + noise(p * 2.1) * 0.3);
        gl_FragColor = vec4(uColor, 0.12 * edge.x * edge.y * density);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
        #include <fog_fragment>
      }
    `,transparent:!0,depthWrite:!1,side:2,forceSinglePass:!0,fog:!0});Se.uniforms.uTime=ge.timeUniform;let Ce=new Ot(1,1);for(let[e,t,n,r,i]of[[65,1,0,100,260],[145,2.4,20,180,300]]){let a=new z(Ce,Se);a.name=`platform-valley-mist`,a.rotation.x=-Math.PI/2,a.scale.set(r,i,1),a.position.set(e-7,t-.8,n),a.raycast=()=>{},a.userData.noCameraCollision=!0,a.userData.noInteractionBlocker=!0,V.add(a)}V.userData.drawCalls=xe.stats.drawCalls+2,V.userData.triangles=xe.stats.triangles+4,e.add(ge.mesh,be.group,V,d,m,k,v.group,...P);let we=null,Te=null;u&&(we=cS(u,ge.mesh),ge.setPreset(`boarding-platform`),Te=cS(u,ge.mesh),ge.setPreset(`boarding`),e.environment=we.texture,e.environmentIntensity=.4);let De=t.registerBlocker(d),Oe=t.registerBlocker(k);e.background=new q(1710638),e.fog=I;let H=[];d.traverse(e=>{e.isMesh&&e.name!==`vision-cone`&&!e.userData.decor&&H.push(e)});let ke=Bw({scene:e,player:i,respawn:o,hud:r,collidables:H,obstacles:f,assets:n});w.setupStealth(ke),T.setupStealth(ke),E.setupStealth(ke);let Ae=o?.onFail?.((e,t)=>{t?.gameOver||ke.clearSuspicion()})??(()=>{}),je=gC({scene:e,player:i,camera:a,stealth:ke,hud:r,inventory:C,hearingRadius:10.5,groundHeightAt:()=>0,isEnabled:()=>!!(E.isComplete()&&i?.mesh?.position?.y>-.55&&!E.isInsidePassage())}),W=[],Me=new p(.09,.09,.26,10);Me.rotateZ(Math.PI/2);let Ne=new x({color:11570495,emissive:3810824,emissiveIntensity:.45,roughness:.28,metalness:.9});function G(e,n){let i=new U;i.name=n,i.position.copy(e);let a=new z(Me,Ne);a.position.y=.16,i.add(a),d.add(i);let o=!1,s=t.register(i,{prompt:`Pick up loose metal distractor`,range:2.2,onInteract:()=>{if(!o){if(C.count>=C.max){r?.showToast?.(`Distractor pouch full — ${C.count}/${C.max}`,1300);return}o=!0,C.count+=1,i.visible=!1,r?.showToast?.(`Distractor collected — ${C.count}/${C.max}`,1300)}}});W.push(s)}G(new R(-43.5,.02,-26.2),`distractor-pickup-p4-a`),G(new R(-14.5,.02,-22.7),`distractor-pickup-p4-b`),G(new R(.2,.02,-10),`distractor-pickup-p5-a`),G(new R(-2.8,.02,10),`distractor-pickup-p5-b`),ke.addGuard({waypoints:[new R(-37,0,-23),new R(-31,0,-26)],speed:1.45,waitTime:2,initialWaypoint:0});let Pe=ke.addLaserGrid({position:new R(Iv[1],0,-23.025),width:2.1,height:2.2,beamCount:4,rotationY:Math.PI/2}),Fe=new U;Fe.name=`west-wing-security-terminal`,Fe.position.set(-32,1.2,-22),Fe.rotation.y=Math.PI/2;let Ie=new z(new K(.35,.55,.22),new x({color:1976635,roughness:.4,metalness:.8}));Fe.add(Ie);let Le=new x({color:15680580,emissive:14427686,emissiveIntensity:2.5,roughness:.2}),Re=new z(new K(.04,.28,.16),Le);Re.position.set(.18,.05,0),Fe.add(Re);let ze=new j(15680580,3,3);ze.position.set(.3,.05,0),Fe.add(ze),d.add(Fe);let Be=!1,He=t.register(Fe,{prompt:`Deactivate West Wing Laser Grid`,onInteract:()=>{Be||(Be=!0,Pe.setActive(!1),Le.color.setHex(1096065),Le.emissive.setHex(366185),ze.color.setHex(1096065),t.flashPrompt(`West Wing Security Grid Deactivated!`),r&&r.showToast(`Laser grid offline — Gate 2 is clear`,2200))}});ke.addGuard({waypoints:[new R(-27,0,-26),new R(-20,0,-23)],speed:1.55,waitTime:1.7,initialWaypoint:1}),ke.addGuard({waypoints:[new R(-16,0,-23),new R(-8,0,-26)],speed:1.7,waitTime:1.5,initialWaypoint:0}),ke.addCamera({position:new R(-10.5,4.6,-21.95),baseAngle:Math.PI,sweepRange:Math.PI/3.6,sweepSpeed:.9,range:8});let Ue=[{id:`platform-rear`,start:-16,end:0,speed:1.25,waitTime:3,initialWaypoint:0,delay:0},{id:`platform-middle`,start:7,end:23,speed:1.35,waitTime:3.5,initialWaypoint:1,delay:0},{id:`platform-front`,start:30,end:39,speed:1.2,waitTime:4,initialWaypoint:0,delay:3}],We=Ue.map(e=>{let t=ke.addGuard({waypoints:[new R(0,0,e.start),new R(0,0,e.end)],speed:e.speed,waitTime:e.waitTime,initialWaypoint:e.initialWaypoint});return t.group.userData.patrolId=e.id,t.facing=e.initialWaypoint===0?0:Math.PI,t.scanBase=t.facing,t.group.rotation.y=t.facing,t.waitTimer=e.delay,t}),Ge=!1,Ke=0,qe=t.register(A,{prompt:`Sneak aboard`,onInteract:()=>{Ge||(Ge=!0,M(),l?.(),t.flashPrompt(`Boarding the Chrono Express…`),r&&r.setObjective(`Departing station… hold on!`))}}),Ye=[`Infiltrate the west gallery — use luggage and benches as cover`,`Baggage passage — find a way through the security laser`,`Security hall — stay behind cover and avoid the patrol`,`Final approach — reach the station junction`],Xe=-1,Ze=[`Reach the front carriage — use luggage as cover`,`Keep low and watch the patrols`,`The front carriage door is ahead — sneak aboard`],Qe=-1,$e=!1,et=new R(Lv.x,0,Lv.z),tt=!1,nt=w.spawn.clone(),rt=T.entryCheckpoint.clone(),it=!1,at=E.entryCheckpoint.clone(),ot=!1,st=E.exitCheckpoint.clone(),ct=!1,lt=new Set([w.group,T.group,E.group]),ut=new U;ut.name=`station-hall-region`;let dt=new U;dt.name=`station-platform-region`;let ft=new Ve,pt=new R;d.updateMatrixWorld(!0);for(let e of[...d.children]){if(lt.has(e))continue;ft.setFromObject(e);let t=ft.isEmpty()?e.position.x:ft.getCenter(pt).x;(e.userData.platformRegion||t>=-5?dt:ut).add(e)}d.add(ut,dt);let mt=new U;mt.name=`lamp-floor-glows`,e.add(mt);let ht=[{root:w.group,keep:3,pools:new U},{root:T.group,keep:2,pools:new U},{root:E.group,keep:2,pools:new U},{root:ut,keep:3,pools:new U},{root:dt,keep:3,pools:new U}];for(let e of ht)QE([e],e.pools),mt.add(e.pools);me.addRegion(`p1`,w.group,ht[0].pools),me.addRegion(`p2`,T.group,ht[1].pools),me.addRegion(`p3`,E.group,ht[2].pools),me.addRegion(`p4`,ut,m,ht[3].pools),me.addRegion(`platform`,dt,ht[4].pools),me.addRegion(`train`,k),me.addRegion(`landing`,v.group),me.addRegion(`outdoor`,be.group),me.addRegion(`platform-backdrop`,V);let gt=new U;gt.name=`boarding-light-pools`,e.add(gt);let _t=Ww({roots:[d,k,v.group],host:gt,size:8}),vt=Ww({root:e,host:gt,size:4,accept:e=>e.name===`torch-spot`,name:`torch-pool`,kind:`spot`}),yt=document.createElement(`div`);Object.assign(yt.style,{position:`fixed`,inset:`0`,background:`#000`,opacity:`0`,pointerEvents:`none`,zIndex:`40`}),document.body.appendChild(yt);let bt=new Ee;bt.name=`landing-door`,bt.position.set(X-3.05,1.15,nm),v.group.add(bt);let xt=!1,St=!1,Ct=null;function wt(){xt=!0,i.setPose(nt,Math.PI/2),a?.setYaw?.(Math.PI/2),a?.setPitch?.(.25),a?.snap?.(),o.setCheckpoint(nt.clone(),Math.PI/2,{restore:()=>ke.reset()}),r?.setObjective(`Infiltrate all three security passageways, then rejoin the station route to the Chrono Express`)}function Tt(e){if(!Ct)return;Ct.t+=e;let t=Math.min(1,Ct.t/.6);Ct.phase===`out`?(yt.style.opacity=String(t),t>=1&&(wt(),Ct={t:0,phase:`in`})):(yt.style.opacity=String(1-t),t>=1&&(yt.style.opacity=`0`,Ct=null,St=!1))}let Et=t.register(bt,{prompt:`Enter the station`,range:2.7,onInteract(){xt||Ct||(St=!0,Ct={t:0,phase:`out`},l?.())}});return{objective:`Enter the station`,checkpoint:{position:new R(lm.x,lm.y,lm.z),yaw:lm.yaw,pitch:lm.pitch,restore:()=>ke.reset()},bounds:D,obstacles:f,groundHeightAt(e,t,n=0){if(e>=pm.minX-.4&&e<=23.4+.4&&t>=pm.minZ-.4&&t<=pm.maxZ+.4)return pm.y;let r=E.getGroundHeight(e,t,NaN);if(Number.isFinite(r))return r;let i=T.getGroundHeight(e,t,NaN);if(Number.isFinite(i))return i;let a=w.getGroundHeight(e,t,NaN);return Number.isFinite(a)?a:n},handleAction(e){return E.handleAction(e)||T.handleAction(e)?!0:e===`distract`&&je.throw()},getGuards:()=>ke.getGuards(),updateAtmosphere(e,t){ge.update(e,null),t&&(he(t),dy(te,v.shadowFocus,me.zone?.name===`platform`?ge.uniforms.uMoonDirection.value:ry),_t.update(t,e)),B(e,!1)},get isCinematic(){return Ge||St},update(e){if(Tt(e),he(i.mesh.position),ge.update(e,s),dy(te,i.mesh.position,me.zone?.name===`platform`?ge.uniforms.uMoonDirection.value:ry),B(e),w.update(e),T.update(e),E.update(e),je.update(e),!it&&T.isInsidePassage()&&(it=!0,o.setCheckpoint(rt,Math.PI/2),r?.showToast?.(`Checkpoint reached — lower security passage`,2100)),!ot&&E.hasClearedVent()&&(ot=!0,o.setCheckpoint(at,Math.PI),r?.showToast?.(`Checkpoint reached — Passageway 3 maintenance level`,2200)),!ct&&E.hasReachedExit()&&(ct=!0,o.setCheckpoint(st,Math.PI/2),r?.showToast?.(`Checkpoint reached — Passageway 4 approach`,2200)),!tt&&!$e){if(E.isComplete()&&i.mesh.position.y>-.15&&i.mesh.position.x>=-52.15&&Math.abs(i.mesh.position.z- -24.5)<=3){let e=Iv.filter(e=>i.mesh.position.x>e).length;e!==Xe&&(Xe=e,r&&r.showToast(Ye[Xe],2200))}let e=Math.hypot(i.mesh.position.x-Lv.x,i.mesh.position.z-Lv.z);E.isComplete()&&i.mesh.position.y>-1&&e<1.4&&(tt=!0,o.setCheckpoint(et,0,{restore:()=>ke.reset()}),r&&r.showToast(`Checkpoint reached — station concourse infiltrated`,2400))}let t=i.mesh.position;if(t.y>-.15&&t.x>-4.8&&t.x<4.5&&t.z>-28&&t.z<62&&!Ge){let e=t.z>34?2:+(t.z>8);e!==Qe&&(Qe=e,r&&r.showToast(Ze[Qe],2200),r?.setObjective(`Reach the open door on the front carriage — Sneak aboard`)),!$e&&t.z>=6&&($e=!0,o.setCheckpoint(new R(4.1,0,6),0,{restore:()=>{ke.reset(),We.forEach((e,t)=>{let n=Ue[t];e.group.position.copy(e.waypoints[n.initialWaypoint]),e.targetIdx=1-n.initialWaypoint,e.facing=n.initialWaypoint===0?0:Math.PI,e.scanBase=e.facing,e.group.rotation.y=e.facing,e.waitTimer=n.delay})}}),r?.showToast(`Checkpoint reached — platform luggage shelter`,2400))}if(Ge){Ke+=e,k.position.z+=Ke*6.5*e,_t.update(i.mesh.position,e),vt.update(i.mesh.position,e),Ke>=2.4&&(Ge=!1,c());return}ke.update(e),_t.update(i.mesh.position,e),vt.update(i.mesh.position,e)},dispose(){Ae(),De(),Oe(),He(),qe(),Et(),yt.remove(),w.dispose(),T.dispose(),E.dispose(),W.forEach(e=>e()),je.dispose(),ke.dispose(),be.dispose(),xe.dispose(),ge.dispose(),we&&=((e.environment===we.texture||e.environment===Te?.texture||le)&&(e.environment=null,e.environmentIntensity=1),we.dispose(),null),Te?.dispose(),Te=null,e.remove(ge.mesh,be.group,V,d,m,k,v.group,...P,gt,mt),Jd([d,m,k,v.group,...P,gt,mt])}}}function eD(){return{objective:``,checkpoint:{position:new R(0,0,0),yaw:0},dispose(){}}}180/Math.PI,Math.PI/180,Math.PI/2,new q(6975352);var tD=document.querySelector(`#app`),{renderer:nD,setScene:rD}=La(tD),iD=$a(nD),aD=(()=>{let e=[1,.85,.7],t={high:1,balanced:.85,performance:.7},n=0,r=null,i=0,a=0,o=0,s=0,c=0;function l(){Y.setRuntimeRenderScale(r??t[Y.get(`renderQuality`)]??e[n])}return Y.subscribe((e,t)=>{(t===`renderQuality`||t===`options`||t===`all`)&&(n=0,o=0,s=0,a=0,i=0,l())}),l(),{update(e){let t=i?e-i:0;if(i=e,!t||t>250||document.hidden||r!==null||Y.get(`renderQuality`)!==`auto`){o=0,s=0;return}a=a?a+(t-a)*(1-Math.exp(-t/500)):t,!(e<c)&&(o=a>33?o+t:0,s=a<22?s+t:0,(o>=2e3&&n<2||s>=4e3&&n>0)&&(n+=o>=2e3?1:-1,o=0,s=0,c=e+2e3,l()))},getScale:()=>Y.get(`renderScale`),setOverride(e){r=e,i=0,a=0,o=0,s=0,l()}}})(),oD=eo();rD(oD);var{camera:sD}=to(),cD=no(),lD=Dc(),uD=Zf(),dD=Oc([`detective`,`police`,`backdrop`,`presentation`]),fD=Qp(lD,{tasks:dD}),pD=su();oD.add(pD.mesh);var mD=dD.track(`detective`,pD.loadVisual(lD)),hD=dD.track(`police`,Mu(lD)),gD=Promise.all([mD,hD]);gD.catch(()=>{});var _D=Zp({scene:oD,hudRoot:uD.root,mainCamera:sD,player:pD,getObstacles:()=>PD.obstacles,getGuards:()=>PD.guards,getLevelState:()=>PD.getState(),getCarriageVolumes:()=>PD.carriageVolumes}),vD=Lu(),yD=Vu(document.documentElement),bD=Od({camera:sD,domElement:nD.domElement,player:pD,hud:uD}),xD={Boarding:{file:`../assets/audio/music/level1-constance.mp3`,loop:!0},MovingHeist:{file:`../assets/audio/music/level2-mistake-the-getaway.mp3`,loop:!0},Timewreck:{file:`../assets/audio/music/level3-final-count.mp3`,loop:!0},Complete:{file:`../assets/audio/music/victory-theme.mp3`,loop:!1}},SD=null;function CD(){return SD||(Lc()?(SD=new Yf,SD.setTimeDilation(1),SD):null)}function wD(){SD&&=(SD.dispose(),null)}function TD(e){let t=xD[e];if(console.log(`[music ${new Date().toISOString()} t=${performance.now().toFixed(1)}] playMusicForState("${e}") drone=${SD?`#`+SD.id:`none`} spec=${t?t.file:`none`}`),!t){jf(),wD();return}e===`Complete`?wD():CD(),Mf(yf(t.file),{loop:t.loop})}async function ED(){console.log(`playMenuMusic called`),await Mf(yf(`../assets/audio/music/menu-theme.mp3`),{loop:!0}),console.log(`playMenuMusic: startLevelMusic() resolved`)}function DD(){console.log(`unlockAudio() called`),Ic();let e=Jc();e&&typeof e.then==`function`&&e.then(()=>{console.log(`[ability-sfx] unlockAudio preload settled before/during menu`)});let t=Lc();console.log(`unlockAudio context before resume: `+(t?t.state:`none`));let n=zc();console.log(`unlockAudio resumeAudio() returned:`,n);let r=async()=>{console.log(`startMenu called, gameStarted: `+ID),!ID&&await ED()},i=()=>{console.log(`unlockAudio: calling startMenu()`);let e=r();if(e&&typeof e.then==`function`)return e.then(()=>{console.log(`unlockAudio: startMenu() finished`)});console.log(`unlockAudio: startMenu() finished`)};n&&typeof n.then==`function`?n.then(i):i()}var OD=[`click`,`keydown`,`touchstart`];function kD(){for(let e of OD)document.removeEventListener(e,kD,!0);DD()}for(let e of OD)document.addEventListener(e,kD,{once:!0,capture:!0});tD.addEventListener(`click`,()=>{console.log(`Canvas clicked, attempting audio resume`),DD()}),console.log(`Audio click listener attached to: `+tD.tagName);var AD=Hd({camera:sD,input:vD}),jD=_f({scene:oD,player:pD,hud:uD,onTimeScale(e){SD&&SD.setTimeDilation(e)}}),MD=qd({player:pD,hud:uD,camera:bD,timeSystem:jD,onStateChange:()=>JD()});vD.onAction(`slow`,()=>jD.triggerSlow()),vD.onAction(`freeze`,()=>jD.triggerFreeze()),vD.onAction(`rewind`,()=>jD.triggerRewind()),vD.onAction(`ghost`,()=>jD.triggerGhost()),vD.onAction(`restart`,()=>{ID&&!WD.isOpen&&(MD.resetLives(),PD.restart())}),vD.onAction(`distract`,()=>{ID&&PD.handleAction(`distract`)}),vD.onAction(`toggleView`,()=>bD.toggle());var ND=0;MD.onFail(()=>{ND+=1});var PD=Ac({scene:oD,interaction:AD,assets:lD,hud:uD,player:pD,camera:bD,respawn:MD,renderer:nD,timeSystem:jD,loadingScreen:fD,onEnter:e=>{TD(e),VD?.sceneChanged?.(),e===`Complete`?XD():jD.warmGhost(nD,sD);let t=e===`Boarding`?`MovingHeist`:e===`MovingHeist`?`Timewreck`:null;t&&requestAnimationFrame(()=>requestAnimationFrame(()=>{PD.getState()===e&&PD.prefetch(t)}))},onLeave:jf,onInputStateChange:()=>JD(),levels:[{state:`Boarding`,create:$E},{state:`MovingHeist`,load:()=>Ec(async()=>{let{createMovingHeistLevel:e}=await import(`./moving-heist-C5spllfr.js`);return{createMovingHeistLevel:e}},__vite__mapDeps([2,1,3]),import.meta.url).then(({createMovingHeistLevel:e})=>t=>e({...t,post:iD}))},{state:`Timewreck`,load:()=>Ec(()=>import(`./timewreck-DcpguXFS.js`).then(e=>e.createTimewreckLevel),__vite__mapDeps([4,1,3]),import.meta.url)},{state:`Complete`,create:eD,keepPrevious:!0}]}),FD=null,ID=!1,LD=null,RD=!1,zD=0,BD=null,VD=null;uD.onTutorialStateChange(e=>{let t=ID&&!RD&&!e;vD.setEnabled(t),AD.setEnabled(t),bD.setEnabled(t)}),uD.setVisible(!1),bD.setEnabled(!1),vD.setEnabled(!1);async function HD(){await lb();let e={scene:oD,interaction:AD,assets:lD,hud:uD,timeSystem:jD,renderer:nD,player:pD,camera:bD,respawn:MD,advance:()=>PD.advance(),beginCinematic(){MD.cancel(),JD()}};AD.setEnabled(!1);let t=$E(e);return t.checkpoint&&pD.setPose(t.checkpoint.position,t.checkpoint.yaw),t}var UD=Im(),WD=Xm({onDismiss:e=>{e===`complete`&&aO()}}),GD=Mm({camera:sD,player:pD,renderer:nD,settingsMenu:UD,unlockAudio:DD,onCredits:()=>WD.open({source:`menu`}),isCreditsOpen:()=>WD.isOpen}),KD=Bm({settingsMenu:UD,canPause:()=>ID&&!WD.isOpen&&!0,getStatus:()=>({level:PD.getState(),objective:uD.getObjective(),elapsed:zD,energy:jD.getEnergy(),maxEnergy:jD.getMaxEnergy(),suspicion:uD.getSuspicion(),timeMode:jD.getMode(),lives:MD.getLives(),maxLives:MD.getMaxLives(),resets:ND}),onPause:()=>YD(!0),onResume:()=>YD(!1),onRestart:()=>{ND=0,zD=0,MD.resetLives(),jD.resetRun?.(),PD.restart(),YD(!1)},onQuit:()=>aO()});function qD(){return jc({gameStarted:ID,creditsOpen:WD.isOpen,paused:RD,transitioning:PD.isTransitioning(),caught:MD.isFailing(),cinematic:PD.isCinematic()||!!LD,editor:!1})}function JD(){let e=qD();PD.setPresentationPaused(e!==`PLAYING`&&e!==`CINEMATIC`);let t=e===`PLAYING`&&!0;vD.setEnabled(t),AD.setEnabled(t),bD.setEnabled(t)}function YD(e){RD!==e&&(RD=e,MD.setPaused(e),JD(),e?(KD.open(),yD.release({exitFullscreen:!1})):ID&&(yD.engage(),qD()===`PLAYING`&&bD.requestLock()))}bD.onLockLost(()=>{qD()===`PLAYING`&&!UD.isOpen&&YD(!0)});function XD(){WD.open({source:`complete`,completionTime:zD}),uD.setVisible(!1),JD(),yD.release({exitFullscreen:!1})}var ZD=um.pivotHeight,QD=lm.pitch,$D=new R(0,1,0),eO=new h;function tO(){let e=lm.yaw,t=Math.min(Y.get(`cameraDistance`),um.maxDistance),r=new R(lm.x,lm.y+ZD,lm.z),i=Math.cos(QD),a=new R(r.x-Math.sin(e)*i*t,r.y+Math.sin(QD)*t,r.z-Math.cos(e)*i*t);eO.lookAt(a,r,$D),LD={t:0,duration:2,yaw:e,pitch:QD,startPos:sD.position.clone(),endPos:a,startQuat:sD.quaternion.clone(),endQuat:new n().setFromRotationMatrix(eO)}}function nO(e){LD.t+=e;let t=Math.min(1,LD.t/LD.duration),n=t<.5?4*t*t*t:1-(-2*t+2)**3/2;return sD.position.lerpVectors(LD.startPos,LD.endPos,n),sD.quaternion.copy(LD.startQuat).slerp(LD.endQuat,n),t<1?!1:(bD.setYaw(LD.yaw),bD.setPitch(LD.pitch),bD.snap(),LD=null,!0)}function rO(){MD.reset(),jD.resetForRun(),ID=!0,RD=!1,zD=0,ND=0,MD.resetLives(),jD.resetRun?.(),bD.reset(),uD.resetRunTimer(),uD.setVisible(!0),yD.engage();let e=iO();if(e){BD&&=(BD.dispose(),null),PD.enter(e.state,{levelOptions:e.levelOptions});return}if(BD){let e=BD;BD=null,PD.adopt(`Boarding`,e),tO();return}PD.enter(`Boarding`)}function iO(){return null}async function aO(){ID=!1,RD=!1,zD=0,ND=0,PD.unload(),JD(),yD.release(),bD.reset(),uD.setVisible(!1),uD.setSuspicion(0),uD.setObjective(``),uD.resetRunTimer(),BD=await HD(),wD(),GD.show(),DD()}requestAnimationFrame(()=>requestAnimationFrame(async()=>{try{BD=await dD.track(`backdrop`,HD()),jD.warmGhost(nD,sD),await gD,requestAnimationFrame(()=>{dD.complete(`presentation`),fD.hide(),GD.show()}),GD.onStart(rO)}catch(e){dD.fail(),console.error(`[startup] required preparation failed`,e)}}));var oO=io({renderer:nD,scene:oD,camera:sD,clock:cD,instrumentation:FD,render(e,t){iD.render(e,t)},afterRender:e=>{let t=ID&&!WD.isOpen;_D.setVisible(t),t&&_D.render(e)}});oO.add(e=>{if(aD.update(performance.now()),pD.updateVisual(e),uD.updateStats(e),WD.isOpen)return;if(!ID){GD.updateCinematicCamera(e),BD?.updateAtmosphere?.(e,sD.position);return}if(uD.isTutorialOpen())return;JD();let t=qD();if(t===`PAUSED`||t===`TRANSITION`||t===`CAUGHT`)return;let n=PD.getState()===`Complete`;if(n||(zD+=e),uD.updateRunTimer({elapsed:zD,delta:e,mode:jD.getMode(),ghostActive:jD.getGhost().isPlaying(),running:!n}),jD.update(e),PD.update(e),!uD.isTutorialOpen()){if(LD&&!nO(e)){JD();return}if(qD()!==`PLAYING`){JD();return}pD.update(e,{keyboard:vD.state,crouchPressed:vD.consumePress(`duck`),runPressed:vD.consumePress(`run`),cameraYaw:bD.getYaw(),bounds:PD.bounds,obstacles:PD.obstacles,groundHeightAt:PD.groundHeightAt,supports:PD.supports,voids:PD.voids}),bD.update(e,pD.mesh,oD,{crouching:pD.isCrouching()}),AD.update(pD.mesh,bD.getYaw()),MD.update(),uD.updateTimeState({mode:jD.getMode(),energy:jD.getEnergy(),maxEnergy:jD.getMaxEnergy(),ghostCooldown:jD.getGhostCooldown(),hasGhost:jD.getGhost().isPlaying(),available:jD.getAbilityAvailability(),strain:jD.getStrain(),maxStrain:jD.getMaxStrain(),strainEnabled:jD.isStrainEnabled(),freezeLockout:jD.getFreezeLockout()})}}),oO.start();export{Ip as A,ja as B,xp as C,mp as D,pp as E,Cp as F,Jd as I,Lc as L,Dp as M,wp as N,Fp as O,_p as P,Rc as R,bp as S,vp as T,Y as V,gp as _,Fx as a,Ep as b,wh as c,_h as d,Sp as f,hp as g,Np as h,aS as i,Hp as j,Ap as k,Ch as l,Pp as m,Bw as n,yh as o,jp as p,pS as r,bh as s,Ww as t,Th as u,Mp as v,yp as w,kp as x,Tp as y,ao as z};